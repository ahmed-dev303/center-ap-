import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    target: ['es2015', 'chrome60', 'safari11'],
  },
  optimizeDeps: {
    include: ['xlsx'],
    exclude: ['lucide-react'],
  },
});
