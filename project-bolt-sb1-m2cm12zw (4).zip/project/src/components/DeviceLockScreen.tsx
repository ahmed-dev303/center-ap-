import { useState } from 'react';
import { Lock, Smartphone, Hash, ShieldCheck, KeyRound, GraduationCap } from 'lucide-react';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Modal } from './ui/Modal';
import { useAuth } from '../context/AuthContext';
import { useFiveClickGesture } from '../hooks/useFiveClickGesture';
import { getThisDeviceId, buildTrialWhatsAppMessage, applyOfflineActivationKey, getThisDeviceLicenseType, isTrialExpired } from '../lib/master';
import { openWhatsApp } from '../lib/whatsapp';
import { useToast } from '../context/ToastContext';

export function DeviceLockScreen() {
  const { loginMaster } = useAuth();
  const { showToast } = useToast();
  const [masterModalOpen, setMasterModalOpen] = useState(false);
  const [masterPin, setMasterPin] = useState('');
  const [masterError, setMasterError] = useState('');
  const [offlineKey, setOfflineKey] = useState('');
  const [keyError, setKeyError] = useState('');

  const deviceId = getThisDeviceId();
  const trialExpired = isTrialExpired();
  const isTrial = getThisDeviceLicenseType() === 'trial';

  const handleLogoClicks = useFiveClickGesture(() => setMasterModalOpen(true));

  const handleSendWhatsApp = () => {
    const msg = buildTrialWhatsAppMessage(deviceId);
    openWhatsApp('', msg);
  };

  const handleMasterLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setMasterError('');
    const ok = loginMaster(masterPin);
    if (!ok) {
      setMasterError('الكود السري غير صحيح');
      setMasterPin('');
    }
  };

  const handleActivateKey = (e: React.FormEvent) => {
    e.preventDefault();
    setKeyError('');
    const ok = applyOfflineActivationKey(offlineKey);
    if (ok) {
      showToast('تم تفعيل التطبيق بنجاح! 🚀');
      setOfflineKey('');
      window.location.reload();
    } else {
      setKeyError('كود التفعيل غير صحيح');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden bg-brand-950">
      <div className="absolute -top-32 -right-32 h-80 w-80 rounded-full bg-rose-600/20 blur-3xl" />
      <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-amber-600/15 blur-3xl" />

      <div className="relative w-full max-w-md animate-scale-in">
        <div className="text-center mb-8">
          <div
            className="inline-grid place-items-center h-20 w-20 rounded-3xl bg-gradient-to-br from-slate-800 to-slate-950 shadow-lg mb-4 cursor-pointer select-none"
            onClick={handleLogoClicks}
            title="—"
          >
            <GraduationCap size={40} className="text-amber-400" />
          </div>
        </div>

        <div className="glass rounded-3xl shadow-glass p-6 sm:p-8 text-center space-y-5">
          <div className="grid place-items-center h-20 w-20 mx-auto rounded-3xl bg-gradient-to-br from-rose-600 to-rose-900 shadow-lg">
            <Lock size={40} className="text-white" />
          </div>

          <div>
            <h1 className="text-xl font-extrabold text-white mb-2">
              {trialExpired && isTrial
                ? 'انتهت الفترة التجريبية المجانية!'
                : 'عفواً، هذا الجهاز غير مصرح له بالدخول'}
            </h1>
            <p className="text-sm text-brand-200 font-semibold">
              {trialExpired && isTrial
                ? 'يرجى التواصل مع المالك للحصول على التفعيل الكامل 🔒'
                : 'يرجى الحصول على إذن المالك للتفعيل'}
            </p>
          </div>

          <div className="rounded-2xl bg-white/10 border border-white/20 p-4 space-y-2">
            <div className="flex items-center justify-center gap-2 text-brand-200">
              <Hash size={14} />
              <span className="text-xs font-semibold">رمز الجهاز (Device ID)</span>
            </div>
            <code className="block text-sm font-mono text-amber-300 break-all select-all bg-black/30 rounded-xl py-2 px-3">
              {deviceId}
            </code>
          </div>

          <Button onClick={handleSendWhatsApp} variant="success" size="lg" className="w-full">
            <Smartphone size={20} />
            طلب التفعيل عبر WhatsApp
          </Button>

          <form onSubmit={handleActivateKey} className="space-y-3 pt-2 border-t border-white/20">
            <p className="text-xs text-brand-300 font-semibold text-center">
              أدخل كود التفعيل 🔑
            </p>
            <Input
              label="كود التفعيل"
              icon={<KeyRound size={18} />}
              placeholder="XXXXXXXX"
              value={offlineKey}
              onChange={(e) => setOfflineKey(e.target.value)}
              className="bg-white/90"
              required
            />
            {keyError && (
              <div className="animate-fade-in rounded-2xl bg-rose-500/20 border border-rose-400/40 px-4 py-2.5 text-sm font-semibold text-rose-300">
                {keyError}
              </div>
            )}
            <Button type="submit" variant="primary" size="md" className="w-full">
              <KeyRound size={16} />
              تفعيل الجهاز
            </Button>
          </form>
        </div>

        <p className="text-center text-xs text-brand-400 mt-6">
          © 2026 سنتر الأفضل — جميع الحقوق محفوظة
        </p>
      </div>

      <Modal open={masterModalOpen} onClose={() => { setMasterModalOpen(false); setMasterPin(''); setMasterError(''); }} title="أدخل رمز المالك الفائق" size="sm">
        <form onSubmit={handleMasterLogin} className="space-y-4">
          <div className="flex flex-col items-center gap-3 py-2">
            <div className="grid place-items-center h-16 w-16 rounded-3xl bg-gradient-to-br from-slate-800 to-slate-950 shadow-lg">
              <ShieldCheck size={32} className="text-amber-400" />
            </div>
            <p className="text-sm text-center text-brand-500 font-semibold">
              أدخل الكود السري للمالك للوصول إلى لوحة تحكم الأجهزة والتراخيص
            </p>
          </div>
          <Input
            label="الكود السري"
            icon={<KeyRound size={18} />}
            type="password"
            placeholder="••••••"
            value={masterPin}
            onChange={(e) => setMasterPin(e.target.value)}
            autoFocus
            required
          />
          {masterError && (
            <div className="animate-fade-in rounded-2xl bg-rose-50 border border-rose-200 px-4 py-2.5 text-sm font-semibold text-rose-600">
              {masterError}
            </div>
          )}
          <Button type="submit" size="lg" className="w-full">
            <ShieldCheck size={20} />
            دخول المالك الفائق
          </Button>
        </form>
      </Modal>
    </div>
  );
}
