import { useState, useEffect } from 'react';
import { Lock, ShieldX, Smartphone, KeyRound, AlertTriangle, Clock, Hash } from 'lucide-react';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { useToast } from '../context/ToastContext';
import {
  getThisDeviceId,
  getLicenseState,
  shouldLockApp,
  applyOfflineActivationKey,
  buildTrialWhatsAppMessage,
  getTrialDaysElapsed,
  getActionCount,
  loadTrialSettings,
  getThisDeviceLicenseType,
} from '../lib/master';
import { openWhatsApp } from '../lib/whatsapp';

interface LicenseGuardProps {
  role?: string;
  children: React.ReactNode;
}

export function LicenseGuard({ role, children }: LicenseGuardProps) {
  const { showToast } = useToast();
  const [locked, setLocked] = useState(false);
  const [lockReason, setLockReason] = useState<'expired' | 'blocked'>('expired');
  const [isTrialMode, setIsTrialMode] = useState(false);
  const [offlineKey, setOfflineKey] = useState('');
  const [keyError, setKeyError] = useState('');
  const [deviceId, setDeviceId] = useState('');
  const [trialInfo, setTrialInfo] = useState({ daysLeft: 0, actionsLeft: 0, daysElapsed: 0, actionsUsed: 0 });

  useEffect(() => {
    setDeviceId(getThisDeviceId());
    const settings = loadTrialSettings();
    const daysElapsed = getTrialDaysElapsed();
    const actionsUsed = getActionCount();
    setTrialInfo({
      daysLeft: Math.max(0, settings.trialDays - daysElapsed),
      actionsLeft: Math.max(0, settings.maxTrialActions - actionsUsed),
      daysElapsed,
      actionsUsed,
    });
  }, [locked]);

  useEffect(() => {
    const check = () => {
      if (shouldLockApp(role)) {
        setLocked(true);
        const state = getLicenseState(role);
        setLockReason(state === 'blocked' ? 'blocked' : 'expired');
        setIsTrialMode(getThisDeviceLicenseType() === 'trial');
      } else {
        setLocked(false);
      }
    };
    check();
    const interval = setInterval(check, 5000);
    return () => clearInterval(interval);
  }, [role]);

  const handleSendWhatsApp = () => {
    const msg = buildTrialWhatsAppMessage(deviceId);
    openWhatsApp('', msg);
  };

  const handleActivateKey = (e: React.FormEvent) => {
    e.preventDefault();
    setKeyError('');
    const ok = applyOfflineActivationKey(offlineKey);
    if (ok) {
      showToast('تم تفعيل الجهاز بنجاح! جاري الدخول...');
      setOfflineKey('');
      setLocked(false);
    } else {
      setKeyError('كود التفعيل غير صحيح');
    }
  };

  if (!locked) return <>{children}</>;

  const isBlocked = lockReason === 'blocked';

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-brand-950/95 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-md">
        <div className="glass rounded-3xl shadow-glass p-6 sm:p-8 text-center space-y-5">
          {/* Lock icon */}
          <div className={`grid place-items-center h-20 w-20 mx-auto rounded-3xl shadow-lg ${
            isBlocked ? 'bg-gradient-to-br from-rose-600 to-rose-900' : 'bg-gradient-to-br from-amber-500 to-amber-700'
          }`}>
            {isBlocked ? <ShieldX size={40} className="text-white" /> : <Lock size={40} className="text-white" />}
          </div>

          {/* Title + message */}
          <div>
            <h1 className="text-xl font-extrabold text-white mb-2">
              {isBlocked ? 'تم حظر هذا الجهاز' : 'انتهت الفترة التجريبية'}
            </h1>
            <p className="text-sm text-brand-200 font-semibold">
              {isBlocked
                ? 'تم حظر هذا الجهاز من قبل مالك النظام. تواصل مع المالك للمزيد من المعلومات.'
                : isTrialMode
                  ? 'انتهت الفترة التجريبية المجانية! يرجى التواصل مع المالك للحصول على التفعيل الكامل 🔒'
                  : 'هذا الجهاز يحتاج موافقة المالك 🔒'}
            </p>
          </div>

          {/* Device ID display */}
          <div className="rounded-2xl bg-white/10 border border-white/20 p-4 space-y-2">
            <div className="flex items-center justify-center gap-2 text-brand-200">
              <Hash size={14} />
              <span className="text-xs font-semibold">رمز الجهاز (Device ID)</span>
            </div>
            <code className="block text-sm font-mono text-amber-300 break-all select-all bg-black/30 rounded-xl py-2 px-3">
              {deviceId}
            </code>
          </div>

          {/* Trial stats (only if expired, not blocked) */}
          {!isBlocked && (
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-xl bg-white/5 p-3">
                <div className="flex items-center justify-center gap-1.5 text-brand-300 mb-1">
                  <Clock size={12} />
                  <span className="text-[10px] font-bold">الأيام المنقضية</span>
                </div>
                <p className="text-lg font-extrabold text-amber-300">{trialInfo.daysElapsed}</p>
              </div>
              <div className="rounded-xl bg-white/5 p-3">
                <div className="flex items-center justify-center gap-1.5 text-brand-300 mb-1">
                  <AlertTriangle size={12} />
                  <span className="text-[10px] font-bold">العمليات المستخدمة</span>
                </div>
                <p className="text-lg font-extrabold text-amber-300">{trialInfo.actionsUsed}</p>
              </div>
            </div>
          )}

          {/* WhatsApp button */}
          <Button onClick={handleSendWhatsApp} variant="success" size="lg" className="w-full">
            <Smartphone size={20} />
            إرسال رمز التفعيل للمالك عبر WhatsApp
          </Button>

          {/* Offline activation key input */}
          {!isBlocked && (
            <form onSubmit={handleActivateKey} className="space-y-3 pt-2 border-t border-white/20">
              <p className="text-xs text-brand-300 font-semibold text-center">
                لديك كود تفعيل من المالك؟ أدخله أدناه
              </p>
              <Input
                label="كود التفعيل"
                icon={<KeyRound size={18} />}
                placeholder="AK-XXXXXX-XXXX"
                value={offlineKey}
                onChange={(e) => setOfflineKey(e.target.value)}
                className="bg-white/90"
                required
              />
              {keyError && (
                <div className="animate-fade-in rounded-2xl bg-rose-500/20 border border-rose-400/40 px-4 py-2.5 text-sm font-semibold text-rose-300">
                  {keyError}
                </div>
              )}
              <Button type="submit" variant="primary" size="md" className="w-full">
                <KeyRound size={16} />
                تفعيل الجهاز
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
