import { type ReactNode, useState } from 'react';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  BookOpen,
  CalendarCheck,
  Wallet,
  Search,
  Settings,
  LogOut,
  Receipt,
  Lock,
  Menu,
  X,
  Sparkles,
  FileStack,
  History,
  RefreshCw,
  UserCog,
  Banknote,
  Landmark,
  UserCircle,
  Briefcase,
  CreditCard,
  Smartphone,
  ClipboardList,
  Trophy,
  ShieldCheck,
} from 'lucide-react';
import { useAuth, canAccess, roleLabel } from '../context/AuthContext';
import { useDB } from '../context/DBContext';
import { useCenter } from '../context/CenterContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Building2, ChevronDown } from 'lucide-react';

export type PageKey =
  | 'dashboard'
  | 'students'
  | 'teachers'
  | 'groups'
  | 'attendance'
  | 'payments'
  | 'scanner'
  | 'materials'
  | 'expenses'
  | 'adjustments'
  | 'profits'
  | 'audit'
  | 'accounts'
  | 'settlements'
  | 'staff'
  | 'installments'
  | 'exams'
  | 'leaderboard'
  | 'settings'
  | 'profile'
  | 'master';

interface NavItem {
  key: PageKey;
  label: string;
  icon: typeof LayoutDashboard;
}

const ALL_NAV: NavItem[] = [
  { key: 'dashboard', label: 'الرئيسية', icon: LayoutDashboard },
  { key: 'students', label: 'الطلاب', icon: Users },
  { key: 'teachers', label: 'المعلمون', icon: GraduationCap },
  { key: 'groups', label: 'المجموعات', icon: BookOpen },
  { key: 'attendance', label: 'الحضور', icon: CalendarCheck },
  { key: 'payments', label: 'المدفوعات', icon: Wallet },
  { key: 'scanner', label: 'البحث السريع', icon: Search },
  { key: 'materials', label: 'المذكرات', icon: FileStack },
  { key: 'expenses', label: 'المصروفات', icon: Receipt },
  { key: 'adjustments', label: 'السلف والمكافآت', icon: Banknote },
  { key: 'profits', label: 'الأرباح السرية', icon: Lock },
  { key: 'audit', label: 'سجل الحركات', icon: History },
  { key: 'accounts', label: 'إدارة الحسابات', icon: UserCog },
  { key: 'settlements', label: 'تصفية الحسابات', icon: Landmark },
  { key: 'staff', label: 'المساعدون والموظفون', icon: Briefcase },
  { key: 'installments', label: 'الأقساط', icon: CreditCard },
  { key: 'exams', label: 'الامتحانات', icon: ClipboardList },
  { key: 'leaderboard', label: 'لوحة الشرف', icon: Trophy },
  { key: 'settings', label: 'الإعدادات', icon: Settings },
  { key: 'profile', label: 'حسابي', icon: UserCircle },
  { key: 'master', label: 'لوحة المالك', icon: ShieldCheck },
];

interface LayoutProps {
  current: PageKey;
  onNavigate: (page: PageKey) => void;
  children: ReactNode;
}

export function Layout({ current, onNavigate, children }: LayoutProps) {
  const { user, logout } = useAuth();
  const { db } = useDB();
  const { selectedCenterId, setSelectedCenterId } = useCenter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [centerOpen, setCenterOpen] = useState(false);
  const { canInstall, promptInstall } = usePWAInstall();

  const navItems = ALL_NAV.filter((n) => canAccess(user?.role, n.key, user?.linkType, user?.linkedTeacherId, user?.specialty));

  const branches = db.branches || [];
  const selectedBranch = branches.find((b) => b.id === selectedCenterId);
  const centerLabel = !selectedCenterId ? 'كل الفروع' : selectedBranch?.name || 'كل الفروع';

  const handleSelectCenter = (id: string | null) => {
    setSelectedCenterId(id);
    setCenterOpen(false);
  };

  const bottomNav = navItems.filter((n) => n.key !== 'settings' && n.key !== 'audit' && n.key !== 'materials' && n.key !== 'accounts' && n.key !== 'expenses' && n.key !== 'profits' && n.key !== 'settlements' && n.key !== 'staff' && n.key !== 'installments' && n.key !== 'master');
  const showMore = bottomNav.length > 4;
  const bottomItems = showMore ? bottomNav.slice(0, 4) : bottomNav;

  const syncTime = db.syncStamp.lastImportTime;
  const syncActor = db.syncStamp.lastImportActor;
  const exportMeta = db.exportMeta;
  const syncLabel = exportMeta
    ? `محدّثة حتى: ${new Date(exportMeta.exportTimestamp).toLocaleString('ar-EG')} — تم التصدير بواسطة: ${exportMeta.exportedBy}`
    : syncTime
    ? `آخر استيراد: ${new Date(syncTime).toLocaleString('ar-EG')}${syncActor ? ` (${syncActor})` : ''}`
    : '';

  return (
    <div className="min-h-screen flex overflow-x-hidden">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-72 shrink-0 sticky top-0 h-screen p-4">
        <div className="glass rounded-3xl shadow-glass h-full flex flex-col p-4">
          <div className="flex items-center gap-3 px-2 py-3 mb-4">
            <div className="grid place-items-center h-12 w-12 rounded-2xl gradient-brand shadow-glow overflow-hidden shrink-0">
              {db.centerLogo ? (
                <img src={db.centerLogo} alt="logo" className="h-full w-full object-cover" />
              ) : (
                <GraduationCap size={26} className="text-white" />
              )}
            </div>
            <div className="min-w-0">
              <h1 className="font-extrabold text-brand-900 leading-tight truncate">{db.centerName}</h1>
              <p className="text-xs text-brand-400">نظام الإدارة</p>
            </div>
          </div>

          {/* Center Selector */}
          {branches.length > 0 && (
            <div className="relative mb-4">
              <button
                onClick={() => setCenterOpen((v) => !v)}
                className="w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-2xl bg-brand-50 border border-brand-100 text-sm font-bold text-brand-900 hover:bg-brand-100 transition-colors"
              >
                <span className="flex items-center gap-2 min-w-0">
                  <Building2 size={16} className="text-brand-500 shrink-0" />
                  <span className="truncate">{centerLabel}</span>
                </span>
                <ChevronDown size={16} className={`text-brand-400 shrink-0 transition-transform ${centerOpen ? 'rotate-180' : ''}`} />
              </button>
              {centerOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setCenterOpen(false)} />
                  <div className="absolute z-20 top-full mt-1 left-0 right-0 rounded-2xl bg-white shadow-glass border border-slate-100 overflow-hidden">
                    <button
                      onClick={() => handleSelectCenter(null)}
                      className={`w-full text-right px-3 py-2.5 text-sm font-semibold hover:bg-brand-50 transition-colors ${!selectedCenterId ? 'bg-brand-50 text-brand-700' : 'text-brand-600'}`}
                    >
                      كل الفروع (إجمالي)
                    </button>
                    {branches.map((b) => (
                      <button
                        key={b.id}
                        onClick={() => handleSelectCenter(b.id)}
                        className={`w-full text-right px-3 py-2.5 text-sm font-semibold hover:bg-brand-50 transition-colors ${selectedCenterId === b.id ? 'bg-brand-50 text-brand-700' : 'text-brand-600'}`}
                      >
                        {b.name}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          <nav className="flex-1 space-y-1 overflow-y-auto no-scrollbar">
            {navItems.map((item) => {
              const active = current === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => onNavigate(item.key)}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-2xl text-sm font-semibold transition-all duration-200 ${
                    active
                      ? 'gradient-brand text-white shadow-soft'
                      : 'text-brand-600 hover:bg-brand-50'
                  }`}
                >
                  <item.icon size={20} className={active ? 'text-white' : 'text-brand-400'} />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Sync status bar */}
          <div className={`mt-2 px-3 py-2 rounded-2xl flex items-center gap-2 text-xs ${(syncTime || exportMeta) ? 'bg-emerald-50/80 text-emerald-700' : 'bg-brand-50/60 text-brand-400'}`}>
            <div className={`grid place-items-center h-7 w-7 rounded-lg shrink-0 ${(syncTime || exportMeta) ? 'bg-emerald-100 text-emerald-600' : 'bg-brand-100 text-brand-400'}`}>
              <RefreshCw size={13} />
            </div>
            <div className="min-w-0">
              {syncLabel ? (
                <p className="font-bold truncate">{syncLabel}</p>
              ) : (
                <p className="font-semibold">لا توجد نسخة مستوردة</p>
              )}
            </div>
          </div>

          {/* PWA Install button (desktop) */}
          {canInstall && (
            <button
              onClick={promptInstall}
              className="mt-2 w-full flex items-center gap-2 px-3 py-2.5 rounded-2xl bg-emerald-50 text-emerald-700 text-sm font-bold hover:bg-emerald-100 transition-colors"
            >
              <Smartphone size={18} />
              تثبيت التطبيق على الهاتف
            </button>
          )}

          <div className="mt-4 pt-4 border-t border-white/40">
            <div className="flex items-center gap-3 px-2 py-2 mb-2">
              <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-700 font-bold">
                {user?.name?.charAt(0) || '?'}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-brand-900 truncate">{user?.name}</p>
                <p className="text-xs text-brand-400">{user ? roleLabel(user.role) : ''}</p>
              </div>
            </div>
            <button
              onClick={logout}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm font-semibold text-rose-500 hover:bg-rose-50 transition-colors"
            >
              <LogOut size={18} />
              تسجيل الخروج
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Mobile top bar */}
        <header className="lg:hidden sticky top-0 z-30 px-4 pt-4 pb-3">
          <div className="glass rounded-2xl shadow-glass flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-2.5">
              <div className="grid place-items-center h-9 w-9 rounded-xl gradient-brand overflow-hidden shrink-0">
                {db.centerLogo ? (
                  <img src={db.centerLogo} alt="logo" className="h-full w-full object-cover" />
                ) : (
                  <GraduationCap size={20} className="text-white" />
                )}
              </div>
              <div className="min-w-0">
                <h1 className="font-bold text-brand-900 text-sm leading-tight truncate">{db.centerName}</h1>
                <p className="text-[10px] text-brand-400">{user ? roleLabel(user.role) : ''}</p>
              </div>
            </div>
            {branches.length > 0 && (
              <div className="relative">
                <button
                  onClick={() => setCenterOpen((v) => !v)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-brand-50 text-brand-900 text-xs font-bold hover:bg-brand-100 transition-colors"
                >
                  <Building2 size={14} className="text-brand-500" />
                  <span className="max-w-[100px] truncate">{centerLabel}</span>
                  <ChevronDown size={14} className={`text-brand-400 transition-transform ${centerOpen ? 'rotate-180' : ''}`} />
                </button>
                {centerOpen && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setCenterOpen(false)} />
                    <div className="absolute z-20 top-full mt-1 left-0 rounded-2xl bg-white shadow-glass border border-slate-100 overflow-hidden min-w-[160px]">
                      <button
                        onClick={() => handleSelectCenter(null)}
                        className={`w-full text-right px-3 py-2 text-xs font-semibold hover:bg-brand-50 transition-colors ${!selectedCenterId ? 'bg-brand-50 text-brand-700' : 'text-brand-600'}`}
                      >
                        كل الفروع
                      </button>
                      {branches.map((b) => (
                        <button
                          key={b.id}
                          onClick={() => handleSelectCenter(b.id)}
                          className={`w-full text-right px-3 py-2 text-xs font-semibold hover:bg-brand-50 transition-colors ${selectedCenterId === b.id ? 'bg-brand-50 text-brand-700' : 'text-brand-600'}`}
                        >
                          {b.name}
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}
            {canInstall && (
              <button
                onClick={promptInstall}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 text-xs font-bold hover:bg-emerald-100 transition-colors"
                title="تثبيت التطبيق على الهاتف"
              >
                <Smartphone size={14} />
                <span className="hidden sm:inline">تثبيت</span>
              </button>
            )}
            <button
              onClick={() => setMobileOpen(true)}
              className="grid place-items-center h-10 w-10 rounded-xl bg-brand-50 text-brand-700"
            >
              <Menu size={22} />
            </button>
          </div>
          {/* Sync status bar mobile */}
          <div className={`mt-1.5 px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-[10px] ${(syncTime || exportMeta) ? 'bg-emerald-50/80 text-emerald-700' : 'bg-brand-50/60 text-brand-400'}`}>
            <RefreshCw size={11} className="shrink-0" />
            <span className="truncate font-semibold">
              {syncLabel || 'لا توجد نسخة مستوردة'}
            </span>
          </div>
        </header>

        {/* Mobile drawer */}
        {mobileOpen && (
          <div className="lg:hidden fixed inset-0 z-50">
            <div className="absolute inset-0 bg-brand-950/40 backdrop-blur-sm animate-fade-in" onClick={() => setMobileOpen(false)} />
            <div className="absolute top-0 right-0 bottom-0 w-72 glass shadow-glass p-5 animate-slide-up max-h-[100dvh] overflow-y-auto overscroll-contain" style={{ WebkitOverflowScrolling: 'touch' }}>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <div className="grid place-items-center h-10 w-10 rounded-2xl gradient-brand overflow-hidden shrink-0">
                    {db.centerLogo ? (
                      <img src={db.centerLogo} alt="logo" className="h-full w-full object-cover" />
                    ) : (
                      <GraduationCap size={22} className="text-white" />
                    )}
                  </div>
                  <span className="font-bold text-brand-900 truncate">{db.centerName}</span>
                </div>
                <button onClick={() => setMobileOpen(false)} className="grid place-items-center h-9 w-9 rounded-xl bg-brand-50 text-brand-700 shrink-0">
                  <X size={20} />
                </button>
              </div>
              <nav className="space-y-1">
                {navItems.map((item) => {
                  const active = current === item.key;
                  return (
                    <button
                      key={item.key}
                      onClick={() => {
                        onNavigate(item.key);
                        setMobileOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-3 rounded-2xl text-sm font-semibold transition-all ${
                        active ? 'gradient-brand text-white shadow-soft' : 'text-brand-600 hover:bg-brand-50'
                      }`}
                    >
                      <item.icon size={20} className={active ? 'text-white' : 'text-brand-400'} />
                      {item.label}
                    </button>
                  );
                })}
              </nav>
              <div className="mt-6 pt-4 border-t border-white/40">
                <div className="flex items-center gap-3 px-2 py-2 mb-2">
                  <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-700 font-bold">
                    {user?.name?.charAt(0) || '?'}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-brand-900 truncate">{user?.name}</p>
                    <p className="text-xs text-brand-400">{user ? roleLabel(user.role) : ''}</p>
                  </div>
                </div>
                <button
                  onClick={logout}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm font-semibold text-rose-500 hover:bg-rose-50 transition-colors"
                >
                  <LogOut size={18} />
                  تسجيل الخروج
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Page content */}
        <main className="flex-1 px-4 lg:px-6 pb-28 lg:pb-6 pt-1">
          <div className="animate-fade-in">{children}</div>
        </main>

        {/* Mobile bottom nav */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 px-3 pb-3 pt-1">
          <div className="glass rounded-2xl shadow-glass px-2 py-2 flex items-center justify-around">
            {bottomItems.map((item) => {
              const active = current === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => onNavigate(item.key)}
                  className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all ${
                    active ? 'text-brand-700' : 'text-brand-400'
                  }`}
                >
                  <div className={`grid place-items-center h-9 w-9 rounded-xl transition-all ${active ? 'gradient-brand shadow-soft' : ''}`}>
                    <item.icon size={20} className={active ? 'text-white' : 'text-brand-400'} />
                  </div>
                  <span className="text-[10px] font-bold">{item.label}</span>
                </button>
              );
            })}
            {showMore && (
              <button
                onClick={() => setMobileOpen(true)}
                className="flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl text-brand-400"
              >
                <div className="grid place-items-center h-9 w-9 rounded-xl">
                  <Sparkles size={20} />
                </div>
                <span className="text-[10px] font-bold">المزيد</span>
              </button>
            )}
          </div>
        </nav>
      </div>
    </div>
  );
}

export { canExport } from '../context/AuthContext';
