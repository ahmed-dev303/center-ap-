import { useRef, useState } from 'react';
import { Download, Upload, FileSpreadsheet, FileJson, Database, Shield, Lock, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useAuth, canExport, canImport, roleLabel } from '../context/AuthContext';
import { useDB } from '../context/DBContext';
import { useToast } from '../context/ToastContext';
import { exportScopedDB, exportFilename } from '../lib/merge';
import { exportToExcel, exportStudentRoster, importStudentRoster } from '../lib/excel';
import { logAction } from '../lib/finance';
import { Card } from './ui/Card';
import { Badge } from './ui/Badge';
import type { Database as DBType } from '../lib/types';

export function BackupPanel() {
  const { user } = useAuth();
  const { db, replace, update } = useDB();
  const { showToast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const rosterFileRef = useRef<HTMLInputElement>(null);
  const [importing, setImporting] = useState(false);
  const [importingRoster, setImportingRoster] = useState(false);

  if (!user) return null;
  const role = user.role;
  const allowExport = canExport(role);
  const allowImport = canImport(role);

  const handleJsonExport = () => {
    const json = exportScopedDB(db, user);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = exportFilename(role);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('تم تصدير ملف النسخة الاحتياطية بنجاح');
  };

  const handleExcelExport = async () => {
    showToast('جاري إنشاء ملف Excel...');
    try {
      await exportToExcel(db, user);
      showToast('تم تصدير تقرير Excel بنجاح');
    } catch {
      showToast('تعذّر تصدير ملف Excel', 'error');
    }
  };

  const handleRosterExport = async () => {
    showToast('جاري إنشاء مف الطلاب...');
    try {
      await exportStudentRoster(db);
      showToast('تم تصدير شيت الطلاب بنجاح');
    } catch {
      showToast('تعذّر تصدير ملف الطلاب', 'error');
    }
  };

  const handleRosterImport = async (file: File) => {
    setImportingRoster(true);
    try {
      const result = await importStudentRoster(db, file);
      update((d) => {
        d.students = db.students;
        d.meta = db.meta;
        logAction(d, 'استيراد الطلاب', `تم استيراد ${result.added} طالب جديد وتحديث ${result.updated} طالب من ملف Excel`, user.name || '', role);
      });
      showToast(`تم استيراد ${result.added} طالب جديد وتحديث ${result.updated} طالب`);
      if (result.errors.length > 0) {
        showToast(`تحذير: ${result.errors.length} صف به مشاكل`, 'info');
      }
    } catch {
      showToast('تعذّر استيراد ملف الطلاب', 'error');
    } finally {
      setImportingRoster(false);
      if (rosterFileRef.current) rosterFileRef.current.value = '';
    }
  };

  const handleImport = async (file: File) => {
    setImporting(true);
    try {
      const text = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(reader.error);
        reader.readAsText(file);
      });
      const incoming = JSON.parse(text) as DBType;
      if (!incoming || !Array.isArray(incoming.users) || !Array.isArray(incoming.students) || !Array.isArray(incoming.groups)) {
        throw new Error('invalid backup');
      }
      const restored: DBType = {
        ...incoming,
        syncStamp: {
          lastImportTime: new Date().toISOString(),
          lastImportActor: user.name || null,
        },
      };
      logAction(restored, 'استعادة بيانات', 'تمت استعادة نسخة احتياطية كاملة', user.name || '', role);
      replace(restored);
      showToast('تمت استعادة النسخة الاحتياطية الكاملة بنجاح');
    } catch {
      showToast('ملف النسخة الاحتياطية غير صالح', 'error');
    } finally {
      setImporting(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const roleConfig: Record<string, { title: string; subtitle: string; scopeNote: string; excelLabel: string }> = {
    admin: {
      title: 'تصدير واستعادة البيانات',
      subtitle: 'نسخة احتياطية كاملة لجميع بيانات السنتر',
      scopeNote: 'صلاحيات كاملة — جميع البيانات والإعدادات المالية',
      excelLabel: 'تقارير Excel الشاملة',
    },
    secretary: {
      title: 'تصدير بيانات التشغيل',
      subtitle: 'تصدير سجلات الحضور والتحصيل لمجموعاتك',
      scopeNote: 'صلاحيات تشغيلية — مجموعاتك المعينة فقط (بدون إعدادات مالية)',
      excelLabel: 'تقارير Excel التشغيلية',
    },
    teacher: {
      title: 'تصدير بيانات المجموعات',
      subtitle: 'نسخة احتياطية لدرجات وحضور مجموعاتك',
      scopeNote: 'صلاحيات المجموعات — مجموعاتك وطلابك فقط',
      excelLabel: 'تقارير Excel للمجموعات',
    },
    supervisor: {
      title: 'تصدير واستعادة البيانات',
      subtitle: 'نسخة احتياطية لبيانات المتابعة',
      scopeNote: 'صلاحيات المشرف — تصدير واستعادة كاملة',
      excelLabel: 'تقارير Excel',
    },
    assistant: {
      title: 'تصدير واستعادة البيانات',
      subtitle: 'نسخة احتياطية لبيانات الحضور والمتابعة',
      scopeNote: 'صلاحيات المساعد — تصدير واستعادة كاملة',
      excelLabel: 'تقارير Excel',
    },
  };

  const cfg = roleConfig[role] || roleConfig.admin;

  return (
    <Card className="p-5 sm:p-6 relative overflow-hidden">
      <div className="absolute -top-8 -left-8 h-32 w-32 rounded-full bg-brand-300/15 blur-2xl" />

      <div className="relative">
        <div className="flex items-center gap-3 mb-1">
          <div className="grid place-items-center h-11 w-11 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-soft">
            <Database size={22} />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-extrabold text-brand-900">{cfg.title}</h3>
            <p className="text-xs text-brand-400">{cfg.subtitle}</p>
          </div>
          <Badge tone="brand">{roleLabel(role)}</Badge>
        </div>

        <div className="mt-3 flex items-start gap-2 rounded-2xl bg-brand-50/60 border border-brand-100 px-3 py-2.5">
          <Shield size={16} className="text-brand-500 shrink-0 mt-0.5" />
          <p className="text-xs font-semibold text-brand-600">{cfg.scopeNote}</p>
        </div>

        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {allowExport && (
            <button
              onClick={handleJsonExport}
              className="group flex items-center gap-3 rounded-2xl border-2 border-brand-200 bg-white p-4 text-right transition-all hover:border-brand-400 hover:shadow-soft active:scale-[0.98]"
            >
              <div className="grid place-items-center h-10 w-10 rounded-xl bg-brand-100 text-brand-600 group-hover:bg-brand-500 group-hover:text-white transition-colors">
                <FileJson size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-brand-900">تصدير نسخة JSON</p>
                <p className="text-xs text-brand-400">{role === 'admin' ? 'نسخة كاملة' : 'بيانات نطاقك فقط'}</p>
              </div>
              <Download size={18} className="text-brand-400 group-hover:text-brand-600 transition-colors" />
            </button>
          )}

          {allowExport && (
            <button
              onClick={handleExcelExport}
              className="group flex items-center gap-3 rounded-2xl border-2 border-emerald-200 bg-white p-4 text-right transition-all hover:border-emerald-400 hover:shadow-soft active:scale-[0.98]"
            >
              <div className="grid place-items-center h-10 w-10 rounded-xl bg-emerald-100 text-emerald-600 group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                <FileSpreadsheet size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-brand-900">{cfg.excelLabel}</p>
                <p className="text-xs text-brand-400">ملف Excel منسق</p>
              </div>
              <Download size={18} className="text-emerald-400 group-hover:text-emerald-600 transition-colors" />
            </button>
          )}

          {allowExport && role === 'admin' && (
            <button
              onClick={handleRosterExport}
              className="group flex items-center gap-3 rounded-2xl border-2 border-brand-200 bg-white p-4 text-right transition-all hover:border-brand-400 hover:shadow-soft active:scale-[0.98]"
            >
              <div className="grid place-items-center h-10 w-10 rounded-xl bg-brand-100 text-brand-600 group-hover:bg-brand-500 group-hover:text-white transition-colors">
                <FileSpreadsheet size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-brand-900">تصدير شيت الطلاب</p>
                <p className="text-xs text-brand-400">شيت Excel بالطلاب والمجموعات وأكواد QR</p>
              </div>
              <Download size={18} className="text-brand-400 group-hover:text-brand-600 transition-colors" />
            </button>
          )}

          {allowImport && role === 'admin' && (
            <>
              <input
                ref={rosterFileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleRosterImport(f);
                }}
              />
              <button
                onClick={() => rosterFileRef.current?.click()}
                disabled={importingRoster}
                className="group flex items-center gap-3 rounded-2xl border-2 border-brand-200 bg-white p-4 text-right transition-all hover:border-brand-400 hover:shadow-soft active:scale-[0.98] disabled:opacity-50"
              >
                <div className="grid place-items-center h-10 w-10 rounded-xl bg-brand-100 text-brand-600 group-hover:bg-brand-500 group-hover:text-white transition-colors">
                  <Upload size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-brand-900">{importingRoster ? 'جاري الاستيراد...' : 'استيراد شيت الطلاب'}</p>
                  <p className="text-xs text-brand-400">رفع ملف Excel لاستيراد الطلاب</p>
                </div>
              </button>
            </>
          )}

          {allowImport && (
            <>
              <input
                ref={fileRef}
                type="file"
                accept="application/json,.json"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleImport(f);
                }}
              />
              <button
                onClick={() => fileRef.current?.click()}
                disabled={importing}
                className="group flex items-center gap-3 rounded-2xl border-2 border-amber-200 bg-white p-4 text-right transition-all hover:border-amber-400 hover:shadow-soft active:scale-[0.98] disabled:opacity-50"
              >
                <div className="grid place-items-center h-10 w-10 rounded-xl bg-amber-100 text-amber-600 group-hover:bg-amber-500 group-hover:text-white transition-colors">
                  <Upload size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-brand-900">{importing ? 'جاري الاستيراد...' : 'استعادة نسخة احتياطية'}</p>
                  <p className="text-xs text-brand-400">رفع ملف JSON للاستعادة الكاملة</p>
                </div>
              </button>
            </>
          )}
        </div>

        {!allowExport && !allowImport && (
          <div className="mt-4 flex items-center gap-2 rounded-2xl bg-rose-50 border border-rose-200 px-3 py-2.5">
            <Lock size={16} className="text-rose-500 shrink-0" />
            <p className="text-xs font-semibold text-rose-700">لا تملك صلاحيات التصدير أو الاستعادة</p>
          </div>
        )}

        {role === 'secretary' && (
          <div className="mt-3 flex items-start gap-2 rounded-2xl bg-amber-50 border border-amber-200 px-3 py-2">
            <AlertTriangle size={14} className="text-amber-500 shrink-0 mt-0.5" />
            <p className="text-xs font-semibold text-amber-700">لا يمكن الوصول إلى الإعدادات المالية العامة أو نموذج أرباح السنتر</p>
          </div>
        )}

        {role === 'teacher' && (
          <div className="mt-3 flex items-start gap-2 rounded-2xl bg-emerald-50 border border-emerald-200 px-3 py-2">
            <CheckCircle2 size={14} className="text-emerald-500 shrink-0 mt-0.5" />
            <p className="text-xs font-semibold text-emerald-700">التصدير يقتصر على مجموعاتك وطلابك فقط — لا يمكن الوصول لبيانات المجموعات الأخرى</p>
          </div>
        )}

        {db.syncStamp.lastImportTime && allowImport && (
          <div className="mt-3 text-xs text-brand-400 font-semibold">
            آخر استيراد: {new Date(db.syncStamp.lastImportTime).toLocaleString('ar-EG')}
            {db.syncStamp.lastImportActor ? ` بواسطة ${db.syncStamp.lastImportActor}` : ''}
          </div>
        )}
      </div>
    </Card>
  );
}
