import { Component, type ReactNode } from 'react';
import { AlertTriangle } from 'lucide-react';

interface Props {
  children: ReactNode;
}
interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'حدث خطأ غير متوقع' };
  }

  componentDidCatch(error: Error) {
    console.error('App error boundary caught:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-4">
          <div className="glass rounded-3xl shadow-glass p-8 max-w-md text-center">
            <div className="grid place-items-center h-16 w-16 rounded-3xl bg-rose-100 text-rose-500 mx-auto mb-4">
              <AlertTriangle size={32} />
            </div>
            <h2 className="text-lg font-bold text-brand-900 mb-2">حدث خطأ غير متوقع</h2>
            <p className="text-sm text-brand-400 mb-4">{this.state.message}</p>
            <button
              onClick={() => this.setState({ hasError: false, message: '' })}
              className="gradient-brand text-white font-semibold rounded-2xl px-6 py-3 text-sm shadow-soft hover:brightness-110 transition-all"
            >
              إعادة المحاولة
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
