import { useState, useEffect } from 'react';
import { GraduationCap, Phone, PhoneCall, BookOpen, Users, Printer, Hash, Users2, QrCode } from 'lucide-react';
import type { Student, Group, GradePrice } from '../lib/types';
import { formatEGP } from '../lib/date';
import { printSingleIDCard } from '../lib/idcard';
import { discountedSessionFee } from '../lib/finance';
import { generateQRDataUrl, generateStudentCode } from '../lib/qr';
import { studentGroupIds } from '../lib/scoping';

interface StudentCardProps {
  student: Student;
  group?: Group;
  groups?: Group[];
  gradePrice?: GradePrice;
  qrEnabled?: boolean;
  isAdmin?: boolean;
}

export function StudentCard({ student, group, groups, gradePrice, qrEnabled, isAdmin = true }: StudentCardProps) {
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);

  const qrValue = student.qrCode || generateStudentCode(student.id);
  const allGroups = groups || (group ? [group] : []);
  const sGroups = studentGroupIds(student)
    .map((id) => allGroups.find((g) => g.id === id))
    .filter(Boolean) as Group[];

  useEffect(() => {
    if (qrEnabled) {
      generateQRDataUrl(qrValue, 160).then(setQrDataUrl).catch(() => setQrDataUrl(null));
    } else {
      setQrDataUrl(null);
    }
  }, [qrEnabled, qrValue]);

  const handlePrint = () => {
    printSingleIDCard(student, allGroups, qrDataUrl || undefined);
  };

  return (
    <div className="space-y-4">
      {/* Card preview */}
      <div className="relative rounded-3xl gradient-brand p-5 text-white shadow-glow overflow-hidden">
        <div className="absolute -top-8 -left-8 h-32 w-32 rounded-full bg-white/10 blur-xl" />
        <div className="absolute -bottom-8 -right-8 h-32 w-32 rounded-full bg-white/10 blur-xl" />
        <div className="relative">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <GraduationCap size={24} />
              <span className="font-extrabold">سنتر الأفضل</span>
            </div>
            <span className="text-xs bg-white/20 rounded-full px-3 py-1 font-bold">بطاقة طالب</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="grid place-items-center h-16 w-16 rounded-2xl bg-white/20 backdrop-blur-sm text-2xl font-extrabold">
              {student.name.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-extrabold truncate">{student.name}</h3>
              <p className="text-sm text-white/80">{student.grade}</p>
              <div className="mt-1 inline-flex items-center gap-1.5 bg-white/20 rounded-full px-3 py-0.5">
                <Hash size={10} /> <span className="text-xs font-bold">كود: {student.id}</span>
              </div>
            </div>
            {qrDataUrl && (
              <div className="bg-white rounded-xl p-1.5 shrink-0">
                <img src={qrDataUrl} alt="QR Code" className="h-20 w-20" />
              </div>
            )}
          </div>
          {qrEnabled && (
            <div className="mt-3 flex items-center gap-1.5 text-xs text-white/70">
              <QrCode size={12} />
              <span className="font-mono font-bold">{qrValue}</span>
            </div>
          )}
        </div>
      </div>

      {/* Details */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-brand-700">
          <Phone size={16} className="text-brand-400" /> {student.phone || '—'}
        </div>
        <div className="flex items-center gap-2 text-sm text-brand-700">
          <PhoneCall size={16} className="text-brand-400" /> {student.parentPhone || '—'}
        </div>
        <div className="flex items-center gap-2 text-sm text-brand-700">
          <BookOpen size={16} className="text-brand-400" /> {student.grade}
        </div>
        <div className="flex items-start gap-2 text-sm text-brand-700">
          <Users size={16} className="text-brand-400 mt-0.5 shrink-0" />
          <div className="flex flex-wrap gap-1">
            {sGroups.length > 0 ? sGroups.map((g) => (
              <span key={g.id} className="bg-brand-50 rounded-lg px-2 py-0.5 text-xs font-semibold text-brand-700">{g.name}</span>
            )) : <span className="text-brand-400">بدون مجموعة</span>}
          </div>
        </div>
        {gradePrice && (
          <div className="flex items-center justify-between rounded-2xl bg-emerald-50 px-3 py-2 mt-2">
            <span className="text-sm font-semibold text-emerald-700">الرسوم الشهرية</span>
            <span className="font-bold text-emerald-700">{formatEGP(discountedSessionFee(gradePrice.price, student))}</span>
          </div>
        )}
        {isAdmin && student.hasSiblingDiscount && student.discountPercent ? (
          <div className={`flex items-center gap-2 rounded-2xl border px-3 py-2 ${student.discountType === 'twin' ? 'bg-violet-50 border-violet-200' : 'bg-amber-50 border-amber-200'}`}>
            {student.discountType === 'twin' ? <Users size={16} className="text-violet-600" /> : <Users2 size={16} className="text-amber-600" />}
            <span className={`text-sm font-semibold ${student.discountType === 'twin' ? 'text-violet-700' : 'text-amber-700'}`}>
              {student.discountType === 'twin' ? 'خصم توأم' : 'خصم أشقاء'} {student.discountPercent}%
            </span>
          </div>
        ) : null}
      </div>

      <button
        onClick={handlePrint}
        className="w-full rounded-2xl gradient-brand text-white py-3 font-bold text-sm flex items-center justify-center gap-2 shadow-soft hover:opacity-90 active:scale-[0.98] transition-all"
      >
        <Printer size={18} /> طباعة الكارت
      </button>
    </div>
  );
}
