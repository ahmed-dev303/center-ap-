import { useState, useRef, useEffect, useMemo } from 'react';
import { Search, X, Phone, BookOpen, Users, Hash, Users2 } from 'lucide-react';
import type { Student, Group } from '../lib/types';

function normalizeArabic(s: string): string {
  return s
    .replace(/[\u0621\u0622\u0623\u0625\u0627]/g, 'ا')
    .replace(/\u0629/g, 'ه')
    .replace(/[\u0649\u064A]/g, 'ي')
    .trim();
}

interface StudentSearchProps {
  students: Student[];
  groups: Group[];
  onSelect: (student: Student) => void;
  placeholder?: string;
  autoFocus?: boolean;
}

export function StudentSearch({ students, groups, onSelect, placeholder = 'ابحث بالاسم أو الكود...', autoFocus }: StudentSearchProps) {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const results = useMemo(() => {
    const q = normalizeArabic(query);
    if (!q) return [];
    return students
      .filter((s) => {
        const name = normalizeArabic(s.name);
        const id = String(s.id);
        return name.includes(q) || id.includes(q);
      })
      .slice(0, 8);
  }, [students, query]);

  useEffect(() => {
    setHighlight(0);
  }, [query]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    if (autoFocus) inputRef.current?.focus();
  }, [autoFocus]);

  const selectStudent = (s: Student) => {
    onSelect(s);
    setQuery('');
    setOpen(false);
    inputRef.current?.focus();
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (!open || results.length === 0) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlight((h) => Math.min(h + 1, results.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlight((h) => Math.max(h - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      selectStudent(results[highlight]);
    } else if (e.key === 'Escape') {
      setOpen(false);
    }
  };

  return (
    <div ref={containerRef} className="relative">
      <div className="relative">
        <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-400 pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onKeyDown={handleKey}
          placeholder={placeholder}
          className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white pr-10 pl-10 text-sm font-semibold text-brand-900 focus:outline-none focus:border-brand-500 transition-colors"
        />
        {query && (
          <button
            type="button"
            onClick={() => { setQuery(''); setOpen(false); inputRef.current?.focus(); }}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-400 hover:text-brand-600"
          >
            <X size={18} />
          </button>
        )}
      </div>

      {open && query && (
        <div className="absolute z-50 left-0 right-0 mt-2 glass rounded-2xl shadow-glass overflow-hidden max-h-80 overflow-y-auto animate-fade-in">
          {results.length === 0 ? (
            <div className="px-4 py-6 text-center text-sm text-brand-400 font-semibold">
              لا يوجد طالب مطابق
            </div>
          ) : (
            results.map((s, idx) => {
              const group = groups.find((g) => g.id === s.groupId);
              return (
                <button
                  key={s.id}
                  type="button"
                  onMouseEnter={() => setHighlight(idx)}
                  onClick={() => selectStudent(s)}
                  className={`w-full flex items-center gap-3 px-4 text-right transition-colors border-b border-white/30 last:border-0 ${
                    idx === highlight ? 'bg-brand-50' : 'bg-white/50'
                  }`}
                  style={{ minHeight: '48px' }}
                >
                  <div className="grid place-items-center h-10 w-10 rounded-xl gradient-brand text-white font-bold shrink-0 text-sm">
                    {s.name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0 py-2">
                    <p className="font-bold text-brand-900 text-sm truncate">{s.name}</p>
                    <div className="flex items-center gap-2 flex-wrap mt-0.5">
                      <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-brand-500 bg-brand-50 rounded-full px-1.5 py-0.5">
                        <Hash size={9} /> {s.id}
                      </span>
                      <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-brand-400 truncate">
                        <BookOpen size={9} /> {s.grade}
                      </span>
                      {group && (
                        <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-brand-400 truncate">
                          <Users size={9} /> {group.name}
                        </span>
                      )}
                      {s.hasSiblingDiscount && s.discountPercent ? (
                        <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-amber-600 bg-amber-50 rounded-full px-1.5 py-0.5">
                          <Users2 size={9} /> خصم {s.discountPercent}%
                        </span>
                      ) : null}
                      {s.phone && (
                        <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-brand-400 truncate">
                          <Phone size={9} /> {s.phone}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
