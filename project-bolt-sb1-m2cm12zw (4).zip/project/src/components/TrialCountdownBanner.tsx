import { useState, useEffect, useRef } from 'react';
import { Clock } from 'lucide-react';
import { getTrialTimeRemaining, getThisDeviceLicenseType } from '../lib/master';

interface TrialCountdownBannerProps {
  onExpired: () => void;
}

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

export function TrialCountdownBanner({ onExpired }: TrialCountdownBannerProps) {
  const [remaining, setRemaining] = useState(() => getTrialTimeRemaining());
  const expiredRef = useRef(false);

  useEffect(() => {
    const tick = () => {
      const r = getTrialTimeRemaining();
      setRemaining(r);
      if (r.expired && !expiredRef.current) {
        expiredRef.current = true;
        onExpired();
      }
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [onExpired]);

  if (getThisDeviceLicenseType() !== 'trial') return null;
  if (remaining.expired) return null;

  const { hours, minutes, seconds } = remaining;
  const totalHours = hours;
  const display = totalHours >= 24
    ? `${Math.floor(totalHours / 24)} يوم و ${totalHours % 24} ساعة و ${pad(minutes)} دقيقة`
    : `${pad(totalHours)}:${pad(minutes)}:${pad(seconds)}`;

  return (
    <div className="sticky top-0 z-[150] w-full bg-gradient-to-l from-amber-500 to-amber-600 text-white shadow-md">
      <div className="flex items-center justify-center gap-2 px-4 py-2 text-sm font-bold">
        <Clock size={16} className="animate-pulse" />
        <span>المتبقي على انتهاء الفترة التجريبية: {display}</span>
      </div>
    </div>
  );
}
