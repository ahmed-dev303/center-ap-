import { type ReactNode, useEffect } from 'react';
import { X } from 'lucide-react';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

const sizes = {
  sm: 'max-w-sm',
  md: 'max-w-md',
  lg: 'max-w-2xl',
  xl: 'max-w-4xl',
};

export function Modal({ open, onClose, title, children, size = 'md' }: ModalProps) {
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = '';
      };
    }
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[90] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div
        className="absolute inset-0 bg-brand-950/40 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />
      <div
        className={`relative w-full ${sizes[size]} glass rounded-t-3xl sm:rounded-3xl shadow-glass animate-slide-up max-h-[88vh] sm:max-h-[92vh] overflow-y-auto no-scrollbar`}
      >
        {title && (
          <div className="sticky top-0 z-10 flex items-center justify-between px-3 sm:px-5 py-3 sm:py-4 glass border-b border-white/40 rounded-t-3xl">
            <h3 className="text-base sm:text-lg font-bold text-brand-900">{title}</h3>
            <button
              onClick={onClose}
              className="grid place-items-center h-8 w-8 sm:h-9 sm:w-9 rounded-xl text-brand-500 hover:bg-brand-50 transition-colors"
            >
              <X size={18} />
            </button>
          </div>
        )}
        <div className="p-3 sm:p-5">{children}</div>
      </div>
    </div>
  );
}
