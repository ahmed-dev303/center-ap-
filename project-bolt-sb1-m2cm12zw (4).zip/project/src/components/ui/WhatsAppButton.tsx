import { useState } from 'react';
import { MessageCircle } from 'lucide-react';
import { openWhatsApp, whatsappMessage, type WhatsAppTemplate } from '../../lib/whatsapp';
import type { Student } from '../../lib/types';

interface WhatsAppButtonProps {
  student: Student;
  template?: WhatsAppTemplate;
  centerName?: string;
  groupName?: string;
  amountDue?: number;
  date?: string;
  dueDate?: string;
  examTitle?: string;
  examScore?: number;
  examMaxScore?: number;
  examPercent?: number;
  examStatus?: string;
  size?: 'sm' | 'md';
  label?: string;
  className?: string;
}

export function WhatsAppButton({
  student,
  template = 'general',
  centerName,
  groupName,
  amountDue,
  date,
  dueDate,
  examTitle,
  examScore,
  examMaxScore,
  examPercent,
  examStatus,
  size = 'sm',
  label,
  className = '',
}: WhatsAppButtonProps) {
  const [open, setOpen] = useState(false);
  const phone = student.parentPhone || student.motherPhone || '';

  const handleClick = (t: WhatsAppTemplate) => {
    const msg = whatsappMessage(t, student, { centerName, groupName, amountDue, date, dueDate, examTitle, examScore, examMaxScore, examPercent, examStatus });
    openWhatsApp(phone, msg);
    setOpen(false);
  };

  if (!phone.trim()) {
    return (
      <button
        disabled
        className={`grid place-items-center rounded-xl bg-slate-100 text-slate-300 cursor-not-allowed ${size === 'sm' ? 'h-8 w-8' : 'h-10 w-10'} ${className}`}
        title="لا يوجد رقم هاتف لولي الأمر"
      >
        <MessageCircle size={size === 'sm' ? 16 : 20} />
      </button>
    );
  }

  if (template !== 'general' || label) {
    return (
      <button
        onClick={() => handleClick(template)}
        className={`flex items-center gap-1.5 rounded-xl bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors font-semibold ${size === 'sm' ? 'px-2.5 py-1.5 text-xs' : 'px-3 py-2 text-sm'} ${className}`}
        title="واتساب ولي الأمر"
      >
        <MessageCircle size={size === 'sm' ? 14 : 18} />
        {label && <span>{label}</span>}
      </button>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className={`grid place-items-center rounded-xl bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors ${size === 'sm' ? 'h-8 w-8' : 'h-10 w-10'} ${className}`}
        title="واتساب ولي الأمر"
      >
        <MessageCircle size={size === 'sm' ? 16 : 20} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute z-50 mt-1 left-0 w-56 rounded-2xl border border-slate-100 bg-white shadow-xl py-1 animate-fade-in">
            <button onClick={() => handleClick('absence')} className="w-full text-right px-3 py-2 text-sm text-brand-700 hover:bg-rose-50 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-rose-400" /> إنذار غياب
            </button>
            <button onClick={() => handleClick('unpaid')} className="w-full text-right px-3 py-2 text-sm text-brand-700 hover:bg-amber-50 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-amber-400" /> تذكير بالمتأخرات
            </button>
            <button onClick={() => handleClick('general')} className="w-full text-right px-3 py-2 text-sm text-brand-700 hover:bg-brand-50 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-brand-400" /> رسالة عامة
            </button>
            {examTitle !== undefined && (
              <button onClick={() => handleClick('exam')} className="w-full text-right px-3 py-2 text-sm text-brand-700 hover:bg-emerald-50 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-400" /> إرسال نتيجة الامتحان
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
}
