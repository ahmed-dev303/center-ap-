import { type ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  glass?: boolean;
  hover?: boolean;
}

export function Card({ children, className = '', glass = true, hover = false }: CardProps) {
  return (
    <div
      className={`rounded-3xl ${glass ? 'glass' : 'bg-white'} card-shadow ${
        hover ? 'transition-all duration-300 hover:shadow-glow hover:-translate-y-0.5' : ''
      } ${className}`}
    >
      {children}
    </div>
  );
}
