import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check, X, Layers, CheckCheck, Square } from 'lucide-react';
import type { Group } from '../../lib/types';

interface MultiGroupSelectProps {
  groups: Group[];
  selectedIds: string[];
  onChange: (ids: string[]) => void;
  placeholder?: string;
  label?: string;
  maxChipDisplay?: number;
}

export function MultiGroupSelect({
  groups,
  selectedIds,
  onChange,
  placeholder = 'اختر المجموعات...',
  label,
  maxChipDisplay = 6,
}: MultiGroupSelectProps) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  const toggle = (id: string) => {
    if (selectedIds.includes(id)) {
      onChange(selectedIds.filter((x) => x !== id));
    } else {
      onChange([...selectedIds, id]);
    }
  };

  const selectAll = () => onChange(groups.map((g) => g.id));
  const deselectAll = () => onChange([]);

  const allSelected = groups.length > 0 && selectedIds.length === groups.length;
  const noneSelected = selectedIds.length === 0;
  const selectedGroups = groups.filter((g) => selectedIds.includes(g.id));
  const displayChips = selectedGroups.slice(0, maxChipDisplay);
  const extraCount = selectedGroups.length - maxChipDisplay;

  const buttonLabel = noneSelected
    ? placeholder
    : selectedGroups.length === 1
    ? selectedGroups[0].name
    : `${selectedGroups.length} مجموعة محددة`;

  return (
    <div ref={containerRef} className="relative">
      {label && (
        <label className="block text-sm font-semibold text-brand-900 mb-1.5">{label}</label>
      )}

      {/* Trigger button */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full h-11 flex items-center justify-between gap-2 rounded-xl border-2 border-slate-200 bg-white px-4 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500 transition-colors"
      >
        <span className="flex items-center gap-2 min-w-0">
          <Layers size={18} className="text-brand-400 shrink-0" />
          <span className={`truncate ${noneSelected ? 'text-brand-400 font-medium' : ''}`}>{buttonLabel}</span>
        </span>
        <ChevronDown size={18} className={`text-brand-400 shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {/* Selected chips */}
      {selectedGroups.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {displayChips.map((g) => (
            <span
              key={g.id}
              className="inline-flex items-center gap-1 rounded-full bg-brand-100 px-2.5 py-1 text-xs font-bold text-brand-700"
            >
              {g.name}
              <button
                type="button"
                onClick={() => toggle(g.id)}
                className="grid place-items-center h-4 w-4 rounded-full bg-brand-200 text-brand-600 hover:bg-rose-200 hover:text-rose-600 transition-colors"
              >
                <X size={10} />
              </button>
            </span>
          ))}
          {extraCount > 0 && (
            <span className="inline-flex items-center rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-500">
              +{extraCount} أخرى
            </span>
          )}
        </div>
      )}

      {/* Dropdown */}
      {open && (
        <div className="absolute z-50 top-full mt-1 left-0 right-0 rounded-2xl bg-white shadow-glass border border-slate-100 overflow-hidden animate-fade-in">
          {/* Select all / Deselect all */}
          <div className="flex gap-2 p-2 border-b border-slate-100 bg-brand-50/50">
            <button
              type="button"
              onClick={allSelected ? deselectAll : selectAll}
              className="flex-1 flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition-colors bg-white text-brand-700 hover:bg-brand-100 border border-brand-200"
            >
              {allSelected ? <Square size={14} /> : <CheckCheck size={14} />}
              {allSelected ? 'إلغاء الكل' : 'تحديد الكل'}
            </button>
          </div>

          {/* Group list */}
          <div className="max-h-64 overflow-y-auto overscroll-contain" style={{ WebkitOverflowScrolling: 'touch' }}>
            {groups.length === 0 ? (
              <p className="px-4 py-6 text-center text-sm text-brand-400 font-semibold">لا توجد مجموعات</p>
            ) : (
              groups.map((g) => {
                const checked = selectedIds.includes(g.id);
                return (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => toggle(g.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-right transition-colors ${
                      checked ? 'bg-brand-50 text-brand-700' : 'text-brand-600 hover:bg-slate-50'
                    }`}
                  >
                    <div
                      className={`grid place-items-center h-6 w-6 rounded-lg border-2 shrink-0 transition-all ${
                        checked ? 'bg-brand-500 border-brand-500 text-white' : 'border-slate-300 bg-white'
                      }`}
                    >
                      {checked && <Check size={14} />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold truncate">{g.name}</p>
                      <p className="text-[11px] text-brand-400 truncate">{g.subject} · {g.grade}</p>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}
