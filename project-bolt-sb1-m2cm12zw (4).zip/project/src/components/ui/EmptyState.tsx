import { type ReactNode } from 'react';
import { AlertCircle } from 'lucide-react';

interface EmptyStateProps {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
}

export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center animate-fade-in">
      <div className="grid place-items-center h-20 w-20 rounded-3xl bg-brand-50 text-brand-300 mb-4">
        {icon || <AlertCircle size={36} />}
      </div>
      <h3 className="text-lg font-bold text-brand-900 mb-1">{title}</h3>
      {description && <p className="text-sm text-brand-400 max-w-xs mb-4">{description}</p>}
      {action}
    </div>
  );
}
