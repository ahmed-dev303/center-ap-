interface ConfirmDialogProps {
  open: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  onCancel: () => void;
  danger?: boolean;
}

export function ConfirmDialog({
  open,
  title,
  message,
  confirmText = 'تأكيد',
  cancelText = 'إلغاء',
  onConfirm,
  onCancel,
  danger = false,
}: ConfirmDialogProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[95] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-brand-950/40 backdrop-blur-sm animate-fade-in" onClick={onCancel} />
      <div className="relative glass rounded-3xl shadow-glass p-6 max-w-sm w-full animate-scale-in">
        <h3 className="text-lg font-bold text-brand-900 mb-2">{title}</h3>
        <p className="text-sm text-brand-500 mb-6">{message}</p>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 h-11 rounded-2xl bg-white border border-slate-200 text-brand-700 font-semibold text-sm hover:bg-brand-50 transition-colors"
          >
            {cancelText}
          </button>
          <button
            onClick={onConfirm}
            className={`flex-1 h-11 rounded-2xl text-white font-semibold text-sm transition-all ${
              danger ? 'bg-rose-500 hover:bg-rose-600' : 'gradient-brand hover:brightness-110'
            }`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
}
