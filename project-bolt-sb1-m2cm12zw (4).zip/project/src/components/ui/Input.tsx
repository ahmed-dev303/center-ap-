import { type InputHTMLAttributes, type SelectHTMLAttributes, type ReactNode } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  icon?: ReactNode;
  error?: string;
}

export function Input({ label, icon, error, className = '', ...props }: InputProps) {
  return (
    <label className="block">
      {label && <span className="block mb-1.5 text-xs sm:text-sm font-semibold text-brand-900">{label}</span>}
      <div className="relative">
        {icon && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-400 pointer-events-none">{icon}</span>
        )}
        <input
          className={`w-full h-10 sm:h-12 rounded-2xl border-2 bg-white/70 backdrop-blur-sm px-3 sm:px-4 text-xs sm:text-sm font-medium text-brand-900 placeholder:text-brand-300 transition-all duration-200 focus:outline-none focus:border-brand-500 focus:bg-white focus:ring-4 focus:ring-brand-100 ${
            icon ? 'pr-11' : ''
          } ${error ? 'border-rose-300' : 'border-slate-200'} ${className}`}
          {...props}
        />
      </div>
      {error && <span className="block mt-1 text-xs font-semibold text-rose-500">{error}</span>}
    </label>
  );
}

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  children: ReactNode;
}

export function Select({ label, children, className = '', ...props }: SelectProps) {
  return (
    <label className="block">
      {label && <span className="block mb-1.5 text-xs sm:text-sm font-semibold text-brand-900">{label}</span>}
      <select
        className={`w-full h-10 sm:h-12 rounded-2xl border-2 border-slate-200 bg-white/70 backdrop-blur-sm px-3 sm:px-4 text-xs sm:text-sm font-medium text-brand-900 transition-all duration-200 focus:outline-none focus:border-brand-500 focus:bg-white focus:ring-4 focus:ring-brand-100 ${className}`}
        {...props}
      >
        {children}
      </select>
    </label>
  );
}

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
}

export function Textarea({ label, className = '', ...props }: TextareaProps) {
  return (
    <label className="block">
      {label && <span className="block mb-1.5 text-xs sm:text-sm font-semibold text-brand-900">{label}</span>}
      <textarea
        className={`w-full rounded-2xl border-2 border-slate-200 bg-white/70 backdrop-blur-sm px-3 sm:px-4 py-2 sm:py-3 text-xs sm:text-sm font-medium text-brand-900 placeholder:text-brand-300 transition-all duration-200 focus:outline-none focus:border-brand-500 focus:bg-white focus:ring-4 focus:ring-brand-100 ${className}`}
        {...props}
      />
    </label>
  );
}
