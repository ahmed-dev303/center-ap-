import { type ButtonHTMLAttributes, type ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline' | 'success';
type Size = 'sm' | 'md' | 'lg' | 'icon';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  children: ReactNode;
}

const variants: Record<Variant, string> = {
  primary:
    'gradient-brand text-white shadow-soft hover:shadow-glow hover:brightness-110 active:scale-[0.98]',
  secondary:
    'bg-white text-brand-700 border border-brand-200 hover:bg-brand-50 active:scale-[0.98]',
  ghost: 'text-brand-700 hover:bg-brand-50 active:scale-[0.98]',
  danger:
    'bg-rose-500 text-white shadow-soft hover:bg-rose-600 active:scale-[0.98]',
  outline:
    'bg-transparent text-brand-700 border-2 border-brand-300 hover:bg-brand-50 active:scale-[0.98]',
  success:
    'bg-emerald-500 text-white shadow-soft hover:bg-emerald-600 active:scale-[0.98]',
};

const sizes: Record<Size, string> = {
  sm: 'h-8 sm:h-9 px-2.5 sm:px-3 text-xs rounded-xl gap-1.5',
  md: 'h-9 sm:h-11 px-3 sm:px-5 text-xs sm:text-sm rounded-2xl gap-2',
  lg: 'h-10 sm:h-13 px-5 sm:px-7 text-sm sm:text-base rounded-2xl gap-2.5 py-2 sm:py-3',
  icon: 'h-9 sm:h-11 w-9 sm:w-11 rounded-2xl',
};

export function Button({ variant = 'primary', size = 'md', className = '', children, ...props }: ButtonProps) {
  return (
    <button
      className={`inline-flex items-center justify-center font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed select-none ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
