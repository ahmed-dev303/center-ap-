const DEFAULT_ICON_192 = '/icons/icon-192.png';
const DEFAULT_ICON_512 = '/icons/icon-512.png';

interface ManifestIcon {
  src: string;
  sizes: string;
  type: string;
  purpose: string;
}

interface FileHandler {
  action: string;
  accept: Record<string, string[]>;
}

interface BaseManifest {
  name: string;
  short_name: string;
  description: string;
  start_url: string;
  scope: string;
  display: string;
  orientation: string;
  theme_color: string;
  background_color: string;
  lang: string;
  dir: string;
  categories: string[];
  icons: ManifestIcon[];
  file_handlers: FileHandler[];
}

const BASE_MANIFEST: BaseManifest = {
  name: 'سنتر الأفضل - نظام الإدارة',
  short_name: 'سنتر الأفضل',
  description: 'نظام إدارة المراكز التعليمية - طلاب، مجموعات، مدفوعات، حضور، أقساط',
  start_url: '/',
  scope: '/',
  display: 'standalone',
  orientation: 'portrait',
  theme_color: '#312e81',
  background_color: '#ffffff',
  lang: 'ar',
  dir: 'rtl',
  categories: ['education', 'productivity', 'business'],
  icons: [
    { src: DEFAULT_ICON_192, sizes: '192x192', type: 'image/png', purpose: 'any maskable' },
    { src: DEFAULT_ICON_512, sizes: '512x512', type: 'image/png', purpose: 'any maskable' },
  ],
  file_handlers: [
    { action: '/import-backup', accept: { 'application/json': ['.json', '.centerbackup'] } },
  ],
};

let dynamicManifestUrl: string | null = null;

function upsertLink(rel: string, href: string, attrs: Record<string, string> = {}): void {
  const existing = document.head.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (existing) {
    existing.href = href;
    for (const [k, v] of Object.entries(attrs)) {
      existing.setAttribute(k, v);
    }
    return;
  }
  const link = document.createElement('link');
  link.rel = rel;
  link.href = href;
  for (const [k, v] of Object.entries(attrs)) {
    link.setAttribute(k, v);
  }
  document.head.appendChild(link);
}

function buildManifest(logoUrl: string | null, centerName: string): Blob {
  const icons: ManifestIcon[] = logoUrl
    ? [
        { src: logoUrl, sizes: '192x192', type: 'image/png', purpose: 'any maskable' },
        { src: logoUrl, sizes: '512x512', type: 'image/png', purpose: 'any maskable' },
        { src: logoUrl, sizes: 'any', type: 'image/png', purpose: 'any' },
      ]
    : BASE_MANIFEST.icons;

  const manifest: BaseManifest = {
    ...BASE_MANIFEST,
    name: `${centerName} - نظام الإدارة`,
    short_name: centerName.slice(0, 12),
    icons,
  };

  return new Blob([JSON.stringify(manifest)], { type: 'application/json' });
}

export function updateAppIcons(logoUrl: string | null, centerName: string = 'سنتر الأفضل'): void {
  try {
    const iconHref = logoUrl || DEFAULT_ICON_192;

    upsertLink('icon', iconHref, { type: logoUrl ? 'image/png' : 'image/svg+xml' });
    upsertLink('apple-touch-icon', iconHref);
    upsertLink('shortcut icon', iconHref);

    if (dynamicManifestUrl) {
      URL.revokeObjectURL(dynamicManifestUrl);
      dynamicManifestUrl = null;
    }

    const manifestBlob = buildManifest(logoUrl, centerName);
    dynamicManifestUrl = URL.createObjectURL(manifestBlob);

    const manifestLink = document.head.querySelector<HTMLLinkElement>('link[rel="manifest"]');
    if (manifestLink) {
      manifestLink.href = dynamicManifestUrl;
    } else {
      const newLink = document.createElement('link');
      newLink.rel = 'manifest';
      newLink.href = dynamicManifestUrl;
      document.head.appendChild(newLink);
    }

    const titleEl = document.title;
    void titleEl;

    const appleTitleMeta = document.head.querySelector<HTMLMetaElement>('meta[name="apple-mobile-web-app-title"]');
    if (appleTitleMeta) {
      appleTitleMeta.setAttribute('content', centerName);
    } else {
      const meta = document.createElement('meta');
      meta.name = 'apple-mobile-web-app-title';
      meta.content = centerName;
      document.head.appendChild(meta);
    }

    if (logoUrl && navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({ type: 'ICON_UPDATE', logoUrl });
    }
  } catch {
    // SSR or headless — ignore
  }
}

export function getDefaultIcons(): { icon192: string; icon512: string } {
  return { icon192: DEFAULT_ICON_192, icon512: DEFAULT_ICON_512 };
}
