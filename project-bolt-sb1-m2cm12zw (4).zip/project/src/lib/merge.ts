import type { Database, User } from './types';
import { getScopedData } from './scoping';

export interface MergeResult {
  studentsUpdated: number;
  studentsAdded: number;
  teachersUpdated: number;
  teachersAdded: number;
  groupsUpdated: number;
  groupsAdded: number;
  attendanceMerged: number;
  paymentsMerged: number;
  materialsMerged: number;
  examScoresMerged: number;
}

export function exportDB(db: Database, exportedBy: string): string {
  const payload = {
    ...db,
    exportMeta: {
      exportTimestamp: new Date().toISOString(),
      exportedBy,
    },
  };
  return JSON.stringify(payload, null, 2);
}

export function exportFilename(role?: string): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  const date = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const roleSlug = role ? role.toLowerCase() : 'full';
  return `backup-${roleSlug}-${date}.json`;
}

export function exportScopedDB(db: Database, user: User): string {
  const baseScoped = getScopedData(db, user);
  const role = user.role;
  const exportGroups = role === 'teacher'
    ? db.groups.filter((g) => !!user.teacherId && g.teacherId === user.teacherId)
    : role === 'secretary'
      ? user.linkedTeacherId
        ? db.groups.filter((g) => g.teacherId === user.linkedTeacherId)
        : (user.branchIds || []).length > 0
          ? db.groups.filter((g) => !!g.branchId && (user.branchIds || []).includes(g.branchId))
          : []
      : baseScoped.groups;
  const exportGroupIds = new Set(exportGroups.map((g) => g.id));
  const exportStudents = db.students.filter((s) => !!s.groupId && exportGroupIds.has(s.groupId));
  const exportStudentIds = new Set(exportStudents.map((s) => s.id));
  const scoped = {
    ...baseScoped,
    groups: exportGroups,
    students: exportStudents,
    attendance: db.attendance.filter((a) => exportGroupIds.has(a.groupId)),
    payments: db.payments.filter((p) => exportGroupIds.has(p.groupId || '') || exportStudentIds.has(p.studentId)),
    materials: db.materials.filter((m) => exportGroupIds.has(m.groupId)),
  };
  let payload: Record<string, unknown>;

  if (role === 'admin') {
    payload = {
      ...db,
      exportMeta: { exportTimestamp: new Date().toISOString(), exportedBy: user.name || user.username, role: 'admin' },
    };
  } else if (role === 'teacher') {
    const groupIds = new Set(scoped.groups.map((g) => g.id));
    const teacherExams = (db.exams || []).filter((e) => groupIds.has(e.groupId));
    payload = {
      students: scoped.students,
      groups: scoped.groups,
      attendance: scoped.attendance,
      materials: scoped.materials,
      exams: teacherExams,
      examScores: (db.examScores || []).filter((e) => groupIds.has(e.groupId)),
      exportMeta: { exportTimestamp: new Date().toISOString(), exportedBy: user.name || user.username, role: 'teacher', scope: 'own-groups' },
    };
  } else {
    payload = {
      students: scoped.students,
      groups: scoped.groups,
      attendance: scoped.attendance,
      payments: scoped.payments,
      materials: scoped.materials,
      exams: (db.exams || []).filter((e) => { const g = scoped.groups.find((gg) => gg.id === e.groupId); return !!g; }),
      examScores: (db.examScores || []).filter((e) => { const g = scoped.groups.find((gg) => gg.id === e.groupId); return !!g; }),
      exportMeta: { exportTimestamp: new Date().toISOString(), exportedBy: user.name || user.username, role: 'secretary', scope: 'assigned-groups' },
    };
  }
  return JSON.stringify(payload, null, 2);
}

export function importDB(current: Database, incoming: Database): { db: Database; result: MergeResult } {
  const result: MergeResult = {
    studentsUpdated: 0,
    studentsAdded: 0,
    teachersUpdated: 0,
    teachersAdded: 0,
    groupsUpdated: 0,
    groupsAdded: 0,
    attendanceMerged: 0,
    paymentsMerged: 0,
    materialsMerged: 0,
    examScoresMerged: 0,
  };

  const db: Database = {
    users: current.users,
    branches: [...current.branches],
    students: [...current.students],
    teachers: [...current.teachers],
    groups: [...current.groups],
    attendance: [...current.attendance],
    payments: [...current.payments],
    expenses: [...current.expenses],
    salaries: [...current.salaries],
    gradePrices: current.gradePrices,
    materials: [...current.materials],
    exams: [...current.exams],
    examScores: [...current.examScores],
    auditLog: [...current.auditLog],
    globalProfitModel: incoming.globalProfitModel ?? current.globalProfitModel,
    globalProfitValue: incoming.globalProfitValue ?? current.globalProfitValue,
    allowProfitOverride: incoming.allowProfitOverride ?? current.allowProfitOverride,
    teacherArrears: [...(incoming.teacherArrears ?? current.teacherArrears ?? [])],
    secretarySalaries: [...(incoming.secretarySalaries ?? current.secretarySalaries ?? [])],
    idCardPrice: incoming.idCardPrice ?? current.idCardPrice,
    siblingDiscountPercent: incoming.siblingDiscountPercent ?? current.siblingDiscountPercent,
    twinDiscountPercent: incoming.twinDiscountPercent ?? current.twinDiscountPercent,
    centerName: incoming.centerName ?? current.centerName,
    centerLogo: incoming.centerLogo ?? current.centerLogo,
    qrEnabled: incoming.qrEnabled ?? current.qrEnabled,
    syncStamp: { ...current.syncStamp },
    staffAdjustments: [...(incoming.staffAdjustments ?? []), ...current.staffAdjustments],
    contactNotes: [...(incoming.contactNotes ?? []), ...current.contactNotes],
    exportMeta: incoming.exportMeta ?? current.exportMeta,
    staff: [...(incoming.staff ?? []), ...current.staff],
    staffAttendance: [...(incoming.staffAttendance ?? []), ...current.staffAttendance],
    staffPayouts: [...(incoming.staffPayouts ?? []), ...current.staffPayouts],
    installmentPlans: [...(incoming.installmentPlans ?? []), ...current.installmentPlans],
    meta: { ...current.meta },
  };

  // Merge branches by id
  const branchMap = new Map(db.branches.map((b) => [b.id, b]));
  for (const b of incoming.branches ?? []) {
    branchMap.set(b.id, { ...branchMap.get(b.id) ?? {}, ...b });
    if (!db.branches.find((x) => x.id === b.id)) db.branches.push(b);
  }

  // Merge students by id
  const studentMap = new Map(db.students.map((s) => [s.id, s]));
  for (const s of incoming.students) {
    if (studentMap.has(s.id)) {
      studentMap.set(s.id, { ...studentMap.get(s.id)!, ...s });
      result.studentsUpdated++;
    } else {
      studentMap.set(s.id, s);
      db.students.push(s);
      result.studentsAdded++;
    }
  }

  // Merge teachers by id
  const teacherMap = new Map(db.teachers.map((t) => [t.id, t]));
  for (const t of incoming.teachers) {
    if (teacherMap.has(t.id)) {
      teacherMap.set(t.id, { ...teacherMap.get(t.id)!, ...t });
      result.teachersUpdated++;
    } else {
      teacherMap.set(t.id, t);
      db.teachers.push(t);
      result.teachersAdded++;
    }
  }

  // Merge groups by id
  const groupMap = new Map(db.groups.map((g) => [g.id, g]));
  for (const g of incoming.groups) {
    if (groupMap.has(g.id)) {
      groupMap.set(g.id, { ...groupMap.get(g.id)!, ...g });
      result.groupsUpdated++;
    } else {
      groupMap.set(g.id, g);
      db.groups.push(g);
      result.groupsAdded++;
    }
  }

  // Merge attendance - dedupe by studentId+groupId+date+status
  const attKeys = new Set(db.attendance.map((a) => `${a.studentId}|${a.groupId}|${a.date}|${a.status}`));
  for (const a of incoming.attendance) {
    const key = `${a.studentId}|${a.groupId}|${a.date}|${a.status}`;
    if (!attKeys.has(key)) {
      attKeys.add(key);
      db.attendance.push(a);
      result.attendanceMerged++;
    }
  }

  // Merge payments - dedupe by studentId+date+amount+month+paymentType
  const payKeys = new Set(db.payments.map((p) => `${p.studentId}|${p.date}|${p.amount}|${p.month}|${p.paymentType}|${p.bookTitle || ''}`));
  for (const p of incoming.payments) {
    const key = `${p.studentId}|${p.date}|${p.amount}|${p.month}|${p.paymentType}|${p.bookTitle || ''}`;
    if (!payKeys.has(key)) {
      payKeys.add(key);
      db.payments.push(p);
      result.paymentsMerged++;
    }
  }

  // Merge materials - dedupe by id
  const matIds = new Set(db.materials.map((m) => m.id));
  for (const m of incoming.materials) {
    if (!matIds.has(m.id)) {
      matIds.add(m.id);
      db.materials.push(m);
      result.materialsMerged++;
    }
  }

  // Merge examScores - dedupe by id
  const examIds = new Set(db.examScores.map((e) => e.id));
  for (const e of incoming.examScores) {
    if (!examIds.has(e.id)) {
      examIds.add(e.id);
      db.examScores.push(e);
      result.examScoresMerged++;
    }
  }

  // Merge expenses - dedupe by id
  const expIds = new Set(db.expenses.map((e) => e.id));
  for (const e of incoming.expenses ?? []) {
    if (!expIds.has(e.id)) {
      expIds.add(e.id);
      db.expenses.push(e);
    }
  }

  // Merge salaries - dedupe by id
  const salIds = new Set(db.salaries.map((s) => s.id));
  for (const s of incoming.salaries ?? []) {
    if (!salIds.has(s.id)) {
      salIds.add(s.id);
      db.salaries.push(s);
    }
  }

  // Update nextStudentId if incoming has higher
  if (incoming.meta?.nextStudentId && incoming.meta.nextStudentId > db.meta.nextStudentId) {
    db.meta.nextStudentId = incoming.meta.nextStudentId;
  }

  // Merge gradePrices if incoming has any
  if (incoming.gradePrices?.length) {
    const priceMap = new Map(db.gradePrices.map((g) => [g.grade, g]));
    for (const gp of incoming.gradePrices) {
      priceMap.set(gp.grade, gp);
    }
    db.gradePrices = Array.from(priceMap.values());
  }

  // Merge users by id (keep current, add new from incoming)
  const userIds = new Set(db.users.map((u) => u.id));
  for (const u of incoming.users ?? []) {
    if (!userIds.has(u.id)) {
      db.users.push(u);
    }
  }

  // Merge exams - dedupe by id
  const existingExamIds = new Set(db.exams.map((e) => e.id));
  for (const e of incoming.exams ?? []) {
    if (!existingExamIds.has(e.id)) {
      existingExamIds.add(e.id);
      db.exams.push(e);
    }
  }

  return { db, result };
}

export function formatMergeResult(r: MergeResult): string {
  const parts: string[] = [];
  if (r.studentsUpdated) parts.push(`تحديث ${r.studentsUpdated} طالب`);
  if (r.studentsAdded) parts.push(`إضافة ${r.studentsAdded} طالب`);
  if (r.teachersUpdated) parts.push(`تحديث ${r.teachersUpdated} معلم`);
  if (r.teachersAdded) parts.push(`إضافة ${r.teachersAdded} معلم`);
  if (r.groupsUpdated) parts.push(`تحديث ${r.groupsUpdated} مجموعة`);
  if (r.groupsAdded) parts.push(`إضافة ${r.groupsAdded} مجموعة`);
  if (r.attendanceMerged) parts.push(`دمج ${r.attendanceMerged} سجل حضور`);
  if (r.paymentsMerged) parts.push(`دمج ${r.paymentsMerged} دفعة`);
  if (r.materialsMerged) parts.push(`دمج ${r.materialsMerged} مذكرة`);
  if (r.examScoresMerged) parts.push(`دمج ${r.examScoresMerged} درجة`);
  return parts.length ? `تم دمج البيانات بنجاح! (${parts.join('، ')})` : 'تم دمج البيانات بنجاح!';
}
