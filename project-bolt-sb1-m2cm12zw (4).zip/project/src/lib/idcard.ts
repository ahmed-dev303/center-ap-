import type { Student, Group } from './types';
import { getCenterBrand, brandLogoHTML } from './branding';
import { generateStudentCode } from './qr';
import { studentGroupIds } from './scoping';

function cardHTML(student: Student, groups: Group[], qrDataUrl?: string): string {
  const brand = getCenterBrand();
  const sGroupIds = studentGroupIds(student);
  const groupNames = sGroupIds
    .map((id) => groups.find((g) => g.id === id)?.name)
    .filter(Boolean)
    .join('، ') || '—';
  const qrValue = student.qrCode || generateStudentCode(student.id);
  const qrImg = qrDataUrl
    ? `<div class="qr-box"><img src="${qrDataUrl}" alt="QR" class="qr-img" /></div>`
    : '';

  return `
    <div class="id-card">
      <div class="card-header">
        <div class="logo">${brandLogoHTML(brand.logo, 36)}</div>
        <div class="title">
          <span class="name">${brand.name}</span>
          <span class="sub">Student ID Card</span>
        </div>
        <div class="badge">بطاقة طالب</div>
      </div>
      <div class="card-body">
        <div class="avatar">${student.name.charAt(0)}</div>
        <div class="info">
          <div class="student-name">${student.name}</div>
          <div class="row"><span class="label">الكود:</span> <span class="val">${qrValue}</span></div>
          <div class="row"><span class="label">الصف:</span> <span class="val">${student.grade}</span></div>
          <div class="row"><span class="label">المجموعة:</span> <span class="val">${groupNames}</span></div>
        </div>
        ${qrImg}
      </div>
    </div>`;
}

const printStyles = `
  @page { size: A4; margin: 8mm; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Cairo', sans-serif; background: #fff; }
  .sheet { display: grid; grid-template-columns: repeat(2, 1fr); grid-auto-rows: 64mm; gap: 0; padding: 0; }
  .id-card {
    border: 1px dashed #cbd5e1;
    padding: 6mm 5mm;
    display: flex;
    flex-direction: column;
    background: linear-gradient(135deg, #1e3a5f 0%, #2d5a8e 100%);
    color: #fff;
    position: relative;
    overflow: hidden;
    page-break-inside: avoid;
  }
  .card-header { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
  .logo { display: flex; align-items: center; justify-content: center; }
  .title { display: flex; flex-direction: column; flex: 1; min-width: 0; }
  .title .name { font-weight: 800; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .title .sub { font-size: 8px; opacity: 0.7; }
  .badge { background: rgba(255,255,255,0.2); border-radius: 16px; padding: 3px 8px; font-size: 8px; font-weight: 700; white-space: nowrap; }
  .card-body { display: flex; gap: 10px; flex: 1; align-items: center; }
  .avatar { width: 36px; height: 36px; border-radius: 50%; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 800; flex-shrink: 0; }
  .info { flex: 1; min-width: 0; }
  .student-name { font-size: 15px; font-weight: 800; margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .row { font-size: 10px; margin-bottom: 3px; opacity: 0.9; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .row .label { font-weight: 700; }
  .qr-box { width: 40px; height: 40px; background: #fff; border-radius: 6px; padding: 3px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; }
  .qr-img { width: 34px; height: 34px; }
`;

function pageShell(title: string, body: string): string {
  return `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>${title}</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet"><style>${printStyles}</style></head><body><div class="sheet">${body}</div><script>window.onload=function(){setTimeout(function(){window.print();},500);}</script></body></html>`;
}

export function printIDCards(students: Student[], groups: Group[]): void {
  const cards = students.map((s) => cardHTML(s, groups, groups.find((g) => g.id === (studentGroupIds(s)[0] || s.groupId)) ? undefined : undefined)).join('');
  const brand = getCenterBrand();
  const html = pageShell(`كروت الطلاب - ${brand.name}`, cards);
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.write(html);
  w.document.close();
}

export function printSingleIDCard(student: Student, groups: Group[], qrDataUrl?: string): void {
  const card = cardHTML(student, groups, qrDataUrl);
  const html = pageShell(`كارت ${student.name}`, card);
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.write(html);
  w.document.close();
}
