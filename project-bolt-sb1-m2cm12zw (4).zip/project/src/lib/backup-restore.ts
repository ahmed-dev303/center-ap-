import type { Database } from './types';
import { loadDB } from './db';

const REQUIRED_KEYS: (keyof Database)[] = [
  'users', 'students', 'groups', 'attendance', 'payments',
];

export interface ValidationResult {
  valid: boolean;
  data: Database | null;
  error: string;
}

export function validateBackup(raw: unknown): ValidationResult {
  if (!raw || typeof raw !== 'object') {
    return { valid: false, data: null, error: 'الملف ليس بصيغة JSON صالحة' };
  }

  const obj = raw as Record<string, unknown>;

  for (const key of REQUIRED_KEYS) {
    if (!Array.isArray(obj[key])) {
      return { valid: false, data: null, error: `الملف لا يحتوي على مفتاح "${key}" المطلوب` };
    }
  }

  const base = loadDB();
  const merged: Database = {
    ...base,
    ...(obj as Partial<Database>),
    syncStamp: {
      lastImportTime: new Date().toISOString(),
      lastImportActor: 'استيراد تلقائي',
    },
  };

  return { valid: true, data: merged, error: '' };
}

export async function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(reader.error);
    reader.readAsText(file);
  });
}

export async function readFileSystemHandle(handle: FileSystemFileHandle): Promise<string> {
  const file = await handle.getFile();
  return readFileAsText(file);
}
