let memoryStore: Record<string, string> = {};

function hasLocalStorage(): boolean {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return false;
    const testKey = '__ls_test__';
    window.localStorage.setItem(testKey, '1');
    window.localStorage.removeItem(testKey);
    return true;
  } catch {
    return false;
  }
}

const lsAvailable = hasLocalStorage();

export function safeGetItem(key: string): string | null {
  try {
    if (lsAvailable) return window.localStorage.getItem(key);
    return memoryStore[key] ?? null;
  } catch {
    return memoryStore[key] ?? null;
  }
}

export function safeSetItem(key: string, value: string): void {
  try {
    if (lsAvailable) {
      window.localStorage.setItem(key, value);
    } else {
      memoryStore[key] = value;
    }
  } catch {
    memoryStore[key] = value;
  }
}

export function safeRemoveItem(key: string): void {
  try {
    if (lsAvailable) {
      window.localStorage.removeItem(key);
    }
    delete memoryStore[key];
  } catch {
    delete memoryStore[key];
  }
}

export function isMediaDevicesSupported(): boolean {
  try {
    return typeof navigator !== 'undefined' && !!navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function';
  } catch {
    return false;
  }
}

export function safeVibrate(pattern: number | number[]): void {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      navigator.vibrate(pattern);
    }
  } catch {
    // ignore
  }
}
