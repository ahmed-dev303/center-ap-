import type { Database, Student, Group, AttendanceRecord, Payment, StudyMaterial, AuditEntry, Teacher, Expense } from '../lib/types';
import type { User } from '../lib/types';

export function studentGroupIds(s: Student): string[] {
  if (Array.isArray(s.groupIds) && s.groupIds.length > 0) return s.groupIds;
  if (s.groupId) return [s.groupId];
  return [];
}

export function studentInGroup(s: Student, groupId: string): boolean {
  return studentGroupIds(s).includes(groupId);
}

export interface ScopedData {
  students: Student[];
  groups: Group[];
  attendance: AttendanceRecord[];
  payments: Payment[];
  materials: StudyMaterial[];
  auditLog: AuditEntry[];
}

export function getScopedData(db: Database, user: User | null): ScopedData {
  if (!user) return { students: [], groups: [], attendance: [], payments: [], materials: [], auditLog: [] };

  if (user.role === 'teacher') {
    let teacherGroups: Group[];

    if (user.teacherId) {
      teacherGroups = db.groups.filter((g) => g.teacherId === user.teacherId);
    } else {
      teacherGroups = [];
    }

    if (user.branchIds && user.branchIds.length > 0) {
      const branchSet = new Set(user.branchIds);
      const branchGroups = db.groups.filter((g) => g.branchId && branchSet.has(g.branchId));
      const groupIds = new Set(teacherGroups.map((g) => g.id));
      for (const g of branchGroups) groupIds.add(g.id);
      teacherGroups = db.groups.filter((g) => groupIds.has(g.id));
    }

    const groupIds = new Set(teacherGroups.map((g) => g.id));
    const students = db.students.filter((s) => studentGroupIds(s).some((id) => groupIds.has(id)));
    const studentIds = new Set(students.map((s) => s.id));
    const attendance = db.attendance.filter((a) => groupIds.has(a.groupId));
    const payments = db.payments.filter(
      (p) => (p.groupId && groupIds.has(p.groupId)) || studentIds.has(p.studentId)
    );
    const materials = db.materials.filter((m) => groupIds.has(m.groupId));
    return { students, groups: teacherGroups, attendance, payments, materials, auditLog: [] };
  }

  if (user.role === 'secretary' && user.linkedTeacherId) {
    const linkedGroups = db.groups.filter((g) => g.teacherId === user.linkedTeacherId);
    const groupIds = new Set(linkedGroups.map((g) => g.id));
    const students = db.students.filter((s) => studentGroupIds(s).some((id) => groupIds.has(id)));
    const studentIds = new Set(students.map((s) => s.id));
    const linkType = user.linkType || 'both';

    const attendance = linkType === 'payments' ? [] : db.attendance.filter((a) => groupIds.has(a.groupId));
    const payments = linkType === 'attendance' ? [] : db.payments.filter(
      (p) => (p.groupId && groupIds.has(p.groupId)) || studentIds.has(p.studentId)
    );
    const materials = linkType === 'attendance' ? [] : db.materials.filter((m) => groupIds.has(m.groupId));

    return {
      students,
      groups: linkedGroups,
      attendance,
      payments,
      materials,
      auditLog: [],
    };
  }

  return {
    students: db.students,
    groups: db.groups,
    attendance: db.attendance,
    payments: db.payments,
    materials: db.materials,
    auditLog: db.auditLog,
  };
}

export function canSecretaryAccessFeature(user: User | null, feature: 'attendance' | 'payments'): boolean {
  if (!user || user.role !== 'secretary') return true;
  if (!user.linkedTeacherId) return true;
  const linkType = user.linkType || 'both';
  if (linkType === 'both') return true;
  if (linkType === 'attendance') return feature === 'attendance';
  if (linkType === 'payments') return feature === 'payments';
  return true;
}

export function filterByCenter<T extends { branchId?: string | null }>(
  items: T[],
  centerId: string | null
): T[] {
  if (!centerId) return items;
  return items.filter((item) => item.branchId === centerId);
}

export function getCenterScopedData(db: Database, centerId: string | null): {
  students: Student[];
  teachers: Teacher[];
  groups: Group[];
  attendance: AttendanceRecord[];
  payments: Payment[];
  expenses: Expense[];
  materials: StudyMaterial[];
} {
  if (!centerId) {
    return {
      students: db.students,
      teachers: db.teachers,
      groups: db.groups,
      attendance: db.attendance,
      payments: db.payments,
      expenses: db.expenses,
      materials: db.materials,
    };
  }
  const groups = db.groups.filter((g) => g.branchId === centerId);
  const groupIds = new Set(groups.map((g) => g.id));
  const students = db.students.filter((s) => s.branchId === centerId || studentGroupIds(s).some((id) => groupIds.has(id)));
  const studentIds = new Set(students.map((s) => s.id));
  return {
    students,
    teachers: db.teachers.filter((t) => t.branchId === centerId),
    groups,
    attendance: db.attendance.filter((a) => groupIds.has(a.groupId)),
    payments: db.payments.filter((p) => p.branchId === centerId || studentIds.has(p.studentId) || (p.groupId && groupIds.has(p.groupId))),
    expenses: db.expenses.filter((e) => e.branchId === centerId),
    materials: db.materials.filter((m) => groupIds.has(m.groupId)),
  };
}
