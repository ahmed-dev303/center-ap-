import type { Database } from './types';
import { todayStr } from './date';

/**
 * Parse a schedule string like "السبت والأربعاء 4م" to extract the hour.
 * Returns the hour (0-23) or null if unparseable.
 */
function parseScheduleHour(schedule: string): number | null {
  const match = schedule.match(/(\d+)\s*م/);
  if (!match) return null;
  let h = parseInt(match[1], 10);
  if (h >= 1 && h <= 11) h += 12; // PM
  if (h === 12) h = 12; // 12م = noon (unlikely but handle)
  return h >= 0 && h <= 23 ? h : null;
}

/**
 * Check if today's day name matches any Arabic day name in the schedule.
 */
function isSessionToday(schedule: string): boolean {
  const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const today = new Date().getDay(); // 0=Sunday..6=Saturday
  const todayName = dayNames[today];
  return schedule.includes(todayName);
}

/**
 * Check if the session time has passed today.
 */
function hasSessionPassed(schedule: string): boolean {
  const hour = parseScheduleHour(schedule);
  if (hour === null) {
    // If we can't parse the time, consider it passed if it's after 8 PM
    return new Date().getHours() >= 20;
  }
  return new Date().getHours() >= hour;
}

export interface AutoAbsenceResult {
  added: number;
  groups: string[];
}

/**
 * Automatically mark absent students whose group session has passed today
 * and who don't have any attendance record for today.
 * This is called on app load and can be triggered manually.
 */
export function runAutoAbsence(db: Database): AutoAbsenceResult {
  const today = todayStr();
  let added = 0;
  const affectedGroups = new Set<string>();

  for (const group of db.groups) {
    // Only process groups with a schedule that indicates today is a session day
    if (group.schedule && !isSessionToday(group.schedule)) continue;

    // Check if session time has passed
    if (group.schedule && !hasSessionPassed(group.schedule)) continue;

    // Get students in this group
    const groupStudents = db.students.filter(
      (s) => s.groupId === group.id
    );

    // Find students who have NO attendance record for today
    for (const student of groupStudents) {
      const hasRecord = db.attendance.some(
        (a) => a.studentId === student.id && a.date === today && a.groupId === group.id
      );

      if (!hasRecord) {
        db.attendance.push({
          id: `att_auto_${student.id}_${group.id}_${today}`,
          studentId: student.id,
          groupId: group.id,
          date: today,
          status: 'absent',
          createdAt: new Date().toISOString(),
        });
        added++;
        affectedGroups.add(group.id);
      }
    }
  }

  return { added, groups: Array.from(affectedGroups) };
}

/**
 * Check if auto-absence has already run for today (by looking for auto-generated records).
 */
export function hasAutoAbsenceRunToday(db: Database): boolean {
  const today = todayStr();
  return db.attendance.some((a) => a.id.startsWith('att_auto_') && a.date === today);
}
