let audioCtx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    try {
      const Ctor = window.AudioContext || (window as any).webkitAudioContext;
      if (!Ctor) return null;
      audioCtx = new Ctor();
    } catch {
      return null;
    }
  }
  return audioCtx;
}

function playTone(freq: number, duration: number, type: OscillatorType = 'sine', volume = 0.3): void {
  try {
    const ctx = getCtx();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      ctx.resume().catch(function () { /* ignore */ });
    }
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch {
    // Audio not supported — silent fallback
  }
}

export function playSuccessSound(): void {
  playTone(880, 0.12, 'sine', 0.3);
  setTimeout(function () { playTone(1320, 0.15, 'sine', 0.3); }, 80);
}

export function playWarningSound(): void {
  playTone(440, 0.15, 'square', 0.25);
  setTimeout(function () { playTone(440, 0.15, 'square', 0.25); }, 200);
}

export function playErrorSound(): void {
  playTone(200, 0.3, 'sawtooth', 0.25);
}

export function isAudioSupported(): boolean {
  return getCtx() !== null;
}
