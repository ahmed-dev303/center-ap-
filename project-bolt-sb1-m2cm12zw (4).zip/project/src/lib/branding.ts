const DEFAULT_CENTER_NAME = 'سنتر الأفضل';

export interface CenterBrand {
  name: string;
  logo: string | null;
}

export function getCenterBrand(): CenterBrand {
  try {
    const raw = localStorage.getItem('al_afdal_db_v1');
    if (raw) {
      const db = JSON.parse(raw);
      return {
        name: (db.centerName as string | undefined) ?? DEFAULT_CENTER_NAME,
        logo: (db.centerLogo as string | null | undefined) ?? null,
      };
    }
  } catch {
    // ignore
  }
  return { name: DEFAULT_CENTER_NAME, logo: null };
}

export function brandLogoHTML(logo: string | null, size = 40): string {
  if (logo) {
    return `<img src="${logo}" alt="logo" style="width:${size}px;height:${size}px;object-fit:contain;border-radius:8px;" />`;
  }
  return `<div style="font-size:${Math.round(size * 0.7)}px;line-height:1;">🎓</div>`;
}
