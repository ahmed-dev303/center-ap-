import type { Database, User, Teacher, Group, Student, GradePrice, Branch, Expense, Salary, Staff, StaffAttendance, StaffPayout, InstallmentPlan, Exam, ExamScore, PayoutType } from './types';
import { safeGetItem, safeSetItem, safeRemoveItem } from './safe-storage';

const STORAGE_KEY = 'al_afdal_db_v1';

const ACADEMIC_GRADES = [
  'الصف الأول الابتدائي',
  'الصف الثاني الابتدائي',
  'الصف الثالث الابتدائي',
  'الصف الرابع الابتدائي',
  'الصف الخامس الابتدائي',
  'الصف السادس الابتدائي',
  'الصف الأول الإعدادي',
  'الصف الثاني الإعدادي',
  'الصف الثالث الإعدادي',
  'الصف الأول الثانوي',
  'الصف الثاني الثانوي',
  'الصف الثالث الثانوي',
];

export function getAcademicGrades(): string[] {
  return [...ACADEMIC_GRADES];
}

function seed(): Database {
  const now = new Date().toISOString();
  const today = new Date();
  const dateStr = (d: Date) => d.toISOString().slice(0, 10);
  const daysAgo = (n: number) => { const d = new Date(today); d.setDate(d.getDate() - n); return dateStr(d); };

  const branches: Branch[] = [
    { id: 'b1', name: 'الفرع الرئيسي', address: 'شارع الجامعة - وسط البلد', createdAt: now },
    { id: 'b2', name: 'فرع المعادي', address: 'شارع 9 - المعادي', createdAt: now },
    { id: 'b3', name: 'فرع مدينة نصر', address: 'شارع مكرم عبيد - مدينة نصر', createdAt: now },
  ];

  const users: User[] = [
    { id: 'u1', username: 'admin', password: 'admin123', name: 'مدير السنتر', role: 'admin' },
    { id: 'u2', username: 'sec', password: 'sec123', name: 'سكرتيرة السنتر', role: 'secretary', linkedTeacherId: '', linkType: 'both', specialty: 'full', branchIds: ['b1'], phone: '01000000001', payModel: 'fixed_monthly', rate: 3500 },
    { id: 'u3', username: 'teacher', password: 'teach123', name: 'أ. أحمد محمود', role: 'teacher', teacherId: 't1', branchIds: ['b1'] },
    { id: 'u4', username: 'teacher2', password: 'teach456', name: 'أ. محمود علي', role: 'teacher', teacherId: 't3', branchIds: ['b3'] },
    { id: 'u5', username: 'sec_att', password: 'att123', name: 'سكرتير الحضور', role: 'secretary', linkedTeacherId: 't1', linkType: 'attendance', specialty: 'full', branchIds: ['b1'], phone: '01000000002', payModel: 'per_session', rate: 40 },
    { id: 'u6', username: 'sec_pay', password: 'pay123', name: 'سكرتير التحصيل', role: 'secretary', linkedTeacherId: 't1', linkType: 'payments', specialty: 'full', branchIds: ['b1'], phone: '01000000003', payModel: 'percentage', rate: 5 },
    { id: 'u7', username: 'sec_full', password: 'full123', name: 'سكرتير شامل', role: 'secretary', linkedTeacherId: 't3', linkType: 'both', specialty: 'full', branchIds: ['b3'], phone: '01000000004', payModel: 'fixed_monthly', rate: 3000 },
    { id: 'u8', username: 'super', password: 'super123', name: 'مشرف عام', role: 'supervisor', branchIds: ['b1'], phone: '01000000005', payModel: 'fixed_monthly', rate: 2500 },
  ];

  const teachers: Teacher[] = [
    { id: 't1', name: 'أ. أحمد محمود', phone: '01001234567', subject: 'الرياضيات', branchId: 'b1', centerSharePercent: 20, createdAt: now },
    { id: 't2', name: 'أ. سارة عبد الله', phone: '01098765432', subject: 'اللغة العربية', branchId: 'b2', centerSharePercent: 25, createdAt: now },
    { id: 't3', name: 'أ. محمود علي', phone: '01155678901', subject: 'العلوم', branchId: 'b3', centerSharePercent: 20, createdAt: now },
  ];

  const groups: Group[] = [
    { id: 'g1', name: 'مجموعة الرياضيات - إعدادي', teacherId: 't1', subject: 'الرياضيات', grade: 'الصف الأول الإعدادي', schedule: 'السبت والأربعاء 4م', scheduleDays: ['السبت', 'الأربعاء'], startTime: '16:00', endTime: '18:00', halfwayTime: '17:00', branchId: 'b1', billingModel: 'per_session', customPrice: null, payoutType: 'fixed_seat', payoutValue: 20, monthlyFee: null, packageFee: null, createdAt: now },
    { id: 'g2', name: 'مجموعة الرياضيات - ثانوي', teacherId: 't1', subject: 'الرياضيات', grade: 'الصف الأول الثانوي', schedule: 'الأحد والثلاثاء 5م', scheduleDays: ['الأحد', 'الثلاثاء'], startTime: '17:00', endTime: '19:00', halfwayTime: '18:00', branchId: 'b1', billingModel: 'monthly', customPrice: null, payoutType: 'percentage', payoutValue: 80, monthlyFee: 400, packageFee: null, createdAt: now },
    { id: 'g3', name: 'مجموعة العربية - إعدادي', teacherId: 't2', subject: 'اللغة العربية', grade: 'الصف الثاني الإعدادي', schedule: 'الاثنين والخميس 3م', scheduleDays: ['الاثنين', 'الخميس'], startTime: '15:00', endTime: '17:00', halfwayTime: '16:00', branchId: 'b2', billingModel: 'per_session', customPrice: null, payoutType: 'fixed_seat', payoutValue: 25, monthlyFee: null, packageFee: null, createdAt: now },
    { id: 'g4', name: 'مجموعة العلوم', teacherId: 't3', subject: 'العلوم', grade: 'الصف الثالث الإعدادي', schedule: 'السبت والثلاثاء 6م', scheduleDays: ['السبت', 'الثلاثاء'], startTime: '18:00', endTime: '20:00', halfwayTime: '19:00', branchId: 'b3', billingModel: 'full_package', customPrice: null, payoutType: 'flat_per_session', payoutValue: 30, monthlyFee: null, packageFee: 1500, createdAt: now },
    { id: 'g5', name: 'مجموعة الرياضيات - ابتدائي', teacherId: 't1', subject: 'الرياضيات', grade: 'الصف السادس الابتدائي', schedule: 'الجمعة 2م', scheduleDays: ['الجمعة'], startTime: '14:00', endTime: '16:00', halfwayTime: '15:00', branchId: 'b1', billingModel: 'per_session', customPrice: null, payoutType: 'fixed_seat', payoutValue: 15, monthlyFee: null, packageFee: null, createdAt: now },
  ];

  const students: Student[] = [
    { id: 1001, name: 'محمود يوسف', phone: '01223344556', parentPhone: '01223344550', parentName: 'السيد يوسف', motherPhone: '01223344599', grade: 'الصف الأول الإعدادي', groupId: 'g1', groupIds: ['g1'], branchId: 'b1', note: '', qrCode: 'STD-01001', createdAt: now },
    { id: 1002, name: 'فاطمة علي', phone: '01223344557', parentPhone: '01223344551', parentName: 'السيد علي', motherPhone: '01223344598', grade: 'الصف الأول الإعدادي', groupId: 'g1', groupIds: ['g1'], branchId: 'b1', note: 'ولي الأمر طلب متابعة المستوى', qrCode: 'STD-01002', createdAt: now },
    { id: 1003, name: 'خالد حسن', phone: '01223344558', parentPhone: '01223344552', parentName: 'السيد حسن', grade: 'الصف الأول الثانوي', groupId: 'g2', groupIds: ['g2'], branchId: 'b1', note: '', qrCode: 'STD-01003', hasSiblingDiscount: true, discountType: 'sibling', discountPercent: 10, createdAt: now },
    { id: 1004, name: 'نورا سمير', phone: '01223344559', parentPhone: '01223344553', parentName: 'السيد سمير', grade: 'الصف الثاني الإعدادي', groupId: 'g3', groupIds: ['g3'], branchId: 'b2', note: '', qrCode: 'STD-01004', createdAt: now },
    { id: 1005, name: 'عمر هشام', phone: '01223344560', parentPhone: '01223344554', parentName: 'السيد هشام', grade: 'الصف الثالث الإعدادي', groupId: 'g4', groupIds: ['g4'], branchId: 'b3', note: '', qrCode: 'STD-01005', hasSpecialDiscount: true, specialDiscountPercent: 15, specialDiscountNote: 'خصم خاص للأوائل', createdAt: now },
    { id: 1006, name: 'سلمى أحمد', phone: '01223344561', parentPhone: '01223344555', parentName: 'السيد أحمد', grade: 'الصف الأول الثانوي', groupId: 'g2', groupIds: ['g2'], branchId: 'b1', note: '', qrCode: 'STD-01006', hasSiblingDiscount: true, discountType: 'twin', discountPercent: 20, createdAt: now },
    { id: 1007, name: 'يوسف محمد', phone: '01223344562', parentPhone: '01223344556', parentName: 'السيد محمد', grade: 'الصف السادس الابتدائي', groupId: 'g5', groupIds: ['g5'], branchId: 'b1', note: '', qrCode: 'STD-01007', createdAt: now },
    { id: 1008, name: 'مريم خالد', phone: '01223344563', parentPhone: '01223344557', parentName: 'السيد خالد', grade: 'الصف الثالث الإعدادي', groupId: 'g4', groupIds: ['g4'], branchId: 'b3', note: '', qrCode: 'STD-01008', createdAt: now },
  ];

  const gradePrices: GradePrice[] = [
    { grade: 'الصف الأول الابتدائي', price: 60 },
    { grade: 'الصف الثاني الابتدائي', price: 65 },
    { grade: 'الصف الثالث الابتدائي', price: 70 },
    { grade: 'الصف الرابع الابتدائي', price: 75 },
    { grade: 'الصف الخامس الابتدائي', price: 80 },
    { grade: 'الصف السادس الابتدائي', price: 90 },
    { grade: 'الصف الأول الإعدادي', price: 120 },
    { grade: 'الصف الثاني الإعدادي', price: 130 },
    { grade: 'الصف الثالث الإعدادي', price: 150 },
    { grade: 'الصف الأول الثانوي', price: 200 },
    { grade: 'الصف الثاني الثانوي', price: 220 },
    { grade: 'الصف الثالث الثانوي', price: 250 },
  ];

  const attendance: Database['attendance'] = [
    { id: 'att1', studentId: 1001, groupId: 'g1', date: daysAgo(7), status: 'present', createdAt: now },
    { id: 'att2', studentId: 1002, groupId: 'g1', date: daysAgo(7), status: 'present', createdAt: now },
    { id: 'att3', studentId: 1001, groupId: 'g1', date: daysAgo(5), status: 'absent', createdAt: now },
    { id: 'att4', studentId: 1002, groupId: 'g1', date: daysAgo(5), status: 'present', createdAt: now },
    { id: 'att5', studentId: 1003, groupId: 'g2', date: daysAgo(6), status: 'present', createdAt: now },
    { id: 'att6', studentId: 1006, groupId: 'g2', date: daysAgo(6), status: 'present', createdAt: now },
    { id: 'att7', studentId: 1004, groupId: 'g3', date: daysAgo(4), status: 'present', createdAt: now },
    { id: 'att8', studentId: 1005, groupId: 'g4', date: daysAgo(3), status: 'absent', createdAt: now },
    { id: 'att9', studentId: 1008, groupId: 'g4', date: daysAgo(3), status: 'present', createdAt: now },
    { id: 'att10', studentId: 1007, groupId: 'g5', date: daysAgo(2), status: 'present', createdAt: now },
  ];

  const payments: Database['payments'] = [
    { id: 'pay1', studentId: 1001, groupId: 'g1', branchId: 'b1', amount: 120, date: daysAgo(10), month: daysAgo(10).slice(0, 7), method: 'cash', paymentType: 'session', note: '', createdAt: now },
    { id: 'pay2', studentId: 1002, groupId: 'g1', branchId: 'b1', amount: 120, date: daysAgo(9), month: daysAgo(9).slice(0, 7), method: 'cash', paymentType: 'session', note: '', createdAt: now },
    { id: 'pay3', studentId: 1003, groupId: 'g2', branchId: 'b1', amount: 360, date: daysAgo(8), month: daysAgo(8).slice(0, 7), method: 'transfer', paymentType: 'tuition', note: 'دفعة شهرية', discountType: 'sibling', discountPercent: 10, createdAt: now },
    { id: 'pay4', studentId: 1006, groupId: 'g2', branchId: 'b1', amount: 320, date: daysAgo(8), month: daysAgo(8).slice(0, 7), method: 'cash', paymentType: 'tuition', note: 'دفعة شهرية', discountType: 'twin', discountPercent: 20, createdAt: now },
    { id: 'pay5', studentId: 1004, groupId: 'g3', branchId: 'b2', amount: 130, date: daysAgo(6), month: daysAgo(6).slice(0, 7), method: 'cash', paymentType: 'session', note: '', createdAt: now },
    { id: 'pay6', studentId: 1005, groupId: 'g4', branchId: 'b3', amount: 1275, date: daysAgo(5), month: daysAgo(5).slice(0, 7), method: 'card', paymentType: 'tuition', note: 'باقة كاملة (خصم 15%)', createdAt: now },
    { id: 'pay7', studentId: 1001, groupId: 'g1', branchId: 'b1', amount: 50, date: daysAgo(4), month: daysAgo(4).slice(0, 7), method: 'cash', paymentType: 'id', note: 'كارت ID', createdAt: now },
    { id: 'pay8', studentId: 1007, groupId: 'g5', branchId: 'b1', amount: 90, date: daysAgo(3), month: daysAgo(3).slice(0, 7), method: 'cash', paymentType: 'session', note: '', createdAt: now },
  ];

  const exams: Exam[] = [
    { id: 'ex1', groupId: 'g1', title: 'امتحان الفصل الأول - جبر', type: 'monthly', date: daysAgo(5), maxScore: 20, createdAt: now },
    { id: 'ex2', groupId: 'g1', title: 'واجب الأسبوع - معادلات', type: 'homework', date: daysAgo(2), maxScore: 10, createdAt: now },
    { id: 'ex3', groupId: 'g2', title: 'امتحان شهري - تفاضل', type: 'monthly', date: daysAgo(4), maxScore: 25, createdAt: now },
    { id: 'ex4', groupId: 'g4', title: 'اختبار قصير - خلايا', type: 'weekly', date: daysAgo(1), maxScore: 15, createdAt: now },
  ];

  const examScores: ExamScore[] = [
    { id: 'sc1', examId: 'ex1', studentId: 1001, groupId: 'g1', examTitle: 'امتحان الفصل الأول - جبر', score: 17, maxScore: 20, note: '', date: daysAgo(5), createdAt: now },
    { id: 'sc2', examId: 'ex1', studentId: 1002, groupId: 'g1', examTitle: 'امتحان الفصل الأول - جبر', score: 19, maxScore: 20, note: 'ممتاز', date: daysAgo(5), createdAt: now },
    { id: 'sc3', examId: 'ex2', studentId: 1001, groupId: 'g1', examTitle: 'واجب الأسبوع - معادلات', score: 8, maxScore: 10, note: '', date: daysAgo(2), createdAt: now },
    { id: 'sc4', examId: 'ex3', studentId: 1003, groupId: 'g2', examTitle: 'امتحان شهري - تفاضل', score: 22, maxScore: 25, note: '', date: daysAgo(4), createdAt: now },
    { id: 'sc5', examId: 'ex3', studentId: 1006, groupId: 'g2', examTitle: 'امتحان شهري - تفاضل', score: 20, maxScore: 25, note: '', date: daysAgo(4), createdAt: now },
    { id: 'sc6', examId: 'ex4', studentId: 1005, groupId: 'g4', examTitle: 'اختبار قصير - خلايا', score: 13, maxScore: 15, note: '', date: daysAgo(1), createdAt: now },
    { id: 'sc7', examId: 'ex4', studentId: 1008, groupId: 'g4', examTitle: 'اختبار قصير - خلايا', score: 14, maxScore: 15, note: 'جيد جداً', date: daysAgo(1), createdAt: now },
  ];

  const materials: Database['materials'] = [
    { id: 'm1', title: 'مذكرة الجبر - الفصل الأول', groupId: 'g1', description: 'مذكرة شاملة لمنهج الجبر', price: 30, stock: 50, createdAt: now },
    { id: 'm2', title: 'مذكرة التفاضل - المراجعة', groupId: 'g2', description: 'مراجعة نهائية في التفاضل', price: 45, stock: 30, createdAt: now },
    { id: 'm3', title: 'مذكرة العلوم - الخلايا', groupId: 'g4', description: 'مذكرة وحدة الخلايا', price: 35, stock: 40, createdAt: now },
  ];

  const expenses: Expense[] = [
    { id: 'exp1', category: 'rent', categoryLabel: 'إيجار', branchId: 'b1', amount: 5000, date: daysAgo(10), note: 'إيجار الشهر', createdAt: now },
    { id: 'exp2', category: 'electricity', categoryLabel: 'كهرباء', branchId: 'b1', amount: 800, date: daysAgo(8), note: 'فاتورة الكهرباء', createdAt: now },
    { id: 'exp3', category: 'printing', categoryLabel: 'طباعة', branchId: 'b1', amount: 600, date: daysAgo(5), note: 'طباعة مذكرات', createdAt: now },
    { id: 'exp4', category: 'other', categoryLabel: 'أجور موظفين', branchId: 'b1', amount: 3500, date: daysAgo(3), note: 'صرف أجور سكرتيرة السنتر', createdAt: now },
    { id: 'exp5', category: 'cleaning', categoryLabel: 'نظافة', branchId: 'b2', amount: 300, date: daysAgo(2), note: 'مصاريف نظافة', createdAt: now },
  ];

  const staff: Staff[] = [
    { id: 'st1', userId: 'u2', name: 'سكرتيرة السنتر', phone: '01000000001', role: 'assistant', payModel: 'fixed_monthly', rate: 3500, branchId: 'b1', active: true, createdAt: now },
    { id: 'st2', userId: 'u5', name: 'سكرتير الحضور', phone: '01000000002', role: 'assistant', payModel: 'per_session', rate: 40, branchId: 'b1', active: true, createdAt: now },
    { id: 'st3', userId: 'u6', name: 'سكرتير التحصيل', phone: '01000000003', role: 'assistant', payModel: 'percentage', rate: 5, branchId: 'b1', active: true, createdAt: now },
    { id: 'st4', userId: 'u7', name: 'سكرتير شامل', phone: '01000000004', role: 'assistant', payModel: 'fixed_monthly', rate: 3000, branchId: 'b3', active: true, createdAt: now },
    { id: 'st5', userId: 'u8', name: 'مشرف عام', phone: '01000000005', role: 'supervisor', payModel: 'fixed_monthly', rate: 2500, branchId: 'b1', active: true, createdAt: now },
  ];

  const staffAttendance: StaffAttendance[] = [
    { id: 'sa1', staffId: 'st1', date: daysAgo(10), clockIn: '09:00', clockOut: '17:00', sessions: 0, hours: 8, note: '', createdAt: now },
    { id: 'sa2', staffId: 'st1', date: daysAgo(5), clockIn: '09:00', clockOut: '17:00', sessions: 0, hours: 8, note: '', createdAt: now },
    { id: 'sa3', staffId: 'st2', date: daysAgo(7), clockIn: null, clockOut: null, sessions: 4, hours: 0, note: '4 حصص', createdAt: now },
    { id: 'sa4', staffId: 'st2', date: daysAgo(3), clockIn: null, clockOut: null, sessions: 5, hours: 0, note: '', createdAt: now },
    { id: 'sa5', staffId: 'st5', date: daysAgo(5), clockIn: '14:00', clockOut: '22:00', sessions: 0, hours: 8, note: '', createdAt: now },
  ];

  const staffPayouts: StaffPayout[] = [
    { id: 'spo1', staffId: 'st1', staffName: 'سكرتيرة السنتر', amount: 3500, date: daysAgo(3), periodLabel: 'راتب شهر', note: 'صرف راتب شهر', createdAt: now },
  ];

  const staffAdjustments: Database['staffAdjustments'] = [
    { id: 'sad1', userId: 'u2', userName: 'سكرتيرة السنتر', type: 'advance', amount: 500, date: daysAgo(6), reason: 'سلفة', month: daysAgo(6).slice(0, 7), createdAt: now },
    { id: 'sad2', userId: 'u8', userName: 'مشرف عام', type: 'reward', amount: 200, date: daysAgo(4), reason: 'مكافأة اجتهاد', month: daysAgo(4).slice(0, 7), createdAt: now },
  ];

  const contactNotes: Database['contactNotes'] = [
    { id: 'cn1', studentId: 1002, text: 'ولي الأمر طلب إرسال تقرير المستوى أسبوعياً', date: daysAgo(5), active: true, createdAt: now },
    { id: 'cn2', studentId: 1005, text: 'الطالب من الأوائل — خصم خاص 15%', date: daysAgo(7), active: true, createdAt: now },
  ];

  const installmentPlans: InstallmentPlan[] = [
    {
      id: 'ip1', studentId: 1005, groupId: 'g4', totalAmount: 1500,
      installments: [
        { id: 'i1', amount: 500, dueDate: daysAgo(10), status: 'paid', paidDate: daysAgo(10), paymentId: 'pay6' },
        { id: 'i2', amount: 500, dueDate: daysAgo(0), status: 'pending', paidDate: null, paymentId: null },
        { id: 'i3', amount: 500, dueDate: daysAgo(-15), status: 'pending', paidDate: null, paymentId: null },
      ],
      createdAt: now,
    },
  ];

  const auditLog: Database['auditLog'] = [
    { id: 'a1', action: 'تسجيل دخول', detail: 'تسجيل دخول مدير السنتر', actorName: 'مدير السنتر', actorRole: 'admin', timestamp: now },
    { id: 'a2', action: 'صرف أجور', detail: 'صرف راتب سكرتيرة السنتر 3500 ج.م', actorName: 'مدير السنتر', actorRole: 'admin', timestamp: now },
  ];

  return {
    users,
    branches,
    students,
    teachers,
    groups,
    attendance,
    payments,
    gradePrices,
    materials,
    exams,
    examScores,
    expenses,
    salaries: [],
    auditLog,
    globalProfitModel: 'percentage',
    globalProfitValue: 20,
    allowProfitOverride: false,
    teacherArrears: [],
    secretarySalaries: [{ userId: 'u2', amount: 3500, locked: true, updatedAt: now }],
    idCardPrice: 50,
    siblingDiscountPercent: 10,
    twinDiscountPercent: 20,
    centerName: 'سنتر الأفضل',
    centerLogo: null,
    qrEnabled: true,
    attendanceOpeningBuffer: 10,
    attendanceClosingPercent: 50,
    allowFlexibleAttendanceTime: false,
    syncStamp: { lastImportTime: null, lastImportActor: null },
    staffAdjustments,
    contactNotes,
    exportMeta: null,
    staff,
    staffAttendance,
    staffPayouts,
    installmentPlans,
    meta: { nextStudentId: 1009 },
  };
}

function migrate(raw: Record<string, unknown>): Database {
  const base = seed();
  const merged: Database = {
    ...base,
    ...raw,
    users: (raw.users as User[] | undefined)?.map((u) => ({ ...u, branchIds: u.branchIds ?? [] })) ?? base.users,
    branches: (raw.branches as Branch[] | undefined) ?? base.branches,
    students: (raw.students as Student[] | undefined)?.map((s) => ({
      ...s,
      note: s.note ?? '',
      branchId: s.branchId ?? null,
      parentName: s.parentName ?? undefined,
      motherPhone: s.motherPhone ?? undefined,
      hasSpecialDiscount: s.hasSpecialDiscount ?? false,
      specialDiscountPercent: s.specialDiscountPercent ?? undefined,
      specialDiscountNote: s.specialDiscountNote ?? undefined,
      discountType: s.discountType ?? (s.hasSiblingDiscount ? 'sibling' : 'none'),
      qrCode: s.qrCode ?? undefined,
      groupIds: s.groupIds ?? (s.groupId ? [s.groupId] : []),
    })) ?? base.students,
    teachers: (raw.teachers as Teacher[] | undefined)?.map((t) => ({ ...t, branchId: t.branchId ?? null })) ?? base.teachers,
    groups: (raw.groups as Group[] | undefined)?.map((g) => ({
      ...g,
      branchId: g.branchId ?? null,
      billingModel: g.billingModel ?? 'per_session',
      customPrice: g.customPrice ?? null,
      payoutType: g.payoutType ?? 'fixed_seat',
      payoutValue: g.payoutValue ?? 20,
      monthlyFee: g.monthlyFee ?? null,
      packageFee: g.packageFee ?? null,
      scheduleDays: g.scheduleDays ?? [],
      startTime: g.startTime ?? null,
      endTime: g.endTime ?? null,
      halfwayTime: g.halfwayTime ?? null,
    })) ?? base.groups,
    payments: (raw.payments as Database['payments'] | undefined)?.map((p) => ({ ...p, paymentType: p.paymentType ?? 'session', bookTitle: p.bookTitle, branchId: p.branchId ?? null })) ?? base.payments,
    materials: (raw.materials as Database['materials'] | undefined)?.map((m) => ({ ...m, price: m.price ?? 0, stock: m.stock ?? 0 })) ?? base.materials,
    exams: (raw.exams as Exam[] | undefined) ?? base.exams,
    examScores: (raw.examScores as ExamScore[] | undefined)?.map((e) => ({ ...e, examId: e.examId ?? '', note: e.note ?? '' })) ?? base.examScores,
    expenses: (raw.expenses as Expense[] | undefined)?.map((e) => ({ ...e, branchId: e.branchId ?? null })) ?? base.expenses,
    salaries: (raw.salaries as Salary[] | undefined) ?? base.salaries,
    auditLog: (raw.auditLog as Database['auditLog'] | undefined) ?? base.auditLog,
    globalProfitModel: (raw.globalProfitModel as PayoutType | undefined) ?? base.globalProfitModel,
    globalProfitValue: (raw.globalProfitValue as number | undefined) ?? base.globalProfitValue,
    allowProfitOverride: (raw.allowProfitOverride as boolean | undefined) ?? false,
    teacherArrears: (raw.teacherArrears as Database['teacherArrears'] | undefined) ?? base.teacherArrears,
    secretarySalaries: (raw.secretarySalaries as Database['secretarySalaries'] | undefined) ?? base.secretarySalaries,
    idCardPrice: (raw.idCardPrice as number | undefined) ?? base.idCardPrice,
    siblingDiscountPercent: (raw.siblingDiscountPercent as number | undefined) ?? base.siblingDiscountPercent,
    twinDiscountPercent: (raw.twinDiscountPercent as number | undefined) ?? base.twinDiscountPercent,
    centerName: (raw.centerName as string | undefined) ?? base.centerName,
    centerLogo: (raw.centerLogo as string | null | undefined) ?? base.centerLogo,
    qrEnabled: (raw.qrEnabled as boolean | undefined) ?? false,
    allowFlexibleAttendanceTime: (raw.allowFlexibleAttendanceTime as boolean | undefined) ?? false,
    syncStamp: (raw.syncStamp as Database['syncStamp'] | undefined) ?? base.syncStamp,
    staffAdjustments: (raw.staffAdjustments as Database['staffAdjustments'] | undefined) ?? base.staffAdjustments,
    contactNotes: (raw.contactNotes as Database['contactNotes'] | undefined) ?? base.contactNotes,
    exportMeta: (raw.exportMeta as Database['exportMeta'] | undefined) ?? base.exportMeta,
    staff: (raw.staff as Staff[] | undefined)?.map((s) => ({ ...s, branchId: s.branchId ?? null, active: s.active ?? true })) ?? base.staff,
    staffAttendance: (raw.staffAttendance as StaffAttendance[] | undefined) ?? base.staffAttendance,
    staffPayouts: (raw.staffPayouts as StaffPayout[] | undefined) ?? base.staffPayouts,
    installmentPlans: (raw.installmentPlans as InstallmentPlan[] | undefined) ?? base.installmentPlans,
  };
  return merged;
}

let cache: Database | null = null;

export function loadDB(): Database {
  if (cache) return cache;
  try {
    const raw = safeGetItem(STORAGE_KEY);
    if (raw) {
      cache = migrate(JSON.parse(raw));
      return cache;
    }
  } catch {
    // ignore corrupt
  }
  cache = seed();
  saveDB(cache);
  return cache;
}

export function saveDB(db: Database): void {
  cache = db;
  try {
    safeSetItem(STORAGE_KEY, JSON.stringify(db));
  } catch {
    // storage full / unavailable
  }
}

export function resetDB(): Database {
  try {
    safeRemoveItem(STORAGE_KEY);
    safeRemoveItem('al-afdal-db');
  } catch {
    // ignore
  }
  cache = null;
  cache = seed();
  saveDB(cache);
  return cache;
}

export function wipeDemoData(): Database {
  try {
    safeRemoveItem(STORAGE_KEY);
    safeRemoveItem('al-afdal-db');
  } catch {
    // ignore
  }
  cache = null;
  const fresh: Database = {
    users: [
      { id: 'u1', username: 'admin', password: 'admin123', name: 'مدير السنتر', role: 'admin' },
    ],
    branches: [
      { id: 'b1', name: 'الفرع الرئيسي', address: '', createdAt: new Date().toISOString() },
    ],
    students: [],
    teachers: [],
    groups: [],
    attendance: [],
    payments: [],
    gradePrices: [
      { grade: 'الصف الأول الإعدادي', price: 120 },
      { grade: 'الصف الثاني الإعدادي', price: 130 },
      { grade: 'الصف الثالث الإعدادي', price: 150 },
      { grade: 'الصف الأول الثانوي', price: 200 },
      { grade: 'الصف الثاني الثانوي', price: 220 },
      { grade: 'الصف الثالث الثانوي', price: 250 },
    ],
    materials: [],
    exams: [],
    examScores: [],
    expenses: [],
    salaries: [],
    auditLog: [],
    globalProfitModel: 'percentage',
    globalProfitValue: 20,
    allowProfitOverride: false,
    teacherArrears: [],
    secretarySalaries: [],
    idCardPrice: 50,
    siblingDiscountPercent: 10,
    twinDiscountPercent: 20,
    centerName: 'سنتر الأفضل',
    centerLogo: null,
    qrEnabled: false,
    attendanceOpeningBuffer: 10,
    attendanceClosingPercent: 50,
    allowFlexibleAttendanceTime: false,
    syncStamp: { lastImportTime: null, lastImportActor: null },
    staffAdjustments: [],
    contactNotes: [],
    exportMeta: null,
    staff: [],
    staffAttendance: [],
    staffPayouts: [],
    installmentPlans: [],
    meta: { nextStudentId: 1 },
  };
  cache = fresh;
  saveDB(cache);
  return cache;
}

export function getDB(): Database {
  return loadDB();
}

export function setDB(db: Database): void {
  saveDB(db);
}

export function nextStudentId(db: Database): number {
  const id = db.meta.nextStudentId;
  db.meta.nextStudentId = id + 1;
  return id;
}

export { STORAGE_KEY };
