import type { Database, User, Student, Payment } from './types';
import { getScopedData, studentGroupIds } from './scoping';
import { computeSharesForPrice, computeTeacherPayout, arrearFor, discountedSessionFee } from './finance';
import { formatDate, currentMonthStr } from './date';

type CellValue = string | number;
type RowVals = CellValue[];

interface SheetData {
  name: string;
  headers: string[];
  rows: RowVals[];
}

function money(n: number): string {
  return `${n.toLocaleString('en-US')} ج.م`;
}

function dateStamp(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

async function downloadBlob(blob: Blob, filename: string): Promise<void> {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ---- Primary: SheetJS (xlsx) export ----

async function exportWithXLSX(centerName: string, sheets: SheetData[], filename: string): Promise<void> {
  const XLSX = await import('xlsx');
  const wb = XLSX.utils.book_new();
  wb.Props = { Title: centerName, Author: centerName };

  for (const s of sheets) {
    const data = [s.headers, ...s.rows];
    const ws = XLSX.utils.aoa_to_sheet(data);
    ws['!cols'] = s.headers.map((h) => ({ wch: Math.max(h.length + 4, 12) }));
    ws['!views'] = [{ RTL: true }];
    XLSX.utils.book_append_sheet(wb, ws, s.name.slice(0, 31));
  }

  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array', cellStyles: false });
  const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  await downloadBlob(blob, filename);
}

// ---- Fallback: UTF-8 CSV export (BOM header for Arabic) ----

function exportAsCSV(sheets: SheetData[], filename: string): void {
  const BOM = '\uFEFF';
  const csvParts: string[] = [];

  for (let si = 0; si < sheets.length; si++) {
    const s = sheets[si];
    if (sheets.length > 1) {
      csvParts.push(`=== ${s.name} ===`);
    }
    const lines = [s.headers, ...s.rows];
    for (const line of lines) {
      const cells = line.map((cell) => {
        const str = String(cell ?? '');
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      });
      csvParts.push(cells.join(','));
    }
    if (sheets.length > 1 && si < sheets.length - 1) {
      csvParts.push('');
    }
  }

  const csv = BOM + csvParts.join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  downloadBlob(blob, filename);
}

// ---- Safe export dispatcher ----

async function safeExport(centerName: string, sheets: SheetData[], xlsxFilename: string, csvFilename: string): Promise<void> {
  try {
    await exportWithXLSX(centerName, sheets, xlsxFilename, csvFilename);
  } catch {
    try {
      exportAsCSV(sheets, csvFilename);
    } catch {
      throw new Error('export_failed');
    }
  }
}

// ---- Helpers ----

function studentGroupNames(db: Database, s: Student): string {
  return studentGroupIds(s)
    .map((id) => db.groups.find((g) => g.id === id)?.name)
    .filter(Boolean)
    .join(', ') || '—';
}

function paymentTypeLabel(type: Payment['paymentType']): string {
  if (type === 'session') return 'رسوم شهرية';
  if (type === 'book') return 'مذكرة / كتاب';
  if (type === 'tuition') return 'رسوم دراسية';
  return 'كارت ID';
}

function paymentMethodLabel(method: Payment['method']): string {
  return method === 'cash' ? 'نقدي' : method === 'card' ? 'كارت' : 'تحويل';
}

// ---- Unpaid Fees Radar ----

export interface UnpaidStudent {
  id: number;
  name: string;
  parentPhone: string;
  grade: string;
  groupId: string;
  groupName: string;
  groupNames: string;
  amountDue: number;
  monthsOverdue: number;
  status: string;
}

export function computeUnpaidRadar(db: Database, month: string, groupId?: string): UnpaidStudent[] {
  const result: UnpaidStudent[] = [];
  for (const s of db.students) {
    const sGids = studentGroupIds(s);
    if (groupId && !sGids.includes(groupId)) continue;
    const gp = db.gradePrices.find((g) => g.grade === s.grade);
    if (!gp) continue;
    const expected = discountedSessionFee(gp.price, s);
    const paid = db.payments
      .filter((p) => p.studentId === s.id && p.paymentType === 'session' && p.month === month)
      .reduce((sum, p) => sum + p.amount, 0);
    if (paid < expected) {
      const amountDue = expected - paid;
      const monthsOverdue = db.payments.filter(
        (p) => p.studentId === s.id && p.paymentType === 'session'
      ).length === 0
        ? 1
        : 0;
      const hasNote = (db.contactNotes || []).some((n) => n.studentId === s.id && n.active);
      const status = hasNote ? 'متابعة نشطة' : monthsOverdue > 0 ? 'متأخر جديد' : 'بانتظار التحصيل';
      const primaryGroup = sGids.length > 0 ? db.groups.find((g) => g.id === sGids[0]) : null;
      result.push({
        id: s.id,
        name: s.name,
        parentPhone: s.parentPhone,
        grade: s.grade,
        groupId: primaryGroup?.id || '',
        groupName: primaryGroup?.name || '—',
        groupNames: studentGroupNames(db, s),
        amountDue,
        monthsOverdue,
        status,
      });
    }
  }
  return result.sort((a, b) => b.amountDue - a.amountDue);
}

// ---- Admin Excel ----

export async function exportAdminExcel(db: Database): Promise<void> {
  const month = currentMonthStr();

  const totalRevenue = db.payments.reduce((s, p) => s + p.amount, 0);
  const centerShareTotal = db.payments.reduce((s, p) => {
    const student = db.students.find((st) => st.id === p.studentId);
    const gp = db.gradePrices.find((g) => g.grade === student?.grade);
    const price = gp?.price ?? p.amount;
    return s + computeSharesForPrice(db, price).centerShare;
  }, 0);
  const totalExpenses = db.expenses.reduce((s, e) => s + e.amount, 0);
  const totalSalaries = (db.salaries || []).reduce((s, sal) => s + sal.net, 0);
  const totalAdjustments = (db.staffAdjustments || []).reduce((s, a) => {
    const sign = a.type === 'reward' ? 1 : -1;
    return s + sign * a.amount;
  }, 0);
  const netProfit = centerShareTotal - totalExpenses - totalSalaries - totalAdjustments;

  const summaryRows: RowVals[] = [
    ['إجمالي الإيرادات', money(totalRevenue)],
    ['حصة السنتر (المركز)', money(centerShareTotal)],
    ['إجمالي المصاريف', money(totalExpenses)],
    ['إجمالي الرواتب المدفوعة', money(totalSalaries)],
    ['صافي السلف والمكافآت', money(totalAdjustments)],
    ['صافي الربح', money(netProfit)],
  ];

  const radar = computeUnpaidRadar(db, month);
  const radarRows: RowVals[] = radar.map((u) => [
    u.id, u.name, u.parentPhone, u.grade, u.groupNames, money(u.amountDue),
    u.monthsOverdue > 0 ? `${u.monthsOverdue} شهر` : 'هذا الشهر', u.status,
  ]);

  // Financial payments sheet: [اسم الطالب | المجموعة | المبلغ | نوع الدفع | التاريخ | المستلم]
  const payRows: RowVals[] = [...db.payments]
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((p) => {
      const student = db.students.find((s) => s.id === p.studentId);
      const group = db.groups.find((g) => g.id === p.groupId);
      return [
        student?.name || '—',
        group?.name || p.groupName || '—',
        money(p.amount),
        paymentTypeLabel(p.paymentType),
        formatDate(p.date),
        p.collectedBy || '—',
      ];
    });

  // Student roster sheet: [الكود | الاسم | الصف | المجموعات | الهاتف | ولي الأمر | كود QR]
  const studentRows: RowVals[] = db.students.map((s) => [
    s.id, s.name, s.grade, studentGroupNames(db, s), s.phone, s.parentPhone, s.qrCode || `STD-${s.id}`,
  ]);

  // Attendance sheet: [اسم الطالب | المجموعة | الحصة | التاريخ والوقت | طريقة التسجيل | حالة السداد]
  const attRows: RowVals[] = [...db.attendance]
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((a) => {
      const student = db.students.find((s) => s.id === a.studentId);
      const group = db.groups.find((g) => g.id === a.groupId);
      const gp = db.gradePrices.find((g) => g.grade === student?.grade);
      const expected = gp ? discountedSessionFee(gp.price, student!) : 0;
      const paid = db.payments
        .filter((p) => p.studentId === a.studentId && p.paymentType === 'session' && p.month === a.date.slice(0, 7))
        .reduce((sum, p) => sum + p.amount, 0);
      const paymentStatus = paid >= expected ? 'مسدد' : 'متأخر';
      const timeStr = new Date(a.createdAt).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
      return [
        student?.name || '—',
        group?.name || '—',
        'حضور',
        `${formatDate(a.date)} ${timeStr}`,
        'يدوي',
        paymentStatus,
      ];
    });

  const sheets: SheetData[] = [
    { name: 'الملخص المالي', headers: ['البند', 'القيمة'], rows: summaryRows },
    { name: 'رادار المتأخرات', headers: ['الكود', 'الاسم', 'هاتف ولي الأمر', 'الصف', 'المجموعات', 'المبلغ المستحق', 'مدة التأخر', 'حالة المتابعة'], rows: radarRows },
    { name: 'سجل المدفوعات', headers: ['اسم الطالب', 'المجموعة', 'المبلغ', 'نوع الدفع', 'التاريخ', 'المستلم'], rows: payRows },
    { name: 'قائمة الطلاب', headers: ['الكود', 'الاسم', 'الصف', 'المجموعات', 'الهاتف', 'ولي الأمر', 'كود QR'], rows: studentRows },
    { name: 'سجل الحضور', headers: ['اسم الطالب', 'المجموعة', 'الحصة', 'التاريخ والوقت', 'طريقة التسجيل', 'حالة السداد'], rows: attRows },
  ];

  const stamp = dateStamp();
  await safeExport(db.centerName || 'سنتر الأفضل', sheets, `admin_report_${stamp}.xlsx`, `admin_report_${stamp}.csv`);
}

// ---- Teacher Excel ----

export async function exportTeacherExcel(db: Database, user: User): Promise<void> {
  const scoped = getScopedData(db, user);
  const month = currentMonthStr();

  // Attendance: [اسم الطالب | المجموعة | الحصة | التاريخ والوقت | طريقة التسجيل | حالة السداد]
  const attRows: RowVals[] = scoped.attendance
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((a) => {
      const student = scoped.students.find((s) => s.id === a.studentId);
      const group = scoped.groups.find((g) => g.id === a.groupId);
      const gp = db.gradePrices.find((g) => g.grade === student?.grade);
      const expected = gp ? discountedSessionFee(gp.price, student!) : 0;
      const paid = db.payments
        .filter((p) => p.studentId === a.studentId && p.paymentType === 'session' && p.month === a.date.slice(0, 7))
        .reduce((sum, p) => sum + p.amount, 0);
      const paymentStatus = paid >= expected ? 'مسدد' : 'متأخر';
      const timeStr = new Date(a.createdAt).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
      return [
        student?.name || '—',
        group?.name || '—',
        'حضور',
        `${formatDate(a.date)} ${timeStr}`,
        'يدوي',
        paymentStatus,
      ];
    });

  const teacherGroupIds = new Set(scoped.groups.map((g) => g.id));
  const examRows: RowVals[] = (db.examScores || [])
    .filter((e) => teacherGroupIds.has(e.groupId))
    .map((e) => {
      const student = scoped.students.find((s) => s.id === e.studentId);
      const group = scoped.groups.find((g) => g.id === e.groupId);
      return [formatDate(e.date), student?.name || '—', group?.name || '—', e.examTitle, e.score, e.maxScore, `${Math.round((e.score / e.maxScore) * 100)}%`];
    });

  const liqHeaders = ['المعلم', 'الصف', 'المجموعة', 'إجمالي الطلاب', 'تم التحصيل', 'جاري التحصيل', 'المبلغ المحصل', 'عهدة السنتر', 'صافي المستحق', 'تخلفات سابقة', 'الإجمالي النهائي'];
  const liqRows: RowVals[] = [];
  const myTeachers = db.teachers.filter((t) => t.id === user.teacherId);
  for (const teacher of myTeachers) {
    const teacherGroups = scoped.groups.filter((g) => g.teacherId === teacher.id);
    for (const group of teacherGroups) {
      const grade = group.grade || 'غير محدد';
      const groupStudents = scoped.students.filter((s) => studentGroupIds(s).includes(group.id));
      const totalStudents = groupStudents.length;
      const groupPayments = scoped.payments.filter((p) => p.groupId === group.id && p.month === month && p.paymentType === 'session');
      const paidStudentIds = new Set(groupPayments.map((p) => p.studentId));
      const paidStudents = paidStudentIds.size;
      const pendingStudents = Math.max(0, totalStudents - paidStudents);
      const collectedAmount = groupPayments.reduce((s, p) => s + p.amount, 0);
      const { centerShare, teacherShare } = computeTeacherPayout(db, group, totalStudents, collectedAmount);
      const teacherNet = teacherShare;
      const arrears = arrearFor(db, teacher.id, grade);
      liqRows.push([teacher.name, grade, group.name, totalStudents, paidStudents, pendingStudents, money(collectedAmount), money(centerShare), money(teacherNet), money(arrears), money(teacherNet + arrears)]);
    }
  }

  // Student roster for teacher's groups
  const studentRows: RowVals[] = scoped.students.map((s) => [
    s.id, s.name, s.grade, studentGroupNames(db, s), s.phone, s.parentPhone, s.qrCode || `STD-${s.id}`,
  ]);

  const sheets: SheetData[] = [
    { name: 'كشف الحضور', headers: ['اسم الطالب', 'المجموعة', 'الحصة', 'التاريخ والوقت', 'طريقة التسجيل', 'حالة السداد'], rows: attRows },
    { name: 'درجات الاختبارات', headers: ['التاريخ', 'الطالب', 'المجموعة', 'الاختبار', 'الدرجة', 'الدرجة الكبرى', 'النسبة'], rows: examRows },
    { name: `تصفية ${month}`, headers: liqHeaders, rows: liqRows },
    { name: 'قائمة الطلاب', headers: ['الكود', 'الاسم', 'الصف', 'المجموعات', 'الهاتف', 'ولي الأمر', 'كود QR'], rows: studentRows },
  ];

  const stamp = dateStamp();
  const safeName = (user.name || 'teacher').replace(/\s+/g, '_');
  await safeExport(db.centerName || 'سنتر الأفضل', sheets, `teacher_report_${safeName}_${stamp}.xlsx`, `teacher_report_${safeName}_${stamp}.csv`);
}

// ---- Secretary Excel ----

export async function exportSecretaryExcel(db: Database, user: User): Promise<void> {
  const scoped = getScopedData(db, user);

  const branchIds = new Set(user.branchIds || []);
  const branchStudents = branchIds.size > 0
    ? scoped.students.filter((s) => {
        const sGids = studentGroupIds(s);
        return sGids.some((gid) => {
          const group = scoped.groups.find((g) => g.id === gid);
          return group && group.branchId && branchIds.has(group.branchId);
        });
      })
    : scoped.students;

  // Student roster: [الكود | الاسم | الصف | المجموعات | الهاتف | ولي الأمر | كود QR]
  const studentRows: RowVals[] = branchStudents.map((s) => [
    s.id, s.name, s.grade, studentGroupNames(db, s), s.phone, s.parentPhone, s.qrCode || `STD-${s.id}`,
  ]);

  const myActions = (db.auditLog || []).filter((a) => a.actorName === user.name);
  const logRows: RowVals[] = myActions
    .sort((a, b) => b.timestamp.localeCompare(a.timestamp))
    .map((a) => [formatDate(a.timestamp), a.action, a.detail]);

  const branchAttendance = branchIds.size > 0
    ? scoped.attendance.filter((a) => {
        const group = scoped.groups.find((g) => g.id === a.groupId);
        return group && group.branchId && branchIds.has(group.branchId);
      })
    : scoped.attendance;

  // Attendance: [اسم الطالب | المجموعة | الحصة | التاريخ والوقت | طريقة التسجيل | حالة السداد]
  const checkinRows: RowVals[] = branchAttendance
    .filter((a) => a.status === 'present')
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((a) => {
      const student = scoped.students.find((s) => s.id === a.studentId);
      const group = scoped.groups.find((g) => g.id === a.groupId);
      const gp = db.gradePrices.find((g) => g.grade === student?.grade);
      const expected = gp ? discountedSessionFee(gp.price, student!) : 0;
      const paid = db.payments
        .filter((p) => p.studentId === a.studentId && p.paymentType === 'session' && p.month === a.date.slice(0, 7))
        .reduce((sum, p) => sum + p.amount, 0);
      const paymentStatus = paid >= expected ? 'مسدد' : 'متأخر';
      const timeStr = new Date(a.createdAt).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
      return [
        student?.name || '—',
        group?.name || '—',
        'حضور',
        `${formatDate(a.date)} ${timeStr}`,
        'يدوي',
        paymentStatus,
      ];
    });

  // Payments: [اسم الطالب | المجموعة | المبلغ | نوع الدفع | التاريخ | المستلم]
  const branchPayments = branchIds.size > 0
    ? scoped.payments.filter((p) => {
        const group = scoped.groups.find((g) => g.id === p.groupId);
        return group && group.branchId && branchIds.has(group.branchId);
      })
    : scoped.payments;

  const payRows: RowVals[] = [...branchPayments]
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((p) => {
      const student = scoped.students.find((s) => s.id === p.studentId);
      const group = scoped.groups.find((g) => g.id === p.groupId);
      return [
        student?.name || '—',
        group?.name || p.groupName || '—',
        money(p.amount),
        paymentTypeLabel(p.paymentType),
        formatDate(p.date),
        p.collectedBy || '—',
      ];
    });

  const sheets: SheetData[] = [
    { name: 'قائمة الطلاب', headers: ['الكود', 'الاسم', 'الصف', 'المجموعات', 'الهاتف', 'ولي الأمر', 'كود QR'], rows: studentRows },
    { name: 'سجل العمليات', headers: ['التاريخ', 'العملية', 'التفاصيل'], rows: logRows },
    { name: 'سجل الحضور', headers: ['اسم الطالب', 'المجموعة', 'الحصة', 'التاريخ والوقت', 'طريقة التسجيل', 'حالة السداد'], rows: checkinRows },
    { name: 'سجل المدفوعات', headers: ['اسم الطالب', 'المجموعة', 'المبلغ', 'نوع الدفع', 'التاريخ', 'المستلم'], rows: payRows },
  ];

  const stamp = dateStamp();
  const safeName = (user.name || 'secretary').replace(/\s+/g, '_');
  await safeExport(db.centerName || 'سنتر الأفضل', sheets, `secretary_report_${safeName}_${stamp}.xlsx`, `secretary_report_${safeName}_${stamp}.csv`);
}

export async function exportToExcel(db: Database, user: User): Promise<void> {
  if (user.role === 'admin') return exportAdminExcel(db);
  if (user.role === 'teacher') return exportTeacherExcel(db, user);
  return exportSecretaryExcel(db, user);
}

// ---- Student Roster Export (standalone) ----

export async function exportStudentRoster(db: Database): Promise<void> {
  const rows: RowVals[] = db.students.map((s) => [
    s.id, s.name, s.firstName || '', s.lastName || '', s.grade,
    studentGroupNames(db, s), s.phone, s.parentPhone, s.parentName || '',
    s.motherPhone || '', s.note, s.qrCode || `STD-${s.id}`,
  ]);

  const sheets: SheetData[] = [
    { name: 'قائمة الطلاب', headers: ['الكود', 'الاسم', 'الاسم الأول', 'الاسم الأخير', 'الصف', 'المجموعات', 'الهاتف', 'هاتف ولي الأمر', 'اسم ولي الأمر', 'هاتف الأم', 'ملاحظات', 'كود QR'], rows },
  ];

  const stamp = dateStamp();
  await safeExport(db.centerName || 'سنتر الأفضل', sheets, `students_${stamp}.xlsx`, `students_${stamp}.csv`);
}

// ---- Student Roster Import from Excel ----

export interface ImportResult {
  added: number;
  updated: number;
  errors: string[];
}

export async function importStudentRoster(db: Database, file: File): Promise<ImportResult> {
  const XLSX = await import('xlsx');
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: 'array' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  if (!ws) return { added: 0, updated: 0, errors: ['الملف لا يحتوي على ورقة بيانات'] };

  const data: unknown[][] = XLSX.utils.sheet_to_json(ws, { header: 1 });
  if (data.length < 2) return { added: 0, updated: 0, errors: ['الملف فارغ أو لا يحتوي على بيانات'] };

  const headers = (data[0] as string[]).map((h) => String(h || '').trim());
  const findCol = (names: string[]): number => {
    for (const name of names) {
      const idx = headers.findIndex((h) => h.includes(name));
      if (idx >= 0) return idx;
    }
    return -1;
  };

  const colId = findCol(['الكود']);
  const colName = findCol(['الاسم']);
  const colFirstName = findCol(['الاسم الأول']);
  const colLastName = findCol(['الاسم الأخير']);
  const colGrade = findCol(['الصف']);
  const colGroups = findCol(['المجموعات', 'المجموعة']);
  const colPhone = findCol(['الهاتف']);
  const colParentPhone = findCol(['ولي الأمر', 'هاتف ولي']);
  const colParentName = findCol(['اسم ولي']);
  const colMotherPhone = findCol(['هاتف الأم']);
  const colNote = findCol(['ملاحظات']);
  const colQr = findCol(['كود QR', 'QR']);

  if (colName < 0) return { added: 0, updated: 0, errors: ['عمود الاسم غير موجود'] };

  let added = 0;
  let updated = 0;
  const errors: string[] = [];
  const nextId = db.meta.nextStudentId;

  const rows = data.slice(1) as unknown[][];

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.every((c) => c === null || c === undefined || String(c).trim() === '')) continue;

    const getStr = (col: number): string => col >= 0 ? String(row[col] ?? '').trim() : '';
    const name = getStr(colName);
    if (!name) {
      errors.push(`الصف ${i + 2}: اسم الطالب فارغ`);
      continue;
    }

    const idStr = getStr(colId);
    const id = idStr ? Number(idStr) : NaN;
    const grade = getStr(colGrade) || 'غير محدد';
    const groupsStr = getStr(colGroups);
    const groupIds: string[] = groupsStr && groupsStr !== '—'
      ? groupsStr.split(',').map((g) => g.trim()).filter(Boolean).map((gname) => {
          const found = db.groups.find((g) => g.name.trim() === gname);
          return found?.id || '';
        }).filter(Boolean)
      : [];
    const primaryGroupId = groupIds.length > 0 ? groupIds[0] : null;
    const phone = getStr(colPhone);
    const parentPhone = getStr(colParentPhone);
    const parentName = getStr(colParentName);
    const motherPhone = getStr(colMotherPhone);
    const note = getStr(colNote);
    const qrCode = getStr(colQr) || (id ? `STD-${id}` : `STD-${nextId + added}`);

    const existingIdx = !isNaN(id) ? db.students.findIndex((s) => s.id === id) : -1;

    if (existingIdx >= 0) {
      db.students[existingIdx] = {
        ...db.students[existingIdx],
        name,
        firstName: getStr(colFirstName) || undefined,
        lastName: getStr(colLastName) || undefined,
        grade,
        groupId: primaryGroupId,
        groupIds,
        phone,
        parentPhone,
        parentName,
        motherPhone,
        note,
        qrCode,
      };
      updated++;
    } else {
      const newId = !isNaN(id) ? id : nextId + added;
      db.students.push({
        id: newId,
        name,
        firstName: getStr(colFirstName) || undefined,
        lastName: getStr(colLastName) || undefined,
        grade,
        groupId: primaryGroupId,
        groupIds,
        branchId: null,
        note,
        phone,
        parentPhone,
        parentName,
        motherPhone,
        qrCode,
        createdAt: new Date().toISOString(),
      });
      added++;
    }
  }

  return { added, updated, errors };
}

// ---- Per-group defaulters export ----

export async function exportGroupDefaultersExcel(
  centerName: string,
  groupName: string,
  defaulters: UnpaidStudent[],
): Promise<void> {
  const rows: RowVals[] = defaulters.map((u) => [
    u.id, u.name, u.parentPhone, u.grade, u.groupNames, money(u.amountDue),
    u.monthsOverdue > 0 ? `${u.monthsOverdue} شهر` : 'هذا الشهر', u.status,
  ]);
  const sheets: SheetData[] = [
    { name: 'متأخرات المجموعة', headers: ['الكود', 'الاسم', 'هاتف ولي الأمر', 'الصف', 'المجموعات', 'المبلغ المستحق', 'مدة التأخر', 'حالة المتابعة'], rows },
  ];
  const stamp = dateStamp();
  const safeName = groupName.replace(/\s+/g, '_');
  await safeExport(centerName || 'سنتر الأفضل', sheets, `defaulters_${safeName}_${stamp}.xlsx`, `defaulters_${safeName}_${stamp}.csv`);
}
