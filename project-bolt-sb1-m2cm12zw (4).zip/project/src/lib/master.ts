import type { MasterDevice, TrialSettings, DeviceStatus, LicenseState, LicenseType } from './types';
import { safeGetItem, safeSetItem } from './safe-storage';

const DEFAULT_MASTER_PIN = '998877';
const DEVICES_KEY = 'al_afdal_master_devices';
const TRIAL_KEY = 'al_afdal_trial_settings';
const THIS_DEVICE_KEY = 'al_afdal_this_device_id';
const ACTION_COUNT_KEY = 'al_afdal_action_count';
const FIRST_LAUNCH_KEY = 'al_afdal_first_launch';
const OFFLINE_KEY_KEY = 'al_afdal_offline_key';

export function getMasterPin(): string {
  return import.meta.env.VITE_MASTER_PIN || DEFAULT_MASTER_PIN;
}

export function verifyMasterPin(pin: string): boolean {
  return pin === getMasterPin();
}

function generateId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function getThisDeviceId(): string {
  let id = safeGetItem(THIS_DEVICE_KEY);
  if (!id) {
    const ua = navigator.userAgent;
    const lang = navigator.language;
    const screen = `${window.screen.width}x${window.screen.height}`;
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const raw = `${ua}::${lang}::${screen}::${tz}`;
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      hash = ((hash << 5) - hash + raw.charCodeAt(i)) | 0;
    }
    id = `DEV-${Math.abs(hash).toString(36).toUpperCase()}-${Date.now().toString(36).slice(-4).toUpperCase()}`;
    safeSetItem(THIS_DEVICE_KEY, id);
  }
  return id;
}

export function getDeviceName(): string {
  const ua = navigator.userAgent;
  let browser = 'Unknown';
  let os = 'Unknown';
  if (/Chrome\/(\d+)/.test(ua) && !/Edg/.test(ua)) browser = `Chrome ${RegExp.$1}`;
  else if (/Firefox\/(\d+)/.test(ua)) browser = `Firefox ${RegExp.$1}`;
  else if (/Edg\/(\d+)/.test(ua)) browser = `Edge ${RegExp.$1}`;
  else if (/Safari\/(\d+)/.test(ua) && !/Chrome/.test(ua)) browser = 'Safari';
  if (/Windows NT 10/.test(ua)) os = 'Windows';
  else if (/Android/.test(ua)) os = 'Android';
  else if (/iPhone|iPad/.test(ua)) os = 'iOS';
  else if (/Mac OS X/.test(ua)) os = 'macOS';
  else if (/Linux/.test(ua)) os = 'Linux';
  return `${browser} — ${os}`;
}

export function loadDevices(): MasterDevice[] {
  try {
    const raw = safeGetItem(DEVICES_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as MasterDevice[];
  } catch {
    return [];
  }
}

export function saveDevices(devices: MasterDevice[]): void {
  safeSetItem(DEVICES_KEY, JSON.stringify(devices));
}

export function registerThisDevice(): MasterDevice {
  const devices = loadDevices();
  const thisId = getThisDeviceId();
  let device = devices.find((d) => d.deviceId === thisId);
  const now = new Date().toISOString();
  const firstLaunch = safeGetItem(FIRST_LAUNCH_KEY) || now;
  if (!safeGetItem(FIRST_LAUNCH_KEY)) safeSetItem(FIRST_LAUNCH_KEY, firstLaunch);
  const actionCount = parseInt(safeGetItem(ACTION_COUNT_KEY) || '0', 10);
  if (!device) {
    device = {
      id: generateId(),
      deviceId: thisId,
      deviceName: getDeviceName(),
      ipAddress: '',
      status: 'pending',
      activationHash: null,
      firstSeen: now,
      lastActive: now,
      notes: '',
      actionCount,
      firstLaunchAt: firstLaunch,
      trialExpired: false,
      licenseType: 'trial',
      trialExpiresAt: null,
    };
    devices.push(device);
    saveDevices(devices);
  } else {
    device.lastActive = now;
    device.actionCount = actionCount;
    device.firstLaunchAt = device.firstLaunchAt || firstLaunch;
    saveDevices(devices);
  }
  return device;
}

export function updateDeviceStatus(deviceId: string, status: DeviceStatus): void {
  const devices = loadDevices();
  const d = devices.find((dev) => dev.id === deviceId);
  if (d) {
    d.status = status;
    if (status === 'approved') {
      d.trialExpired = false;
    }
    saveDevices(devices);
  }
}

export function setDeviceLicense(deviceRecordId: string, licenseType: LicenseType, trialDurationHours: number): void {
  const devices = loadDevices();
  const d = devices.find((dev) => dev.id === deviceRecordId);
  if (!d) return;

  d.licenseType = licenseType;
  d.trialExpired = false;

  if (licenseType === 'full') {
    d.status = 'approved';
    d.trialExpiresAt = null;
  } else {
    d.status = 'approved';
    const expiry = new Date(Date.now() + trialDurationHours * 60 * 60 * 1000);
    d.trialExpiresAt = expiry.toISOString();
  }

  saveDevices(devices);

  const thisId = getThisDeviceId();
  if (d.deviceId === thisId) {
    if (licenseType === 'full') {
      safeSetItem(OFFLINE_KEY_KEY, 'FULL_ACCESS');
    }
  }
}

export function getThisDevice(): MasterDevice | null {
  const devices = loadDevices();
  const thisId = getThisDeviceId();
  return devices.find((d) => d.deviceId === thisId) || null;
}

export function getThisDeviceLicenseType(): LicenseType {
  const d = getThisDevice();
  return d?.licenseType || 'trial';
}

export function getTrialExpiry(): Date | null {
  const d = getThisDevice();
  if (!d || d.licenseType !== 'trial' || !d.trialExpiresAt) return null;
  return new Date(d.trialExpiresAt);
}

export function getTrialTimeRemaining(): { expired: boolean; ms: number; hours: number; minutes: number; seconds: number } {
  const expiry = getTrialExpiry();
  if (!expiry) return { expired: false, ms: 0, hours: 0, minutes: 0, seconds: 0 };
  const remaining = expiry.getTime() - Date.now();
  if (remaining <= 0) return { expired: true, ms: 0, hours: 0, minutes: 0, seconds: 0 };
  const totalSeconds = Math.floor(remaining / 1000);
  return {
    expired: false,
    ms: remaining,
    hours: Math.floor(totalSeconds / 3600),
    minutes: Math.floor((totalSeconds % 3600) / 60),
    seconds: totalSeconds % 60,
  };
}

export function isTrialExpired(): boolean {
  const d = getThisDevice();
  if (!d) return false;
  if (d.licenseType === 'full') return false;
  if (d.status !== 'approved') return false;
  if (!d.trialExpiresAt) return false;
  return new Date(d.trialExpiresAt).getTime() <= Date.now();
}

export function deleteDevice(deviceId: string): void {
  const devices = loadDevices().filter((d) => d.id !== deviceId);
  saveDevices(devices);
}

export function generateActivationHash(deviceId: string): string {
  const devices = loadDevices();
  const d = devices.find((dev) => dev.id === deviceId);
  if (!d) return '';
  const hash = generateExpectedKey(d.deviceId);
  d.activationHash = hash;
  d.status = 'approved';
  d.trialExpired = false;
  d.licenseType = 'full';
  d.trialExpiresAt = null;
  saveDevices(devices);
  return hash;
}

export function loadTrialSettings(): TrialSettings {
  try {
    const raw = safeGetItem(TRIAL_KEY);
    if (!raw) return { trialDays: 7, maxTrialActions: 100, trialEnabled: true, updatedAt: new Date().toISOString() };
    return JSON.parse(raw) as TrialSettings;
  } catch {
    return { trialDays: 7, maxTrialActions: 100, trialEnabled: true, updatedAt: new Date().toISOString() };
  }
}

export function saveTrialSettings(settings: TrialSettings): void {
  settings.updatedAt = new Date().toISOString();
  safeSetItem(TRIAL_KEY, JSON.stringify(settings));
}

export function isThisDeviceApproved(): boolean {
  const devices = loadDevices();
  const thisId = getThisDeviceId();
  const d = devices.find((dev) => dev.deviceId === thisId);
  return d?.status === 'approved';
}

export function isThisDeviceBlocked(): boolean {
  const devices = loadDevices();
  const thisId = getThisDeviceId();
  const d = devices.find((dev) => dev.deviceId === thisId);
  return d?.status === 'blocked';
}

export function getActionCount(): number {
  return parseInt(safeGetItem(ACTION_COUNT_KEY) || '0', 10);
}

export function incrementActionCount(): number {
  const count = getActionCount() + 1;
  safeSetItem(ACTION_COUNT_KEY, String(count));
  const devices = loadDevices();
  const thisId = getThisDeviceId();
  const d = devices.find((dev) => dev.deviceId === thisId);
  if (d) {
    d.actionCount = count;
    saveDevices(devices);
  }
  return count;
}

export function getFirstLaunchDate(): Date {
  const raw = safeGetItem(FIRST_LAUNCH_KEY);
  if (!raw) {
    const now = new Date().toISOString();
    safeSetItem(FIRST_LAUNCH_KEY, now);
    return new Date(now);
  }
  return new Date(raw);
}

export function getTrialDaysElapsed(): number {
  const first = getFirstLaunchDate();
  const now = new Date();
  return Math.floor((now.getTime() - first.getTime()) / (1000 * 60 * 60 * 24));
}

export function checkTrialExpired(): boolean {
  const settings = loadTrialSettings();
  if (!settings.trialEnabled) return false;
  if (isThisDeviceApproved()) return false;

  const daysElapsed = getTrialDaysElapsed();
  const actions = getActionCount();

  if (daysElapsed >= settings.trialDays) return true;
  if (actions >= settings.maxTrialActions) return true;

  return false;
}

export function getLicenseState(role?: string): LicenseState {
  if (role === 'master') return 'master';
  if (isThisDeviceBlocked()) return 'blocked';
  if (isThisDeviceApproved()) {
    if (isTrialExpired()) return 'expired';
    return 'approved';
  }
  if (checkTrialExpired()) return 'expired';
  return 'trial';
}

export function shouldLockApp(role?: string): boolean {
  const state = getLicenseState(role);
  return state === 'expired' || state === 'blocked';
}

export function markTrialExpired(): void {
  const devices = loadDevices();
  const thisId = getThisDeviceId();
  const d = devices.find((dev) => dev.deviceId === thisId);
  if (d) {
    d.trialExpired = true;
    saveDevices(devices);
  }
}

export function applyOfflineActivationKey(key: string): boolean {
  const thisId = getThisDeviceId();
  const result = verifyOfflineKey(thisId, key);
  if (!result.valid) return false;

  const devices = loadDevices();
  const d = devices.find((dev) => dev.deviceId === thisId);
  if (d) {
    d.status = 'approved';
    d.activationHash = key.trim().toUpperCase().replace(/\s/g, '');
    d.trialExpired = false;

    if (result.kind === 'FULL') {
      d.licenseType = 'full';
      d.trialExpiresAt = null;
    } else {
      d.licenseType = 'trial';
      d.trialExpiresAt = new Date(Date.now() + result.trialDays * 24 * 60 * 60 * 1000).toISOString();
    }

    saveDevices(devices);
  }

  safeSetItem(OFFLINE_KEY_KEY, key.trim().toUpperCase().replace(/\s/g, ''));
  return true;
}

export function generateExpectedKey(deviceId: string): string {
  let hash = 0;
  const salt = 'AL_AFDAL_2026';
  const raw = `${deviceId}::${salt}`;
  for (let i = 0; i < raw.length; i++) {
    hash = ((hash << 5) - hash + raw.charCodeAt(i)) | 0;
  }
  const part1 = Math.abs(hash).toString(36).toUpperCase().padStart(6, '0').slice(0, 6);
  const part2 = Math.abs(hash >> 8).toString(36).toUpperCase().padStart(4, '0').slice(0, 4);
  return `AK-${part1}-${part2}`;
}

const MASTER_SALT = 'AL_AFDAL_MASTER_2026_XK';

export type OfflineLicenseKind = 'FULL' | 'TRIAL';

export interface OfflineKeyResult {
  key: string;
  kind: OfflineLicenseKind;
  trialDays: number;
}

function computeShortHash(deviceId: string, licenseTag: string): string {
  let hash = 0;
  const raw = `${deviceId}::${licenseTag}::${MASTER_SALT}`;
  for (let i = 0; i < raw.length; i++) {
    hash = ((hash << 5) - hash + raw.charCodeAt(i)) | 0;
  }
  const h1 = Math.abs(hash).toString(36).toUpperCase().padStart(4, '0');
  const h2 = Math.abs(hash >> 11).toString(36).toUpperCase().padStart(4, '0');
  return (h1 + h2).slice(0, 8);
}

export function generateOfflineKey(deviceId: string, kind: OfflineLicenseKind, trialDays: number): string {
  const tag = kind === 'FULL' ? 'FULL' : `TRIAL_${trialDays}D`;
  return computeShortHash(deviceId, tag);
}

export function verifyOfflineKey(deviceId: string, key: string): { valid: boolean; kind: OfflineLicenseKind; trialDays: number } {
  const clean = key.trim().toUpperCase().replace(/\s/g, '');

  const fullKey = computeShortHash(deviceId, 'FULL');
  if (clean === fullKey) {
    return { valid: true, kind: 'FULL', trialDays: 0 };
  }

  for (let days = 1; days <= 365; days++) {
    const trialKey = computeShortHash(deviceId, `TRIAL_${days}D`);
    if (clean === trialKey) {
      return { valid: true, kind: 'TRIAL', trialDays: days };
    }
  }

  return { valid: false, kind: 'FULL', trialDays: 0 };
}

export function buildTrialWhatsAppMessage(deviceId: string): string {
  return `السلام عليكم،\nأحتاج تفعيل جهازي على نظام سنتر الأفضل.\nرمز الجهاز (Device ID): ${deviceId}\nبرجاء إرسال كود التفعيل.\nشكراً لكم.`;
}

export function extendDeviceTrial(deviceRecordId: string, extraDays: number, resetActions: boolean): void {
  const devices = loadDevices();
  const d = devices.find((dev) => dev.id === deviceRecordId);
  if (!d) return;

  const now = new Date();
  const newFirst = new Date(now.getTime());
  d.firstLaunchAt = newFirst.toISOString();
  d.trialExpired = false;

  if (extraDays > 0) {
    d.licenseType = 'trial';
    d.status = 'approved';
    d.trialExpiresAt = new Date(now.getTime() + extraDays * 24 * 60 * 60 * 1000).toISOString();
  }

  if (resetActions) {
    d.actionCount = 0;
  }

  if (d.status === 'blocked') {
    d.status = 'pending';
  }

  saveDevices(devices);

  const thisId = getThisDeviceId();
  if (d.deviceId === thisId) {
    safeSetItem(FIRST_LAUNCH_KEY, newFirst.toISOString());
    if (resetActions) {
      safeSetItem(ACTION_COUNT_KEY, '0');
    }
  }
}
