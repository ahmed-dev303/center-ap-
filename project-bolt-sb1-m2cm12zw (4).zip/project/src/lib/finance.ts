import type { Database, AuditEntry, Role, Student, Group, BillingModel, PayoutType } from './types';
import { uid } from './date';

export function logAction(
  db: Database,
  action: string,
  detail: string,
  actorName: string,
  actorRole: Role
): void {
  const entry: AuditEntry = {
    id: uid('audit'),
    action,
    detail,
    actorName,
    actorRole,
    timestamp: new Date().toISOString(),
  };
  db.auditLog.push(entry);
  // Keep last 500 entries
  if (db.auditLog.length > 500) {
    db.auditLog = db.auditLog.slice(-500);
  }
}

export function computeSharesForPrice(db: Database, price: number): { centerShare: number; teacherShare: number } {
  const payoutType = db.globalProfitModel;
  const payoutValue = db.globalProfitValue;
  if (payoutType === 'fixed_seat') {
    const teacherShare = payoutValue;
    const centerShare = Math.max(0, price - teacherShare);
    return { teacherShare, centerShare };
  }
  if (payoutType === 'percentage') {
    const teacherShare = Math.round((price * payoutValue) / 100);
    const centerShare = price - teacherShare;
    return { teacherShare, centerShare };
  }
  const teacherShare = payoutValue;
  const centerShare = Math.max(0, price - teacherShare);
  return { teacherShare, centerShare };
}


export function arrearFor(
  db: Database,
  teacherId: string,
  grade: string
): number {
  const entry = db.teacherArrears.find(
    (a) => a.teacherId === teacherId && a.grade === grade
  );
  return entry ? entry.amount : 0;
}

export function secretarySalaryFor(
  db: Database,
  userId: string
): number {
  const entry = db.secretarySalaries.find((s) => s.userId === userId);
  return entry ? entry.amount : 0;
}

export function canViewFinancials(role: Role | undefined): boolean {
  return role === 'admin';
}

export function canViewLiquidation(role: Role | undefined): boolean {
  return role === 'admin' || role === 'teacher';
}

export function discountedSessionFee(
  basePrice: number,
  student: Pick<Student, 'hasSiblingDiscount' | 'discountPercent' | 'discountType' | 'hasSpecialDiscount' | 'specialDiscountPercent'>
): number {
  let price = basePrice;
  if (student.hasSiblingDiscount && student.discountPercent && student.discountPercent > 0) {
    price = Math.round(price * (1 - student.discountPercent / 100));
  }
  if (student.hasSpecialDiscount && (student.specialDiscountPercent ?? 0) > 0) {
    price = Math.round(price * (1 - (student.specialDiscountPercent ?? 0) / 100));
  }
  return price;
}

export function findSiblings(
  students: Student[],
  current: { id?: number; lastName?: string; parentPhone?: string }
): Student[] {
  const lastName = (current.lastName || '').trim();
  const parentPhone = (current.parentPhone || '').trim();
  if (!lastName && !parentPhone) return [];
  return students.filter((s) => {
    if (current.id !== undefined && s.id === current.id) return false;
    const sLast = (s.lastName || (s.name.split(' ').slice(1).join(' ') || '')).trim();
    const matchLast = lastName && sLast && sLast === lastName;
    const matchPhone = parentPhone && s.parentPhone && s.parentPhone.trim() === parentPhone;
    return Boolean(matchLast || matchPhone);
  });
}

export const BILLING_MODEL_LABELS: Record<BillingModel, string> = {
  per_session: 'لكل حصة',
  monthly: 'اشتراك شهري',
  full_package: 'باقة كاملة',
};

export const PAYOUT_TYPE_LABELS: Record<PayoutType, string> = {
  fixed_seat: 'رسم ثابت للطالب',
  percentage: 'نسبة مئوية',
  flat_per_session: 'مبلغ ثابت للحصة',
};

export function groupBasePrice(db: Database, group: Group): number {
  if (group.customPrice && group.customPrice > 0) return group.customPrice;
  const gp = db.gradePrices.find((p) => p.grade === group.grade);
  return gp?.price ?? 0;
}

export function groupBillingPrice(db: Database, group: Group): number {
  const base = groupBasePrice(db, group);
  if (group.billingModel === 'monthly' && group.monthlyFee) return group.monthlyFee;
  if (group.billingModel === 'full_package' && group.packageFee) return group.packageFee;
  return base;
}

export function effectiveStudentDiscount(student: Student): { percent: number; type: 'sibling' | 'twin' | 'special' | 'none' } {
  const sibling = student.hasSiblingDiscount && (student.discountPercent ?? 0) > 0
    ? student.discountPercent!
    : 0;
  const special = student.hasSpecialDiscount && (student.specialDiscountPercent ?? 0) > 0
    ? student.specialDiscountPercent!
    : 0;
  if (special > 0) return { percent: special, type: 'special' };
  if (sibling > 0) return { percent: sibling, type: student.discountType === 'twin' ? 'twin' : 'sibling' };
  return { percent: 0, type: 'none' };
}

export function studentFinalPrice(db: Database, group: Group, student: Student): number {
  const base = groupBillingPrice(db, group);
  const { percent } = effectiveStudentDiscount(student);
  if (percent > 0) return Math.round(base * (1 - percent / 100));
  return base;
}

export function resolvePayoutConfig(db: Database, group: Group): { payoutType: PayoutType; payoutValue: number } {
  if (db.allowProfitOverride) {
    return { payoutType: group.payoutType, payoutValue: group.payoutValue };
  }
  return { payoutType: db.globalProfitModel, payoutValue: db.globalProfitValue };
}

export function computeTeacherPayout(
  db: Database,
  group: Group,
  studentCount: number,
  grossRevenue: number
): { teacherShare: number; centerShare: number } {
  const { payoutType, payoutValue } = resolvePayoutConfig(db, group);
  if (payoutType === 'fixed_seat') {
    const teacherShare = Math.round(payoutValue * studentCount);
    const centerShare = Math.max(0, grossRevenue - teacherShare);
    return { teacherShare, centerShare };
  }
  if (payoutType === 'percentage') {
    const teacherShare = Math.round(grossRevenue * payoutValue / 100);
    const centerShare = grossRevenue - teacherShare;
    return { teacherShare, centerShare };
  }
  // flat_per_session
  const teacherShare = payoutValue;
  const centerShare = Math.max(0, grossRevenue - teacherShare);
  return { teacherShare, centerShare };
}

export function applyAllDiscounts(basePrice: number, student: Student): number {
  let price = basePrice;
  if (student.hasSiblingDiscount && (student.discountPercent ?? 0) > 0) {
    price = Math.round(price * (1 - student.discountPercent! / 100));
  }
  if (student.hasSpecialDiscount && (student.specialDiscountPercent ?? 0) > 0) {
    price = Math.round(price * (1 - student.specialDiscountPercent! / 100));
  }
  return price;
}

export const DISCOUNT_TYPE_LABELS: Record<NonNullable<Student['discountType']>, string> = {
  none: 'بدون خصم',
  sibling: 'خصم أشقاء',
  twin: 'خصم توأم',
};

export function resolveDiscountPercent(
  type: 'none' | 'sibling' | 'twin',
  siblingPercent: number,
  twinPercent: number
): number {
  if (type === 'sibling') return siblingPercent;
  if (type === 'twin') return twinPercent;
  return 0;
}
