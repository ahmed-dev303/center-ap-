import type { Group, Database } from './types';
import { uid } from './date';

export const DAYS_OF_WEEK = [
  'السبت',
  'الأحد',
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
];

const DAY_NAME_MAP: Record<string, number> = {
  'السبت': 6,
  'الأحد': 0,
  'الاثنين': 1,
  'الثلاثاء': 2,
  'الأربعاء': 3,
  'الخميس': 4,
  'الجمعة': 5,
};

export function generateTimeSlots(): string[] {
  const slots: string[] = [];
  for (let h = 8; h <= 23; h++) {
    for (const m of [0, 30]) {
      slots.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);
    }
  }
  return slots;
}

export function formatTimeArabic(time: string): string {
  const [h, m] = time.split(':').map(Number);
  const period = h >= 12 ? 'م' : 'ص';
  const displayH = h > 12 ? h - 12 : h === 0 ? 12 : h;
  return `${displayH}:${String(m).padStart(2, '0')} ${period}`;
}

export function calculateHalfwayTime(startTime: string, endTime: string): string {
  const [sh, sm] = startTime.split(':').map(Number);
  const [eh, em] = endTime.split(':').map(Number);
  const startMin = sh * 60 + sm;
  const endMin = eh * 60 + em;
  const halfMin = Math.round((startMin + endMin) / 2);
  const hh = Math.floor(halfMin / 60);
  const mm = halfMin % 60;
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

export function isSessionToday(group: Group): boolean {
  if (!group.scheduleDays || group.scheduleDays.length === 0) return false;
  const today = new Date().getDay();
  return group.scheduleDays.some((day) => DAY_NAME_MAP[day] === today);
}

export function getCurrentTimeStr(): string {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
}

export function hasHalfTimePassed(group: Group): boolean {
  if (!group.halfwayTime || !group.startTime || !group.endTime) return false;
  if (!isSessionToday(group)) return false;
  const now = getCurrentTimeStr();
  return now >= group.halfwayTime;
}

export type AttendanceWindowState = 'before' | 'open' | 'closed';

export function getAttendanceWindowState(
  group: Group,
  openingBufferMinutes: number,
  closingPercent: number
): AttendanceWindowState {
  if (!group.startTime || !group.endTime) return 'closed';
  if (!isSessionToday(group)) return 'closed';

  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();

  const [sh, sm] = group.startTime.split(':').map(Number);
  const [eh, em] = group.endTime.split(':').map(Number);
  const startMin = sh * 60 + sm;
  const endMin = eh * 60 + em;
  const duration = endMin - startMin;
  const closingMin = startMin + Math.round((duration * closingPercent) / 100);
  const openingMin = startMin - openingBufferMinutes;

  if (nowMin < openingMin) return 'before';
  if (nowMin >= closingMin) return 'closed';
  return 'open';
}

export function getAttendanceWindowLabel(
  group: Group,
  openingBufferMinutes: number,
  closingPercent: number
): string | null {
  const state = getAttendanceWindowState(group, openingBufferMinutes, closingPercent);
  if (state === 'before') {
    return `لم يبدأ وقت تسجيل الحضور بعد (يفتح قبل الحصة بـ ${openingBufferMinutes} دقائق) ⏳`;
  }
  if (state === 'closed') {
    return 'انتهى وقت تسجيل الحضور لهذه الحصة ⛔';
  }
  return null;
}

export function autoMarkAbsent(
  db: Database,
  group: Group,
  date: string,
  actorName: string,
  actorRole: 'admin' | 'secretary' | 'teacher'
): number {
  const enrolledStudents = db.students.filter((s) => s.groupId === group.id);
  const existingAttendance = db.attendance.filter(
    (a) => a.groupId === group.id && a.date === date
  );
  const presentStudentIds = new Set(
    existingAttendance.filter((a) => a.status === 'present').map((a) => a.studentId)
  );
  const alreadyMarkedIds = new Set(existingAttendance.map((a) => a.studentId));

  let count = 0;
  for (const s of enrolledStudents) {
    if (!presentStudentIds.has(s.id) && !alreadyMarkedIds.has(s.id)) {
      db.attendance.push({
        id: uid('att'),
        studentId: s.id,
        groupId: group.id,
        date,
        status: 'absent',
        createdAt: new Date().toISOString(),
      });
      count++;
    }
  }

  if (count > 0) {
    db.auditLog.push({
      id: uid('audit'),
      action: 'تسجيل غياب تلقائي',
      detail: `تم تسجيل غياب ${count} طالب تلقائياً في مجموعة ${group.name} (انقضى نصف الوقت).`,
      actorName,
      actorRole,
      timestamp: new Date().toISOString(),
    });
    if (db.auditLog.length > 500) db.auditLog = db.auditLog.slice(-500);
  }

  return count;
}

export function getActiveSessionGroups(db: Database): Group[] {
  return db.groups.filter((g) => {
    if (!g.startTime || !g.endTime) return false;
    if (!isSessionToday(g)) return false;
    const now = getCurrentTimeStr();
    return now >= g.startTime && now <= g.endTime;
  });
}

export function getHalfTimePassedGroups(db: Database): Group[] {
  return db.groups.filter((g) => hasHalfTimePassed(g));
}
