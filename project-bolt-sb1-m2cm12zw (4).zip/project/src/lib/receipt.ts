import type { Payment, Student, Group } from './types';
import { getCenterBrand, brandLogoHTML } from './branding';
import { formatEGP } from './date';

const receiptStyles = `
  @page { size: 80mm auto; margin: 0; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Cairo', sans-serif; background: #fff; color: #1e293b; width: 80mm; }
  .receipt { width: 80mm; padding: 4mm 3mm; }
  .center-name { font-size: 15px; font-weight: 800; color: #1e293b; text-align: center; }
  .center-sub { font-size: 9px; color: #64748b; text-align: center; margin-bottom: 2px; }
  .divider { border-top: 1px dashed #94a3b8; margin: 6px 0; }
  .title { text-align: center; font-size: 12px; font-weight: 700; color: #1e293b; margin: 4px 0; letter-spacing: 1px; }
  .receipt-no { text-align: center; font-size: 10px; color: #64748b; margin-bottom: 4px; }
  .row { display: flex; justify-content: space-between; font-size: 10px; padding: 2px 0; }
  .row .label { color: #64748b; }
  .row .val { font-weight: 700; color: #1e293b; }
  .amount-box { text-align: center; margin: 6px 0; padding: 6px; background: #f0fdf4; border: 1px dashed #bbf7d0; border-radius: 6px; }
  .amount-box .lbl { font-size: 9px; color: #15803d; font-weight: 600; }
  .amount-box .amt { font-size: 18px; font-weight: 800; color: #166534; }
  .note { font-size: 9px; color: #64748b; text-align: center; margin-top: 4px; }
  .footer { text-align: center; margin-top: 6px; padding-top: 4px; border-top: 1px dashed #94a3b8; font-size: 9px; color: #94a3b8; }
  .sign { display: flex; justify-content: space-between; margin-top: 10px; font-size: 9px; color: #64748b; }
  .sign-line { width: 70px; border-top: 1px solid #94a3b8; margin-bottom: 3px; }
  .barcode-wrap { text-align: center; margin: 6px 0; }
  .barcode { font-family: 'Libre Barcode 39', monospace; font-size: 28px; letter-spacing: 2px; color: #1e293b; }
  .barcode-text { font-size: 9px; color: #64748b; letter-spacing: 3px; }
`;

function typeLabel(type: Payment['paymentType']): string {
  if (type === 'session') return 'رسوم شهرية';
  if (type === 'book') return 'مذكرة / كتاب';
  return 'كارت ID';
}

export function printReceipt(
  payment: Payment,
  student: Student | undefined,
  group: Group | undefined
): void {
  const brand = getCenterBrand();
  const dateStr = new Date(payment.date).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' });
  const timeStr = new Date(payment.createdAt).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  const html = `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>إيصال ${student?.name || ''}</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&family=Libre+Barcode+39&display=swap" rel="stylesheet"><style>${receiptStyles}</style></head><body>
    <div class="receipt">
      ${brand.logo ? `<div style="text-align:center;margin-bottom:2px;">${brandLogoHTML(brand.logo, 40)}</div>` : ''}
      <div class="center-name">${brand.name}</div>
      <div class="center-sub">إيصال تحصيل رسوم</div>
      <div class="divider"></div>
      <div class="title">إيصال رقم #${payment.id}</div>
      <div class="receipt-no">${dateStr} — ${timeStr}</div>
      <div class="divider"></div>
      <div class="row"><span class="label">الطالب:</span><span class="val">${student?.name || '—'}</span></div>
      <div class="row"><span class="label">الكود:</span><span class="val">${student?.id ?? '—'}</span></div>
      <div class="row"><span class="label">الصف:</span><span class="val">${student?.grade || '—'}</span></div>
      <div class="row"><span class="label">المجموعة:</span><span class="val">${group?.name || payment.groupName || '—'}</span></div>
      ${student?.hasSiblingDiscount && student.discountPercent ? `<div class="row"><span class="label">نوع الخصم:</span><span class="val" style="color:${student.discountType === 'twin' ? '#7c3aed' : '#b45309'}">${student.discountType === 'twin' ? 'خصم توأم' : 'خصم أشقاء'} ${student.discountPercent}%</span></div>` : ''}
      <div class="row"><span class="label">نوع الدفعة:</span><span class="val">${typeLabel(payment.paymentType)}</span></div>
      ${payment.month ? `<div class="row"><span class="label">الشهر:</span><span class="val">${payment.month}</span></div>` : ''}
      <div class="row"><span class="label">طريقة الدفع:</span><span class="val">${payment.method === 'cash' ? 'نقدي' : payment.method === 'card' ? 'بطاقة' : 'تحويل'}</span></div>
      <div class="row"><span class="label">المستلم:</span><span class="val">${payment.collectedBy || '—'}</span></div>
      ${payment.discountType && payment.discountType !== 'none' && payment.discountPercent ? `<div class="row"><span class="label">الخصم المطبّق:</span><span class="val" style="color:${payment.discountType === 'twin' ? '#7c3aed' : '#b45309'}">${payment.discountType === 'twin' ? 'خصم توأم' : 'خصم أشقاء'} ${payment.discountPercent}%</span></div>` : ''}
      <div class="amount-box">
        <div class="lbl">المبلغ المحصّل</div>
        <div class="amt">${formatEGP(payment.amount)} ج.م</div>
      </div>
      ${payment.note ? `<div class="note">${payment.note}</div>` : ''}
      <div class="barcode-wrap">
        <div class="barcode">*${payment.id}*</div>
        <div class="barcode-text">${payment.id}</div>
      </div>
      <div class="divider"></div>
      <div class="sign">
        <div><div class="sign-line"></div>المحصّل (${payment.collectedBy || ''})</div>
        <div><div class="sign-line"></div>ولي الأمر</div>
      </div>
      <div class="footer">شكراً لكم — ${brand.name}</div>
    </div>
    <script>window.onload=function(){setTimeout(function(){window.print();},500);}</script>
  </body></html>`;
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.write(html);
  w.document.close();
}
