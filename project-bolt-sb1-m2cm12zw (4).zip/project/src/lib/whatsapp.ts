import type { Student } from './types';
import { formatEGP } from './date';

export type WhatsAppTemplate = 'absence' | 'unpaid' | 'general' | 'installment' | 'exam';

function normalizePhone(phone: string): string {
  let p = phone.replace(/[\s\-+]/g, '');
  if (p.startsWith('00')) p = p.slice(2);
  if (p.startsWith('0')) p = '2' + p;
  return p;
}

export function buildWhatsAppURL(phone: string, message: string): string {
  const clean = normalizePhone(phone);
  return `https://wa.me/${clean}?text=${encodeURIComponent(message)}`;
}

export function openWhatsApp(phone: string, message: string) {
  if (!phone.trim()) return;
  window.open(buildWhatsAppURL(phone, message), '_blank', 'noopener,noreferrer');
}

export function whatsappMessage(
  template: WhatsAppTemplate,
  student: Student,
  opts?: { centerName?: string; groupName?: string; amountDue?: number; date?: string; dueDate?: string; examTitle?: string; examScore?: number; examMaxScore?: number; examPercent?: number; examStatus?: string }
): string {
  const center = opts?.centerName || 'السنتر';
  const group = opts?.groupName || '';
  const date = opts?.date || '';
  const parentName = student.parentName || 'ولي الأمر';

  switch (template) {
    case 'absence':
      return `السلام عليكم ${parentName}،\nنعلمكم بأن الطالب/ة ${student.name} (كود #${student.id})${group ? ` - مجموعة ${group}` : ''} لم يحضر اليوم${date ? ` ${date}` : ''}.\nنرجو التواصل مع إدارة ${center} لمعرفة السبب.\nشكراً لكم.`;

    case 'unpaid': {
      const amount = opts?.amountDue ? formatEGP(opts.amountDue) : '';
      return `السلام عليكم ${parentName}،\nتذكير ودي بأن هناك رسوم مستحقة بقيمة ${amount} ج.م للطالب/ة ${student.name} (كود #${student.id})${group ? ` - مجموعة ${group}` : ''}.\nنرجو السداد في أقرب وقت لتجنب وقف الخدمة.\nمع خالص تقديرنا، إدارة ${center}.`;
    }

    case 'installment': {
      const amount = opts?.amountDue ? formatEGP(opts.amountDue) : '';
      const dueDate = opts?.dueDate || '';
      return `السلام عليكم ${parentName}،\nتذكير ودي بأن هناك قسط مستحق بقيمة ${amount} للطالب/ة ${student.name} (كود #${student.id})${group ? ` - مجموعة ${group}` : ''}${dueDate ? ` كان مستحق السداد في ${dueDate}` : ''}.\nنرجو السداد في أقرب وقت لتجنب رسوم إضافية.\nمع خالص تقديرنا، إدارة ${center}.`;
    }

    case 'exam': {
      const examTitle = opts?.examTitle || '';
      const score = opts?.examScore ?? 0;
      const maxScore = opts?.examMaxScore ?? 0;
      const percent = opts?.examPercent ?? 0;
      const status = opts?.examStatus || '';
      return `السلام عليكم ${parentName}،\nنتشرف بإفادتكم بنتيجة الطالب/ة ${student.name} (كود #${student.id})${group ? ` - مجموعة ${group}` : ''}${examTitle ? ` في ${examTitle}` : ''}.${date ? ` بتاريخ ${date}` : ''}\nالدرجة: ${score} من ${maxScore} (${percent}%) — ${status}\nمع خالص تقديرنا، إدارة ${center}.`;
    }

    case 'general':
    default:
      return `السلام عليكم ${parentName}،\nبرجاء العلم بأن الطالب/ة ${student.name} (كود #${student.id})${group ? ` - مجموعة ${group}` : ''}.\nلدينا ملاحظة نود التواصل معكم بشأنها.\nإدارة ${center}.`;
  }
}
