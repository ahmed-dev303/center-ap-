import type { Student } from './types';
import { getCenterBrand, brandLogoHTML } from './branding';

const certStyles = `
  @page { size: A4 landscape; margin: 0; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Cairo', sans-serif; background: #fff; display: grid; place-items: center; min-height: 100vh; }
  .cert {
    width: 270mm; height: 190mm;
    background: linear-gradient(135deg, #f8fafc 0%, #eef2f7 100%);
    border: 3px solid #1e3a5f;
    border-radius: 20px;
    padding: 15mm;
    position: relative;
    overflow: hidden;
  }
  .cert::before {
    content: ''; position: absolute; top: 8mm; left: 8mm; right: 8mm; bottom: 8mm;
    border: 1.5px solid #cbd5e1; border-radius: 14px; pointer-events: none;
  }
  .corner { position: absolute; width: 40mm; height: 40mm; opacity: 0.08; }
  .corner-tl { top: 0; left: 0; border-top: 6px solid #1e3a5f; border-left: 6px solid #1e3a5f; border-top-left-radius: 20px; }
  .corner-tr { top: 0; right: 0; border-top: 6px solid #1e3a5f; border-right: 6px solid #1e3a5f; border-top-right-radius: 20px; }
  .corner-bl { bottom: 0; left: 0; border-bottom: 6px solid #1e3a5f; border-left: 6px solid #1e3a5f; border-bottom-left-radius: 20px; }
  .corner-br { bottom: 0; right: 0; border-bottom: 6px solid #1e3a5f; border-right: 6px solid #1e3a5f; border-bottom-right-radius: 20px; }
  .header { text-align: center; margin-bottom: 8mm; }
  .logo { font-size: 48px; margin-bottom: 4mm; }
  .center-name { font-size: 32px; font-weight: 800; color: #1e3a5f; }
  .center-sub { font-size: 14px; color: #64748b; letter-spacing: 2px; }
  .title { text-align: center; margin: 6mm 0; }
  .title h1 { font-size: 28px; font-weight: 800; color: #1e3a5f; }
  .body { text-align: center; margin: 8mm 0; }
  .body p { font-size: 16px; color: #334155; margin-bottom: 4mm; }
  .student-name { font-size: 36px; font-weight: 800; color: #1e3a5f; margin: 4mm 0; }
  .reason { font-size: 14px; color: #475569; max-width: 180mm; margin: 0 auto; line-height: 1.6; }
  .footer { position: absolute; bottom: 15mm; left: 0; right: 0; display: flex; justify-content: space-around; }
  .sign { text-align: center; }
  .sign-line { width: 50mm; border-top: 1.5px solid #334155; margin-bottom: 3mm; }
  .sign-label { font-size: 12px; color: #64748b; font-weight: 600; }
  .seal { position: absolute; bottom: 25mm; left: 50%; transform: translateX(-50%); width: 30mm; height: 30mm; border: 2px solid #1e3a5f; border-radius: 50%; display: grid; place-items: center; font-size: 10px; font-weight: 700; color: #1e3a5f; opacity: 0.3; }
`;

export function printCertificate(student: Student, reason: string): void {
  const brand = getCenterBrand();
  const dateStr = new Date().toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' });
  const html = `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>شهادة تقدير - ${student.name}</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet"><style>${certStyles}</style></head><body>
    <div class="cert">
      <div class="corner corner-tl"></div><div class="corner corner-tr"></div><div class="corner corner-bl"></div><div class="corner corner-br"></div>
      <div class="header">
        <div class="logo">${brandLogoHTML(brand.logo, 48)}</div>
        <div class="center-name">${brand.name}</div>
        <div class="center-sub">CERTIFICATE OF APPRECIATION</div>
      </div>
      <div class="title"><h1>شهادة تقدير</h1></div>
      <div class="body">
        <p>تشهد إدارة ${brand.name} بأن الطالب/ة</p>
        <div class="student-name">${student.name}</div>
        <p>قد حصل على هذه الشهادة تقديراً لتفوقه ومجهوده</p>
        <p class="reason">${reason}</p>
      </div>
      <div class="seal">ختم<br>السنتر</div>
      <div class="footer">
        <div class="sign"><div class="sign-line"></div><div class="sign-label">مدير السنتر</div></div>
        <div class="sign"><div class="sign-line"></div><div class="sign-label">التاريخ: ${dateStr}</div></div>
      </div>
    </div>
    <script>window.onload=function(){setTimeout(function(){window.print();},500);}</script>
  </body></html>`;
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.write(html);
  w.document.close();
}
