export type Role = 'admin' | 'secretary' | 'teacher' | 'assistant' | 'supervisor' | 'master';

export interface Branch {
  id: string;
  name: string;
  address: string;
  createdAt: string;
}

export type SecretaryLinkType = 'attendance' | 'payments' | 'both';
export type SecretarySpecialty = 'full' | 'attendance' | 'collection' | 'materials';

export interface User {
  id: string;
  username: string;
  password: string;
  name: string;
  role: Role;
  teacherId?: string;
  branchIds?: string[];
  linkedTeacherId?: string;
  linkType?: SecretaryLinkType;
  specialty?: SecretarySpecialty;
  payModel?: StaffPayModel;
  rate?: number;
  phone?: string;
}

export interface Student {
  id: number;
  name: string;
  firstName?: string;
  lastName?: string;
  phone: string;
  parentPhone: string;
  parentName?: string;
  motherPhone?: string;
  grade: string;
  groupId: string | null;
  groupIds: string[];
  branchId: string | null;
  note: string;
  qrCode?: string;
  hasSiblingDiscount?: boolean;
  discountPercent?: number;
  discountType?: 'none' | 'sibling' | 'twin';
  hasSpecialDiscount?: boolean;
  specialDiscountPercent?: number;
  specialDiscountNote?: string;
  createdAt: string;
}

export interface Teacher {
  id: string;
  name: string;
  phone: string;
  subject: string;
  branchId: string | null;
  centerSharePercent?: number;
  createdAt: string;
}

export type BillingModel = 'per_session' | 'monthly' | 'full_package';
export type PayoutType = 'fixed_seat' | 'percentage' | 'flat_per_session';

export interface Group {
  id: string;
  name: string;
  teacherId: string | null;
  subject: string;
  grade: string;
  schedule: string;
  scheduleDays: string[];
  startTime: string | null;
  endTime: string | null;
  halfwayTime: string | null;
  branchId: string | null;
  billingModel: BillingModel;
  customPrice: number | null;
  payoutType: PayoutType;
  payoutValue: number;
  monthlyFee: number | null;
  packageFee: number | null;
  createdAt: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: number;
  groupId: string;
  date: string;
  status: 'present' | 'absent';
  createdAt: string;
}

export type PaymentType = 'session' | 'book' | 'id' | 'tuition';

export interface Payment {
  id: string;
  studentId: number;
  groupId: string | null;
  groupName?: string;
  branchId: string | null;
  amount: number;
  date: string;
  month: string;
  method: 'cash' | 'card' | 'transfer';
  paymentType: PaymentType;
  bookTitle?: string;
  note: string;
  collectedBy?: string;
  discountType?: 'none' | 'sibling' | 'twin';
  discountPercent?: number;
  createdAt: string;
}

export interface GradePrice {
  grade: string;
  price: number;
}

export interface TeacherArrearEntry {
  teacherId: string;
  grade: string;
  amount: number;
  note: string;
  updatedAt: string;
}

export interface SecretarySalary {
  userId: string;
  amount: number;
  locked: boolean;
  updatedAt: string;
}

export interface StudyMaterial {
  id: string;
  title: string;
  groupId: string;
  description: string;
  price: number;
  stock: number;
  createdAt: string;
}

export type ExpenseCategory = 'rent' | 'electricity' | 'printing' | 'cleaning' | 'hospitality' | 'maintenance' | 'other';

export interface Expense {
  id: string;
  category: ExpenseCategory;
  categoryLabel: string;
  branchId: string | null;
  amount: number;
  date: string;
  note: string;
  createdAt: string;
}

export interface Salary {
  id: string;
  userId: string;
  userName: string;
  basic: number;
  bonus: number;
  deductions: number;
  advances: number;
  net: number;
  month: string;
  date: string;
  note: string;
  createdAt: string;
}

export type ExamType = 'monthly' | 'weekly' | 'homework';

export interface Exam {
  id: string;
  groupId: string;
  title: string;
  type: ExamType;
  date: string;
  maxScore: number;
  createdAt: string;
}

export interface ExamScore {
  id: string;
  examId: string;
  studentId: number;
  groupId: string;
  examTitle: string;
  score: number;
  maxScore: number;
  note: string;
  date: string;
  createdAt: string;
}

export interface AuditEntry {
  id: string;
  action: string;
  detail: string;
  actorName: string;
  actorRole: Role;
  timestamp: string;
}

export interface SyncStamp {
  lastImportTime: string | null;
  lastImportActor: string | null;
}

export type AdjustmentType = 'advance' | 'reward' | 'deduction';

export interface StaffAdjustment {
  id: string;
  userId: string;
  userName: string;
  type: AdjustmentType;
  amount: number;
  date: string;
  reason: string;
  month: string;
  createdAt: string;
}

export interface ContactNote {
  id: string;
  studentId: number;
  text: string;
  date: string;
  active: boolean;
  createdAt: string;
}

export interface ExportMeta {
  exportTimestamp: string;
  exportedBy: string;
}

export type StaffRole = 'secretary' | 'supervisor' | 'assistant';
export type StaffPayModel = 'hourly' | 'per_session' | 'fixed_monthly' | 'percentage';

export interface Staff {
  id: string;
  userId?: string;
  name: string;
  phone: string;
  role: StaffRole;
  payModel: StaffPayModel;
  rate: number;
  branchId: string | null;
  active: boolean;
  createdAt: string;
}

export interface StaffAttendance {
  id: string;
  staffId: string;
  date: string;
  clockIn: string | null;
  clockOut: string | null;
  sessions: number;
  hours: number;
  note: string;
  createdAt: string;
}

export interface StaffPayout {
  id: string;
  staffId: string;
  staffName: string;
  amount: number;
  date: string;
  periodLabel: string;
  note: string;
  createdAt: string;
}

export type InstallmentStatus = 'paid' | 'pending' | 'overdue';

export interface Installment {
  id: string;
  amount: number;
  dueDate: string;
  status: InstallmentStatus;
  paidDate: string | null;
  paymentId: string | null;
}

export interface InstallmentPlan {
  id: string;
  studentId: number;
  groupId: string;
  totalAmount: number;
  installments: Installment[];
  createdAt: string;
}

export interface Database {
  users: User[];
  branches: Branch[];
  students: Student[];
  teachers: Teacher[];
  groups: Group[];
  attendance: AttendanceRecord[];
  payments: Payment[];
  gradePrices: GradePrice[];
  materials: StudyMaterial[];
  exams: Exam[];
  examScores: ExamScore[];
  expenses: Expense[];
  salaries: Salary[];
  auditLog: AuditEntry[];
  globalProfitModel: PayoutType;
  globalProfitValue: number;
  allowProfitOverride: boolean;
  teacherArrears: TeacherArrearEntry[];
  secretarySalaries: SecretarySalary[];
  idCardPrice: number;
  siblingDiscountPercent: number;
  twinDiscountPercent: number;
  centerName: string;
  centerLogo: string | null;
  qrEnabled: boolean;
  attendanceOpeningBuffer: number;
  attendanceClosingPercent: number;
  allowFlexibleAttendanceTime: boolean;
  syncStamp: SyncStamp;
  staffAdjustments: StaffAdjustment[];
  contactNotes: ContactNote[];
  exportMeta: ExportMeta | null;
  staff: Staff[];
  staffAttendance: StaffAttendance[];
  staffPayouts: StaffPayout[];
  installmentPlans: InstallmentPlan[];
  meta: { nextStudentId: number };
}

export type DeviceStatus = 'approved' | 'pending' | 'blocked';

export type LicenseType = 'full' | 'trial';

export interface MasterDevice {
  id: string;
  deviceId: string;
  deviceName: string;
  ipAddress: string;
  status: DeviceStatus;
  activationHash: string | null;
  firstSeen: string;
  lastActive: string;
  notes: string;
  actionCount: number;
  firstLaunchAt: string | null;
  trialExpired: boolean;
  licenseType: LicenseType;
  trialExpiresAt: string | null;
}

export interface TrialSettings {
  trialDays: number;
  maxTrialActions: number;
  trialEnabled: boolean;
  updatedAt: string;
}

export type LicenseState = 'approved' | 'trial' | 'expired' | 'blocked' | 'master';
