import QRCode from 'qrcode';

export async function generateQRDataUrl(text: string, size = 200): Promise<string> {
  return QRCode.toDataURL(text, {
    width: size,
    margin: 1,
    color: { dark: '#1e1b4b', light: '#ffffff' },
    errorCorrectionLevel: 'M',
  });
}

export function generateStudentCode(studentId: number): string {
  return `STD-${String(studentId).padStart(5, '0')}`;
}

export function parseStudentCode(code: string): number | null {
  const match = code.trim().match(/STD-?(\d+)/i);
  if (match) return Number(match[1]);
  const numeric = code.trim();
  if (/^\d+$/.test(numeric)) return Number(numeric);
  return null;
}

export function isQrCodeUnique(students: { id: number; qrCode?: string }[], code: string, excludeId?: number): boolean {
  return !students.some((s) => s.qrCode === code && s.id !== excludeId);
}
