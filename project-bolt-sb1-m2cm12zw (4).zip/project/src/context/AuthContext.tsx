import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { User, Role, SecretarySpecialty } from '../lib/types';
import { loadDB } from '../lib/db';
import { verifyMasterPin } from '../lib/master';

interface AuthState {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  loginMaster: (pin: string) => boolean;
  logout: () => void;
  updateProfile: (patch: Partial<Pick<User, 'username' | 'password' | 'name'>>) => void;
}

const AuthContext = createContext<AuthState | null>(null);

const SESSION_KEY = 'al_afdal_session';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(SESSION_KEY);
      if (raw) setUser(JSON.parse(raw));
    } catch {
      // ignore
    }
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    const trimmed = username.trim();
    const db = loadDB();
    const found = db.users.find((u) => u.username === trimmed && u.password === password);
    if (found) {
      setUser(found);
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(found));
      return true;
    }
    return false;
  };

  const loginMaster = (pin: string): boolean => {
    if (!verifyMasterPin(pin)) return false;
    const masterUser: User = {
      id: 'SUPER_ADMIN_MASTER',
      username: '__master__',
      password: '',
      name: 'مالك النظام الفائق',
      role: 'master',
    };
    setUser(masterUser);
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(masterUser));
    return true;
  };

  const logout = () => {
    setUser(null);
    sessionStorage.removeItem(SESSION_KEY);
  };

  const updateProfile = (patch: Partial<Pick<User, 'username' | 'password' | 'name'>>) => {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, ...patch };
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(next));
      return next;
    });
  };

  return <AuthContext.Provider value={{ user, login, loginMaster, logout, updateProfile }}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export function canAccess(role: Role | undefined, page: string, linkType?: string, linkedTeacherId?: string, specialty?: SecretarySpecialty): boolean {
  if (!role) return false;
  const adminPages = ['dashboard', 'students', 'teachers', 'groups', 'attendance', 'payments', 'scanner', 'materials', 'exams', 'expenses', 'adjustments', 'profits', 'audit', 'accounts', 'settlements', 'staff', 'installments', 'leaderboard', 'settings', 'profile'];
  let secretaryPages = ['dashboard', 'students', 'attendance', 'payments', 'scanner', 'materials', 'exams', 'installments', 'leaderboard', 'profile'];
  const teacherPages = ['dashboard', 'groups', 'attendance', 'scanner', 'materials', 'exams', 'settlements', 'leaderboard', 'profile'];
  const staffPages = ['dashboard', 'attendance', 'scanner', 'profile'];

  if (role === 'secretary' && linkedTeacherId && linkType) {
    if (linkType === 'attendance') {
      secretaryPages = secretaryPages.filter((p) => p !== 'payments' && p !== 'materials' && p !== 'installments');
    } else if (linkType === 'payments') {
      secretaryPages = secretaryPages.filter((p) => p !== 'attendance' && p !== 'scanner');
    }
  }

  if (role === 'master') return true;

  if (role === 'secretary' && specialty && specialty !== 'full') {
    if (specialty === 'attendance') {
      secretaryPages = secretaryPages.filter((p) => p !== 'payments' && p !== 'materials' && p !== 'installments' && p !== 'scanner' && p !== 'exams');
    } else if (specialty === 'collection') {
      secretaryPages = secretaryPages.filter((p) => p !== 'attendance' && p !== 'scanner' && p !== 'exams');
    } else if (specialty === 'materials') {
      secretaryPages = secretaryPages.filter((p) => p !== 'attendance' && p !== 'payments' && p !== 'scanner' && p !== 'installments' && p !== 'exams' && p !== 'staff');
    }
  }

  const map: Record<Role, string[]> = {
    admin: adminPages,
    secretary: secretaryPages,
    teacher: teacherPages,
    assistant: staffPages,
    supervisor: staffPages,
    master: adminPages,
  };
  return map[role].includes(page);
}

export function canExport(role: Role | undefined): boolean {
  return role === 'admin' || role === 'secretary' || role === 'teacher' || role === 'assistant' || role === 'supervisor' || role === 'master';
}

export function canImport(role: Role | undefined): boolean {
  return role === 'admin' || role === 'secretary' || role === 'teacher' || role === 'assistant' || role === 'supervisor' || role === 'master';
}

export function canEditGradePrices(role: Role | undefined): boolean {
  return role === 'admin';
}

export function canManageTeachers(role: Role | undefined): boolean {
  return role === 'admin';
}

export function canEditSettings(role: Role | undefined): boolean {
  return role === 'admin';
}

export function canViewAuditLog(role: Role | undefined): boolean {
  return role === 'admin';
}

export function canManageStudents(role: Role | undefined): boolean {
  return role === 'admin' || role === 'secretary';
}

export function canManageMaterials(role: Role | undefined): boolean {
  return role === 'admin' || role === 'teacher';
}

export function canSellMaterials(role: Role | undefined): boolean {
  return role === 'admin' || role === 'secretary';
}

export function canViewPayments(role: Role | undefined): boolean {
  return role === 'admin' || role === 'secretary';
}

export function canManageAccounts(role: Role | undefined): boolean {
  return role === 'admin';
}

export function roleLabel(role: Role): string {
  return { admin: 'مدير', secretary: 'سكرتير', teacher: 'معلم', assistant: 'مساعد', supervisor: 'مشرف', master: 'مالك النظام' }[role];
}
