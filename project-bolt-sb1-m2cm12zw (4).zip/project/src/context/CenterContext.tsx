import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

const CENTER_KEY = 'al_afdal_selected_center';

interface CenterState {
  selectedCenterId: string | null;
  setSelectedCenterId: (id: string | null) => void;
}

const CenterContext = createContext<CenterState | null>(null);

export function CenterProvider({ children }: { children: ReactNode }) {
  const [selectedCenterId, setSelectedCenterId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(CENTER_KEY) || null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    try {
      if (selectedCenterId) localStorage.setItem(CENTER_KEY, selectedCenterId);
      else localStorage.removeItem(CENTER_KEY);
    } catch {
      // ignore
    }
  }, [selectedCenterId]);

  return (
    <CenterContext.Provider value={{ selectedCenterId, setSelectedCenterId }}>
      {children}
    </CenterContext.Provider>
  );
}

export function useCenter(): CenterState {
  const ctx = useContext(CenterContext);
  if (!ctx) throw new Error('useCenter must be used within CenterProvider');
  return ctx;
}
