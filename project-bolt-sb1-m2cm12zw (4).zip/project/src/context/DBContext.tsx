import { createContext, useContext, useState, useEffect, useCallback, useRef, type ReactNode } from 'react';
import type { Database } from '../lib/types';
import { loadDB, saveDB } from '../lib/db';
import { runAutoAbsence } from '../lib/absence';
import { updateAppIcons } from '../lib/app-icons';

interface DBState {
  db: Database;
  update: (mutator: (db: Database) => void) => void;
  replace: (db: Database) => void;
  reset: () => void;
  refresh: () => void;
}

const DBContext = createContext<DBState | null>(null);

export function DBProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<Database>(() => loadDB());
  const autoRan = useRef(false);

  useEffect(() => {
    updateAppIcons(db.centerLogo ?? null, db.centerName ?? 'سنتر الأفضل');
  }, [db.centerLogo, db.centerName]);

  useEffect(() => {
    if (autoRan.current) return;
    autoRan.current = true;
    const result = runAutoAbsence(db);
    if (result.added > 0) {
      saveDB(db);
      setDb({ ...db });
    }
  }, [db]);

  const update = useCallback((mutator: (db: Database) => void) => {
    setDb((prev) => {
      const next: Database = JSON.parse(JSON.stringify(prev));
      mutator(next);
      saveDB(next);
      return next;
    });
  }, []);

  const replace = useCallback((newDb: Database) => {
    saveDB(newDb);
    setDb(newDb);
  }, []);

  const reset = useCallback(() => {
    const fresh = loadDB();
    saveDB(fresh);
    setDb(fresh);
  }, []);

  const refresh = useCallback(() => {
    setDb(loadDB());
  }, []);

  return (
    <DBContext.Provider value={{ db, update, replace, reset, refresh }}>
      {children}
    </DBContext.Provider>
  );
}

export function useDB(): DBState {
  const ctx = useContext(DBContext);
  if (!ctx) throw new Error('useDB must be used within DBProvider');
  return ctx;
}
