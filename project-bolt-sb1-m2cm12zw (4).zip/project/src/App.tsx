import { useState, useEffect, useRef } from 'react';
import { AuthProvider, useAuth, canAccess } from './context/AuthContext';
import { ToastProvider, useToast } from './context/ToastContext';
import { DBProvider, useDB } from './context/DBContext';
import { CenterProvider } from './context/CenterContext';
import { validateBackup, readFileSystemHandle, readFileAsText } from './lib/backup-restore';
import { logAction } from './lib/finance';
import type { Database } from './lib/types';
import { Login } from './pages/Login';
import { Layout, type PageKey } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Students } from './pages/Students';
import { Teachers } from './pages/Teachers';
import { Groups } from './pages/Groups';
import { Attendance } from './pages/Attendance';
import { Payments } from './pages/Payments';
import { Scanner } from './pages/Scanner';
import { Settings } from './pages/Settings';
import { Materials } from './pages/Materials';
import { Expenses } from './pages/Expenses';
import { StaffAdjustments } from './pages/StaffAdjustments';
import { SecretProfits } from './pages/SecretProfits';
import { AuditLog } from './pages/AuditLog';
import { Accounts } from './pages/Accounts';
import { Settlements } from './pages/Settlements';
import { Staff } from './pages/Staff';
import { Installments } from './pages/Installments';
import { Exams } from './pages/Exams';
import { Leaderboard } from './pages/Leaderboard';
import { Profile } from './pages/Profile';
import { MasterPanel } from './pages/MasterPanel';
import { LicenseGuard } from './components/LicenseGuard';
import { DeviceLockScreen } from './components/DeviceLockScreen';
import { TrialCountdownBanner } from './components/TrialCountdownBanner';
import { registerThisDevice, isThisDeviceApproved, isThisDeviceBlocked, getThisDeviceLicenseType, isTrialExpired, markTrialExpired } from './lib/master';
import { ErrorBoundary } from './components/ErrorBoundary';

function AppContent() {
  const { user } = useAuth();
  const { replace } = useDB();
  const { showToast } = useToast();
  const [page, setPage] = useState<PageKey>('dashboard');
  const [trialLocked, setTrialLocked] = useState(false);
  const launchHandled = useRef(false);

  useEffect(() => {
    registerThisDevice();
  }, []);

  useEffect(() => {
    if (launchHandled.current) return;
    launchHandled.current = true;

    const w = window as unknown as {
      launchQueue?: {
        setConsumer: (cb: (params: { files: FileSystemFileHandle[] }) => void) => void;
      };
    };

    if (!w.launchQueue?.setConsumer) return;

    w.launchQueue.setConsumer(async (params) => {
      if (!params.files || params.files.length === 0) return;
      try {
        const text = await readFileSystemHandle(params.files[0]);
        const parsed = JSON.parse(text);
        const result = validateBackup(parsed);
        if (!result.valid || !result.data) {
          showToast(result.error || 'ملف غير صالح', 'error');
          return;
        }
        const restored: Database = result.data;
        logAction(restored, 'استيراد تلقائي', 'تم تحميل ملف الحفظ عبر فتح الملف من الجهاز', 'النظام', 'admin');
        replace(restored);
        showToast('تم تحميل ملف الحفظ واستعادة البيانات بنجاح');
      } catch {
        showToast('تعذّر قراءة ملف الحفظ', 'error');
      }
    });
  }, [replace, showToast]);

  if (!user) {
    if (isThisDeviceBlocked()) return <DeviceLockScreen />;
    if (!isThisDeviceApproved()) return <DeviceLockScreen />;
    return <Login />;
  }

  if (user.role === 'master') {
    return <MasterPanel />;
  }

  if (!isThisDeviceApproved()) {
    return <DeviceLockScreen />;
  }

  if (isTrialExpired()) {
    markTrialExpired();
    return <DeviceLockScreen />;
  }

  const showTrialBanner = getThisDeviceLicenseType() === 'trial';

  const effectivePage = canAccess(user.role, page, user.linkType, user.linkedTeacherId, user.specialty) ? page : (user.role === 'master' ? 'master' : 'dashboard');

  const renderPage = () => {
    switch (effectivePage) {
      case 'dashboard':
        return <Dashboard onNavigate={setPage} />;
      case 'students':
        return <Students />;
      case 'teachers':
        return <Teachers />;
      case 'groups':
        return <Groups />;
      case 'attendance':
        return <Attendance />;
      case 'payments':
        return <Payments />;
      case 'scanner':
        return <Scanner />;
      case 'materials':
        return <Materials />;
      case 'expenses':
        return <Expenses />;
      case 'adjustments':
        return <StaffAdjustments />;
      case 'profits':
        return <SecretProfits />;
      case 'audit':
        return <AuditLog />;
      case 'accounts':
        return <Accounts />;
      case 'settlements':
        return <Settlements />;
      case 'staff':
        return <Staff />;
      case 'installments':
        return <Installments />;
      case 'exams':
        return <Exams />;
      case 'leaderboard':
        return <Leaderboard />;
      case 'settings':
        return <Settings />;
      case 'profile':
        return <Profile />;
      case 'master':
        return <MasterPanel />;
      default:
        return <Dashboard onNavigate={setPage} />;
    }
  };

  return (
    <LicenseGuard role={user.role}>
      <div className="flex flex-col min-h-screen">
        {showTrialBanner && !trialLocked && (
          <TrialCountdownBanner onExpired={() => {
            markTrialExpired();
            setTrialLocked(true);
          }} />
        )}
        {trialLocked ? (
          <DeviceLockScreen />
        ) : (
          <Layout current={effectivePage} onNavigate={setPage}>
            {renderPage()}
          </Layout>
        )}
      </div>
    </LicenseGuard>
  );
}

export default function App() {
  return (
    <DBProvider>
      <AuthProvider>
        <CenterProvider>
          <ToastProvider>
            <ErrorBoundary>
              <AppContent />
            </ErrorBoundary>
          </ToastProvider>
        </CenterProvider>
      </AuthProvider>
    </DBProvider>
  );
}
