import { useMemo, useRef, useState } from 'react';
import {
  Trophy, Crown, Medal, Award, Download, Printer, Filter,
  TrendingUp, CalendarCheck, ClipboardList, Star, Users, Lock,
} from 'lucide-react';
import html2canvas from 'html2canvas';
import { useAuth, roleLabel } from '../context/AuthContext';
import { useDB } from '../context/DBContext';
import { useCenter } from '../context/CenterContext';
import { getScopedData, filterByCenter } from '../lib/scoping';
import { formatDate } from '../lib/date';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import type { Teacher } from '../lib/types';

type SortKey = 'overall' | 'attendance' | 'exams' | 'behavior';
type RankMode = 'center' | 'subject';

interface RankedStudent {
  id: number;
  name: string;
  grade: string;
  groupName: string;
  teacherName: string;
  attendanceRate: number;
  examAverage: number;
  behaviorScore: number;
  overall: number;
}

export function Leaderboard() {
  const { user } = useAuth();
  const { db } = useDB();
  const { selectedCenterId } = useCenter();
  const posterRef = useRef<HTMLDivElement>(null);

  const [gradeFilter, setGradeFilter] = useState('all');
  const [groupFilter, setGroupFilter] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('overall');
  const [rankMode, setRankMode] = useState<RankMode>('center');
  const [selectedTeacherId, setSelectedTeacherId] = useState('all');

  const isAdmin = user?.role === 'admin';
  const isTeacher = user?.role === 'teacher';
  const isLinkedSecretary = user?.role === 'secretary' && !!user?.linkedTeacherId;
  const isLockedScope = isTeacher || isLinkedSecretary;

  const lockedTeacherId = isTeacher
    ? user?.teacherId
    : isLinkedSecretary
    ? user?.linkedTeacherId
    : null;

  const roleScoped = getScopedData(db, user);
  const scopedStudents = filterByCenter(roleScoped.students, selectedCenterId);
  const scopedGroups = filterByCenter(roleScoped.groups, selectedCenterId);
  const scopedGroupIds = new Set(scopedGroups.map((g) => g.id));

  const centerTeachers = useMemo(() => {
    const teacherIds = new Set(
      filterByCenter(db.groups, selectedCenterId)
        .map((g) => g.teacherId)
        .filter(Boolean) as string[]
    );
    return db.teachers.filter((t) => teacherIds.has(t.id));
  }, [db.groups, db.teachers, selectedCenterId]);

  const grades = useMemo(() => {
    const set = new Set<string>();
    for (const s of scopedStudents) if (s.grade) set.add(s.grade);
    return Array.from(set).sort();
  }, [scopedStudents]);

  const groups = useMemo(() => {
    let filtered = scopedGroups;
    if (gradeFilter !== 'all') filtered = filtered.filter((g) => g.grade === gradeFilter);
    if (isAdmin && rankMode === 'subject' && selectedTeacherId !== 'all') {
      filtered = filtered.filter((g) => g.teacherId === selectedTeacherId);
    }
    return filtered;
  }, [scopedGroups, gradeFilter, isAdmin, rankMode, selectedTeacherId]);

  const ranked: RankedStudent[] = useMemo(() => {
    const visibleGroupIds = new Set(groups.map((g) => g.id));

    const students = scopedStudents.filter((s) => {
      if (!s.groupId || !visibleGroupIds.has(s.groupId)) return false;
      if (gradeFilter !== 'all' && s.grade !== gradeFilter) return false;
      if (groupFilter !== 'all' && s.groupId !== groupFilter) return false;
      return true;
    });

    return students.map((s) => {
      const group = db.groups.find((g) => g.id === s.groupId);
      const teacher = db.teachers.find((t) => t.id === group?.teacherId);
      const studentAttendance = db.attendance.filter((a) => a.studentId === s.id && visibleGroupIds.has(a.groupId));
      const presentCount = studentAttendance.filter((a) => a.status === 'present').length;
      const attendanceRate = studentAttendance.length > 0 ? (presentCount / studentAttendance.length) * 100 : 0;

      const scores = (db.examScores || []).filter((e) => e.studentId === s.id && visibleGroupIds.has(e.groupId));
      const examAverage = scores.length > 0
        ? scores.reduce((sum, e) => sum + (e.score / e.maxScore) * 100, 0) / scores.length
        : 0;

      const notes = (db.contactNotes || []).filter((n) => n.studentId === s.id && n.active);
      const behaviorScore = Math.max(0, 100 - notes.length * 15);

      const overall = attendanceRate * 0.35 + examAverage * 0.45 + behaviorScore * 0.20;

      return {
        id: s.id,
        name: s.name,
        grade: s.grade,
        groupName: group?.name || '—',
        teacherName: teacher?.name || '—',
        attendanceRate,
        examAverage,
        behaviorScore,
        overall,
      };
    }).sort((a, b) => b[sortKey] - a[sortKey]);
  }, [scopedStudents, groups, db.groups, db.teachers, db.attendance, db.examScores, db.contactNotes, gradeFilter, groupFilter, sortKey]);

  const handleExportPNG = async () => {
    if (!posterRef.current) return;
    try {
      const canvas = await html2canvas(posterRef.current, {
        scale: 2,
        backgroundColor: '#ffffff',
        useCORS: true,
      });
      const link = document.createElement('a');
      link.download = `leaderboard-${new Date().toISOString().slice(0, 10)}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch {
      // ignore
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const sortLabels: Record<SortKey, string> = {
    overall: 'المجموع التراكمي الشامل',
    attendance: 'نسبة الحضور والالتزام',
    exams: 'متوسط درجات الامتحانات',
    behavior: 'التقييم السلوكي والملاحظات',
  };

  const rankModeLabels: Record<RankMode, string> = {
    center: 'الأول على مستوى كل المواد',
    subject: 'الأول في مادة محددة',
  };

  const podiumStyles = [
    { border: 'border-amber-400', bg: 'from-amber-400 to-yellow-500', badge: 'bg-amber-400', icon: Crown, label: 'المركز الأول' },
    { border: 'border-slate-400', bg: 'from-slate-300 to-slate-400', badge: 'bg-slate-400', icon: Medal, label: 'المركز الثاني' },
    { border: 'border-orange-400', bg: 'from-orange-300 to-orange-500', badge: 'bg-orange-400', icon: Award, label: 'المركز الثالث' },
  ];

  const today = formatDate(new Date().toISOString());

  const activeTeacherName = lockedTeacherId
    ? db.teachers.find((t) => t.id === lockedTeacherId)?.name || '—'
    : null;

  const headerSubtitle = isLockedScope && activeTeacherName
    ? `ترتيب أوائل ${activeTeacherName}`
    : rankMode === 'subject' && selectedTeacherId !== 'all'
    ? `الأول في مادة: ${centerTeachers.find((t) => t.id === selectedTeacherId)?.name || ''}`
    : 'الأول على مستوى السنتر — جميع المواد';

  return (
    <div className="space-y-5">
      {/* Filters Bar */}
      <Card className="p-4 sm:p-5 no-print">
        <div className="flex items-center gap-2 mb-3">
          <Filter size={18} className="text-brand-500" />
          <h3 className="font-bold text-brand-900">الفلاتر والترتيب</h3>
          {isLockedScope && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-brand-100 text-brand-600 text-[10px] font-bold mr-auto">
              <Lock size={10} /> مقفل على مجموعاتك
            </span>
          )}
        </div>

        {/* Admin Ranking Mode Toggle */}
        {isAdmin && (
          <div className="mb-3">
            <label className="block text-xs font-semibold text-brand-400 mb-1.5">نمط الترتيب</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => { setRankMode('center'); setSelectedTeacherId('all'); }}
                className={`flex items-center gap-2 px-3 py-2.5 rounded-2xl text-sm font-bold transition-all ${
                  rankMode === 'center'
                    ? 'gradient-brand text-white shadow-soft'
                    : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
                }`}
              >
                <Trophy size={16} /> الأول على مستوى كل المواد
              </button>
              <button
                onClick={() => setRankMode('subject')}
                className={`flex items-center gap-2 px-3 py-2.5 rounded-2xl text-sm font-bold transition-all ${
                  rankMode === 'subject'
                    ? 'gradient-brand text-white shadow-soft'
                    : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
                }`}
              >
                <Users size={16} /> الأول في مادة محددة
              </button>
            </div>
          </div>
        )}

        <div className={`grid grid-cols-1 sm:grid-cols-3 ${isAdmin && rankMode === 'subject' ? 'lg:grid-cols-4' : ''} gap-3`}>
          {/* Subject/Teacher selector — admin subject mode only */}
          {isAdmin && rankMode === 'subject' && (
            <div>
              <label className="block text-xs font-semibold text-brand-400 mb-1.5">المعلم / المادة</label>
              <select
                value={selectedTeacherId}
                onChange={(e) => { setSelectedTeacherId(e.target.value); setGroupFilter('all'); }}
                className="w-full rounded-2xl border-2 border-brand-100 bg-white px-3 py-2.5 text-sm font-bold text-brand-900 focus:border-brand-400 outline-none transition-colors"
              >
                <option value="all">جميع المعلمين</option>
                {centerTeachers.map((t: Teacher) => (
                  <option key={t.id} value={t.id}>{t.name} — {t.subject || 'مادة'}</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-brand-400 mb-1.5">الصف الدراسي</label>
            <select
              value={gradeFilter}
              onChange={(e) => { setGradeFilter(e.target.value); setGroupFilter('all'); }}
              className="w-full rounded-2xl border-2 border-brand-100 bg-white px-3 py-2.5 text-sm font-bold text-brand-900 focus:border-brand-400 outline-none transition-colors"
            >
              <option value="all">جميع الصفوف</option>
              {grades.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-brand-400 mb-1.5">المجموعة</label>
            <select
              value={groupFilter}
              onChange={(e) => setGroupFilter(e.target.value)}
              className="w-full rounded-2xl border-2 border-brand-100 bg-white px-3 py-2.5 text-sm font-bold text-brand-900 focus:border-brand-400 outline-none transition-colors"
            >
              <option value="all">جميع المجموعات</option>
              {groups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-brand-400 mb-1.5">معيار الترتيب</label>
            <select
              value={sortKey}
              onChange={(e) => setSortKey(e.target.value as SortKey)}
              className="w-full rounded-2xl border-2 border-brand-100 bg-white px-3 py-2.5 text-sm font-bold text-brand-900 focus:border-brand-400 outline-none transition-colors"
            >
              {(Object.keys(sortLabels) as SortKey[]).map((k) => (
                <option key={k} value={k}>{sortLabels[k]}</option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {/* Action Buttons */}
      <div className="flex items-center gap-3 no-print">
        <button
          onClick={handleExportPNG}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-brand-600 text-white text-sm font-bold shadow-soft hover:bg-brand-700 active:scale-95 transition-all"
        >
          <Download size={18} /> حفظ كصورة PNG
        </button>
        <button
          onClick={handlePrint}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-emerald-600 text-white text-sm font-bold shadow-soft hover:bg-emerald-700 active:scale-95 transition-all"
        >
          <Printer size={18} /> طباعة كشف الأوائل
        </button>
        <div className="mr-auto">
          <Badge tone="brand">{user ? roleLabel(user.role) : ''}</Badge>
        </div>
      </div>

      {/* Leaderboard Poster (capture target) */}
      <div ref={posterRef} className="leaderboard-poster bg-white rounded-3xl shadow-glass overflow-hidden">
        {/* Header */}
        <div className="gradient-brand px-5 sm:px-8 py-5 sm:py-6 text-white relative overflow-hidden">
          <div className="absolute -top-8 -left-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
          <div className="relative flex items-center gap-4">
            <div className="grid place-items-center h-14 w-14 rounded-2xl bg-white/20 overflow-hidden shrink-0">
              {db.centerLogo ? (
                <img src={db.centerLogo} alt="logo" className="h-full w-full object-cover" />
              ) : (
                <Trophy size={28} />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl sm:text-2xl font-extrabold truncate">{db.centerName}</h1>
              <p className="text-sm text-white/80">لوحة الشرف وترتيب الأوائل — {headerSubtitle}</p>
              <p className="text-xs text-white/60 mt-0.5">{today}</p>
            </div>
          </div>
        </div>

        {ranked.length === 0 ? (
          <div className="py-16 text-center">
            <Trophy size={48} className="text-brand-200 mx-auto mb-3" />
            <p className="text-sm font-semibold text-brand-400">لا توجد بيانات كافية لعرض الترتيب</p>
          </div>
        ) : (
          <>
            {/* Podium Top 3 */}
            {ranked.length >= 1 && (
              <div className="px-4 sm:px-8 pt-6 pb-2">
                <div className="flex items-end justify-center gap-3 sm:gap-6">
                  {ranked.slice(0, 3).map((s, idx) => {
                    const style = podiumStyles[idx];
                    const Icon = style.icon;
                    const heights = ['h-32', 'h-24', 'h-20'];
                    const order = idx === 0 ? 2 : idx === 1 ? 1 : 3;
                    return (
                      <div key={s.id} className="flex flex-col items-center" style={{ order }}>
                        <div className={`grid place-items-center h-12 w-12 rounded-2xl bg-gradient-to-br ${style.bg} text-white shadow-soft mb-2`}>
                          <Icon size={24} />
                        </div>
                        <p className="font-bold text-brand-900 text-sm text-center truncate max-w-[110px]">{s.name}</p>
                        <p className="text-xs text-brand-400 mb-2">{s.grade}</p>
                        <div className={`rounded-t-2xl bg-gradient-to-br ${style.bg} ${heights[idx]} w-20 sm:w-24 flex items-center justify-center text-white font-extrabold text-2xl shadow-soft`}>
                          {idx + 1}
                        </div>
                        <div className={`mt-1.5 px-3 py-1 rounded-full ${style.badge} text-white text-[10px] font-bold`}>
                          {style.label}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Full Roster Table */}
            <div className="px-3 sm:px-8 pb-6 pt-4">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b-2 border-brand-100">
                      <th className="text-right py-3 px-2 font-bold text-brand-400 text-xs">#</th>
                      <th className="text-right py-3 px-2 font-bold text-brand-400 text-xs">الطالب</th>
                      <th className="text-right py-3 px-2 font-bold text-brand-400 text-xs hidden sm:table-cell">الصف</th>
                      <th className="text-right py-3 px-2 font-bold text-brand-400 text-xs hidden md:table-cell">المجموعة</th>
                      <th className="text-center py-3 px-2 font-bold text-brand-400 text-xs">الحضور%</th>
                      <th className="text-center py-3 px-2 font-bold text-brand-400 text-xs">الامتحان%</th>
                      <th className="text-center py-3 px-2 font-bold text-brand-400 text-xs hidden sm:table-cell">السلوك</th>
                      <th className="text-center py-3 px-2 font-bold text-brand-400 text-xs">المجموع</th>
                      <th className="text-center py-3 px-2 font-bold text-brand-400 text-xs">المركز</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ranked.map((s, idx) => {
                      const podium = idx < 3 ? podiumStyles[idx] : null;
                      return (
                        <tr
                          key={s.id}
                          className={`border-b border-brand-50 transition-colors ${podium ? `border-l-4 ${podium.border}` : ''} hover:bg-brand-50/40`}
                        >
                          <td className="py-3 px-2 font-bold text-brand-600">{idx + 1}</td>
                          <td className="py-3 px-2">
                            <div className="flex items-center gap-2">
                              {podium && (
                                <div className={`grid place-items-center h-7 w-7 rounded-lg bg-gradient-to-br ${podium.bg} text-white shrink-0`}>
                                  <podium.icon size={14} />
                                </div>
                              )}
                              <span className="font-bold text-brand-900 truncate">{s.name}</span>
                            </div>
                          </td>
                          <td className="py-3 px-2 text-brand-600 hidden sm:table-cell">{s.grade}</td>
                          <td className="py-3 px-2 text-brand-600 hidden md:table-cell">
                            <span className="truncate block max-w-[120px]">{s.groupName}</span>
                          </td>
                          <td className="py-3 px-2 text-center font-bold text-emerald-600">{Math.round(s.attendanceRate)}%</td>
                          <td className="py-3 px-2 text-center font-bold text-brand-600">{Math.round(s.examAverage)}%</td>
                          <td className="py-3 px-2 text-center font-bold text-amber-600 hidden sm:table-cell">{Math.round(s.behaviorScore)}%</td>
                          <td className="py-3 px-2 text-center">
                            <span className="font-extrabold text-brand-900">{s.overall.toFixed(1)}</span>
                          </td>
                          <td className="py-3 px-2 text-center">
                            {podium ? (
                              <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full ${podium.badge} text-white text-[10px] font-bold`}>
                                <podium.icon size={10} /> {idx + 1}
                              </span>
                            ) : (
                              <span className="text-xs font-bold text-brand-400">{idx + 1}</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Footer with teacher names */}
            <div className="px-5 sm:px-8 py-4 border-t border-brand-100 bg-brand-50/40">
              <div className="flex items-center gap-2 flex-wrap">
                <Users size={14} className="text-brand-400" />
                <span className="text-xs font-semibold text-brand-500">المعلمون:</span>
                {Array.from(new Set(ranked.map((r) => r.teacherName))).map((name) => (
                  <span key={name} className="text-xs font-bold text-brand-700 bg-white rounded-full px-2.5 py-1 border border-brand-100">
                    {name}
                  </span>
                ))}
              </div>
              <p className="text-[10px] text-brand-300 mt-2">
                {db.centerName} — تم إنشاء هذا الكشف بواسطة نظام إدارة سنتر الأفضل بتاريخ {today}
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
