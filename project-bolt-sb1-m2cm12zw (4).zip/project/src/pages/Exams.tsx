import { useState, useMemo } from 'react';
import { ClipboardList, Plus, Trash2, Edit3, X, Award, BookOpen, Calendar, Users, Check } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { getScopedData, filterByCenter } from '../lib/scoping';
import { useCenter } from '../context/CenterContext';
import { uid, todayStr, formatDate } from '../lib/date';
import { logAction } from '../lib/finance';
import { getCenterBrand } from '../lib/branding';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { WhatsAppButton } from '../components/ui/WhatsAppButton';
import type { Exam, ExamType, ExamScore } from '../lib/types';

const EXAM_TYPE_LABELS: Record<ExamType, string> = {
  monthly: 'امتحان شهري',
  weekly: 'امتحان أسبوعي',
  homework: 'واجب منزلي',
};

function getGradeStatus(percent: number | null, submitted: boolean): { label: string; tone: 'emerald' | 'brand' | 'amber' | 'rose' | 'slate' } {
  if (!submitted) return { label: 'لم يسلم', tone: 'rose' };
  if (percent === null) return { label: '—', tone: 'slate' };
  if (percent >= 85) return { label: 'ممتاز', tone: 'emerald' };
  if (percent >= 65) return { label: 'مجتهد', tone: 'brand' };
  if (percent >= 50) return { label: 'مقبول', tone: 'amber' };
  return { label: 'ضعيف', tone: 'rose' };
}

export function Exams() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { showToast } = useToast();
  const { selectedCenterId } = useCenter();
  const scoped = getScopedData(db, user);
  const isTeacher = user?.role === 'teacher';
  const groups = isTeacher ? scoped.groups : filterByCenter(scoped.groups, selectedCenterId);

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Exam | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [gradingExam, setGradingExam] = useState<Exam | null>(null);

  const exams = useMemo(() => {
    const groupIds = new Set(groups.map((g) => g.id));
    return db.exams.filter((e) => groupIds.has(e.groupId));
  }, [db.exams, groups]);

  const handleSaveExam = (data: Omit<Exam, 'id' | 'createdAt'> & { id?: string }) => {
    update((d) => {
      if (editing) {
        const idx = d.exams.findIndex((e) => e.id === editing.id);
        if (idx >= 0) {
          d.exams[idx] = { ...d.exams[idx], ...data };
          d.examScores = d.examScores.map((s) =>
            s.examId === editing.id
              ? { ...s, examTitle: data.title, maxScore: data.maxScore, groupId: data.groupId, date: data.date }
              : s
          );
        }
        logAction(d, 'تعديل امتحان', `قام ${user?.name || ''} بتعديل الامتحان: ${data.title}.`, user?.name || '', user?.role || 'admin');
      } else {
        d.exams.push({ ...data, id: uid('exam'), createdAt: new Date().toISOString() } as Exam);
        logAction(d, 'إنشاء امتحان', `قام ${user?.name || ''} بإنشاء امتحان جديد: ${data.title}.`, user?.name || '', user?.role || 'admin');
      }
    });
    showToast(editing ? 'تم تحديث الامتحان' : 'تم إنشاء الامتحان بنجاح');
    setShowForm(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const exam = db.exams.find((e) => e.id === deleteId);
    update((d) => {
      d.exams = d.exams.filter((e) => e.id !== deleteId);
      d.examScores = d.examScores.filter((s) => s.examId !== deleteId);
      logAction(d, 'حذف امتحان', `قام ${user?.name || ''} بحذف الامتحان: ${exam?.title || ''}.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف الامتحان', 'info');
    setDeleteId(null);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900">الامتحانات والواجبات</h2>
          <p className="text-sm text-brand-400 mt-0.5">{exams.length} امتحان / واجب</p>
        </div>
        <Button onClick={() => { setEditing(null); setShowForm(true); }}>
          <Plus size={18} /> امتحان جديد
        </Button>
      </div>

      {exams.length === 0 ? (
        <EmptyState icon={<ClipboardList size={36} />} title="لا توجد امتحانات" description="أنشئ امتحاناً أو واجباً جديداً لإدخال درجات الطلاب" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {exams.map((exam) => {
            const group = db.groups.find((g) => g.id === exam.groupId);
            const studentCount = db.students.filter((s) => s.groupId === exam.groupId).length;
            const gradedCount = db.examScores.filter((s) => s.examId === exam.id).length;
            return (
              <Card key={exam.id} className="p-5" hover>
                <div className="flex items-start justify-between mb-3">
                  <div className="grid place-items-center h-14 w-14 rounded-2xl bg-gradient-to-br from-violet-500 to-brand-700 text-white shadow-soft">
                    <Award size={26} />
                  </div>
                  <Badge tone={exam.type === 'homework' ? 'amber' : 'brand'}>{EXAM_TYPE_LABELS[exam.type]}</Badge>
                </div>
                <h3 className="font-bold text-brand-900 mb-1">{exam.title}</h3>
                <div className="space-y-1.5 text-sm">
                  <div className="flex items-center gap-2 text-brand-600">
                    <BookOpen size={14} className="text-brand-400" /> {group?.name || '—'}
                  </div>
                  <div className="flex items-center gap-2 text-brand-600">
                    <Calendar size={14} className="text-brand-400" /> {formatDate(exam.date)}
                  </div>
                  <div className="flex items-center gap-2 text-brand-600">
                    <Users size={14} className="text-brand-400" /> {gradedCount}/{studentCount} تم التقييم
                  </div>
                  <div className="flex items-center gap-2 text-brand-600">
                    <Award size={14} className="text-brand-400" /> الدرجة العظمى: {exam.maxScore}
                  </div>
                </div>
                <div className="flex gap-2 mt-3 pt-3 border-t border-slate-100">
                  <Button size="sm" variant="secondary" className="flex-1" onClick={() => setGradingExam(exam)}>
                    <Edit3 size={15} /> إدخال الدرجات
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => { setEditing(exam); setShowForm(true); }}>
                    <Edit3 size={15} />
                  </Button>
                  <Button size="sm" variant="ghost" className="text-rose-500" onClick={() => setDeleteId(exam.id)}>
                    <Trash2 size={15} />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {showForm && (
        <ExamForm exam={editing} groups={groups} onClose={() => { setShowForm(false); setEditing(null); }} onSave={handleSaveExam} />
      )}

      {gradingExam && (
        <GradeGrid exam={gradingExam} db={db} update={update} onClose={() => setGradingExam(null)} showToast={showToast} user={user} />
      )}

      <ConfirmDialog
        open={deleteId !== null}
        title="حذف الامتحان"
        message="سيتم حذف الامتحان وكل درجاته. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function ExamForm({ exam, groups, onClose, onSave }: {
  exam: Exam | null;
  groups: { id: string; name: string }[];
  onClose: () => void;
  onSave: (data: Omit<Exam, 'id' | 'createdAt'> & { id?: string }) => void;
}) {
  const [title, setTitle] = useState(exam?.title || '');
  const [groupId, setGroupId] = useState(exam?.groupId || '');
  const [type, setType] = useState<ExamType>(exam?.type || 'monthly');
  const [date, setDate] = useState(exam?.date || todayStr());
  const [maxScore, setMaxScore] = useState(exam ? String(exam.maxScore) : '20');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !groupId || !maxScore) return;
    onSave({
      id: exam?.id,
      title: title.trim(),
      groupId,
      type,
      date,
      maxScore: Number(maxScore),
    });
  };

  return (
    <Modal open onClose={onClose} title={exam ? 'تعديل الامتحان' : 'إنشاء امتحان / واجب'} size="md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input label="اسم الامتحان / الواجب" placeholder="مثال: امتحان الوحدة الأولى" value={title} onChange={(e) => setTitle(e.target.value)} required />
        <Select label="المجموعة" value={groupId} onChange={(e) => setGroupId(e.target.value)} required>
          <option value="">اختر المجموعة</option>
          {groups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
        </Select>
        <Select label="النوع" value={type} onChange={(e) => setType(e.target.value as ExamType)}>
          <option value="monthly">امتحان شهري</option>
          <option value="weekly">امتحان أسبوعي</option>
          <option value="homework">واجب منزلي</option>
        </Select>
        <div className="grid grid-cols-2 gap-3">
          <Input label="التاريخ" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
          <Input label="الدرجة العظمى" type="number" placeholder="مثال: 20" value={maxScore} onChange={(e) => setMaxScore(e.target.value)} required />
        </div>
        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إلغاء</Button>
          <Button type="submit" className="flex-1">{exam ? 'حفظ' : 'إنشاء'}</Button>
        </div>
      </form>
    </Modal>
  );
}

function GradeGrid({ exam, db, update, onClose, showToast, user }: {
  exam: Exam;
  db: ReturnType<typeof useDB>['db'];
  update: ReturnType<typeof useDB>['update'];
  onClose: () => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
  user: ReturnType<typeof useAuth>['user'];
}) {
  const centerName = getCenterBrand().name;
  const group = db.groups.find((g) => g.id === exam.groupId);
  const students = db.students.filter((s) => s.groupId === exam.groupId);
  const existingScores = useMemo(() => {
    const map = new Map<number, ExamScore>();
    db.examScores.filter((s) => s.examId === exam.id).forEach((s) => map.set(s.studentId, s));
    return map;
  }, [db.examScores, exam.id]);

  const [scores, setScores] = useState<Record<number, string>>({});
  const [notes, setNotes] = useState<Record<number, string>>({});

  students.forEach((s) => {
    const existing = existingScores.get(s.id);
    if (scores[s.id] === undefined) scores[s.id] = existing ? String(existing.score) : '';
    if (notes[s.id] === undefined) notes[s.id] = existing?.note || '';
  });

  const handleSave = () => {
    update((d) => {
      d.examScores = d.examScores.filter((s) => s.examId !== exam.id);
      for (const student of students) {
        const raw = scores[student.id];
        if (raw === '' || raw === undefined) continue;
        const score = Number(raw);
        d.examScores.push({
          id: uid('es'),
          examId: exam.id,
          studentId: student.id,
          groupId: exam.groupId,
          examTitle: exam.title,
          score,
          maxScore: exam.maxScore,
          note: notes[student.id] || '',
          date: exam.date,
          createdAt: new Date().toISOString(),
        });
      }
      logAction(d, 'إدخال درجات', `قام ${user?.name || ''} بإدخال درجات ${exam.title}.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حفظ الدرجات بنجاح');
    onClose();
  };

  return (
    <Modal open onClose={onClose} title={`درجات: ${exam.title}`} size="lg">
      <div className="space-y-3">
        <div className="rounded-2xl bg-brand-50 px-4 py-2.5 flex items-center justify-between">
          <span className="text-sm font-bold text-brand-900">الدرجة العظمى: {exam.maxScore}</span>
          <span className="text-sm text-brand-400">{students.length} طالب</span>
        </div>
        {students.length === 0 ? (
          <EmptyState icon={<Users size={36} />} title="لا يوجد طلاب" description="لا يوجد طلاب مسجلون في هذه المجموعة" />
        ) : (
          <>
            <div className="space-y-2 max-h-[50vh] overflow-y-auto">
              {students.map((s) => {
                const raw = scores[s.id] ?? '';
                const score = raw ? Number(raw) : null;
                const percent = score !== null && exam.maxScore > 0 ? Math.round((score / exam.maxScore) * 100) : null;
                const status = getGradeStatus(percent, raw !== '');
                return (
                  <div key={s.id} className="flex items-center gap-2 rounded-2xl border border-slate-100 p-3">
                    <div className="grid place-items-center h-10 w-10 rounded-xl bg-brand-100 text-brand-700 font-bold shrink-0">
                      {s.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-brand-900 text-sm truncate">{s.name}</p>
                      <p className="text-xs text-brand-400">#{s.id}</p>
                    </div>
                    <input
                      type="number"
                      value={raw}
                      onChange={(e) => setScores((p) => ({ ...p, [s.id]: e.target.value }))}
                      placeholder="الدرجة"
                      className="w-20 h-10 rounded-xl border-2 border-slate-200 px-2 text-sm font-bold text-center text-brand-900 focus:outline-none focus:border-brand-500"
                    />
                    <input
                      value={notes[s.id] ?? ''}
                      onChange={(e) => setNotes((p) => ({ ...p, [s.id]: e.target.value }))}
                      placeholder="ملاحظة"
                      className="hidden sm:block w-32 h-10 rounded-xl border-2 border-slate-200 px-2 text-xs text-brand-600 focus:outline-none focus:border-brand-500"
                    />
                    {percent !== null && <Badge tone={status.tone}>{percent}%</Badge>}
                    <Badge tone={status.tone}>{status.label}</Badge>
                    {raw !== '' && (
                      <WhatsAppButton
                        student={s}
                        template="exam"
                        centerName={centerName}
                        groupName={group?.name}
                        examTitle={exam.title}
                        examScore={Number(raw)}
                        examMaxScore={exam.maxScore}
                        examPercent={percent ?? 0}
                        examStatus={status.label}
                        date={exam.date}
                      />
                    )}
                  </div>
                );
              })}
            </div>
            <div className="flex gap-3 pt-2">
              <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إغلاق</Button>
              <Button className="flex-1" onClick={handleSave}><Check size={18} /> حفظ الدرجات</Button>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}
