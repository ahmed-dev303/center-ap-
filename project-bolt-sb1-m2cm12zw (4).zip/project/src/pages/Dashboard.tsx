import { useMemo } from 'react';
import {
  Users, BookOpen, UserCheck, Wallet, TrendingUp,
  Award, UserPlus, Receipt, Search, Clock, Crown, Medal, Trophy,
  Lock, Sparkles, ArrowLeft, Sunrise, Moon, Sun, AlertTriangle, Download, FileSpreadsheet,
  CreditCard,
} from 'lucide-react';
import { useAuth, roleLabel, canExport } from '../context/AuthContext';
import { useDB } from '../context/DBContext';
import { useCenter } from '../context/CenterContext';
import { useToast } from '../context/ToastContext';
import { getScopedData, filterByCenter } from '../lib/scoping';
import { todayStr, currentMonthStr, formatEGP, monthName, formatDate } from '../lib/date';
import { exportDB, exportFilename } from '../lib/merge';
import { printCertificate } from '../lib/certificate';
import { exportToExcel } from '../lib/excel';
import { secretarySalaryFor, canViewFinancials } from '../lib/finance';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { WhatsAppButton } from '../components/ui/WhatsAppButton';
import type { PageKey } from '../components/Layout';
import { BackupPanel } from '../components/BackupPanel';

interface DashboardProps {
  onNavigate: (page: PageKey) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { user } = useAuth();
  const { db } = useDB();
  const { selectedCenterId } = useCenter();
  const roleScoped = getScopedData(db, user);
  const scoped = {
    students: filterByCenter(roleScoped.students, selectedCenterId),
    groups: filterByCenter(roleScoped.groups, selectedCenterId),
    attendance: selectedCenterId ? roleScoped.attendance.filter((a) => { const g = db.groups.find((gg) => gg.id === a.groupId); return g?.branchId === selectedCenterId; }) : roleScoped.attendance,
    payments: filterByCenter(roleScoped.payments, selectedCenterId),
    materials: selectedCenterId ? roleScoped.materials.filter((m) => { const g = db.groups.find((gg) => gg.id === m.groupId); return g?.branchId === selectedCenterId; }) : roleScoped.materials,
    auditLog: roleScoped.auditLog,
  };
  const today = todayStr();
  const month = currentMonthStr();

  const isAdmin = user?.role === 'admin';
  const isTeacher = user?.role === 'teacher';
  const isSecretary = user?.role === 'secretary';
  const canSeeMoney = canViewFinancials(user?.role);
  const allowExport = canExport(user?.role);

  const totalStudents = scoped.students.length;
  const totalGroups = scoped.groups.length;

  const todayAttendance = scoped.attendance.filter((a) => a.date === today && a.status === 'present');
  const attendanceRate = totalStudents > 0 ? Math.round((todayAttendance.length / totalStudents) * 100) : 0;

  const monthRevenue = scoped.payments
    .filter((p) => p.month === month)
    .reduce((sum, p) => sum + p.amount, 0);
  const totalRevenue = scoped.payments.reduce((sum, p) => sum + p.amount, 0);

  const todayCashIn = scoped.payments
    .filter((p) => p.date === today)
    .reduce((sum, p) => sum + p.amount, 0);

  // Today's active groups (groups with schedule matching today's day name)
  const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const todayName = dayNames[new Date().getDay()];
  const todayGroups = useMemo(() => {
    return scoped.groups.filter((g) => {
      if (!g.schedule) return false;
      return g.schedule.includes(todayName);
    });
  }, [scoped.groups, todayName]);

  // Current time check for "جارية الآن" badge
  const now = new Date();
  const currentHour = now.getHours();
  const isClassActive = (schedule: string): boolean => {
    const hourMatch = schedule.match(/(\d+)\s*(?:م|ص|am|pm)/i);
    if (!hourMatch) return false;
    let h = parseInt(hourMatch[1]);
    const isPM = /م|pm/i.test(schedule);
    if (isPM && h < 12) h += 12;
    return currentHour >= h && currentHour < h + 2;
  };

  // Honor roll: top students by attendance count + exam scores
  const honorRoll = useMemo(() => {
    const studentScores = scoped.students.map((s) => {
      const attCount = scoped.attendance.filter((a) => a.studentId === s.id && a.status === 'present').length;
      const scores = db.examScores.filter((e) => e.studentId === s.id);
      const avgScore = scores.length > 0
        ? scores.reduce((sum, e) => sum + (e.score / e.maxScore) * 100, 0) / scores.length
        : 0;
      return { student: s, attCount, avgScore, total: attCount + avgScore };
    });
    return studentScores
      .filter((s) => s.attCount > 0 || s.avgScore > 0)
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
  }, [scoped.students, scoped.attendance, db.examScores]);

  // Time-of-day greeting
  const greeting = currentHour < 12 ? 'صباح الخير' : currentHour < 18 ? 'مساء الخير' : 'مساء الخير';
  const GreetingIcon = currentHour < 12 ? Sunrise : currentHour < 18 ? Sun : Moon;

  const { showToast } = useToast();

  const handleExcelExport = async () => {
    if (!user) return;
    showToast('جاري إنشاء ملف Excel...');
    try {
      await exportToExcel(db, user);
      showToast('تم تصدير التقرير بنجاح');
    } catch {
      showToast('تعذّر تصدير الملف', 'error');
    }
  };

  const handleExport = () => {
    const json = exportDB(db, user?.name || user?.username || 'unknown');
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = exportFilename();
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const BackupAlertBanner = () => (
    <div className="relative rounded-3xl overflow-hidden border-2 border-amber-300 bg-gradient-to-l from-amber-50 to-orange-50 p-4 animate-fade-in">
      <div className="absolute inset-0 bg-amber-100/30 animate-pulse" />
      <div className="relative flex items-center gap-3 flex-wrap">
        <div className="grid place-items-center h-10 w-10 rounded-2xl bg-amber-400 text-white shrink-0 shadow-soft">
          <AlertTriangle size={20} />
        </div>
        <p className="flex-1 min-w-0 text-sm font-bold text-amber-800">
          تنبيه هام: يرجى تحميل ملف النسخة الاحتياطية ومشاركته مع المعلمين لتحديث بيانات الحضور والدرجات لديهم أولاً بأول.
        </p>
        <button
          onClick={handleExport}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-amber-500 text-white text-sm font-bold shadow-soft hover:bg-amber-600 active:scale-95 transition-all shrink-0"
        >
          <Download size={16} /> تصدير الآن
        </button>
      </div>
    </div>
  );

  // Non-admin dashboard (secretary/teacher)
  if (!isAdmin) {
    const stats = [
      { label: 'إجمالي الطلاب', value: totalStudents, icon: Users, tone: 'from-brand-500 to-brand-700' },
      { label: isTeacher ? 'مجموعاتي' : 'المجموعات', value: totalGroups, icon: BookOpen, tone: 'from-emerald-500 to-emerald-700' },
      { label: 'حضور اليوم', value: todayAttendance.length, icon: UserCheck, tone: 'from-amber-500 to-amber-600' },
      ...(canSeeMoney
        ? [{ label: 'إيراد الشهر', value: formatEGP(monthRevenue), icon: Wallet, tone: 'from-violet-500 to-violet-700' as const }]
        : [{ label: 'طلاب اليوم', value: todayAttendance.length, icon: UserCheck, tone: 'from-emerald-500 to-emerald-700' as const }]
      ),
    ];

    return (
      <div className="space-y-5">
        <BackupPanel />

        <div className="glass rounded-3xl shadow-glass p-5 sm:p-6 relative overflow-hidden">
          <div className="absolute -top-10 -left-10 h-40 w-40 rounded-full bg-brand-300/20 blur-2xl" />
          <div className="relative flex items-center justify-between gap-3 flex-wrap">
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <Badge tone="brand">{user ? roleLabel(user.role) : ''}</Badge>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900">أهلاً، {user?.name}</h2>
              <p className="text-sm text-brand-400 mt-1">
                {isTeacher ? 'هذه لوحة التحكم الخاصة بمجموعاتك فقط' : 'نظرة عامة على أداء السنتر'}
              </p>
            </div>
            {allowExport && (
              <button
                onClick={handleExcelExport}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-emerald-500 text-white text-sm font-bold shadow-soft hover:bg-emerald-600 active:scale-95 transition-all shrink-0"
              >
                <FileSpreadsheet size={18} /> تصدير التقرير لـ Excel
              </button>
            )}
          </div>
        </div>

        {/* Secretary fixed salary card (read-only) */}
        {isSecretary && user && (
          <Card className="p-5 relative overflow-hidden">
            <div className="absolute top-0 right-0 h-32 w-32 rounded-full bg-emerald-300/20 blur-2xl" />
            <div className="relative flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="grid place-items-center h-12 w-12 rounded-2xl bg-emerald-100 text-emerald-600">
                  <Wallet size={24} />
                </div>
                <div>
                  <p className="text-sm text-brand-400 font-semibold">الراتب المحدد من الإدارة</p>
                  <p className="text-2xl sm:text-3xl font-extrabold text-emerald-600">{formatEGP(secretarySalaryFor(db, user.id))}</p>
                </div>
              </div>
              <Badge tone="brand">شهري</Badge>
            </div>
          </Card>
        )}

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {stats.map((s, i) => (
            <Card key={i} hover className="p-4 sm:p-5">
              <div className={`grid place-items-center h-11 w-11 sm:h-12 sm:w-12 rounded-2xl bg-gradient-to-br ${s.tone} shadow-soft mb-3`}>
                <s.icon size={22} className="text-white" />
              </div>
              <p className="text-2xl sm:text-3xl font-extrabold text-brand-900">{s.value}</p>
              <p className="text-xs sm:text-sm text-brand-400 font-semibold mt-0.5">{s.label}</p>
            </Card>
          ))}
        </div>

        {/* Recent payments — only for roles allowed to see money */}
        {canSeeMoney && (
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <Award size={20} className="text-brand-500" />
              <h3 className="font-bold text-brand-900">أحدث المدفوعات</h3>
            </div>
            {scoped.payments.length === 0 ? (
              <p className="text-sm text-brand-400 py-6 text-center">لا توجد مدفوعات بعد</p>
            ) : (
              <div className="space-y-2">
                {[...scoped.payments].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5).map((p) => {
                  const student = scoped.students.find((s) => s.id === p.studentId);
                  return (
                    <div key={p.id} className="flex items-center justify-between rounded-2xl bg-brand-50/50 px-3 py-2.5">
                      <div className="min-w-0">
                        <p className="text-sm font-bold text-brand-900 truncate">{student?.name || 'طالب'}</p>
                        <p className="text-xs text-brand-400">{monthName(p.month)}</p>
                      </div>
                      <Badge tone="emerald">{formatEGP(p.amount)}</Badge>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        )}
      </div>
    );
  }

  // ===== ADMIN DASHBOARD =====
  const adminStats = [
    { label: 'إجمالي الطلاب', value: totalStudents, icon: Users, tone: 'from-brand-500 to-brand-700' },
    { label: 'مجموعات اليوم', value: todayGroups.length, icon: BookOpen, tone: 'from-emerald-500 to-emerald-700' },
    { label: 'نسبة حضور اليوم', value: `${attendanceRate}%`, icon: UserCheck, tone: 'from-amber-500 to-amber-600', isRate: true },
    { label: 'خزينة اليوم', value: formatEGP(todayCashIn), icon: Wallet, tone: 'from-violet-500 to-violet-700' },
  ];

  const quickActions = [
    { label: 'تسجيل طالب جديد', icon: UserPlus, page: 'students' as PageKey, tone: 'from-brand-500 to-brand-700' },
    { label: 'تسجيل مصروف جديد', icon: Receipt, page: 'expenses' as PageKey, tone: 'from-rose-500 to-rose-700' },
    { label: 'البحث السريع', icon: Search, page: 'scanner' as PageKey, tone: 'from-emerald-500 to-emerald-700' },
  ];

  return (
    <div className="space-y-5">
      <BackupPanel />

      {/* Greeting banner */}
      <div className="glass rounded-3xl shadow-glass p-5 sm:p-7 relative overflow-hidden">
        <div className="absolute -top-12 -left-12 h-48 w-48 rounded-full bg-brand-300/20 blur-3xl" />
        <div className="absolute -bottom-12 -right-12 h-48 w-48 rounded-full bg-emerald-300/20 blur-3xl" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-600 text-white text-xs font-bold shadow-glow">
                <Lock size={12} /> مدير النظام
              </div>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-brand-900 flex items-center gap-2">
              <GreetingIcon size={28} className="text-amber-500" />
              {greeting} يا هندسة {user?.name}
            </h2>
            <p className="text-sm text-brand-400 mt-1.5">
              {new Date().toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleExcelExport}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-emerald-500 text-white text-sm font-bold shadow-soft hover:bg-emerald-600 active:scale-95 transition-all shrink-0"
            >
              <FileSpreadsheet size={18} /> تصدير التقرير لـ Excel
            </button>
            <div className="grid place-items-center h-20 w-20 rounded-3xl gradient-brand text-white shadow-glow">
              <Sparkles size={36} />
            </div>
          </div>
        </div>
      </div>

      {/* Honor Roll Podium */}
      <HonorRoll />

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {adminStats.map((s, i) => (
          <Card key={i} hover className="p-4 sm:p-5 relative overflow-hidden">
            <div className={`absolute -top-6 -left-6 h-20 w-20 rounded-full bg-gradient-to-br ${s.tone} opacity-10 blur-2xl`} />
            <div className="relative">
              <div className={`grid place-items-center h-11 w-11 sm:h-12 sm:w-12 rounded-2xl bg-gradient-to-br ${s.tone} shadow-soft mb-3`}>
                <s.icon size={22} className="text-white" />
              </div>
              {s.isRate ? (
                <div className="flex items-center gap-3">
                  <p className="text-2xl sm:text-3xl font-extrabold text-brand-900">{s.value}</p>
                  <div className="relative h-10 w-10 shrink-0">
                    <svg className="h-full w-full -rotate-90" viewBox="0 0 36 36">
                      <circle cx="18" cy="18" r="15" fill="none" stroke="#fef3c7" strokeWidth="4" />
                      <circle
                        cx="18" cy="18" r="15" fill="none" stroke="#f59e0b" strokeWidth="4"
                        strokeLinecap="round"
                        strokeDasharray={`${(attendanceRate / 100) * 94.2} 94.2`}
                        className="transition-all duration-700"
                      />
                    </svg>
                  </div>
                </div>
              ) : (
                <p className="text-2xl sm:text-3xl font-extrabold text-brand-900">{s.value}</p>
              )}
              <p className="text-xs sm:text-sm text-brand-400 font-semibold mt-0.5">{s.label}</p>
            </div>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-sm font-bold text-brand-700 mb-3 px-1">إجراءات سريعة</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {quickActions.map((action, i) => (
            <button
              key={i}
              onClick={() => onNavigate(action.page)}
              className="group glass rounded-3xl p-5 text-right transition-all duration-300 hover:shadow-glow hover:-translate-y-1 relative overflow-hidden"
            >
              <div className={`absolute -top-8 -left-8 h-24 w-24 rounded-full bg-gradient-to-br ${action.tone} opacity-10 blur-2xl group-hover:opacity-20 transition-opacity`} />
              <div className="relative flex items-center gap-3">
                <div className={`grid place-items-center h-12 w-12 rounded-2xl bg-gradient-to-br ${action.tone} text-white shadow-soft group-hover:scale-110 transition-transform`}>
                  <action.icon size={24} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-brand-900">{action.label}</p>
                </div>
                <ArrowLeft size={18} className="text-brand-300 group-hover:text-brand-600 group-hover:-translate-x-1 transition-all" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Today's classes timeline + Honor roll */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Today's classes */}
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <Clock size={20} className="text-brand-500" />
            <h3 className="font-bold text-brand-900">حصص اليوم</h3>
            <Badge tone="brand" className="mr-auto">{todayName}</Badge>
          </div>
          {todayGroups.length === 0 ? (
            <p className="text-sm text-brand-400 py-6 text-center">لا توجد حصص مجدولة اليوم</p>
          ) : (
            <div className="space-y-2.5">
              {todayGroups.map((g) => {
                const teacher = db.teachers.find((t) => t.id === g.teacherId);
                const active = isClassActive(g.schedule);
                const studentCount = scoped.students.filter((s) => s.groupId === g.id).length;
                return (
                  <div key={g.id} className="flex items-center gap-3 rounded-2xl bg-brand-50/50 px-4 py-3">
                    <div className={`grid place-items-center h-10 w-10 rounded-2xl ${active ? 'bg-emerald-500 text-white' : 'bg-brand-100 text-brand-600'}`}>
                      <BookOpen size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-brand-900 truncate">{g.name}</p>
                      <p className="text-xs text-brand-400">{teacher?.name || 'بدون معلم'} • {g.schedule}</p>
                    </div>
                    <div className="text-left">
                      {active ? (
                        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" /> جارية الآن
                        </span>
                      ) : (
                        <span className="text-xs text-brand-400 font-semibold">{studentCount} طالب</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* Honor roll */}
        <Card className="p-5 relative overflow-hidden">
          <div className="absolute -top-8 -left-8 h-32 w-32 rounded-full bg-amber-300/20 blur-2xl" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-4">
              <Trophy size={20} className="text-amber-500" />
              <h3 className="font-bold text-brand-900">لوحة شرف الأفضل</h3>
            </div>
            {honorRoll.length === 0 ? (
              <p className="text-sm text-brand-400 py-6 text-center">لا توجد بيانات كافية</p>
            ) : (
              <div className="space-y-2.5">
                {honorRoll.map((item, idx) => {
                  const rankIcon = idx === 0 ? Crown : idx === 1 ? Medal : idx === 2 ? Award : Trophy;
                  const RankIcon = rankIcon;
                  const tone = idx === 0 ? 'text-amber-500' : idx === 1 ? 'text-slate-400' : idx === 2 ? 'text-orange-400' : 'text-brand-400';
                  return (
                    <div key={item.student.id} className="flex items-center gap-3 rounded-2xl bg-brand-50/50 px-4 py-3">
                      <div className={`grid place-items-center h-10 w-10 rounded-2xl bg-white ${tone}`}>
                        <RankIcon size={18} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-brand-900 truncate">{item.student.name}</p>
                        <p className="text-xs text-brand-400">{item.student.grade}</p>
                      </div>
                      <div className="text-left">
                        <p className="text-xs font-bold text-brand-600">{item.attCount} حضور</p>
                        {item.avgScore > 0 && <p className="text-[10px] text-brand-400">{Math.round(item.avgScore)}% اختبارات</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Overdue Installments Widget */}
      <OverdueInstallmentsWidget onNavigate={onNavigate} />

      {/* Revenue overview */}
      <Card className="p-5 relative overflow-hidden">
        <div className="absolute top-0 right-0 h-32 w-32 rounded-full bg-emerald-300/20 blur-2xl" />
        <div className="relative">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="grid place-items-center h-10 w-10 rounded-2xl bg-emerald-100 text-emerald-600">
                <Wallet size={20} />
              </div>
              <div>
                <h3 className="font-bold text-brand-900">إيرادات {monthName(month)}</h3>
                <p className="text-xs text-brand-400">إجمالي المحصل هذا الشهر</p>
              </div>
            </div>
            <TrendingUp size={20} className="text-emerald-500" />
          </div>
          <p className="text-3xl sm:text-4xl font-extrabold text-emerald-600">{formatEGP(monthRevenue)}</p>
          <div className="mt-4 pt-4 border-t border-slate-100">
            <span className="text-xs text-brand-400 font-semibold">الإيراد الكلي</span>
            <span className="text-sm font-bold text-brand-700 block mt-0.5">{formatEGP(totalRevenue)}</span>
          </div>
        </div>
      </Card>
    </div>
  );
}

function HonorRoll() {
  const { db } = useDB();
  const { selectedCenterId } = useCenter();
  const roleScoped = getScopedData(db, { role: 'admin', id: '', username: '', name: '' } as any);
  const scoped = {
    students: filterByCenter(roleScoped.students, selectedCenterId),
    attendance: selectedCenterId ? roleScoped.attendance.filter((a) => { const g = db.groups.find((gg) => gg.id === a.groupId); return g?.branchId === selectedCenterId; }) : roleScoped.attendance,
  };

  const topStudents = useMemo(() => {
    const students = scoped.students;
    const attendance = scoped.attendance;
    const scores = db.examScores || [];

    return students
      .map((s) => {
        const studentAttendance = attendance.filter((a) => a.studentId === s.id);
        const presentCount = studentAttendance.filter((a) => a.status === 'present').length;
        const attendanceRate = studentAttendance.length > 0 ? presentCount / studentAttendance.length : 0;
        const studentScores = scores.filter((sc) => sc.studentId === s.id);
        const avgScore = studentScores.length > 0 ? studentScores.reduce((sum, sc) => sum + sc.score, 0) / studentScores.length : 0;
        return { student: s, attendanceRate, avgScore, score: attendanceRate * 100 + avgScore };
      })
      .filter((s) => s.attendanceRate >= 0.8)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);
  }, [db.students, db.attendance, db.examScores]);

  if (topStudents.length === 0) return null;

  const podiumColors = ['from-amber-400 to-yellow-500', 'from-slate-300 to-slate-400', 'from-orange-300 to-orange-500'];
  const podiumHeights = ['h-28', 'h-20', 'h-16'];
  const medals = [Crown, Medal, Trophy];

  return (
    <Card className="p-5 sm:p-6 relative overflow-hidden">
      <div className="absolute -top-10 -left-10 h-40 w-40 rounded-full bg-amber-200/20 blur-2xl" />
      <div className="relative">
        <div className="flex items-center gap-2 mb-4">
          <Trophy size={22} className="text-amber-500" />
          <h3 className="font-extrabold text-brand-900">لوحة الشرف وتكريم المتفوقين</h3>
        </div>
        <div className="flex items-end justify-center gap-3 sm:gap-6">
          {topStudents.map((item, idx) => {
            const Icon = medals[idx] || Medal;
            const student = item.student;
            return (
              <div key={student.id} className="flex flex-col items-center" style={{ order: idx === 0 ? 2 : idx === 1 ? 1 : 3 }}>
                <div className={`grid place-items-center h-12 w-12 rounded-2xl bg-gradient-to-br ${podiumColors[idx]} text-white shadow-soft mb-2`}>
                  <Icon size={24} />
                </div>
                <p className="font-bold text-brand-900 text-sm text-center truncate max-w-[100px]">{student.name}</p>
                <p className="text-xs text-brand-400 mb-2">{Math.round(item.attendanceRate * 100)}% حضور</p>
                <div className={`rounded-t-2xl bg-gradient-to-br ${podiumColors[idx]} ${podiumHeights[idx]} w-20 sm:w-24 flex items-center justify-center text-white font-extrabold text-2xl shadow-soft`}>
                  {idx + 1}
                </div>
                <button
                  onClick={() => printCertificate(student, `لحصوله على نسبة حضور ${Math.round(item.attendanceRate * 100)}% ومتوسط درجات ${item.avgScore.toFixed(1)} في امتحانات السنتر`)}
                  className="mt-2 text-xs font-bold text-brand-600 hover:text-brand-800 flex items-center gap-1 transition-colors"
                >
                  <Award size={12} /> شهادة تقدير
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </Card>
  );
}

function OverdueInstallmentsWidget({ onNavigate }: { onNavigate: (page: PageKey) => void }) {
  const { db } = useDB();
  const { selectedCenterId } = useCenter();

  const overdueInstallments = useMemo(() => {
    const students = filterByCenter(db.students, selectedCenterId);
    const today = todayStr();
    const result: { installment: typeof db.installmentPlans[0]['installments'][0]; student: typeof students[0]; group: typeof db.groups[0] | undefined }[] = [];
    for (const plan of db.installmentPlans) {
      const student = students.find((s) => s.id === plan.studentId);
      if (!student) continue;
      const group = db.groups.find((g) => g.id === plan.groupId);
      for (const inst of plan.installments) {
        if (inst.status !== 'paid' && inst.dueDate < today) {
          result.push({ installment: inst, student, group });
        }
      }
    }
    return result.sort((a, b) => a.installment.dueDate.localeCompare(b.installment.dueDate));
  }, [db.installmentPlans, db.students, db.groups, selectedCenterId]);

  if (overdueInstallments.length === 0) return null;

  return (
    <Card className="p-5" glass={false}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-brand-900 flex items-center gap-2">
          <AlertTriangle size={20} className="text-rose-500" />
          الأقساط المتأخرة
        </h3>
        <Badge tone="rose">{overdueInstallments.length} قسط متأخر</Badge>
      </div>
      <div className="space-y-2 max-h-64 overflow-y-auto no-scrollbar">
        {overdueInstallments.slice(0, 5).map(({ installment, student, group }) => (
          <div key={installment.id} className="flex items-center gap-3 rounded-2xl bg-rose-50/50 border border-rose-100 px-3 py-2.5">
            <div className="grid place-items-center h-9 w-9 rounded-xl bg-rose-100 text-rose-600 shrink-0">
              <CreditCard size={16} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-brand-900 truncate">{student.name}</p>
              <p className="text-xs text-brand-400">{group?.name || '—'} • {formatDate(installment.dueDate)}</p>
            </div>
            <Badge tone="rose" className="text-[10px]">{formatEGP(installment.amount)}</Badge>
            <WhatsAppButton
              student={student}
              template="installment"
              centerName={db.centerName}
              groupName={group?.name}
              amountDue={installment.amount}
              dueDate={formatDate(installment.dueDate)}
              size="sm"
              label="تذكير"
            />
          </div>
        ))}
      </div>
      {overdueInstallments.length > 5 && (
        <button
          onClick={() => onNavigate('installments')}
          className="mt-3 text-xs font-bold text-brand-500 hover:text-brand-700 flex items-center gap-1 transition-colors"
        >
          عرض الكل ({overdueInstallments.length}) <ArrowLeft size={12} />
        </button>
      )}
    </Card>
  );
}
