import { useState, useMemo } from 'react';
import { ArrowRight, Search, Users, UserCheck, Wallet, Calendar, BookOpen, Trophy, Star, Printer, DollarSign, TrendingUp, Building2 } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { getScopedData, studentGroupIds } from '../lib/scoping';
import { todayStr, daysAgoStr, dateInRange, formatEGP, formatDate } from '../lib/date';
import { printIDCards } from '../lib/idcard';
import { BILLING_MODEL_LABELS, PAYOUT_TYPE_LABELS, computeTeacherPayout, groupBillingPrice, studentFinalPrice, effectiveStudentDiscount } from '../lib/finance';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import type { Group } from '../lib/types';

type Timeframe = 'today' | 'week' | 'month' | 'custom';

interface GroupDashboardProps {
  group: Group;
  onBack: () => void;
}

export function GroupDashboard({ group, onBack }: GroupDashboardProps) {
  const { db } = useDB();
  const { user } = useAuth();
  const scoped = getScopedData(db, user);

  const [timeframe, setTimeframe] = useState<Timeframe>('today');
  const [customStart, setCustomStart] = useState(daysAgoStr(7));
  const [customEnd, setCustomEnd] = useState(todayStr());
  const [search, setSearch] = useState('');

  const { startDate, endDate } = useMemo(() => {
    const today = todayStr();
    switch (timeframe) {
      case 'today':
        return { startDate: today, endDate: today };
      case 'week':
        return { startDate: daysAgoStr(7), endDate: today };
      case 'month':
        return { startDate: daysAgoStr(30), endDate: today };
      case 'custom':
        return { startDate: customStart, endDate: customEnd };
    }
  }, [timeframe, customStart, customEnd]);

  // Students in this group
  const groupStudents = useMemo(
    () => scoped.students.filter((s) => s.groupId === group.id),
    [scoped.students, group.id]
  );

  const filteredStudents = useMemo(
    () => groupStudents.filter((s) => !search || s.name.includes(search) || String(s.id).includes(search)),
    [groupStudents, search]
  );

  // All attendance records for this group within the date range
  const groupAttendanceInRange = useMemo(
    () => scoped.attendance.filter((a) => a.groupId === group.id && dateInRange(a.date, startDate, endDate)),
    [scoped.attendance, group.id, startDate, endDate]
  );

  // All payments for this group within the date range
  const groupPaymentsInRange = useMemo(
    () => scoped.payments.filter((p) => p.groupId === group.id && dateInRange(p.date, startDate, endDate)),
    [scoped.payments, group.id, startDate, endDate]
  );

  // Total distinct session dates in range (for attendance rate calc)
  const sessionDates = useMemo(
    () => new Set(groupAttendanceInRange.map((a) => a.date)),
    [groupAttendanceInRange]
  );
  const totalSessions = sessionDates.size;

  // Overall stats
  const totalStudents = groupStudents.length;
  const totalPresent = groupAttendanceInRange.filter((a) => a.status === 'present').length;
  const overallAttRate = groupAttendanceInRange.length > 0
    ? Math.round((totalPresent / groupAttendanceInRange.length) * 100)
    : 0;
  const totalRevenue = groupPaymentsInRange.reduce((sum, p) => sum + p.amount, 0);

  // Billing & payout breakdown
  const payout = useMemo(
    () => computeTeacherPayout(db, group, totalStudents, totalRevenue),
    [db, group, totalStudents, totalRevenue]
  );
  const billingPrice = groupBillingPrice(db, group);

  // Expected revenue (if all students paid full price)
  const expectedRevenue = useMemo(
    () => groupStudents.reduce((sum, s) => sum + studentFinalPrice(db, group, s), 0),
    [db, group, groupStudents]
  );

  // Students with discounts
  const discountedStudents = useMemo(
    () => groupStudents.filter((s) => effectiveStudentDiscount(s).type !== 'none'),
    [groupStudents]
  );

  // Per-student stats
  const studentStats = useMemo(() => {
    return filteredStudents.map((s) => {
      const studentRecords = groupAttendanceInRange.filter((a) => a.studentId === s.id);
      const presentCount = studentRecords.filter((a) => a.status === 'present').length;
      const attRate = studentRecords.length > 0
        ? Math.round((presentCount / studentRecords.length) * 100)
        : 0;

      // Payment status: check if student has any payment in range
      const studentPayments = groupPaymentsInRange.filter((p) => p.studentId === s.id);
      const hasPaid = studentPayments.length > 0;
      const paidAmount = studentPayments.reduce((sum, p) => sum + p.amount, 0);

      return {
        student: s,
        attRate,
        presentCount,
        totalRecords: studentRecords.length,
        hasPaid,
        paidAmount,
      };
    });
  }, [filteredStudents, groupAttendanceInRange, groupPaymentsInRange]);

  // Honor Roll: top 5 students by attendance rate + exam scores
  const honorRoll = useMemo(() => {
    return groupStudents
      .map((s) => {
        const records = groupAttendanceInRange.filter((a) => a.studentId === s.id);
        const present = records.filter((a) => a.status === 'present').length;
        const attRate = records.length > 0 ? present / records.length : 0;
        const exams = db.examScores.filter((e) => e.studentId === s.id && e.groupId === group.id && dateInRange(e.date, startDate, endDate));
        const avgExam = exams.length > 0
          ? exams.reduce((sum, e) => sum + (e.score / e.maxScore), 0) / exams.length
          : 0;
        // Combined score: 60% attendance + 40% exam
        const combined = attRate * 0.6 + avgExam * 0.4;
        return { student: s, attRate: Math.round(attRate * 100), avgExam: Math.round(avgExam * 100), combined, examCount: exams.length };
      })
      .sort((a, b) => b.combined - a.combined)
      .slice(0, 5);
  }, [groupStudents, groupAttendanceInRange, db.examScores, group.id, startDate, endDate]);

  const timeframeOptions: { key: Timeframe; label: string }[] = [
    { key: 'today', label: 'اليوم' },
    { key: 'week', label: 'آخر أسبوع' },
    { key: 'month', label: 'آخر شهر' },
    { key: 'custom', label: 'فترة مخصصة' },
  ];

  return (
    <div className="space-y-5">
      {/* Back button + group header */}
      <div className="flex items-center gap-3">
        <button
          onClick={onBack}
          className="grid place-items-center h-11 w-11 rounded-2xl glass text-brand-700 hover:bg-brand-50 transition-all shrink-0"
        >
          <ArrowRight size={20} />
        </button>
        <div className="min-w-0">
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 truncate">{group.name}</h2>
          <p className="text-sm text-brand-400">{group.subject} — {group.grade}</p>
        </div>
        <Button variant="secondary" size="sm" className="shrink-0" onClick={() => printIDCards(scoped.students.filter((s) => studentGroupIds(s).includes(group.id)), scoped.groups)}>
          <Printer size={16} /> طباعة كروت المجموعة
        </Button>
      </div>

      {/* Timeframe filter */}
      <Card className="p-4" glass={false}>
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <Calendar size={18} className="text-brand-400" />
          <span className="text-sm font-semibold text-brand-700">الفترة الزمنية</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {timeframeOptions.map((opt) => (
            <button
              key={opt.key}
              onClick={() => setTimeframe(opt.key)}
              className={`rounded-2xl px-3 py-2.5 text-sm font-bold transition-all ${
                timeframe === opt.key
                  ? 'gradient-brand text-white shadow-soft'
                  : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
        {timeframe === 'custom' && (
          <div className="grid grid-cols-2 gap-3 mt-3 animate-fade-in">
            <Input label="من تاريخ" type="date" value={customStart} onChange={(e) => setCustomStart(e.target.value)} />
            <Input label="إلى تاريخ" type="date" value={customEnd} onChange={(e) => setCustomEnd(e.target.value)} />
          </div>
        )}
        <p className="text-xs text-brand-400 mt-3 font-semibold">
          الفترة: {formatDate(startDate)} — {formatDate(endDate)} ({totalSessions} جلسة مسجلة)
        </p>
      </Card>

      {/* Stats cards */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <Card className="p-4 sm:p-5" hover>
          <div className="grid place-items-center h-11 w-11 sm:h-12 sm:w-12 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 shadow-soft mb-3">
            <Users size={22} className="text-white" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-brand-900">{totalStudents}</p>
          <p className="text-xs sm:text-sm text-brand-400 font-semibold mt-0.5">إجمالي الطلاب</p>
        </Card>

        <Card className="p-4 sm:p-5" hover>
          <div className="grid place-items-center h-11 w-11 sm:h-12 sm:w-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-700 shadow-soft mb-3">
            <UserCheck size={22} className="text-white" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-emerald-600">{overallAttRate}%</p>
          <p className="text-xs sm:text-sm text-brand-400 font-semibold mt-0.5">نسبة الحضور</p>
        </Card>

        <Card className="p-4 sm:p-5" hover>
          <div className="grid place-items-center h-11 w-11 sm:h-12 sm:w-12 rounded-2xl bg-gradient-to-br from-violet-500 to-violet-700 shadow-soft mb-3">
            <Wallet size={22} className="text-white" />
          </div>
          <p className="text-lg sm:text-2xl font-extrabold text-violet-600">{formatEGP(totalRevenue)}</p>
          <p className="text-xs sm:text-sm text-brand-400 font-semibold mt-0.5">إيراد الفترة</p>
        </Card>
      </div>

      {/* Billing & Payout Breakdown */}
      <Card className="p-5" glass={false}>
        <div className="flex items-center gap-2 mb-4">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-600">
            <DollarSign size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">نظام الفوترة وتوزيع الإيراد</h3>
            <p className="text-xs text-brand-400">نوع الفوترة: {BILLING_MODEL_LABELS[group.billingModel]} — نوع دفع المعلم: {PAYOUT_TYPE_LABELS[group.payoutType]}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Billing price */}
          <div className="rounded-2xl bg-brand-50/50 px-4 py-3">
            <div className="flex items-center gap-1.5 mb-1">
              <DollarSign size={14} className="text-brand-400" />
              <span className="text-xs font-semibold text-brand-500">سعر الفوترة</span>
            </div>
            <p className="text-lg font-extrabold text-brand-900">{formatEGP(billingPrice)}</p>
            <p className="text-[10px] text-brand-400">
              {group.billingModel === 'per_session' ? 'للحصة' : group.billingModel === 'monthly' ? 'شهرياً' : 'للباقة'}
            </p>
          </div>

          {/* Expected revenue */}
          <div className="rounded-2xl bg-violet-50 px-4 py-3">
            <div className="flex items-center gap-1.5 mb-1">
              <TrendingUp size={14} className="text-violet-400" />
              <span className="text-xs font-semibold text-violet-500">الإيراد المتوقع</span>
            </div>
            <p className="text-lg font-extrabold text-violet-700">{formatEGP(expectedRevenue)}</p>
            <p className="text-[10px] text-violet-400">{totalStudents} طالب × السعر</p>
          </div>

          {/* Teacher share */}
          <div className="rounded-2xl bg-emerald-50 px-4 py-3">
            <div className="flex items-center gap-1.5 mb-1">
              <Wallet size={14} className="text-emerald-400" />
              <span className="text-xs font-semibold text-emerald-500">حصة المعلم</span>
            </div>
            <p className="text-lg font-extrabold text-emerald-700">{formatEGP(payout.teacherShare)}</p>
            <p className="text-[10px] text-emerald-400">
              {group.payoutType === 'fixed_seat' ? `${group.payoutValue} ج.م × ${totalStudents}` :
               group.payoutType === 'percentage' ? `${group.payoutValue}% من الإيراد` :
               `${group.payoutValue} ج.م/حصة`}
            </p>
          </div>

          {/* Center share */}
          <div className="rounded-2xl bg-amber-50 px-4 py-3">
            <div className="flex items-center gap-1.5 mb-1">
              <Building2 size={14} className="text-amber-400" />
              <span className="text-xs font-semibold text-amber-500">حصة السنتر</span>
            </div>
            <p className="text-lg font-extrabold text-amber-700">{formatEGP(payout.centerShare)}</p>
            <p className="text-[10px] text-amber-400">من إيراد {formatEGP(totalRevenue)}</p>
          </div>
        </div>

        {/* Discount info */}
        {discountedStudents.length > 0 && (
          <div className="mt-4 rounded-2xl bg-rose-50/50 border border-rose-100 px-4 py-3">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold text-rose-600">طلاب بخصومات ({discountedStudents.length})</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {discountedStudents.map((s) => {
                const d = effectiveStudentDiscount(s);
                return (
                  <span key={s.id} className="inline-flex items-center gap-1 rounded-lg bg-white px-2 py-1 text-[10px] font-semibold text-brand-600 border border-slate-100">
                    {s.name}
                    <Badge tone={d.type === 'special' ? 'rose' : 'brand'} className="text-[9px] px-1.5 py-0">
                      -{d.percent}%
                    </Badge>
                  </span>
                );
              })}
            </div>
          </div>
        )}
      </Card>

      {/* Honor Roll */}
      {honorRoll.length > 0 && (
        <Card className="p-5 relative overflow-hidden">
          <div className="absolute -top-8 -left-8 h-32 w-32 rounded-full bg-amber-300/20 blur-2xl pointer-events-none" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-4">
              <div className="grid place-items-center h-10 w-10 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-white shadow-soft">
                <Trophy size={20} />
              </div>
              <div>
                <h3 className="font-bold text-brand-900">لوحة الشرف</h3>
                <p className="text-xs text-brand-400">أفضل 5 طلاب بناءً على الحضور والامتحانات</p>
              </div>
            </div>
            <div className="space-y-2">
              {honorRoll.map((item, idx) => (
                <div key={item.student.id} className="flex items-center gap-3 rounded-2xl bg-brand-50/50 px-3 py-2.5">
                  <div className={`grid place-items-center h-9 w-9 rounded-xl font-extrabold text-sm shrink-0 ${
                    idx === 0 ? 'bg-amber-400 text-white' : idx === 1 ? 'bg-slate-300 text-slate-700' : idx === 2 ? 'bg-amber-700 text-white' : 'bg-brand-100 text-brand-600'
                  }`}>
                    {idx === 0 ? <Star size={16} /> : idx + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-brand-900 text-sm truncate">{item.student.name}</p>
                    <p className="text-[10px] text-brand-400">حضور {item.attRate}% {item.examCount > 0 && `• امتحان ${item.avgExam}%`}</p>
                  </div>
                  <Badge tone={idx === 0 ? 'amber' : 'brand'} className="text-xs">{Math.round(item.combined * 100)}%</Badge>
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}

      {/* Search */}
      <Card className="p-4" glass={false}>
        <Input icon={<Search size={18} />} placeholder="بحث عن طالب بالاسم أو الكود..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </Card>

      {/* Student table / cards */}
      {studentStats.length === 0 ? (
        <EmptyState icon={<BookOpen size={36} />} title="لا يوجد طلاب" description="لا توجد طلاب مسجلون في هذه المجموعة" />
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden lg:block overflow-hidden" glass={false}>
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-brand-50 text-brand-700 text-right">
                  <th className="px-4 py-3 font-bold">الكود</th>
                  <th className="px-4 py-3 font-bold">الاسم</th>
                  <th className="px-4 py-3 font-bold">نسبة الحضور</th>
                  <th className="px-4 py-3 font-bold">الحضور/الإجمالي</th>
                  <th className="px-4 py-3 font-bold">حالة الدفع</th>
                  <th className="px-4 py-3 font-bold">المبلغ المدفوع</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {studentStats.map(({ student, attRate, presentCount, totalRecords, hasPaid, paidAmount }) => (
                  <tr key={student.id} className="hover:bg-brand-50/40 transition-colors">
                    <td className="px-4 py-3"><Badge tone="brand">{student.id}</Badge></td>
                    <td className="px-4 py-3 font-bold text-brand-900">{student.name}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-2 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${attRate >= 75 ? 'bg-emerald-500' : attRate >= 50 ? 'bg-amber-500' : 'bg-rose-500'}`}
                            style={{ width: `${attRate}%` }}
                          />
                        </div>
                        <span className={`text-xs font-bold ${attRate >= 75 ? 'text-emerald-600' : attRate >= 50 ? 'text-amber-600' : 'text-rose-500'}`}>
                          {attRate}%
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-brand-600 text-xs font-semibold">
                      {presentCount} / {totalRecords || 0}
                    </td>
                    <td className="px-4 py-3">
                      <Badge tone={hasPaid ? 'emerald' : 'rose'} className="px-3 py-1">
                        {hasPaid ? 'تم الدفع' : 'لم يدفع'}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-brand-700 font-bold text-xs">
                      {hasPaid ? formatEGP(paidAmount) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards */}
          <div className="lg:hidden space-y-3">
            {studentStats.map(({ student, attRate, presentCount, totalRecords, hasPaid, paidAmount }) => (
              <Card key={student.id} className="p-4" hover>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="grid place-items-center h-12 w-12 rounded-2xl gradient-brand text-white font-extrabold text-lg shrink-0">
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-brand-900">{student.name}</h3>
                      <Badge tone="brand" className="text-[10px] mt-0.5">#{student.id}</Badge>
                    </div>
                  </div>
                  <Badge tone={hasPaid ? 'emerald' : 'rose'} className="px-3 py-1.5">
                    {hasPaid ? 'تم الدفع' : 'لم يدفع'}
                  </Badge>
                </div>

                {/* Attendance rate bar */}
                <div className="mb-2">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-brand-400">نسبة الحضور</span>
                    <span className={`text-xs font-bold ${attRate >= 75 ? 'text-emerald-600' : attRate >= 50 ? 'text-amber-600' : 'text-rose-500'}`}>
                      {attRate}% ({presentCount}/{totalRecords || 0})
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${attRate >= 75 ? 'bg-emerald-500' : attRate >= 50 ? 'bg-amber-500' : 'bg-rose-500'}`}
                      style={{ width: `${attRate}%` }}
                    />
                  </div>
                </div>

                {hasPaid && (
                  <div className="flex items-center justify-between rounded-xl bg-emerald-50 px-3 py-2 mt-2">
                    <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                      <Wallet size={12} /> المبلغ المدفوع
                    </span>
                    <span className="text-sm font-bold text-emerald-700">{formatEGP(paidAmount)}</span>
                  </div>
                )}
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
