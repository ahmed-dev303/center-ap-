import { useState } from 'react';
import { BookOpen, Plus, GraduationCap, Calendar, Trash2, Edit3, X, ChevronLeft, Lock, DollarSign, Users2, Clock } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { useCenter } from '../context/CenterContext';
import { useToast } from '../context/ToastContext';
import { getScopedData, filterByCenter } from '../lib/scoping';
import { getAcademicGrades } from '../lib/db';
import { uid, formatEGP } from '../lib/date';
import { logAction } from '../lib/finance';
import { DAYS_OF_WEEK, generateTimeSlots, formatTimeArabic, calculateHalfwayTime } from '../lib/schedule';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { GroupDashboard } from './GroupDashboard';
import type { Group, BillingModel, PayoutType } from '../lib/types';
import { BILLING_MODEL_LABELS, PAYOUT_TYPE_LABELS, groupBillingPrice } from '../lib/finance';

export function Groups() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { selectedCenterId } = useCenter();
  const { showToast } = useToast();
  const roleScoped = getScopedData(db, user);
  const isTeacher = user?.role === 'teacher';

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Group | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);

  const groups = filterByCenter(roleScoped.groups, selectedCenterId);
  const scoped = {
    ...roleScoped,
    students: filterByCenter(roleScoped.students, selectedCenterId),
    groups,
  };
  const grades = getAcademicGrades();

  if (selectedGroup) {
    return <GroupDashboard group={selectedGroup} onBack={() => setSelectedGroup(null)} />;
  }

  const handleSave = (data: Omit<Group, 'id' | 'createdAt'> & { id?: string }) => {
    update((d) => {
      if (editing) {
        const idx = d.groups.findIndex((g) => g.id === editing.id);
        if (idx >= 0) d.groups[idx] = { ...d.groups[idx], ...data };
        logAction(d, 'تعديل مجموعة', `قام ${user?.name || ''} بتعديل المجموعة: ${data.name}.`, user?.name || '', user?.role || 'admin');
      } else {
        d.groups.push({ ...data, id: uid('g'), createdAt: new Date().toISOString() } as Group);
        logAction(d, 'إنشاء مجموعة', `قام ${user?.name || ''} بإنشاء مجموعة جديدة باسم ${data.name}.`, user?.name || '', user?.role || 'admin');
      }
    });
    showToast(editing ? 'تم تحديث المجموعة' : 'تم إنشاء المجموعة بنجاح');
    setShowForm(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const gname = db.groups.find((g) => g.id === deleteId)?.name || '';
    update((d) => {
      d.groups = d.groups.filter((g) => g.id !== deleteId);
      d.students = d.students.map((s) => (s.groupId === deleteId ? { ...s, groupId: null } : s));
      d.attendance = d.attendance.filter((a) => a.groupId !== deleteId);
      logAction(d, 'حذف مجموعة', `قام ${user?.name || ''} بحذف المجموعة: ${gname}.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف المجموعة', 'info');
    setDeleteId(null);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900">المجموعات</h2>
          <p className="text-sm text-brand-400 mt-0.5">{groups.length} مجموعة</p>
        </div>
        {!isTeacher && (
          <Button onClick={() => { setEditing(null); setShowForm(true); }}>
            <Plus size={18} /> مجموعة جديدة
          </Button>
        )}
      </div>

      {isTeacher && (
        <p className="text-sm text-brand-400 font-semibold">اضغط على أي مجموعة لعرض تفاصيلها وإحصائياتها</p>
      )}

      {groups.length === 0 ? (
        <EmptyState icon={<BookOpen size={36} />} title="لا توجد مجموعات" description="أنشئ مجموعات لتنظيم الطلاب" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {groups.map((g) => {
            const teacher = db.teachers.find((t) => t.id === g.teacherId);
            const studentCount = scoped.students.filter((s) => s.groupId === g.id).length;
            return (
              <Card key={g.id} className="p-5" hover>
                <div className="flex items-start justify-between mb-3">
                  <div className="grid place-items-center h-14 w-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-brand-700 text-white shadow-soft">
                    <BookOpen size={26} />
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <Badge tone="emerald">{studentCount} طالب</Badge>
                    <Badge tone="brand">{BILLING_MODEL_LABELS[g.billingModel]}</Badge>
                  </div>
                </div>
                <h3 className="font-bold text-brand-900 mb-1">{g.name}</h3>
                <div className="space-y-1.5 text-sm">
                  <div className="flex items-center gap-2 text-brand-600">
                    <GraduationCap size={14} className="text-brand-400" /> {teacher?.name || 'بدون معلم'}
                  </div>
                  <div className="flex items-center gap-2 text-brand-600">
                    <BookOpen size={14} className="text-brand-400" /> {g.subject} - {g.grade}
                  </div>
                  <div className="flex items-center gap-2 text-brand-600">
                    <Calendar size={14} className="text-brand-400" /> {g.schedule}
                  </div>
                  {g.startTime && g.endTime && (
                    <div className="flex items-center gap-2 text-brand-600">
                      <Clock size={14} className="text-brand-400" /> {formatTimeArabic(g.startTime)} - {formatTimeArabic(g.endTime)}
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-brand-600">
                    <DollarSign size={14} className="text-brand-400" />
                    {g.billingModel === 'monthly' && g.monthlyFee ? formatEGP(g.monthlyFee) + '/شهر' :
                     g.billingModel === 'full_package' && g.packageFee ? formatEGP(g.packageFee) + ' باقة' :
                     formatEGP(groupBillingPrice(db, g)) + '/حصة'}
                    <span className="text-brand-300 text-xs">· {PAYOUT_TYPE_LABELS[db.allowProfitOverride ? g.payoutType : db.globalProfitModel]}</span>
                  </div>
                </div>
                <div className="flex gap-2 mt-3 pt-3 border-t border-slate-100">
                  <Button size="sm" variant="secondary" className="flex-1" onClick={() => setSelectedGroup(g)}>
                    <ChevronLeft size={15} /> التفاصيل
                  </Button>
                  {!isTeacher && (
                    <>
                      <Button size="sm" variant="ghost" onClick={() => { setEditing(g); setShowForm(true); }}>
                        <Edit3 size={15} />
                      </Button>
                      <Button size="sm" variant="ghost" className="text-rose-500" onClick={() => setDeleteId(g.id)}>
                        <Trash2 size={15} />
                      </Button>
                    </>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {showForm && (
        <GroupForm group={editing} teachers={db.teachers} grades={grades} gradePrices={db.gradePrices} branches={db.branches} allowProfitOverride={db.allowProfitOverride} globalProfitModel={db.globalProfitModel} globalProfitValue={db.globalProfitValue} onClose={() => { setShowForm(false); setEditing(null); }} onSave={handleSave} />
      )}
      <ConfirmDialog
        open={deleteId !== null}
        title="حذف المجموعة"
        message="سيتم حذف المجموعة وفصل طلابها. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function GroupForm({ group, teachers, grades, gradePrices, branches, allowProfitOverride, globalProfitModel, globalProfitValue, onClose, onSave }: {
  group: Group | null;
  teachers: { id: string; name: string }[];
  grades: string[];
  gradePrices: { grade: string; price: number }[];
  branches: { id: string; name: string }[];
  allowProfitOverride: boolean;
  globalProfitModel: PayoutType;
  globalProfitValue: number;
  onClose: () => void;
  onSave: (data: Omit<Group, 'id' | 'createdAt'> & { id?: string }) => void;
}) {
  const [name, setName] = useState(group?.name || '');
  const [teacherId, setTeacherId] = useState(group?.teacherId || '');
  const [subject, setSubject] = useState(group?.subject || '');
  const [grade, setGrade] = useState(group?.grade || '');
  const [schedule, setSchedule] = useState(group?.schedule || '');
  const [scheduleDays, setScheduleDays] = useState<string[]>(group?.scheduleDays ?? []);
  const [startTime, setStartTime] = useState(group?.startTime || '');
  const [endTime, setEndTime] = useState(group?.endTime || '');
  const [branchId, setBranchId] = useState(group?.branchId || '');
  const [billingModel, setBillingModel] = useState<BillingModel>(group?.billingModel || 'per_session');
  const [customPrice, setCustomPrice] = useState(group?.customPrice ? String(group.customPrice) : '');
  const [payoutType, setPayoutType] = useState<PayoutType>(group?.payoutType || globalProfitModel || 'fixed_seat');
  const [payoutValue, setPayoutValue] = useState(String(group?.payoutValue ?? globalProfitValue ?? 20));
  const [monthlyFee, setMonthlyFee] = useState(group?.monthlyFee ? String(group.monthlyFee) : '');
  const [packageFee, setPackageFee] = useState(group?.packageFee ? String(group.packageFee) : '');

  const timeSlots = generateTimeSlots();
  const halfwayTime = startTime && endTime ? calculateHalfwayTime(startTime, endTime) : null;

  const toggleDay = (day: string) => {
    setScheduleDays((prev) => prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]);
  };

  const lockedPrice = gradePrices.find((gp) => gp.grade === grade);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!grade) return;
    const scheduleLabel = scheduleDays.length > 0 && startTime && endTime
      ? `${scheduleDays.join(' و ')} ${formatTimeArabic(startTime)} - ${formatTimeArabic(endTime)}`
      : schedule.trim();
    onSave({
      id: group?.id,
      name: name.trim(),
      teacherId: teacherId || null,
      subject: subject.trim(),
      grade,
      schedule: scheduleLabel,
      scheduleDays,
      startTime: startTime || null,
      endTime: endTime || null,
      halfwayTime,
      branchId: branchId || null,
      billingModel,
      customPrice: customPrice ? Number(customPrice) : null,
      payoutType,
      payoutValue: Number(payoutValue) || 0,
      monthlyFee: monthlyFee ? Number(monthlyFee) : null,
      packageFee: packageFee ? Number(packageFee) : null,
    });
  };

  return (
    <Modal open onClose={onClose} title={group ? 'تعديل مجموعة' : 'إنشاء مجموعة جديدة'} size="md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input label="اسم المجموعة" placeholder="مثال: مجموعة الرياضيات - إعدادي" value={name} onChange={(e) => setName(e.target.value)} required />
        <div className="grid grid-cols-2 gap-3">
          <Select label="المعلم" value={teacherId} onChange={(e) => setTeacherId(e.target.value)}>
            <option value="">بدون معلم</option>
            {teachers.map((t) => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </Select>
          <Input label="المادة" placeholder="مثال: الرياضيات" value={subject} onChange={(e) => setSubject(e.target.value)} required />
        </div>
        <Select label="الصف الدراسي (مطلوب)" value={grade} onChange={(e) => setGrade(e.target.value)} required>
          <option value="">اختر الصف</option>
          {grades.map((g) => (
            <option key={g} value={g}>{g}</option>
          ))}
        </Select>
        {lockedPrice && (
          <div className="rounded-2xl bg-emerald-50 border border-emerald-200 px-4 py-2.5 flex items-center justify-between">
            <span className="text-sm font-semibold text-emerald-700 flex items-center gap-1.5">
              <Lock size={14} /> السعر المقفل للصف
            </span>
            <Badge tone="emerald">{formatEGP(lockedPrice.price)}</Badge>
          </div>
        )}

        {/* Billing Model */}
        <div className="rounded-2xl border-2 border-slate-100 p-4 space-y-3">
          <div className="flex items-center gap-2">
            <DollarSign size={16} className="text-brand-500" />
            <span className="text-sm font-bold text-brand-900">نوع الفوترة</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {(['per_session', 'monthly', 'full_package'] as BillingModel[]).map((bm) => (
              <button
                key={bm}
                type="button"
                onClick={() => setBillingModel(bm)}
                className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${billingModel === bm ? 'bg-brand-500 text-white shadow-sm' : 'bg-slate-100 text-brand-600 hover:bg-slate-200'}`}
              >
                {BILLING_MODEL_LABELS[bm]}
              </button>
            ))}
          </div>
          {billingModel === 'per_session' && (
            <Input
              label="سعر مخصص للحصة (اختياري - يتجاوز سعر الصف)"
              type="number"
              placeholder={lockedPrice ? formatEGP(lockedPrice.price) : '0'}
              value={customPrice}
              onChange={(e) => setCustomPrice(e.target.value)}
            />
          )}
          {billingModel === 'monthly' && (
            <Input
              label="رسوم الاشتراك الشهري"
              type="number"
              placeholder="مثال: 400"
              value={monthlyFee}
              onChange={(e) => setMonthlyFee(e.target.value)}
              required
            />
          )}
          {billingModel === 'full_package' && (
            <Input
              label="سعر الباقة الكاملة"
              type="number"
              placeholder="مثال: 1500"
              value={packageFee}
              onChange={(e) => setPackageFee(e.target.value)}
              required
            />
          )}
        </div>

        {/* Teacher Payout */}
        {allowProfitOverride ? (
        <div className="rounded-2xl border-2 border-slate-100 p-4 space-y-3">
          <div className="flex items-center gap-2">
            <Users2 size={16} className="text-brand-500" />
            <span className="text-sm font-bold text-brand-900">نسبة المعلم</span>
          </div>
          <Select label="نوع الحساب" value={payoutType} onChange={(e) => setPayoutType(e.target.value as PayoutType)}>
            <option value="fixed_seat">رسم ثابت للطالب (مثال: 20 ج.م/طالب)</option>
            <option value="percentage">نسبة مئوية (مثال: 80% للمعلم)</option>
            <option value="flat_per_session">مبلغ ثابت للحصة (مثال: 200 ج.م/حصة)</option>
          </Select>
          <Input
            label={payoutType === 'fixed_seat' ? 'المبلغ لكل طالب (ج.م)' : payoutType === 'percentage' ? 'نسبة المعلم (%)' : 'المبلغ لكل حصة (ج.م)'}
            type="number"
            value={payoutValue}
            onChange={(e) => setPayoutValue(e.target.value)}
            required
          />
        </div>
        ) : (
        <div className="rounded-2xl border-2 border-slate-100 p-4 space-y-2">
          <div className="flex items-center gap-2">
            <Lock size={16} className="text-brand-400" />
            <span className="text-sm font-bold text-brand-400">نسبة المعلم — مغلقة (يُستخدم النظام العام)</span>
          </div>
          <p className="text-xs text-brand-300">نظام المكسب العام الحالي: {PAYOUT_TYPE_LABELS[globalProfitModel]} — {globalProfitValue}{globalProfitModel === 'percentage' ? '%' : ' ج.م'}. لتفعيل التخصيص الفردي، فعّل الخيار من إعدادات السنتر.</p>
        </div>
        )}
        {/* Schedule: Day Checkboxes + Time Dropdowns */}
        <div className="rounded-2xl border-2 border-slate-100 p-4 space-y-3">
          <div className="flex items-center gap-2">
            <Clock size={16} className="text-brand-500" />
            <span className="text-sm font-bold text-brand-900">مواعيد الحصص</span>
          </div>
          <div>
            <label className="block text-sm font-semibold text-brand-700 mb-2">أيام الحصص</label>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
              {DAYS_OF_WEEK.map((day) => (
                <button
                  key={day}
                  type="button"
                  onClick={() => toggleDay(day)}
                  className={`px-2 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    scheduleDays.includes(day)
                      ? 'gradient-brand text-white shadow-soft'
                      : 'bg-slate-100 text-brand-600 hover:bg-slate-200'
                  }`}
                >
                  {day}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Select label="ساعة البداية" value={startTime} onChange={(e) => setStartTime(e.target.value)}>
              <option value="">اختر ساعة البداية</option>
              {timeSlots.map((t) => (
                <option key={t} value={t}>{formatTimeArabic(t)}</option>
              ))}
            </Select>
            <Select label="ساعة النهاية" value={endTime} onChange={(e) => setEndTime(e.target.value)}>
              <option value="">اختر ساعة النهاية</option>
              {timeSlots.map((t) => (
                <option key={t} value={t}>{formatTimeArabic(t)}</option>
              ))}
            </Select>
          </div>
          {halfwayTime && (
            <div className="rounded-xl bg-amber-50 border border-amber-100 px-3 py-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-amber-600 flex items-center gap-1.5">
                <Clock size={12} /> نصف وقت الحصة (تسجيل الغياب التلقائي)
              </span>
              <Badge tone="amber">{formatTimeArabic(halfwayTime)}</Badge>
            </div>
          )}
          <Input label="ملاحظة المواعيد (اختياري)" placeholder="مثال: السبت والأربعاء 4م" value={schedule} onChange={(e) => setSchedule(e.target.value)} />
        </div>

        <Select label="الفرع" value={branchId} onChange={(e) => setBranchId(e.target.value)}>
          <option value="">بدون فرع</option>
          {branches.map((b) => (
            <option key={b.id} value={b.id}>{b.name}</option>
          ))}
        </Select>
        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إلغاء</Button>
          <Button type="submit" className="flex-1">{group ? 'حفظ' : 'إنشاء'}</Button>
        </div>
      </form>
    </Modal>
  );
}
