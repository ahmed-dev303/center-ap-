import { useState } from 'react';
import { GraduationCap, UserPlus, Phone, BookOpen, Trash2, Edit3, X, KeyRound, Link2, CheckCircle2, Lock } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth, canManageTeachers } from '../context/AuthContext';
import { useCenter } from '../context/CenterContext';
import { useToast } from '../context/ToastContext';
import { uid } from '../lib/date';
import { filterByCenter } from '../lib/scoping';
import { logAction, PAYOUT_TYPE_LABELS } from '../lib/finance';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import type { Teacher, User, PayoutType } from '../lib/types';

interface UnifiedTeacherForm {
  name: string;
  phone: string;
  subject: string;
  centerSharePercent: string;
  username: string;
  password: string;
  createAccount: boolean;
}

export function Teachers() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { selectedCenterId } = useCenter();
  const { showToast } = useToast();
  const canManage = canManageTeachers(user?.role);

  const teachers = filterByCenter(db.teachers, selectedCenterId);

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Teacher | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const handleSave = (data: Omit<Teacher, 'id' | 'createdAt'> & { id?: string }, credentials?: { username: string; password: string }) => {
    const branchId = selectedCenterId || data.branchId || null;
    update((d) => {
      let teacherId: string;
      if (editing) {
        teacherId = editing.id;
        const idx = d.teachers.findIndex((t) => t.id === editing.id);
        if (idx >= 0) d.teachers[idx] = { ...d.teachers[idx], ...data, branchId };
      } else {
        teacherId = uid('t');
        d.teachers.push({ ...data, branchId, id: teacherId, createdAt: new Date().toISOString() } as Teacher);
      }

      if (credentials && credentials.username.trim() && credentials.password.trim()) {
        const existing = d.users.find((u) => u.teacherId === teacherId);
        if (existing) {
          existing.username = credentials.username.trim();
          existing.password = credentials.password.trim();
          existing.name = data.name;
        } else {
          const dup = d.users.find((u) => u.username === credentials.username.trim());
          if (dup) {
            showToast('اسم المستخدم مستخدم بالفعل', 'error');
            return;
          }
          const newUser: User = {
            id: `u${Date.now()}`,
            username: credentials.username.trim(),
            password: credentials.password.trim(),
            name: data.name,
            role: 'teacher',
            teacherId,
          };
          d.users.push(newUser);
        }
      }

      logAction(d, editing ? 'تعديل معلم' : 'إضافة معلم', `قام ${user?.name || ''} بـ${editing ? 'تعديل' : 'إضافة'} المعلم ${data.name}.`, user?.name || '', user?.role || 'admin');
    });
    showToast(editing ? 'تم تحديث بيانات المعلم' : 'تم إضافة المعلم بنجاح');
    setShowForm(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    update((d) => {
      d.teachers = d.teachers.filter((t) => t.id !== deleteId);
      d.groups = d.groups.map((g) => (g.teacherId === deleteId ? { ...g, teacherId: null } : g));
      d.users = d.users.filter((u) => u.teacherId !== deleteId);
      logAction(d, 'حذف معلم', `قام ${user?.name || ''} بحذف معلم.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف المعلم وحسابه', 'info');
    setDeleteId(null);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900">المعلمون</h2>
          <p className="text-sm text-brand-400 mt-0.5">{teachers.length} معلم</p>
        </div>
        {canManage && (
          <Button onClick={() => { setEditing(null); setShowForm(true); }}>
            <UserPlus size={18} /> معلم جديد
          </Button>
        )}
      </div>

      {teachers.length === 0 ? (
        <EmptyState icon={<GraduationCap size={36} />} title="لا يوجد معلمون" description="أضف معلمين للسنتر لبدء تنظيم المجموعات" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {teachers.map((t) => {
            const teacherGroups = db.groups.filter((g) => g.teacherId === t.id);
            const linkedUser = db.users.find((u) => u.teacherId === t.id);
            return (
              <Card key={t.id} className="p-5" hover>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="grid place-items-center h-14 w-14 rounded-2xl bg-gradient-to-br from-violet-500 to-brand-700 text-white font-extrabold text-xl shadow-soft">
                      {t.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-brand-900">{t.name}</h3>
                      <Badge tone="violet" className="mt-0.5">{t.subject}</Badge>
                    </div>
                  </div>
                  {linkedUser && (
                    <Badge tone="emerald" className="text-[10px]"><KeyRound size={10} className="inline" /> حساب نشط</Badge>
                  )}
                </div>
                <div className="space-y-1.5 text-sm">
                  <div className="flex items-center gap-2 text-brand-600">
                    <Phone size={14} className="text-brand-400" /> {t.phone || '—'}
                  </div>
                  <div className="flex items-center gap-2 text-brand-600">
                    <BookOpen size={14} className="text-brand-400" /> {teacherGroups.length} مجموعة
                  </div>
                  {db.allowProfitOverride && t.centerSharePercent != null && (
                    <div className="flex items-center gap-2 text-brand-600">
                      <Link2 size={14} className="text-brand-400" /> نصيب السنتر: {t.centerSharePercent}%
                    </div>
                  )}
                  {!db.allowProfitOverride && (
                    <div className="flex items-center gap-2 text-brand-400">
                      <Lock size={14} /> المكسب عام: {PAYOUT_TYPE_LABELS[db.globalProfitModel]} — {db.globalProfitValue}{db.globalProfitModel === 'percentage' ? '%' : ' ج.م'}
                    </div>
                  )}
                </div>
                {canManage && (
                  <div className="flex gap-2 mt-3 pt-3 border-t border-slate-100">
                    <Button size="sm" variant="ghost" onClick={() => { setEditing(t); setShowForm(true); }}>
                      <Edit3 size={15} /> تعديل
                    </Button>
                    <Button size="sm" variant="ghost" className="text-rose-500" onClick={() => setDeleteId(t.id)}>
                      <Trash2 size={15} /> حذف
                    </Button>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {showForm && (
        <TeacherForm
          teacher={editing}
          linkedUser={editing ? db.users.find((u) => u.teacherId === editing.id) : undefined}
          allowProfitOverride={db.allowProfitOverride}
          globalProfitModel={db.globalProfitModel}
          globalProfitValue={db.globalProfitValue}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSave={handleSave}
        />
      )}
      <ConfirmDialog
        open={deleteId !== null}
        title="حذف المعلم"
        message="سيتم حذف المعلم وحسابه المرتبط وفصل مجموعاته. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function TeacherForm({ teacher, linkedUser, allowProfitOverride, globalProfitModel, globalProfitValue, onClose, onSave }: {
  teacher: Teacher | null;
  linkedUser?: User;
  allowProfitOverride: boolean;
  globalProfitModel: PayoutType;
  globalProfitValue: number;
  onClose: () => void;
  onSave: (data: Omit<Teacher, 'id' | 'createdAt'> & { id?: string }, credentials?: { username: string; password: string }) => void;
}) {
  const [form, setForm] = useState<UnifiedTeacherForm>({
    name: teacher?.name || '',
    phone: teacher?.phone || '',
    subject: teacher?.subject || '',
    centerSharePercent: teacher?.centerSharePercent != null ? String(teacher.centerSharePercent) : '',
    username: linkedUser?.username || '',
    password: linkedUser?.password || '',
    createAccount: !teacher || !linkedUser,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.subject.trim()) return;

    if (form.createAccount) {
      if (!form.username.trim() || !form.password.trim()) {
        return;
      }
    }

    const teacherData: Omit<Teacher, 'id' | 'createdAt'> & { id?: string } = {
      id: teacher?.id,
      name: form.name.trim(),
      phone: form.phone.trim(),
      subject: form.subject.trim(),
      branchId: teacher?.branchId ?? null,
      centerSharePercent: form.centerSharePercent ? Number(form.centerSharePercent) : undefined,
    };

    const credentials = form.createAccount && form.username.trim() && form.password.trim()
      ? { username: form.username.trim(), password: form.password.trim() }
      : undefined;

    onSave(teacherData, credentials);
  };

  return (
    <Modal open onClose={onClose} title={teacher ? 'تعديل معلم' : 'إضافة معلم جديد'} size="md">
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="rounded-2xl border-2 border-violet-100 p-4 space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <GraduationCap size={18} className="text-violet-500" />
            <h4 className="text-sm font-bold text-brand-900">بيانات المعلم والتعليم</h4>
          </div>
          <Input label="اسم المعلم" placeholder="الاسم الكامل" value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} required />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input label="رقم الهاتف" placeholder="01xxxxxxxxx" value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} />
            <Input label="المادة" placeholder="مثال: الرياضيات" value={form.subject} onChange={(e) => setForm((p) => ({ ...p, subject: e.target.value }))} required />
          </div>
          {allowProfitOverride ? (
            <Input
              label="نصيب السنتر / نسبة العمولة (%)"
              type="number"
              placeholder="مثال: 30"
              value={form.centerSharePercent}
              onChange={(e) => setForm((p) => ({ ...p, centerSharePercent: e.target.value }))}
            />
          ) : (
            <div className="rounded-2xl border-2 border-slate-100 p-4 space-y-2">
              <div className="flex items-center gap-2">
                <Lock size={16} className="text-brand-400" />
                <span className="text-sm font-bold text-brand-400">نصيب السنتر — مغلق (يُستخدم النظام العام)</span>
              </div>
              <p className="text-xs text-brand-300">نظام المكسب العام الحالي: {PAYOUT_TYPE_LABELS[globalProfitModel]} — {globalProfitValue}{globalProfitModel === 'percentage' ? '%' : ' ج.م'}. لتفعيل التخصيص الفردي، فعّل الخيار من إعدادات السنتر.</p>
            </div>
          )}
        </div>

        <div className="rounded-2xl border-2 border-brand-100 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <KeyRound size={18} className="text-brand-500" />
              <h4 className="text-sm font-bold text-brand-900">بيانات الدخول</h4>
            </div>
            {teacher && (
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.createAccount}
                  onChange={(e) => setForm((p) => ({ ...p, createAccount: e.target.checked }))}
                  className="h-4 w-4 rounded accent-brand-500"
                />
                <span className="text-xs font-semibold text-brand-600">إنشاء/تعديل حساب</span>
              </label>
            )}
          </div>
          {form.createAccount && (
            <div className="space-y-3 animate-fade-in">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input label="اسم المستخدم" placeholder="username" value={form.username} onChange={(e) => setForm((p) => ({ ...p, username: e.target.value }))} required={form.createAccount} />
                <Input label="كلمة المرور" placeholder="••••••" value={form.password} onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))} required={form.createAccount} />
              </div>
              {!teacher && (
                <div className="flex items-start gap-2 rounded-xl bg-emerald-50 border border-emerald-200 px-3 py-2">
                  <CheckCircle2 size={16} className="text-emerald-600 shrink-0 mt-0.5" />
                  <p className="text-xs font-semibold text-emerald-700">سيتم إنشاء ملف المعلم وحساب الدخول المرتبط به تلقائياً عند الحفظ.</p>
                </div>
              )}
            </div>
          )}
          {!form.createAccount && teacher && linkedUser && (
            <p className="text-xs text-amber-600 font-semibold">الحساب الحالي سيبقى كما هو دون تغيير.</p>
          )}
        </div>

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إلغاء</Button>
          <Button type="submit" className="flex-1">{teacher ? 'حفظ' : 'إضافة المعلم'}</Button>
        </div>
      </form>
    </Modal>
  );
}
