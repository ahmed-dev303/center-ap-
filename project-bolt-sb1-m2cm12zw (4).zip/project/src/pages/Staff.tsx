import { useState, useMemo } from 'react';
import {
  Briefcase, Search, Trash2, Clock, Banknote,
  Phone, Calendar, X, CheckCircle2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useDB } from '../context/DBContext';
import { useCenter } from '../context/CenterContext';
import { useToast } from '../context/ToastContext';
import { filterByCenter } from '../lib/scoping';
import { logAction } from '../lib/finance';
import { todayStr, formatEGP, uid } from '../lib/date';
import type { StaffPayModel, StaffAttendance, Expense } from '../lib/types';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';

const ROLE_LABELS: Record<string, string> = {
  secretary: 'سكرتير / مساعد',
  supervisor: 'مشرف',
  assistant: 'مساعد مدرس',
};

const PAY_MODEL_LABELS: Record<StaffPayModel, string> = {
  hourly: 'بالساعة',
  per_session: 'للحصة',
  fixed_monthly: 'راتب شهري',
  percentage: 'نسبة مئوية',
};

const PAY_MODEL_UNIT: Record<StaffPayModel, string> = {
  hourly: 'ج.م/ساعة',
  per_session: 'ج.م/حصة',
  fixed_monthly: 'ج.م/شهر',
  percentage: '%',
};

export function Staff() {
  const { user } = useAuth();
  const { db, update } = useDB();
  const { selectedCenterId } = useCenter();
  const { showToast } = useToast();

  const [search, setSearch] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [attendanceStaffId, setAttendanceStaffId] = useState<string | null>(null);
  const [payoutStaffId, setPayoutStaffId] = useState<string | null>(null);

  const staffList = useMemo(() => {
    let list = filterByCenter(db.staff, selectedCenterId);
    const staffUserIds = new Set(list.map((s) => s.userId).filter(Boolean));
    for (const u of db.users) {
      if ((u.role === 'assistant' || u.role === 'supervisor' || u.role === 'secretary') && !staffUserIds.has(u.id)) {
        list = [...list, {
          id: u.id,
          userId: u.id,
          name: u.name,
          phone: u.phone || '',
          role: u.role === 'secretary' ? 'assistant' : u.role,
          payModel: u.payModel || 'fixed_monthly',
          rate: u.rate || 0,
          branchId: (u.branchIds && u.branchIds[0]) || null,
          active: true,
          createdAt: new Date().toISOString(),
        }];
      }
    }
    if (search) {
      list = list.filter((s) => s.name.includes(search) || s.phone.includes(search));
    }
    return list.sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  }, [db.staff, db.users, search, selectedCenterId]);

  const canEdit = user?.role === 'admin';

  const handleDelete = () => {
    if (!deleteId) return;
    const staff = db.staff.find((s) => s.id === deleteId);
    update((d) => {
      d.staff = d.staff.filter((s) => s.id !== deleteId);
      d.staffAttendance = d.staffAttendance.filter((a) => a.staffId !== deleteId);
      logAction(d, 'حذف موظف', `قام ${user?.name || ''} بحذف الموظف ${staff?.name || ''}.`, user?.name || '', user?.role || 'admin');
    });
    setDeleteId(null);
    showToast('تم حذف الموظف');
  };

  const handleToggleActive = (staffId: string) => {
    update((d) => {
      const s = d.staff.find((st) => st.id === staffId);
      if (s) s.active = !s.active;
    });
  };

  const computeUnpaidWages = (staffId: string): number => {
    const staff = db.staff.find((s) => s.id === staffId);
    if (!staff) return 0;
    const records = db.staffAttendance.filter((a) => a.staffId === staffId);
    const paidPayouts = db.staffPayouts.filter((p) => p.staffId === staffId);
    const totalEarned = records.reduce((sum, r) => {
      if (staff.payModel === 'hourly') return sum + r.hours * staff.rate;
      if (staff.payModel === 'per_session') return sum + r.sessions * staff.rate;
      if (staff.payModel === 'fixed_monthly') {
        const months = new Set(records.map((r) => r.date.slice(0, 7)));
        return sum + months.size * staff.rate;
      }
      if (staff.payModel === 'percentage') {
        return sum;
      }
      return sum;
    }, 0);
    const totalPaid = paidPayouts.reduce((sum, p) => sum + p.amount, 0);
    return Math.max(0, totalEarned - totalPaid);
  };

  const handleSaveAttendance = (data: Omit<StaffAttendance, 'id' | 'createdAt' | 'staffId'>) => {
    if (!attendanceStaffId) return;
    const staff = db.staff.find((s) => s.id === attendanceStaffId);
    update((d) => {
      const existing = d.staffAttendance.find(
        (a) => a.staffId === attendanceStaffId && a.date === data.date
      );
      if (existing) {
        Object.assign(existing, data);
      } else {
        d.staffAttendance.push({
          ...data,
          id: uid('att'),
          staffId: attendanceStaffId,
          createdAt: new Date().toISOString(),
        });
      }
      logAction(d, 'تسجيل حضور موظف', `قام ${user?.name || ''} بتسجيل حضور ${staff?.name || ''} بتاريخ ${data.date}.`, user?.name || '', user?.role || 'admin');
    });
    setAttendanceStaffId(null);
    showToast('تم تسجيل الحضور');
  };

  const handlePayout = () => {
    if (!payoutStaffId) return;
    const staff = db.staff.find((s) => s.id === payoutStaffId);
    if (!staff) return;
    const amount = computeUnpaidWages(payoutStaffId);
    if (amount <= 0) {
      showToast('لا توجد أجور مستحقة', 'error');
      setPayoutStaffId(null);
      return;
    }
    const today = todayStr();
    update((d) => {
      d.staffPayouts.push({
        id: uid('payout'),
        staffId: payoutStaffId,
        staffName: staff.name,
        amount,
        date: today,
        periodLabel: 'صرف أجور',
        note: `صرف أجور ${staff.name}`,
        createdAt: new Date().toISOString(),
      });
      const expense: Expense = {
        id: uid('exp'),
        category: 'other',
        categoryLabel: 'أجور موظفين',
        branchId: staff.branchId ?? null,
        amount,
        date: today,
        note: `صرف أجور ${staff.name}`,
        createdAt: new Date().toISOString(),
      };
      d.expenses.push(expense);
      logAction(d, 'صرف أجور موظف', `قام ${user?.name || ''} بصرف أجور ${amount ? formatEGP(amount) : ''} للموظف ${staff.name}.`, user?.name || '', user?.role || 'admin');
    });
    setPayoutStaffId(null);
    showToast(`تم صرف الأجور وتسجيلها في المصروفات`);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 flex items-center gap-2">
            <Briefcase size={24} /> المساعدون والموظفون
          </h2>
          <p className="text-sm text-brand-400 mt-0.5">{staffList.length} موظف مسجل — يتم الإضافة من صفحة الحسابات</p>
        </div>
      </div>

      <Input icon={<Search size={18} />} placeholder="بحث بالاسم أو الهاتف..." value={search} onChange={(e) => setSearch(e.target.value)} />

      {staffList.length === 0 ? (
        <EmptyState
          icon={<Briefcase size={36} />}
          title="لا يوجد موظفون مسجلون"
          description="يتم إضافة المساعدين والمشرفين من صفحة الحسابات عبر زر «حساب جديد»"
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {staffList.map((staff) => {
            const unpaid = computeUnpaidWages(staff.id);
            const attCount = db.staffAttendance.filter((a) => a.staffId === staff.id).length;
            return (
              <Card key={staff.id} className="p-5" hover>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`grid place-items-center h-12 w-12 rounded-2xl shrink-0 ${staff.active ? 'bg-brand-100 text-brand-600' : 'bg-slate-100 text-slate-400'}`}>
                      <Briefcase size={22} />
                    </div>
                    <div className="min-w-0">
                      <p className="font-bold text-brand-900 truncate">{staff.name}</p>
                      <div className="flex items-center gap-2 flex-wrap mt-1">
                        <Badge tone="brand" className="text-[10px]">{ROLE_LABELS[staff.role]}</Badge>
                        <Badge tone={staff.active ? 'emerald' : 'slate'} className="text-[10px]">{staff.active ? 'نشط' : 'متوقف'}</Badge>
                      </div>
                    </div>
                  </div>
                  {canEdit && (
                    <div className="flex gap-1 shrink-0">
                      <button onClick={() => setDeleteId(staff.id)} className="grid place-items-center h-9 w-9 rounded-xl text-rose-500 hover:bg-rose-50 transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  )}
                </div>

                <div className="mt-3 space-y-1.5 text-xs text-brand-400">
                  <p className="flex items-center gap-1.5"><Phone size={12} /> {staff.phone || '—'}</p>
                  <p className="flex items-center gap-1.5"><Banknote size={12} /> {PAY_MODEL_LABELS[staff.payModel]} • {formatEGP(staff.rate)} {PAY_MODEL_UNIT[staff.payModel]}</p>
                  <p className="flex items-center gap-1.5"><Calendar size={12} /> {attCount} يوم حضور</p>
                </div>

                {unpaid > 0 && (
                  <div className="mt-3 rounded-2xl bg-amber-50 border border-amber-200 px-3 py-2 flex items-center justify-between">
                    <span className="text-xs font-semibold text-amber-700">أجور مستحقة</span>
                    <Badge tone="amber">{formatEGP(unpaid)}</Badge>
                  </div>
                )}

                {canEdit && (
                  <div className="mt-3 flex gap-2 flex-wrap">
                    <Button size="sm" variant="secondary" onClick={() => setAttendanceStaffId(staff.id)}>
                      <Clock size={14} /> تسجيل حضور
                    </Button>
                    <Button size="sm" variant="success" onClick={() => setPayoutStaffId(staff.id)} disabled={unpaid <= 0}>
                      <Banknote size={14} /> صرف أجور
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleToggleActive(staff.id)}>
                      {staff.active ? <X size={14} /> : <CheckCircle2 size={14} />} {staff.active ? 'إيقاف' : 'تفعيل'}
                    </Button>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {attendanceStaffId && (
        <AttendanceForm
          staffName={db.staff.find((s) => s.id === attendanceStaffId)?.name || ''}
          payModel={db.staff.find((s) => s.id === attendanceStaffId)?.payModel || 'per_session'}
          onClose={() => setAttendanceStaffId(null)}
          onSave={handleSaveAttendance}
        />
      )}

      <ConfirmDialog
        open={!!payoutStaffId}
        title="صرف الأجور"
        message={`سيتم صرف ${formatEGP(computeUnpaidWages(payoutStaffId || ''))} وتسجيلها كمصروف في السنتر. هل أنت متأكد؟`}
        confirmText="تأكيد الصرف"
        onConfirm={handlePayout}
        onCancel={() => setPayoutStaffId(null)}
      />

      <ConfirmDialog
        open={!!deleteId}
        title="حذف الموظف"
        message="سيتم حذف الموظف وجميع سجلات حضوره. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function AttendanceForm({ staffName, payModel, onClose, onSave }: {
  staffName: string;
  payModel: StaffPayModel;
  onClose: () => void;
  onSave: (data: Omit<StaffAttendance, 'id' | 'createdAt' | 'staffId'>) => void;
}) {
  const [date, setDate] = useState(todayStr());
  const [clockIn, setClockIn] = useState('');
  const [clockOut, setClockOut] = useState('');
  const [sessions, setSessions] = useState('1');
  const [hours, setHours] = useState('');
  const [note, setNote] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      date,
      clockIn: clockIn || null,
      clockOut: clockOut || null,
      sessions: Number(sessions) || 0,
      hours: clockIn && clockOut ? computeHours(clockIn, clockOut) : Number(hours) || 0,
      note: note.trim(),
    });
  };

  const computeHours = (inTime: string, outTime: string): number => {
    const [ih, im] = inTime.split(':').map(Number);
    const [oh, om] = outTime.split(':').map(Number);
    let diff = (oh * 60 + om) - (ih * 60 + im);
    if (diff < 0) diff += 24 * 60;
    return Math.round((diff / 60) * 100) / 100;
  };

  return (
    <Modal open onClose={onClose} title={`تسجيل حضور - ${staffName}`} size="lg">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input label="التاريخ" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
        {payModel === 'hourly' && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <Input label="وقت الحضور" type="time" value={clockIn} onChange={(e) => setClockIn(e.target.value)} />
              <Input label="وقت الانصراف" type="time" value={clockOut} onChange={(e) => setClockOut(e.target.value)} />
            </div>
            {clockIn && clockOut && (
              <div className="rounded-2xl bg-emerald-50 border border-emerald-200 px-3 py-2 text-xs font-semibold text-emerald-700">
                عدد الساعات المحسوبة: {computeHours(clockIn, clockOut)}
              </div>
            )}
            <Input label="أو أدخل الساعات يدوياً" type="number" step="0.5" placeholder="0" value={hours} onChange={(e) => setHours(e.target.value)} />
          </>
        )}
        {payModel === 'per_session' && (
          <Input label="عدد الحصات" type="number" placeholder="1" value={sessions} onChange={(e) => setSessions(e.target.value)} required />
        )}
        {payModel === 'fixed_monthly' && (
          <div className="rounded-2xl bg-brand-50 border border-brand-100 px-3 py-2 text-xs font-semibold text-brand-600">
            تسجيل الحضور للراتب الشهري الثابت - سيتم احتساب الشهر كاملاً
          </div>
        )}
        {payModel === 'percentage' && (
          <div className="rounded-2xl bg-violet-50 border border-violet-200 px-3 py-2 text-xs font-semibold text-violet-700">
            تسجيل الحضور للموظف بنسبة مئوية - يتم حساب الأجور يدوياً عند الصرف
          </div>
        )}
        <Input label="ملاحظة" placeholder="ملاحظة اختيارية" value={note} onChange={(e) => setNote(e.target.value)} />
        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}>إلغاء</Button>
          <Button type="submit" className="flex-1"><CheckCircle2 size={18} /> تسجيل</Button>
        </div>
      </form>
    </Modal>
  );
}
