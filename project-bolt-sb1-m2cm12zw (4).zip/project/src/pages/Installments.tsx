import { useState, useMemo } from 'react';
import {
  CreditCard, Plus, Search, Trash2, Edit3, CheckCircle2, Clock,
  AlertTriangle, Calendar, FileText, Lock,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useDB } from '../context/DBContext';
import { useCenter } from '../context/CenterContext';
import { useToast } from '../context/ToastContext';
import { filterByCenter, canSecretaryAccessFeature } from '../lib/scoping';
import { logAction } from '../lib/finance';
import { todayStr, formatEGP, uid, formatDate, addDays } from '../lib/date';
import type { InstallmentPlan, Installment, InstallmentStatus, Payment } from '../lib/types';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Input, Select } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { WhatsAppButton } from '../components/ui/WhatsAppButton';

const STATUS_CONFIG: Record<InstallmentStatus, { label: string; tone: 'emerald' | 'amber' | 'rose'; icon: typeof CheckCircle2 }> = {
  paid: { label: 'تم الدفع', tone: 'emerald', icon: CheckCircle2 },
  pending: { label: 'معلق', tone: 'amber', icon: Clock },
  overdue: { label: 'متأخر', tone: 'rose', icon: AlertTriangle },
};

function computeStatus(installment: Installment): InstallmentStatus {
  if (installment.status === 'paid') return 'paid';
  if (installment.dueDate < todayStr()) return 'overdue';
  return 'pending';
}

export function Installments() {
  const { user } = useAuth();
  const { db, update } = useDB();
  const { selectedCenterId } = useCenter();
  const { showToast } = useToast();

  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingPlan, setEditingPlan] = useState<InstallmentPlan | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const canEdit = user?.role === 'admin' || user?.role === 'secretary';

  if (!canSecretaryAccessFeature(user, 'payments')) {
    return (
      <div className="grid place-items-center py-20">
        <div className="text-center">
          <div className="grid place-items-center h-20 w-20 rounded-3xl bg-amber-50 text-amber-400 mx-auto mb-4">
            <Lock size={36} />
          </div>
          <h3 className="text-lg font-bold text-brand-900 mb-1">خاصية غير متاحة</h3>
          <p className="text-sm text-brand-400">⚠️ هذه الخاصية غير متاحة لنوع ربط السكرتير بهذا المدرس</p>
        </div>
      </div>
    );
  }

  const students = filterByCenter(db.students, selectedCenterId);
  const groups = filterByCenter(db.groups, selectedCenterId);

  const plans = useMemo(() => {
    let list = db.installmentPlans.filter((p) => {
      const student = students.find((s) => s.id === p.studentId);
      return student !== undefined;
    });
    if (search) {
      list = list.filter((p) => {
        const student = students.find((s) => s.id === p.studentId);
        const group = groups.find((g) => g.id === p.groupId);
        return student?.name.includes(search) || group?.name.includes(search);
      });
    }
    return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [db.installmentPlans, students, groups, search]);

  const handleSavePlan = (data: Omit<InstallmentPlan, 'id' | 'createdAt'> & { id?: string }) => {
    update((d) => {
      if (data.id) {
        const idx = d.installmentPlans.findIndex((p) => p.id === data.id);
        if (idx >= 0) d.installmentPlans[idx] = { ...d.installmentPlans[idx], ...data } as InstallmentPlan;
        logAction(d, 'تعديل أقساط', `قام ${user?.name || ''} بتعديل جدول أقساط لطالب.`, user?.name || '', user?.role || 'admin');
      } else {
        d.installmentPlans.push({
          ...data,
          id: uid('plan'),
          createdAt: new Date().toISOString(),
        } as InstallmentPlan);
        const student = d.students.find((s) => s.id === data.studentId);
        logAction(d, 'إنشاء أقساط', `قام ${user?.name || ''} بإنشاء جدول أقساط للطالب ${student?.name || ''} بقيمة ${formatEGP(data.totalAmount)}.`, user?.name || '', user?.role || 'admin');
      }
    });
    setShowForm(false);
    setEditingPlan(null);
    showToast('تم حفظ جدول الأقساط');
  };

  const handleMarkPaid = (planId: string, installmentId: string) => {
    update((d) => {
      const plan = d.installmentPlans.find((p) => p.id === planId);
      if (!plan) return;
      const inst = plan.installments.find((i) => i.id === installmentId);
      if (!inst) return;
      inst.status = 'paid';
      inst.paidDate = todayStr();
      const student = d.students.find((s) => s.id === plan.studentId);
      const payment: Payment = {
        id: uid('pay'),
        studentId: plan.studentId,
        groupId: plan.groupId,
        branchId: student?.branchId ?? null,
        amount: inst.amount,
        date: todayStr(),
        month: todayStr().slice(0, 7),
        method: 'cash',
        paymentType: 'tuition',
        note: `قسط - ${formatDate(inst.dueDate)}`,
        createdAt: new Date().toISOString(),
      };
      d.payments.push(payment);
      inst.paymentId = payment.id;
      logAction(d, 'سداد قسط', `قام ${user?.name || ''} بتسجيل سداد قسط بقيمة ${formatEGP(inst.amount)} للطالب ${student?.name || ''}.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم تسجيل سداد القسط');
  };

  const handleDelete = () => {
    if (!deleteId) return;
    update((d) => {
      d.installmentPlans = d.installmentPlans.filter((p) => p.id !== deleteId);
      logAction(d, 'حذف أقساط', `قام ${user?.name || ''} بحذف جدول أقساط.`, user?.name || '', user?.role || 'admin');
    });
    setDeleteId(null);
    showToast('تم حذف جدول الأقساط');
  };

  const overdueCount = plans.reduce((sum, p) => sum + p.installments.filter((i) => computeStatus(i) === 'overdue').length, 0);
  const pendingCount = plans.reduce((sum, p) => sum + p.installments.filter((i) => computeStatus(i) === 'pending').length, 0);
  const paidCount = plans.reduce((sum, p) => sum + p.installments.filter((i) => i.status === 'paid').length, 0);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 flex items-center gap-2">
            <CreditCard size={24} /> إدارة الأقساط
          </h2>
          <p className="text-sm text-brand-400 mt-0.5">{plans.length} جدول أقساط</p>
        </div>
        {canEdit && (
          <Button onClick={() => { setEditingPlan(null); setShowForm(true); }}>
            <Plus size={18} /> إنشاء جدول أقساط
          </Button>
        )}
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Card className="p-3 text-center">
          <p className="text-2xl font-extrabold text-emerald-600">{paidCount}</p>
          <p className="text-xs text-brand-400 font-semibold">أقساط مدفوعة</p>
        </Card>
        <Card className="p-3 text-center">
          <p className="text-2xl font-extrabold text-amber-600">{pendingCount}</p>
          <p className="text-xs text-brand-400 font-semibold">أقساط معلقة</p>
        </Card>
        <Card className="p-3 text-center">
          <p className="text-2xl font-extrabold text-rose-600">{overdueCount}</p>
          <p className="text-xs text-brand-400 font-semibold">أقساط متأخرة</p>
        </Card>
      </div>

      <Input icon={<Search size={18} />} placeholder="بحث باسم الطالب أو المجموعة..." value={search} onChange={(e) => setSearch(e.target.value)} />

      {plans.length === 0 ? (
        <EmptyState
          icon={<CreditCard size={36} />}
          title="لا توجد جداول أقساط"
          description="أنشئ جدول أقساط للطلاب في الكورسات الكبيرة لتتبع الدفعات المجدولة"
          action={canEdit ? <Button onClick={() => setShowForm(true)}><Plus size={18} /> إنشاء جدول</Button> : undefined}
        />
      ) : (
        <div className="space-y-4">
          {plans.map((plan) => {
            const student = students.find((s) => s.id === plan.studentId);
            const group = groups.find((g) => g.id === plan.groupId);
            const paidAmount = plan.installments.filter((i) => i.status === 'paid').reduce((s, i) => s + i.amount, 0);
            return (
              <Card key={plan.id} className="p-5" hover>
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="grid place-items-center h-12 w-12 rounded-2xl bg-brand-100 text-brand-600 shrink-0">
                      <CreditCard size={22} />
                    </div>
                    <div className="min-w-0">
                      <p className="font-bold text-brand-900 truncate">{student?.name || 'طالب'}</p>
                      <p className="text-xs text-brand-400">{group?.name || '—'} • كود #{student?.id}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Badge tone="brand">{formatEGP(plan.totalAmount)}</Badge>
                    {canEdit && (
                      <>
                        <button onClick={() => { setEditingPlan(plan); setShowForm(true); }} className="grid place-items-center h-9 w-9 rounded-xl text-brand-500 hover:bg-brand-50 transition-colors">
                          <Edit3 size={16} />
                        </button>
                        <button onClick={() => setDeleteId(plan.id)} className="grid place-items-center h-9 w-9 rounded-xl text-rose-500 hover:bg-rose-50 transition-colors">
                          <Trash2 size={16} />
                        </button>
                      </>
                    )}
                  </div>
                </div>

                <div className="mb-3">
                  <div className="flex items-center justify-between text-xs text-brand-400 mb-1">
                    <span>المدفوع: {formatEGP(paidAmount)}</span>
                    <span>المتبقي: {formatEGP(plan.totalAmount - paidAmount)}</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full gradient-brand transition-all duration-500"
                      style={{ width: `${(paidAmount / plan.totalAmount) * 100}%` }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  {plan.installments.map((inst, idx) => {
                    const status = computeStatus(inst);
                    const config = STATUS_CONFIG[status];
                    const Icon = config.icon;
                    return (
                      <div key={inst.id} className="flex items-center gap-3 rounded-2xl bg-brand-50/40 px-3 py-2.5">
                        <div className={`grid place-items-center h-9 w-9 rounded-xl shrink-0 ${
                          status === 'paid' ? 'bg-emerald-100 text-emerald-600' :
                          status === 'overdue' ? 'bg-rose-100 text-rose-600' :
                          'bg-amber-100 text-amber-600'
                        }`}>
                          <Icon size={16} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-brand-900">قسط {idx + 1} • {formatEGP(inst.amount)}</p>
                          <p className="text-xs text-brand-400 flex items-center gap-1">
                            <Calendar size={10} /> {formatDate(inst.dueDate)}
                            {inst.paidDate && <span className="text-emerald-600"> • دفع في {formatDate(inst.paidDate)}</span>}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Badge tone={config.tone} className="text-[10px]">{config.label}</Badge>
                          {canEdit && status !== 'paid' && (
                            <button
                              onClick={() => handleMarkPaid(plan.id, inst.id)}
                              className="grid place-items-center h-8 w-8 rounded-xl bg-emerald-500 text-white hover:bg-emerald-600 transition-colors"
                              title="تسجيل سداد"
                            >
                              <CheckCircle2 size={16} />
                            </button>
                          )}
                          {canEdit && status === 'overdue' && student && (
                            <WhatsAppButton
                              student={student}
                              template="installment"
                              centerName={db.centerName}
                              groupName={group?.name}
                              amountDue={inst.amount}
                              dueDate={formatDate(inst.dueDate)}
                              size="sm"
                              label=""
                            />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {showForm && (
        <PlanForm
          plan={editingPlan}
          students={students}
          groups={groups}
          onClose={() => { setShowForm(false); setEditingPlan(null); }}
          onSave={handleSavePlan}
        />
      )}

      <ConfirmDialog
        open={!!deleteId}
        title="حذف جدول الأقساط"
        message="سيتم حذف جدول الأقساط بالكامل. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function PlanForm({ plan, students, groups, onClose, onSave }: {
  plan: InstallmentPlan | null;
  students: { id: number; name: string; groupId: string | null }[];
  groups: { id: string; name: string; grade: string }[];
  onClose: () => void;
  onSave: (data: Omit<InstallmentPlan, 'id' | 'createdAt'> & { id?: string }) => void;
}) {
  const [studentId, setStudentId] = useState(plan?.studentId ?? 0);
  const [groupId, setGroupId] = useState(plan?.groupId ?? '');
  const [totalAmount, setTotalAmount] = useState(plan ? String(plan.totalAmount) : '');
  const [installmentCount, setInstallmentCount] = useState(plan ? String(plan.installments.length) : '3');
  const [startDate, setStartDate] = useState(plan?.installments[0]?.dueDate || todayStr());
  const [intervalDays, setIntervalDays] = useState('30');

  const generateInstallments = (): Installment[] => {
    const total = Number(totalAmount);
    const count = Number(installmentCount);
    if (!total || !count) return [];
    const perInstallment = Math.round(total / count);
    const remainder = total - perInstallment * count;
    return Array.from({ length: count }, (_, i) => {
      const existing = plan?.installments[i];
      return {
        id: existing?.id || uid('inst'),
        amount: perInstallment + (i === count - 1 ? remainder : 0),
        dueDate: addDays(startDate, i * Number(intervalDays)),
        status: existing?.status || 'pending' as InstallmentStatus,
        paidDate: existing?.paidDate || null,
        paymentId: existing?.paymentId || null,
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId || !groupId || !totalAmount) return;
    const installments = generateInstallments();
    if (installments.length === 0) return;
    onSave({
      id: plan?.id,
      studentId,
      groupId,
      totalAmount: Number(totalAmount),
      installments,
    });
  };

  const previewInstallments = generateInstallments();

  return (
    <Modal open onClose={onClose} title={plan ? 'تعديل جدول الأقساط' : 'إنشاء جدول أقساط'} size="xl">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Select label="الطالب" value={String(studentId)} onChange={(e) => setStudentId(Number(e.target.value))} required>
          <option value="">اختر الطالب</option>
          {students.map((s) => <option key={s.id} value={s.id}>{s.name} (#{s.id})</option>)}
        </Select>
        <Select label="المجموعة / الكورس" value={groupId} onChange={(e) => setGroupId(e.target.value)} required>
          <option value="">اختر المجموعة</option>
          {groups.map((g) => <option key={g.id} value={g.id}>{g.name} - {g.grade}</option>)}
        </Select>
        <div className="grid grid-cols-2 gap-3">
          <Input label="إجمالي المبلغ (ج.م)" type="number" placeholder="0" value={totalAmount} onChange={(e) => setTotalAmount(e.target.value)} required />
          <Input label="عدد الأقساط" type="number" placeholder="3" value={installmentCount} onChange={(e) => setInstallmentCount(e.target.value)} required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Input label="تاريخ أول قسط" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required />
          <Input label="الفترة بين الأقساط (أيام)" type="number" placeholder="30" value={intervalDays} onChange={(e) => setIntervalDays(e.target.value)} required />
        </div>

        {previewInstallments.length > 0 && (
          <div className="rounded-2xl border-2 border-slate-100 p-4">
            <p className="text-sm font-bold text-brand-900 mb-3 flex items-center gap-1.5"><FileText size={16} /> معاينة جدول الأقساط</p>
            <div className="space-y-2">
              {previewInstallments.map((inst, idx) => (
                <div key={idx} className="flex items-center justify-between rounded-xl bg-brand-50/40 px-3 py-2">
                  <span className="text-xs font-semibold text-brand-700">قسط {idx + 1}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-brand-400">{formatDate(inst.dueDate)}</span>
                    <Badge tone="brand" className="text-[10px]">{formatEGP(inst.amount)}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}>إلغاء</Button>
          <Button type="submit" className="flex-1"><CheckCircle2 size={18} /> حفظ</Button>
        </div>
      </form>
    </Modal>
  );
}
