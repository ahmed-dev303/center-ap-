import { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { CalendarCheck, Search, Check, X as XIcon, UserCheck, UserX, Calendar, Lock, Zap, ScanLine, AlertTriangle, CheckCircle2, Camera, CameraOff, SwitchCamera, Clock, Wallet, BookOpen, Users, AlertCircle } from 'lucide-react';
import { WhatsAppButton } from '../components/ui/WhatsAppButton';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { getScopedData, canSecretaryAccessFeature, studentGroupIds } from '../lib/scoping';
import { logAction, discountedSessionFee } from '../lib/finance';
import { uid, formatDate, todayStr, currentMonthStr, formatEGP } from '../lib/date';
import { autoMarkAbsent, getAttendanceWindowState, getAttendanceWindowLabel } from '../lib/schedule';
import { parseStudentCode } from '../lib/qr';
import { playSuccessSound, playWarningSound, playErrorSound } from '../lib/beep';
import { safeVibrate } from '../lib/safe-storage';
import { useCameraScanner } from '../hooks/useCameraScanner';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { StudentSearch } from '../components/StudentSearch';
import { MultiGroupSelect } from '../components/ui/MultiGroupSelect';
import type { Student } from '../lib/types';

type ScanStatus = 'success' | 'duplicate' | 'error' | 'unpaid' | 'wrong_group';
type ScanResult = {
  student: Student | null;
  status: ScanStatus;
  groupName?: string;
  message: string;
  time: string;
  unpaidAmount?: number;
  studentGroups?: string;
  lessonCount?: number;
};

export function Attendance() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { showToast } = useToast();
  const scoped = getScopedData(db, user);
  const isTeacher = user?.role === 'teacher';

  if (!canSecretaryAccessFeature(user, 'attendance')) {
    return (
      <div className="grid place-items-center py-20">
        <div className="text-center">
          <div className="grid place-items-center h-20 w-20 rounded-3xl bg-amber-50 text-amber-400 mx-auto mb-4">
            <Lock size={36} />
          </div>
          <h3 className="text-lg font-bold text-brand-900 mb-1">خاصية غير متاحة</h3>
          <p className="text-sm text-brand-400">⚠️ هذه الخاصية غير متاحة لنوع ربط السكرتير بهذا المدرس</p>
        </div>
      </div>
    );
  }

  const qrEnabled = db.qrEnabled;
  const [date, setDate] = useState(todayStr());
  const [selectedGroupIds, setSelectedGroupIds] = useState<string[]>([]);
  const [search, setSearch] = useState('');
  const [autoAbsenceTriggered, setAutoAbsenceTriggered] = useState<Set<string>>(new Set());
  const [autoAbsenceCount, setAutoAbsenceCount] = useState(0);
  const [nowTick, setNowTick] = useState(0);

  // Scanner state
  const [scannerInput, setScannerInput] = useState('');
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [scanLog, setScanLog] = useState<ScanResult[]>([]);
  const [showCamera, setShowCamera] = useState(false);
  const scannerRef = useRef<HTMLInputElement>(null);
  const bufferRef = useRef<string>('');
  const lastScanTimeRef = useRef<number>(0);

  const isToday = date === todayStr();
  const openingBuffer = db.attendanceOpeningBuffer ?? 10;
  const closingPercent = db.attendanceClosingPercent ?? 50;
  const flexibleTime = db.allowFlexibleAttendanceTime ?? false;

  const closedWindowGroups = useMemo(() => {
    if (flexibleTime) return [];
    return scoped.groups.filter((g) => isToday && getAttendanceWindowState(g, openingBuffer, closingPercent) === 'closed');
  }, [scoped.groups, isToday, openingBuffer, closingPercent, nowTick, flexibleTime]);

  const lockedGroupIds = useMemo(() => new Set(closedWindowGroups.map((g) => g.id)), [closedWindowGroups]);
  const LOCK_TOAST = 'عفواً، قضي الأمر! لا يمكن التعديل على الحضور والغياب بعد انتهاء الوقت المحدد للحصة 🔒';
  const isSessionLocked = useCallback((groupId: string | null) => {
    if (!groupId || flexibleTime) return false;
    return lockedGroupIds.has(groupId);
  }, [lockedGroupIds, flexibleTime]);

  const processScan = useCallback((code: string) => {
    const time = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const studentId = parseStudentCode(code);

    if (studentId === null) {
      playErrorSound();
      safeVibrate(200);
      const result: ScanResult = { student: null, status: 'error', message: 'كود طالب غير صالح', time };
      setScanResult(result);
      setScanLog((prev) => [result, ...prev].slice(0, 15));
      setScannerInput('');
      return;
    }

    const student = db.students.find((s) => s.id === studentId);
    if (!student) {
      playErrorSound();
      safeVibrate(200);
      const result: ScanResult = { student: null, status: 'error', message: `طالب غير موجود (${code})`, time };
      setScanResult(result);
      setScanLog((prev) => [result, ...prev].slice(0, 15));
      setScannerInput('');
      return;
    }

    const sGroupIds = studentGroupIds(student);
    if (sGroupIds.length === 0) {
      playErrorSound();
      safeVibrate(200);
      const result: ScanResult = { student, status: 'error', message: 'الطالب غير مسجل في أي مجموعة', time };
      setScanResult(result);
      setScanLog((prev) => [result, ...prev].slice(0, 15));
      setScannerInput('');
      return;
    }

    // Determine which group to log attendance for
    // If a specific group is selected and the student is in it, use that group
    // Otherwise use the first group that has a session today, or the first group
    let targetGroupId: string | null = null;
    if (selectedGroupIds.length > 0) {
      const matchGroup = sGroupIds.find((id) => selectedGroupIds.includes(id));
      if (matchGroup) targetGroupId = matchGroup;
    }
    if (!targetGroupId) {
      // Find a group with a session today
      const todayGroup = sGroupIds.find((id) => {
        const g = db.groups.find((gr) => gr.id === id);
        return g && g.scheduleDays && g.scheduleDays.length > 0;
      });
      targetGroupId = todayGroup || sGroupIds[0];
    }

    // Check if student belongs to the selected session group (when a specific group is selected)
    if (selectedGroupIds.length > 0 && !sGroupIds.some((id) => selectedGroupIds.includes(id))) {
      const groupNames = sGroupIds.map((id) => db.groups.find((g) => g.id === id)?.name).filter(Boolean).join('، ');
      playWarningSound();
      safeVibrate(100);
      const result: ScanResult = {
        student, status: 'wrong_group', message: 'الطالب لا ينتمي للمجموعة المحددة', time,
        studentGroups: groupNames,
      };
      setScanResult(result);
      setScanLog((prev) => [result, ...prev].slice(0, 15));
      setScannerInput('');
      return;
    }

    const group = db.groups.find((g) => g.id === targetGroupId);

    // Block scan if the session is permanently locked
    if (isSessionLocked(targetGroupId)) {
      playErrorSound();
      safeVibrate(200);
      const result: ScanResult = { student, status: 'error', groupName: group?.name, message: 'تم إغلاق التعديل نهائياً لهذه الحصة 🔒', time };
      setScanResult(result);
      setScanLog((prev) => [result, ...prev].slice(0, 15));
      setScannerInput('');
      showToast(LOCK_TOAST, 'error');
      return;
    }

    const existing = db.attendance.find((a) => a.studentId === student.id && a.date === date && a.groupId === targetGroupId);

    if (existing && existing.status === 'present') {
      playWarningSound();
      safeVibrate(100);
      const result: ScanResult = { student, status: 'duplicate', groupName: group?.name, message: 'تم تسجيل الحضور مسبقاً', time };
      setScanResult(result);
      setScanLog((prev) => [result, ...prev].slice(0, 15));
      setScannerInput('');
      return;
    }

    // Check payment status for current month
    const month = currentMonthStr();
    const gradePrice = db.gradePrices.find((gp) => gp.grade === student.grade);
    const expected = gradePrice ? discountedSessionFee(gradePrice.price, student) : 0;
    const paid = db.payments
      .filter((p) => p.studentId === student.id && p.paymentType === 'session' && p.month === month)
      .reduce((sum, p) => sum + p.amount, 0);
    const unpaidAmount = expected - paid;
    const isUnpaid = unpaidAmount > 0;

    // Count lessons attended this month for this group
    const lessonCount = db.attendance.filter(
      (a) => a.studentId === student.id && a.status === 'present' && a.groupId === targetGroupId && a.date.startsWith(month.slice(0, 7))
    ).length;

    // Log attendance
    update((d) => {
      d.attendance = d.attendance.filter((a) => !(a.studentId === student.id && a.date === date && a.groupId === targetGroupId));
      d.attendance.push({ id: uid('att'), studentId: student.id, groupId: targetGroupId!, date, status: 'present', createdAt: new Date().toISOString() });
      logAction(d, 'تسجيل حضور', `قام ${user?.name || ''} بتسجيل حضور الطالب ${student.name} في مجموعة ${group?.name || ''} (مسح QR).`, user?.name || '', user?.role || 'admin');
    });

    if (isUnpaid) {
      playWarningSound();
      safeVibrate([100, 50, 100]);
    } else {
      playSuccessSound();
      safeVibrate(50);
    }

    const groupNames = sGroupIds.map((id) => db.groups.find((g) => g.id === id)?.name).filter(Boolean).join('، ');
    const result: ScanResult = {
      student,
      status: isUnpaid ? 'unpaid' : 'success',
      groupName: group?.name,
      message: isUnpaid ? `تم تسجيل الحضور — متأخر ${formatEGP(unpaidAmount)}` : 'تم تسجيل الحضور',
      time,
      unpaidAmount: isUnpaid ? unpaidAmount : undefined,
      studentGroups: groupNames,
      lessonCount,
    };
    setScanResult(result);
    setScanLog((prev) => [result, ...prev].slice(0, 15));
    setScannerInput('');
  }, [db, date, update, user, selectedGroupIds, isSessionLocked]);

  const handleScannerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const code = scannerInput.trim();
    if (code) {
      processScan(code);
    } else {
      const buffered = bufferRef.current.trim();
      if (buffered) processScan(buffered);
    }
    bufferRef.current = '';
  };

  // Camera scanner hook
  const {
    videoRef, canvasRef, cameraActive, cameraError,
    cameras, selectedCameraId, setSelectedCameraId,
    startCamera, stopCamera,
  } = useCameraScanner({ onScan: processScan, active: showCamera && qrEnabled && !isTeacher });

  useEffect(() => {
    const interval = setInterval(() => { setNowTick((t) => t + 1); }, 30000);
    return () => clearInterval(interval);
  }, []);

  // Auto-focus scanner input when QR enabled and no camera
  useEffect(() => {
    if (!isTeacher && qrEnabled && !showCamera) scannerRef.current?.focus();
  }, [isTeacher, qrEnabled, showCamera]);

  // Global keydown listener for hardware scanner
  useEffect(() => {
    if (isTeacher || !qrEnabled || showCamera) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      const now = Date.now();
      const timeSinceLast = now - lastScanTimeRef.current;

      if (e.key === 'Enter') {
        const code = bufferRef.current.trim();
        if (code.length >= 2) {
          e.preventDefault();
          processScan(code);
        }
        bufferRef.current = '';
        lastScanTimeRef.current = now;
        return;
      }

      if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        if (timeSinceLast > 500 && bufferRef.current.length > 0) {
          bufferRef.current = '';
        }
        bufferRef.current += e.key;
        lastScanTimeRef.current = now;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isTeacher, qrEnabled, showCamera, db, date, selectedGroupIds, processScan]);

  useEffect(() => {
    if (isToday && !isTeacher && closedWindowGroups.length > 0) {
      const newlyClosed = closedWindowGroups.filter((g) => !autoAbsenceTriggered.has(g.id));
      if (newlyClosed.length > 0) {
        let total = 0;
        update((d) => {
          for (const g of newlyClosed) {
            total += autoMarkAbsent(d, g, date, user?.name || '', (user?.role || 'admin') as 'admin' | 'secretary' | 'teacher');
          }
        });
        if (total > 0) {
          setAutoAbsenceCount(total);
          showToast(`⚡ تم تسجيل غياب ${total} طالب تلقائياً (انتهى وقت الحضور)`, 'info');
        }
        setAutoAbsenceTriggered((prev) => {
          const next = new Set(prev);
          newlyClosed.forEach((g) => next.add(g.id));
          return next;
        });
      }
    }
  }, [closedWindowGroups, isToday, isTeacher, autoAbsenceTriggered, date, user, update, showToast]);

  const activeGroupForWindow = selectedGroupIds.length === 1 ? scoped.groups.find((g) => g.id === selectedGroupIds[0]) : null;
  const windowState = activeGroupForWindow && isToday
    ? getAttendanceWindowState(activeGroupForWindow, openingBuffer, closingPercent)
    : null;
  const windowLabel = activeGroupForWindow && isToday
    ? getAttendanceWindowLabel(activeGroupForWindow, openingBuffer, closingPercent)
    : null;
  const scannerLocked = !flexibleTime && (windowState === 'before' || windowState === 'closed');

  const availableGroups = scoped.groups;
  const filteredGroups = selectedGroupIds.length > 0 ? availableGroups.filter((g) => selectedGroupIds.includes(g.id)) : availableGroups;
  const groupIds = new Set(filteredGroups.map((g) => g.id));
  const students = scoped.students.filter((s) => studentGroupIds(s).some((id) => groupIds.has(id)));
  const filteredStudents = students.filter((s) => !search || s.name.includes(search) || String(s.id).includes(search));

  const attendanceMap = useMemo(() => {
    const map = new Map<number, 'present' | 'absent'>();
    scoped.attendance
      .filter((a) => a.date === date)
      .forEach((a) => map.set(a.studentId, a.status));
    return map;
  }, [scoped.attendance, date]);

  const toggleAttendance = (studentId: number, groupId: string, status: 'present' | 'absent') => {
    if (isTeacher) return;
    if (isSessionLocked(groupId)) { showToast(LOCK_TOAST, 'error'); return; }
    const student = db.students.find((s) => s.id === studentId);
    const group = db.groups.find((g) => g.id === groupId);
    update((d) => {
      d.attendance = d.attendance.filter((a) => !(a.studentId === studentId && a.date === date && a.groupId === groupId));
      d.attendance.push({ id: uid('att'), studentId, groupId, date, status, createdAt: new Date().toISOString() });
      logAction(d, status === 'present' ? 'تسجيل حضور' : 'تسجيل غياب', `قام ${user?.name || ''} بتسجيل ${status === 'present' ? 'حضور' : 'غياب'} الطالب ${student?.name || ''} في مجموعة ${group?.name || ''}.`, user?.name || '', user?.role || 'admin');
    });
    showToast(status === 'present' ? 'تم تسجيل الحضور' : 'تم تسجيل الغياب', status === 'present' ? 'success' : 'info');
  };

  const markAllPresent = () => {
    if (isTeacher) return;
    const unlockedStudents = filteredStudents.filter((s) => {
      const sGids = studentGroupIds(s);
      const targetGid = sGids.find((id) => groupIds.has(id)) || sGids[0];
      return targetGid && !isSessionLocked(targetGid);
    });
    if (unlockedStudents.length === 0) { showToast(LOCK_TOAST, 'error'); return; }
    update((d) => {
      for (const s of unlockedStudents) {
        const sGids = studentGroupIds(s);
        if (sGids.length === 0) continue;
        const targetGid = sGids.find((id) => groupIds.has(id)) || sGids[0];
        d.attendance = d.attendance.filter((a) => !(a.studentId === s.id && a.date === date && a.groupId === targetGid));
        d.attendance.push({ id: uid('att'), studentId: s.id, groupId: targetGid, date, status: 'present', createdAt: new Date().toISOString() });
      }
      logAction(d, 'تسجيل حضور جماعي', `قام ${user?.name || ''} بتسجيل حضور جميع الطلاب (${unlockedStudents.length}) بتاريخ ${formatDate(date)}.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم تسجيل حضور جميع الطلاب');
  };

  const presentCount = filteredStudents.filter((s) => attendanceMap.get(s.id) === 'present').length;
  const absentCount = filteredStudents.filter((s) => attendanceMap.get(s.id) === 'absent').length;

  const statusColors: Record<ScanStatus, string> = {
    success: 'bg-emerald-50 border-emerald-300',
    duplicate: 'bg-amber-50 border-amber-300',
    error: 'bg-rose-50 border-rose-300',
    unpaid: 'bg-amber-50 border-amber-300',
    wrong_group: 'bg-rose-50 border-rose-300',
  };
  const statusIconColors: Record<ScanStatus, string> = {
    success: 'bg-emerald-500 text-white',
    duplicate: 'bg-amber-500 text-white',
    error: 'bg-rose-500 text-white',
    unpaid: 'bg-amber-500 text-white',
    wrong_group: 'bg-rose-500 text-white',
  };
  const statusTextColors: Record<ScanStatus, string> = {
    success: 'text-emerald-700',
    duplicate: 'text-amber-700',
    error: 'text-rose-700',
    unpaid: 'text-amber-700',
    wrong_group: 'text-rose-700',
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 flex items-center gap-2">
            <ScanLine size={24} /> نظام الحضور بالـ QR Code
          </h2>
          <p className="text-sm text-brand-400 mt-0.5">{formatDate(date)}</p>
        </div>
        {!isTeacher && (
          <Button variant="success" onClick={markAllPresent} disabled={filteredStudents.length === 0 || (closedWindowGroups.length > 0 && closedWindowGroups.length === filteredGroups.length)}>
            <Check size={18} /> حضور الكل
          </Button>
        )}
      </div>

      {/* Flexible time indicator */}
      {flexibleTime && (
        <div className="rounded-2xl bg-emerald-50 border border-emerald-200 px-4 py-3 flex items-center gap-2 animate-fade-in">
          <Clock size={18} className="text-emerald-500 shrink-0" />
          <p className="text-sm font-bold text-emerald-700">
            وضع مرن — يمكن تسجيل الحضور والغياب في أي وقت بدون تقييد بمواعيد الحصص
          </p>
        </div>
      )}

      {/* Permanent lock banner for closed sessions */}
      {closedWindowGroups.length > 0 && isToday && (
        <div className="rounded-2xl bg-rose-50 border-2 border-rose-300 px-4 py-3 flex items-center gap-2 animate-fade-in">
          <Lock size={18} className="text-rose-500 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-bold text-rose-700">
              تم إغلاق التعديل نهائياً بانتهاء الوقت 🔒
              {autoAbsenceCount > 0 && ` — تم تسجيل غياب ${autoAbsenceCount} طالب تلقائياً`}
            </p>
            <p className="text-xs text-rose-500 mt-0.5">
              المجموعات المغلقة: {closedWindowGroups.map((g) => g.name).join('، ')}
            </p>
          </div>
        </div>
      )}

      {/* Teacher read-only banner */}
      {isTeacher && (
        <div className="flex items-center gap-2 rounded-2xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-sm font-semibold text-amber-700">
          <Lock size={16} />
          وضع العرض فقط — يمكنك الاطلاع على سجلات الحضور دون تعديلها
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="p-3 sm:p-4 text-center">
          <p className="text-xl sm:text-2xl font-extrabold text-brand-900">{filteredStudents.length}</p>
          <p className="text-xs text-brand-400 font-semibold">الإجمالي</p>
        </Card>
        <Card className="p-3 sm:p-4 text-center">
          <p className="text-xl sm:text-2xl font-extrabold text-emerald-600">{presentCount}</p>
          <p className="text-xs text-emerald-500 font-semibold flex items-center justify-center gap-1"><UserCheck size={12} /> حاضر</p>
        </Card>
        <Card className="p-3 sm:p-4 text-center">
          <p className="text-xl sm:text-2xl font-extrabold text-rose-500">{absentCount}</p>
          <p className="text-xs text-rose-500 font-semibold flex items-center justify-center gap-1"><UserX size={12} /> غائب</p>
        </Card>
      </div>

      {/* Primary QR Scanner Section */}
      {!isTeacher && qrEnabled && (
        <Card className="p-4 sm:p-5 border-2 border-brand-200 overflow-hidden">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <div className="grid place-items-center h-10 w-10 rounded-2xl gradient-brand text-white shrink-0">
              <ScanLine size={20} />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-brand-900">نظام المسح الأساسي</h3>
              <p className="text-xs text-brand-400">امسح كود QR الخاص بالطالب لتسجيل الحضور فوراً</p>
            </div>
            {scannerLocked ? (
              <Badge tone={windowState === 'before' ? 'amber' : 'rose'} className="text-[10px]">
                {windowState === 'before' ? 'مغلق مؤقتاً' : 'انتهى الوقت'}
              </Badge>
            ) : (
              <Badge tone="brand" className="text-[10px]">جاهز للمسح</Badge>
            )}
          </div>

          {scannerLocked && windowLabel ? (
            <div className={`rounded-2xl border-2 px-4 py-4 text-center animate-fade-in ${
              windowState === 'before' ? 'bg-amber-50 border-amber-300' : 'bg-rose-50 border-rose-300'
            }`}>
              <p className={`text-sm font-bold ${windowState === 'before' ? 'text-amber-700' : 'text-rose-700'}`}>
                {windowLabel}
              </p>
            </div>
          ) : (
            <>
              {/* Camera toggle buttons */}
              <div className="flex flex-col sm:flex-row gap-2 mb-3">
                <button
                  onClick={() => { showCamera ? setShowCamera(false) : setShowCamera(true); }}
                  className={`flex items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-sm font-bold transition-all sm:flex-1 ${
                    showCamera ? 'bg-brand-500 text-white shadow-soft' : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
                  }`}
                >
                  {showCamera ? <CameraOff size={16} /> : <Camera size={16} />}
                  {showCamera ? 'إيقاف الكاميرا' : 'تفعيل الكاميرا'}
                </button>
                <button
                  onClick={() => { setShowCamera(false); scannerRef.current?.focus(); }}
                  className={`flex items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-sm font-bold transition-all sm:flex-1 ${
                    !showCamera ? 'bg-brand-500 text-white shadow-soft' : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
                  }`}
                >
                  <Zap size={16} /> مسح بقارئ الباركود
                </button>
                {cameras.length > 1 && showCamera && (
                  <button
                    onClick={() => {
                      const idx = cameras.findIndex((c) => c.deviceId === selectedCameraId);
                      const next = cameras[(idx + 1) % cameras.length];
                      stopCamera();
                      setSelectedCameraId(next.deviceId);
                      setTimeout(() => startCamera(), 200);
                    }}
                    className="flex items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-sm font-bold bg-brand-50 text-brand-600 hover:bg-brand-100 transition-all sm:flex-1"
                  >
                    <SwitchCamera size={16} /> تبديل الكاميرا
                  </button>
                )}
              </div>

              {/* Live Camera View */}
              {showCamera && (
                <div className="relative rounded-2xl overflow-hidden bg-slate-900 mb-3 animate-fade-in">
                  <video
                    ref={videoRef}
                    playsInline
                    muted
                    autoPlay
                    className="w-full max-h-[300px] aspect-square sm:aspect-auto sm:h-72 min-h-[200px] object-cover"
                  />
                  <canvas ref={canvasRef} className="hidden" />
                  {/* Scanning frame overlay */}
                  <div className="absolute inset-0 grid place-items-center pointer-events-none">
                    <div className="relative w-56 h-56 sm:w-60 sm:h-60">
                      <div className="absolute top-0 left-0 h-8 w-8 border-t-4 border-l-4 border-emerald-400 rounded-tl-xl" />
                      <div className="absolute top-0 right-0 h-8 w-8 border-t-4 border-r-4 border-emerald-400 rounded-tr-xl" />
                      <div className="absolute bottom-0 left-0 h-8 w-8 border-b-4 border-l-4 border-emerald-400 rounded-bl-xl" />
                      <div className="absolute bottom-0 right-0 h-8 w-8 border-b-4 border-r-4 border-emerald-400 rounded-br-xl" />
                      <div className="absolute inset-0 border-2 border-emerald-400/30 rounded-2xl" />
                    </div>
                  </div>
                  {/* Scanning line animation */}
                  {cameraActive && (
                    <div className="absolute inset-0 grid place-items-center pointer-events-none">
                      <div className="w-56 h-56 sm:w-60 sm:h-60 relative overflow-hidden rounded-2xl">
                        <div className="absolute left-0 right-0 h-1 bg-emerald-400/80 shadow-lg animate-scan-line" />
                      </div>
                    </div>
                  )}
                  {/* Camera status badge */}
                  <div className="absolute top-3 right-3">
                    {cameraActive ? (
                      <Badge tone="emerald" className="text-[10px] shadow-lg">
                        <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse mr-1" />
                        كاميرا نشطة
                      </Badge>
                    ) : cameraError ? (
                      <Badge tone="rose" className="text-[10px] shadow-lg">خطأ في الكاميرا</Badge>
                    ) : (
                      <Badge tone="slate" className="text-[10px] shadow-lg">جاري التحميل...</Badge>
                    )}
                  </div>
                </div>
              )}

              {/* Camera error */}
              {showCamera && cameraError && (
                <div className="rounded-2xl bg-rose-50 border border-rose-200 px-4 py-3 mb-3 text-sm font-semibold text-rose-700 flex items-start gap-2 animate-fade-in">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p>{cameraError}</p>
                    <p className="text-xs text-rose-500 mt-1">إذا استمرت المشكلة، تحقق من إعدادات المتصفح: الإعدادات ← الخصوصية والأمان ← الكاميرا ← السماح لهذا الموقع</p>
                  </div>
                  <button onClick={() => startCamera()} className="shrink-0 text-xs text-rose-600 underline font-bold">إعادة المحاولة</button>
                </div>
              )}

              {/* Hardware scanner input (hidden when camera is active) */}
              {!showCamera && (
                <>
                  <p className="text-xs text-brand-400 mb-3">امسح كارت الطالب بالقارئ — يتم تسجيل الحضور تلقائياً مع صوت تنبيه. يعمل القارئ حتى لو لم يكن المؤشر داخل المربع.</p>
                  <form onSubmit={handleScannerSubmit}>
                    <div className="relative">
                      <ScanLine size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-400" />
                      <input
                        ref={scannerRef}
                        type="text"
                        value={scannerInput}
                        onChange={(e) => setScannerInput(e.target.value)}
                        placeholder="امسح أو اكتب كود الطالب (STD-10001)..."
                        className="w-full h-14 rounded-2xl border-2 border-brand-300 bg-white pr-12 pl-4 text-lg font-bold text-brand-900 focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-200 transition-all"
                        autoComplete="off"
                        spellCheck={false}
                      />
                    </div>
                  </form>
                </>
              )}

              {/* Scan result feedback */}
              {scanResult && (
                <div className={`mt-3 rounded-2xl border-2 px-4 py-3 animate-scale-in ${statusColors[scanResult.status]}`}>
                  <div className="flex items-center gap-3">
                    <div className={`grid place-items-center h-12 w-12 rounded-2xl shrink-0 ${statusIconColors[scanResult.status]}`}>
                      {scanResult.status === 'success' ? <CheckCircle2 size={24} /> :
                       scanResult.status === 'duplicate' ? <AlertTriangle size={24} /> :
                       scanResult.status === 'unpaid' ? <Wallet size={24} /> :
                       scanResult.status === 'wrong_group' ? <AlertCircle size={24} /> :
                       <XIcon size={24} />}
                    </div>
                    <div className="min-w-0 flex-1">
                      {scanResult.student ? (
                        <>
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-bold text-brand-900 truncate">{scanResult.student.name}</p>
                            <Badge tone="brand" className="text-[10px]">#{scanResult.student.id}</Badge>
                            <span className="text-xs text-brand-400">{scanResult.student.grade}</span>
                          </div>
                          <p className={`text-sm font-semibold ${statusTextColors[scanResult.status]}`}>
                            {scanResult.message}
                            {scanResult.groupName && ` — ${scanResult.groupName}`}
                          </p>
                          {/* Student profile overlay details */}
                          <div className="flex items-center gap-3 mt-1.5 flex-wrap text-xs text-brand-500">
                            {scanResult.studentGroups && (
                              <span className="flex items-center gap-1"><Users size={11} /> {scanResult.studentGroups}</span>
                            )}
                            {scanResult.lessonCount !== undefined && (
                              <span className="flex items-center gap-1"><BookOpen size={11} /> {scanResult.lessonCount} حصة هذا الشهر</span>
                            )}
                            {scanResult.unpaidAmount !== undefined && (
                              <span className="flex items-center gap-1 text-rose-600 font-bold"><AlertCircle size={11} /> متأخر {formatEGP(scanResult.unpaidAmount)}</span>
                            )}
                          </div>
                          <p className="text-xs text-brand-400 mt-0.5">{scanResult.time}</p>
                        </>
                      ) : (
                        <>
                          <p className="font-bold text-rose-900">{scanResult.message}</p>
                          <p className="text-xs text-rose-400 mt-0.5">{scanResult.time}</p>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Recent scan log */}
              {scanLog.length > 1 && (
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-brand-500">آخر العمليات ({scanLog.length})</span>
                    <button onClick={() => setScanLog([])} className="text-xs text-brand-400 hover:text-brand-600">مسح السجل</button>
                  </div>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto">
                    {scanLog.slice(1).map((entry, i) => (
                      <div key={i} className={`flex items-center justify-between rounded-xl px-3 py-2 text-sm ${
                        entry.status === 'success' ? 'bg-emerald-50 border border-emerald-100' :
                        entry.status === 'duplicate' || entry.status === 'unpaid' ? 'bg-amber-50 border border-amber-100' :
                        'bg-rose-50 border border-rose-100'
                      }`}>
                        <div className="flex items-center gap-2 min-w-0">
                          {entry.status === 'success' ? <CheckCircle2 size={14} className="text-emerald-500 shrink-0" /> :
                           entry.status === 'duplicate' || entry.status === 'unpaid' ? <AlertTriangle size={14} className="text-amber-500 shrink-0" /> :
                           <XIcon size={14} className="text-rose-500 shrink-0" />}
                          <span className="font-semibold text-brand-900 truncate">{entry.student?.name || entry.message}</span>
                        </div>
                        <span className="text-xs text-brand-400 shrink-0">{entry.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </Card>
      )}

      {/* Manual attendance fallback (when QR is OFF) */}
      {!isTeacher && !qrEnabled && (
        <Card className="p-4 sm:p-5 border-2 border-amber-200">
          <div className="flex items-center gap-2 mb-3">
            <AlertCircle size={20} className="text-amber-500" />
            <h3 className="font-bold text-brand-900 text-sm">الحضور اليدوي (نظام QR معطل)</h3>
          </div>
          <p className="text-xs text-brand-400 mb-3">يمكنك تفعيل نظام QR Code من الإعدادات لتسجيل الحضور بالمسح السريع</p>
          <StudentSearch
            students={students}
            groups={db.groups}
            onSelect={(s: Student) => {
              const sGids = studentGroupIds(s);
              if (sGids.length > 0) {
                const targetGid = sGids.find((id) => groupIds.has(id)) || sGids[0];
                if (isSessionLocked(targetGid)) { showToast(LOCK_TOAST, 'error'); return; }
                toggleAttendance(s.id, targetGid, 'present');
                showToast(`تم تسجيل حضور: ${s.name}`, 'success');
              } else {
                showToast('الطالب غير مسجل في مجموعة', 'error');
              }
            }}
            placeholder="اكتب اسم الطالب أو كوده لتسجيل الحضور فوراً..."
          />
        </Card>
      )}

      {/* Quick attendance search (supplementary, always available) */}
      {!isTeacher && qrEnabled && (
        <Card className="p-4 sm:p-5">
          <div className="flex items-center gap-2 mb-3">
            <Zap size={18} className="text-amber-500" />
            <h3 className="font-bold text-brand-900 text-sm">حضور سريع بالبحث</h3>
          </div>
          <StudentSearch
            students={students}
            groups={db.groups}
            onSelect={(s: Student) => {
              const sGids = studentGroupIds(s);
              if (sGids.length > 0) {
                const targetGid = sGids.find((id) => groupIds.has(id)) || sGids[0];
                if (isSessionLocked(targetGid)) { showToast(LOCK_TOAST, 'error'); return; }
                toggleAttendance(s.id, targetGid, 'present');
                showToast(`تم تسجيل حضور: ${s.name}`, 'success');
              }
            }}
            placeholder="اكتب اسم الطالب أو كوده لتسجيل الحضور فوراً..."
          />
        </Card>
      )}

      {/* Filters */}
      <Card className="p-4" glass={false}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input icon={<Calendar size={18} />} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          <Input icon={<Search size={18} />} placeholder="بحث بالاسم أو الكود..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <div className="mt-3">
          <MultiGroupSelect
            groups={availableGroups}
            selectedIds={selectedGroupIds}
            onChange={setSelectedGroupIds}
            placeholder="كل المجموعات"
            label="تصفية حسب المجموعة"
          />
        </div>
      </Card>

      {/* Students list */}
      {filteredStudents.length === 0 ? (
        <EmptyState icon={<CalendarCheck size={36} />} title="لا يوجد طلاب" description="لا توجد طلاب في المجموعات المحددة" />
      ) : (
        <div className="space-y-2.5">
          {filteredStudents.map((s) => {
            const status = attendanceMap.get(s.id);
            const sGroups = studentGroupIds(s).map((id) => db.groups.find((g) => g.id === id)).filter(Boolean);
            return (
              <Card key={s.id} className="p-3 sm:p-4" hover>
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="grid place-items-center h-11 w-11 rounded-2xl gradient-brand text-white font-bold shrink-0">
                      {s.name.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-bold text-brand-900 truncate">{s.name}</h3>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge tone="brand" className="text-[10px]">#{s.id}</Badge>
                        {sGroups.map((g) => (
                          <span key={g!.id} className="text-xs text-brand-400 truncate">{g!.name}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {status ? (
                      <Badge tone={status === 'present' ? 'emerald' : 'rose'} className="px-3 py-1.5 text-sm">
                        {status === 'present' ? 'حاضر' : 'غائب'}
                      </Badge>
                    ) : (
                      <Badge tone="slate" className="px-3 py-1.5 text-sm">لم يُسجل</Badge>
                    )}
                    {(() => {
                      const sGids = studentGroupIds(s);
                      const targetGid = sGids.find((id) => groupIds.has(id)) || sGids[0];
                      const studentLocked = isSessionLocked(targetGid);
                      return (
                        <>
                          {studentLocked && (
                            <span className="flex items-center gap-1 text-xs font-bold text-rose-500 bg-rose-50 px-2 py-1 rounded-lg">
                              <Lock size={12} /> مغلق
                            </span>
                          )}
                          {!isTeacher && !studentLocked && (
                            <>
                              <button
                                onClick={() => { if (targetGid) toggleAttendance(s.id, targetGid, 'present'); }}
                                className={`grid place-items-center h-10 w-10 rounded-xl transition-all ${
                                  status === 'present' ? 'bg-emerald-500 text-white shadow-soft' : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'
                                }`}
                              >
                                <Check size={20} />
                              </button>
                              <button
                                onClick={() => { if (targetGid) toggleAttendance(s.id, targetGid, 'absent'); }}
                                className={`grid place-items-center h-10 w-10 rounded-xl transition-all ${
                                  status === 'absent' ? 'bg-rose-500 text-white shadow-soft' : 'bg-rose-50 text-rose-600 hover:bg-rose-100'
                                }`}
                              >
                                <XIcon size={20} />
                              </button>
                            </>
                          )}
                        </>
                      );
                    })()}
                    {status === 'absent' && (
                      <WhatsAppButton
                        student={s}
                        template="absence"
                        centerName={db.centerName}
                        groupName={sGroups[0]?.name}
                        date={formatDate(date)}
                        size="md"
                      />
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
