import { useState, useMemo } from 'react';
import { Banknote, Plus, Trash2, X, Lock, TrendingUp, TrendingDown, Wallet, Award, ArrowDownCircle, ArrowUpCircle, Calculator } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { uid, formatEGP, currentMonthStr, formatDate, monthName, todayStr } from '../lib/date';
import { logAction, secretarySalaryFor } from '../lib/finance';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select, Textarea } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import type { StaffAdjustment, AdjustmentType, User } from '../lib/types';

const typeMeta: Record<AdjustmentType, { label: string; icon: typeof Award; tone: 'amber' | 'emerald' | 'rose'; sign: 1 | -1 }> = {
  advance: { label: 'سلفة', icon: ArrowDownCircle, tone: 'amber', sign: -1 },
  reward: { label: 'مكافأة', icon: Award, tone: 'emerald', sign: 1 },
  deduction: { label: 'خصم', icon: ArrowUpCircle, tone: 'rose', sign: -1 },
};

export function StaffAdjustments() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { showToast } = useToast();

  const [showForm, setShowForm] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [monthFilter, setMonthFilter] = useState(currentMonthStr());
  const [payoutMonth, setPayoutMonth] = useState(currentMonthStr());

  if (user?.role !== 'admin') {
    return (
      <div className="grid place-items-center py-20">
        <div className="text-center">
          <div className="grid place-items-center h-20 w-20 rounded-3xl bg-rose-50 text-rose-400 mx-auto mb-4">
            <Lock size={36} />
          </div>
          <h3 className="text-lg font-bold text-brand-900 mb-1">صلاحية محظورة</h3>
          <p className="text-sm text-brand-400">هذه الصفحة متاحة للمدير فقط.</p>
        </div>
      </div>
    );
  }

  const staffUsers = db.users.filter((u) => u.role === 'secretary' || u.role === 'admin' || u.role === 'teacher');
  const adjustments = db.staffAdjustments || [];

  const filtered = useMemo(() => {
    return [...adjustments]
      .filter((a) => !monthFilter || a.month === monthFilter)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [adjustments, monthFilter]);

  const payouts = useMemo(() => {
    return staffUsers.map((u) => {
      const baseSalary = secretarySalaryFor(db, u.id);
      const userAdjs = adjustments.filter((a) => a.userId === u.id && a.month === payoutMonth);
      const rewards = userAdjs.filter((a) => a.type === 'reward').reduce((s, a) => s + a.amount, 0);
      const advances = userAdjs.filter((a) => a.type === 'advance').reduce((s, a) => s + a.amount, 0);
      const deductions = userAdjs.filter((a) => a.type === 'deduction').reduce((s, a) => s + a.amount, 0);
      const finalPayout = baseSalary + rewards - (advances + deductions);
      return { user: u, baseSalary, rewards, advances, deductions, finalPayout };
    });
  }, [staffUsers, adjustments, payoutMonth]);

  const totalPayout = payouts.reduce((s, p) => s + p.finalPayout, 0);

  const handleSave = (data: Omit<StaffAdjustment, 'id' | 'createdAt'>) => {
    update((d) => {
      d.staffAdjustments = d.staffAdjustments || [];
      d.staffAdjustments.push({ ...data, id: uid('adj'), createdAt: new Date().toISOString() });
      logAction(d, 'تسجيل تعديل مالي', `قام ${user?.name || ''} بتسجيل ${typeMeta[data.type].label} بقيمة ${formatEGP(data.amount)} لـ ${data.userName}.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم تسجيل التعديل المالي بنجاح');
    setShowForm(false);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    update((d) => {
      d.staffAdjustments = (d.staffAdjustments || []).filter((a) => a.id !== deleteId);
      logAction(d, 'حذف تعديل مالي', `قام ${user?.name || ''} بحذف تعديل مالي.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف التعديل', 'info');
    setDeleteId(null);
  };

  const handleFinalizePayout = () => {
    update((d) => {
      d.salaries = d.salaries || [];
      d.expenses = d.expenses || [];
      const existingForMonth = new Set(
        d.salaries.filter((s) => s.month === payoutMonth).map((s) => s.userId)
      );
      payouts.forEach((p) => {
        if (p.finalPayout === 0) return;
        if (existingForMonth.has(p.user.id)) return;
        d.salaries.push({
          id: uid('sal'),
          userId: p.user.id,
          userName: p.user.name,
          basic: p.baseSalary,
          bonus: p.rewards,
          deductions: p.deductions,
          advances: p.advances,
          net: p.finalPayout,
          month: payoutMonth,
          date: new Date().toISOString().slice(0, 10),
          note: 'تسوية من نظام السلف والمكافآت',
          createdAt: new Date().toISOString(),
        });
        d.expenses.push({
          id: uid('exp'),
          category: 'other',
          categoryLabel: 'أجور موظفين',
          branchId: null,
          amount: p.finalPayout,
          date: todayStr(),
          note: `تسوية راتب ${p.user.name} — ${monthName(payoutMonth)}`,
          createdAt: new Date().toISOString(),
        });
      });
      logAction(d, 'تسوية رواتب', `قام ${user?.name || ''} بتسوية رواتب شهر ${monthName(payoutMonth)} — إجمالي ${formatEGP(totalPayout)}.`, user?.name || '', user?.role || 'admin');
    });
    showToast(`تم تسوية رواتب ${monthName(payoutMonth)} — إجمالي ${formatEGP(totalPayout)}`);
  };

  const availableMonths = useMemo(() => {
    const set = new Set(adjustments.map((a) => a.month));
    set.add(currentMonthStr());
    return Array.from(set).sort().reverse();
  }, [adjustments]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid place-items-center h-12 w-12 rounded-2xl bg-brand-600 text-white shadow-soft">
            <Banknote size={24} />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900">السلف والمكافآت والخصومات</h2>
            <p className="text-sm text-brand-400 mt-0.5">إدارة التعديلات المالية للموظفين</p>
          </div>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus size={18} /> تعديل جديد
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-5 relative overflow-hidden" hover>
          <div className="absolute -top-6 -left-6 h-24 w-24 rounded-full bg-amber-100/50 blur-2xl" />
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <div className="grid place-items-center h-11 w-11 rounded-2xl bg-amber-100 text-amber-600"><ArrowDownCircle size={22} /></div>
              <TrendingUp size={18} className="text-amber-500" />
            </div>
            <p className="text-xs font-bold text-brand-400 mb-1">إجمالي السلف</p>
            <p className="text-2xl font-extrabold text-brand-900">{formatEGP(adjustments.filter((a) => a.type === 'advance').reduce((s, a) => s + a.amount, 0))}</p>
          </div>
        </Card>
        <Card className="p-5 relative overflow-hidden" hover>
          <div className="absolute -top-6 -left-6 h-24 w-24 rounded-full bg-emerald-100/50 blur-2xl" />
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <div className="grid place-items-center h-11 w-11 rounded-2xl bg-emerald-100 text-emerald-600"><Award size={22} /></div>
              <TrendingUp size={18} className="text-emerald-500" />
            </div>
            <p className="text-xs font-bold text-brand-400 mb-1">إجمالي المكافآت</p>
            <p className="text-2xl font-extrabold text-brand-900">{formatEGP(adjustments.filter((a) => a.type === 'reward').reduce((s, a) => s + a.amount, 0))}</p>
          </div>
        </Card>
        <Card className="p-5 relative overflow-hidden" hover>
          <div className="absolute -top-6 -left-6 h-24 w-24 rounded-full bg-rose-100/50 blur-2xl" />
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <div className="grid place-items-center h-11 w-11 rounded-2xl bg-rose-100 text-rose-600"><ArrowUpCircle size={22} /></div>
              <TrendingDown size={18} className="text-rose-500" />
            </div>
            <p className="text-xs font-bold text-brand-400 mb-1">إجمالي الخصومات</p>
            <p className="text-2xl font-extrabold text-brand-900">{formatEGP(adjustments.filter((a) => a.type === 'deduction').reduce((s, a) => s + a.amount, 0))}</p>
          </div>
        </Card>
      </div>

      <Card className="p-5 border-2 border-brand-200">
        <div className="flex items-center justify-between gap-3 flex-wrap mb-4">
          <div className="flex items-center gap-2">
            <Calculator size={20} className="text-brand-600" />
            <h3 className="text-sm font-bold text-brand-900">حاسبة المستحقات النهائية — {monthName(payoutMonth)}</h3>
          </div>
          <div className="flex items-center gap-2">
            <Input type="month" value={payoutMonth} onChange={(e) => setPayoutMonth(e.target.value)} className="w-auto" />
            <Button size="sm" onClick={handleFinalizePayout} disabled={totalPayout === 0}>
              <Wallet size={16} /> تسوية الرواتب
            </Button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-brand-50 text-brand-700 text-right">
                <th className="px-3 py-2.5 font-bold">الموظف</th>
                <th className="px-3 py-2.5 font-bold">الراتب الأساسي</th>
                <th className="px-3 py-2.5 font-bold">مكافآت</th>
                <th className="px-3 py-2.5 font-bold">سلف</th>
                <th className="px-3 py-2.5 font-bold">خصومات</th>
                <th className="px-3 py-2.5 font-bold">صافي المستحق</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {payouts.map((p) => (
                <tr key={p.user.id} className="hover:bg-brand-50/40 transition-colors">
                  <td className="px-3 py-2.5 font-bold text-brand-900">{p.user.name}</td>
                  <td className="px-3 py-2.5 text-brand-600">{formatEGP(p.baseSalary)}</td>
                  <td className="px-3 py-2.5 text-emerald-600">+{formatEGP(p.rewards)}</td>
                  <td className="px-3 py-2.5 text-amber-600">-{formatEGP(p.advances)}</td>
                  <td className="px-3 py-2.5 text-rose-600">-{formatEGP(p.deductions)}</td>
                  <td className="px-3 py-2.5">
                    <Badge tone={p.finalPayout >= 0 ? 'emerald' : 'rose'}>{formatEGP(p.finalPayout)}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-brand-50/60 font-extrabold text-brand-900">
                <td className="px-3 py-3" colSpan={5}>إجمالي المستحقات (يخصم من الأرباح السرية)</td>
                <td className="px-3 py-3 text-lg">{formatEGP(totalPayout)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>

      <Card className="p-5" glass={false}>
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="text-sm font-bold text-brand-900">سجل التعديلات</h3>
          <Select value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)} className="w-auto">
            <option value="">كل الشهور</option>
            {availableMonths.map((m) => <option key={m} value={m}>{monthName(m)}</option>)}
          </Select>
        </div>
        {filtered.length === 0 ? (
          <EmptyState icon={<Banknote size={36} />} title="لا توجد تعديلات" description="ابدأ بتسجيل سلفة أو مكافأة أو خصم" />
        ) : (
          <div className="space-y-2">
            {filtered.map((a) => {
              const meta = typeMeta[a.type];
              const Icon = meta.icon;
              return (
                <div key={a.id} className="flex items-center gap-3 py-2.5 border-b border-slate-50 last:border-0">
                  <div className={`grid place-items-center h-10 w-10 rounded-2xl shrink-0 ${meta.tone === 'amber' ? 'bg-amber-100 text-amber-600' : meta.tone === 'emerald' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                    <Icon size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-brand-900">{a.userName}</span>
                      <Badge tone={meta.tone}>{meta.label}</Badge>
                      <span className="text-sm font-extrabold text-brand-900">{formatEGP(a.amount)}</span>
                    </div>
                    <p className="text-xs text-brand-400 mt-0.5">{formatDate(a.date)} — {a.reason || 'بدون سبب'}</p>
                  </div>
                  <button onClick={() => setDeleteId(a.id)} className="grid place-items-center h-8 w-8 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 shrink-0" title="حذف">
                    <Trash2 size={15} />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {showForm && (
        <AdjustmentForm staffUsers={staffUsers} onClose={() => setShowForm(false)} onSave={handleSave} />
      )}
      <ConfirmDialog
        open={deleteId !== null}
        title="حذف التعديل"
        message="سيتم حذف هذا التعديل المالي. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function AdjustmentForm({ staffUsers, onClose, onSave }: {
  staffUsers: User[];
  onClose: () => void;
  onSave: (data: Omit<StaffAdjustment, 'id' | 'createdAt'>) => void;
}) {
  const [userId, setUserId] = useState('');
  const [type, setType] = useState<AdjustmentType>('advance');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [reason, setReason] = useState('');
  const [month, setMonth] = useState(currentMonthStr());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const u = staffUsers.find((s) => s.id === userId);
    if (!u || !amount) return;
    onSave({
      userId: u.id,
      userName: u.name,
      type,
      amount: Number(amount),
      date,
      reason: reason.trim(),
      month,
    });
  };

  return (
    <Modal open onClose={onClose} title="تسجيل تعديل مالي جديد" size="md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Select label="الموظف" value={userId} onChange={(e) => setUserId(e.target.value)} required>
          <option value="">اختر الموظف...</option>
          {staffUsers.map((u) => <option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}
        </Select>
        <div>
          <span className="block mb-2 text-sm font-semibold text-brand-900">نوع التعديل</span>
          <div className="grid grid-cols-3 gap-2">
            {(Object.keys(typeMeta) as AdjustmentType[]).map((t) => {
              const meta = typeMeta[t];
              const Icon = meta.icon;
              const active = type === t;
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`flex flex-col items-center gap-1.5 rounded-2xl p-3 transition-all duration-200 border-2 ${
                    active
                      ? `bg-brand-50 border-brand-300 text-brand-700 shadow-soft`
                      : 'bg-white border-transparent text-brand-500 hover:bg-brand-50/50'
                  }`}
                >
                  <Icon size={20} />
                  <span className="text-xs font-bold">{meta.label}</span>
                </button>
              );
            })}
          </div>
        </div>
        <Input label="المبلغ (ج.م)" type="number" value={amount} onChange={(e) => setAmount(e.target.value)} required />
        <div className="grid grid-cols-2 gap-3">
          <Input label="التاريخ" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          <Input label="الشهر" type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
        </div>
        <Textarea label="السبب" placeholder="مثال: سلفة على الراتب..." value={reason} onChange={(e) => setReason(e.target.value)} rows={2} />
        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إلغاء</Button>
          <Button type="submit" className="flex-1">تسجيل</Button>
        </div>
      </form>
    </Modal>
  );
}
