import { useState, useMemo } from 'react';
import {
  Receipt, Plus, Trash2, Edit3, X, Home, Zap, Printer, Sparkles, Coffee, Wrench,
  Calendar, TrendingDown, Wallet, Lock,
} from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { useCenter } from '../context/CenterContext';
import { useToast } from '../context/ToastContext';
import { todayStr, formatEGP, formatDate, uid } from '../lib/date';
import { logAction } from '../lib/finance';
import { filterByCenter } from '../lib/scoping';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select, Textarea } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import type { Expense, ExpenseCategory } from '../lib/types';

const CATEGORY_CONFIG: { value: ExpenseCategory; label: string; icon: typeof Home; color: string; bg: string }[] = [
  { value: 'rent', label: 'إيجار', icon: Home, color: 'text-brand-600', bg: 'bg-brand-100' },
  { value: 'electricity', label: 'كهرباء', icon: Zap, color: 'text-amber-600', bg: 'bg-amber-100' },
  { value: 'printing', label: 'طباعة', icon: Printer, color: 'text-violet-600', bg: 'bg-violet-100' },
  { value: 'cleaning', label: 'نظافة', icon: Sparkles, color: 'text-emerald-600', bg: 'bg-emerald-100' },
  { value: 'hospitality', label: 'ضيافة', icon: Coffee, color: 'text-orange-600', bg: 'bg-orange-100' },
  { value: 'maintenance', label: 'صيانة', icon: Wrench, color: 'text-rose-600', bg: 'bg-rose-100' },
];

function getCategoryConfig(cat: ExpenseCategory) {
  return CATEGORY_CONFIG.find((c) => c.value === cat) || CATEGORY_CONFIG[0];
}

export function Expenses() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { selectedCenterId } = useCenter();
  const { showToast } = useToast();

  if (user?.role !== 'admin') {
    return (
      <div className="grid place-items-center py-20">
        <div className="text-center">
          <div className="grid place-items-center h-20 w-20 rounded-3xl bg-rose-50 text-rose-400 mx-auto mb-4">
            <Lock size={36} />
          </div>
          <h3 className="text-lg font-bold text-brand-900 mb-1">صلاحية محظورة</h3>
          <p className="text-sm text-brand-400">هذه الصفحة متاحة للمدير فقط.</p>
        </div>
      </div>
    );
  }

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Expense | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [filterCat, setFilterCat] = useState('');

  const centerExpenses = filterByCenter(db.expenses, selectedCenterId);

  const expenses = useMemo(() => {
    return [...centerExpenses].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [centerExpenses]);

  const filtered = filterCat ? expenses.filter((e) => e.category === filterCat) : expenses;

  const totalAmount = centerExpenses.reduce((sum, e) => sum + e.amount, 0);
  const monthTotal = centerExpenses
    .filter((e) => e.date.startsWith(todayStr().slice(0, 7)))
    .reduce((sum, e) => sum + e.amount, 0);

  // Category totals for breakdown
  const categoryTotals = useMemo(() => {
    const map: Record<string, number> = {};
    for (const e of centerExpenses) {
      map[e.category] = (map[e.category] || 0) + e.amount;
    }
    return map;
  }, [centerExpenses]);

  const handleSave = (data: Omit<Expense, 'id' | 'createdAt'> & { id?: string }) => {
    update((d) => {
      const branchId = selectedCenterId || data.branchId || null;
      if (editing) {
        const idx = d.expenses.findIndex((e) => e.id === editing.id);
        if (idx >= 0) d.expenses[idx] = { ...d.expenses[idx], ...data, branchId };
        logAction(d, 'تعديل مصروف', `قام ${user?.name || ''} بتعديل مصروف فئة ${data.categoryLabel} إلى ${formatEGP(data.amount)}.`, user?.name || '', user?.role || 'admin');
      } else {
        d.expenses.push({ ...data, branchId, id: uid('exp'), createdAt: new Date().toISOString() } as Expense);
        logAction(d, 'تسجيل مصروف', `قام ${user?.name || ''} بتسجيل مصروف جديد فئة ${data.categoryLabel} بقيمة ${formatEGP(data.amount)}.`, user?.name || '', user?.role || 'admin');
      }
    });
    showToast(editing ? 'تم تحديث المصروف' : 'تم تسجيل المصروف');
    setShowForm(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const exp = db.expenses.find((e) => e.id === deleteId);
    if (!exp) return;
    update((d) => {
      d.expenses = d.expenses.filter((e) => e.id !== deleteId);
      logAction(d, 'حذف مصروف', `قام ${user?.name || ''} بحذف مصروف فئة ${exp.categoryLabel} بقيمة ${formatEGP(exp.amount)}.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف المصروف', 'info');
    setDeleteId(null);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 flex items-center gap-2">
            <Receipt size={24} /> المصروفات
          </h2>
          <p className="text-sm text-brand-400 mt-0.5">{filtered.length} عملية • إجمالي {formatEGP(totalAmount)}</p>
        </div>
        <Button onClick={() => { setEditing(null); setShowForm(true); }}>
          <Plus size={18} /> مصروف جديد
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        <Card hover className="p-4 sm:p-5 relative overflow-hidden">
          <div className="absolute -top-6 -left-6 h-20 w-20 rounded-full bg-rose-100/50 blur-2xl" />
          <div className="relative">
            <div className="grid place-items-center h-11 w-11 rounded-2xl bg-rose-100 text-rose-600 mb-3">
              <Receipt size={22} />
            </div>
            <p className="text-2xl font-extrabold text-brand-900">{formatEGP(totalAmount)}</p>
            <p className="text-xs text-brand-400 font-semibold mt-0.5">إجمالي المصروفات</p>
          </div>
        </Card>
        <Card hover className="p-4 sm:p-5 relative overflow-hidden">
          <div className="absolute -top-6 -left-6 h-20 w-20 rounded-full bg-amber-100/50 blur-2xl" />
          <div className="relative">
            <div className="grid place-items-center h-11 w-11 rounded-2xl bg-amber-100 text-amber-600 mb-3">
              <Calendar size={22} />
            </div>
            <p className="text-2xl font-extrabold text-brand-900">{formatEGP(monthTotal)}</p>
            <p className="text-xs text-brand-400 font-semibold mt-0.5">مصروفات هذا الشهر</p>
          </div>
        </Card>
        <Card hover className="p-4 sm:p-5 relative overflow-hidden col-span-2 lg:col-span-1">
          <div className="absolute -top-6 -left-6 h-20 w-20 rounded-full bg-brand-100/50 blur-2xl" />
          <div className="relative">
            <div className="grid place-items-center h-11 w-11 rounded-2xl bg-brand-100 text-brand-600 mb-3">
              <TrendingDown size={22} />
            </div>
            <p className="text-2xl font-extrabold text-brand-900">{centerExpenses.length}</p>
            <p className="text-xs text-brand-400 font-semibold mt-0.5">عدد العمليات</p>
          </div>
        </Card>
      </div>

      {/* Category breakdown */}
      {centerExpenses.length > 0 && (
        <Card className="p-5">
          <h3 className="text-sm font-bold text-brand-900 mb-3">توزيع المصروفات حسب الفئة</h3>
          <div className="space-y-2">
            {CATEGORY_CONFIG.map((cat) => {
              const amount = categoryTotals[cat.value] || 0;
              if (amount === 0) return null;
              const pct = totalAmount > 0 ? (amount / totalAmount) * 100 : 0;
              return (
                <div key={cat.value} className="flex items-center gap-3">
                  <div className={`grid place-items-center h-8 w-8 rounded-xl ${cat.bg} ${cat.color} shrink-0`}>
                    <cat.icon size={16} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-brand-700">{cat.label}</span>
                      <span className="text-xs font-bold text-brand-900">{formatEGP(amount)}</span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div className={`h-full rounded-full ${cat.bg.replace('100', '500')}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Filter */}
      <Card className="p-4" glass={false}>
        <Select value={filterCat} onChange={(e) => setFilterCat(e.target.value)}>
          <option value="">كل الفئات</option>
          {CATEGORY_CONFIG.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
        </Select>
      </Card>

      {/* Expenses list */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={<Receipt size={36} />}
          title="لا توجد مصروفات"
          description="ابدأ بتسجيل أول مصروف للسنتر"
          action={<Button onClick={() => { setEditing(null); setShowForm(true); }}><Plus size={18} /> تسجيل مصروف</Button>}
        />
      ) : (
        <div className="space-y-2.5">
          {filtered.map((exp) => {
            const cat = getCategoryConfig(exp.category);
            return (
              <Card key={exp.id} className="p-4" hover>
                <div className="flex items-start gap-3">
                  <div className={`grid place-items-center h-11 w-11 rounded-2xl ${cat.bg} ${cat.color} shrink-0`}>
                    <cat.icon size={20} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <Badge tone="rose">{formatEGP(exp.amount)}</Badge>
                      <span className="text-xs text-brand-400">{formatDate(exp.date)}</span>
                    </div>
                    <p className="text-sm font-bold text-brand-900">{exp.categoryLabel}</p>
                    {exp.note && <p className="text-xs text-brand-400 mt-1">{exp.note}</p>}
                  </div>
                  <div className="flex gap-1.5 shrink-0">
                    <button onClick={() => { setEditing(exp); setShowForm(true); }} className="grid place-items-center h-8 w-8 rounded-lg bg-amber-50 text-amber-600 hover:bg-amber-100 transition-colors" title="تعديل">
                      <Edit3 size={16} />
                    </button>
                    <button onClick={() => setDeleteId(exp.id)} className="grid place-items-center h-8 w-8 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors" title="حذف">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Expense form modal */}
      {showForm && (
        <ExpenseForm
          expense={editing}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSave={handleSave}
        />
      )}

      <ConfirmDialog
        open={deleteId !== null}
        title="حذف المصروف"
        message="سيتم حذف هذا المصروف نهائياً. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function ExpenseForm({ expense, onClose, onSave }: {
  expense: Expense | null;
  onClose: () => void;
  onSave: (data: Omit<Expense, 'id' | 'createdAt'> & { id?: string }) => void;
}) {
  const [category, setCategory] = useState<ExpenseCategory | 'other'>(expense?.category || 'rent');
  const [customCategory, setCustomCategory] = useState(expense?.category === 'other' ? expense?.categoryLabel : '');
  const [amount, setAmount] = useState(expense ? String(expense.amount) : '');
  const [date, setDate] = useState(expense?.date || todayStr());
  const [note, setNote] = useState(expense?.note || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount) return;
    const isCustom = category === 'other';
    const catConfig = getCategoryConfig(category as ExpenseCategory);
    const label = isCustom ? (customCategory.trim() || 'فئة أخرى') : catConfig.label;
    onSave({
      id: expense?.id,
      category: (isCustom ? 'other' : category) as ExpenseCategory,
      categoryLabel: label,
      branchId: expense?.branchId ?? null,
      amount: Number(amount),
      date,
      note: note.trim(),
    });
  };

  return (
    <Modal open onClose={onClose} title={expense ? 'تعديل المصروف' : 'تسجيل مصروف جديد'} size="lg">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Category grid */}
        <div>
          <span className="block mb-2 text-sm font-semibold text-brand-900">اختر الفئة</span>
          <div className="grid grid-cols-3 gap-2.5">
            {CATEGORY_CONFIG.map((cat) => {
              const active = category === cat.value;
              return (
                <button
                  key={cat.value}
                  type="button"
                  onClick={() => { setCategory(cat.value); setCustomCategory(''); }}
                  className={`flex flex-col items-center gap-1.5 rounded-2xl p-3 transition-all duration-200 border-2 ${
                    active
                      ? `${cat.bg} ${cat.color} border-current shadow-soft`
                      : 'bg-brand-50/50 text-brand-600 border-transparent hover:bg-brand-50'
                  }`}
                >
                  <cat.icon size={22} />
                  <span className="text-xs font-bold">{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Custom category */}
        <Input
          label="أو اكتب فئة أخرى"
          placeholder="مثال: إنترنت، مياه..."
          value={customCategory}
          onChange={(e) => { setCustomCategory(e.target.value); setCategory('other'); }}
        />

        {/* Amount + Date side by side */}
        <div className="grid grid-cols-2 gap-3">
          <Input
            label="المبلغ (ج.م)"
            type="number"
            placeholder="0"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            icon={<Wallet size={18} />}
            required
          />
          <Input
            label="التاريخ"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            icon={<Calendar size={18} />}
            required
          />
        </div>

        {/* Notes */}
        <Textarea
          label="ملاحظات (اختياري)"
          placeholder="تفاصيل إضافية عن المصروف..."
          value={note}
          onChange={(e) => setNote(e.target.value)}
          rows={3}
        />

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}>
            <X size={18} /> إلغاء
          </Button>
          <Button type="submit" className="flex-1">
            <Receipt size={18} /> {expense ? 'حفظ' : 'تسجيل'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
