import { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  Smartphone,
  Monitor,
  CheckCircle2,
  XCircle,
  Trash2,
  KeyRound,
  Settings2,
  Clock,
  Hash,
  Copy,
  Globe,
  Calendar,
  AlertTriangle,
  Hourglass,
  LogOut,
  Crown,
  Timer,
  Wand2,
} from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { useToast } from '../context/ToastContext';
import { useAuth } from '../context/AuthContext';
import {
  loadDevices,
  updateDeviceStatus,
  deleteDevice,
  generateActivationHash,
  loadTrialSettings,
  saveTrialSettings,
  registerThisDevice,
  extendDeviceTrial,
  setDeviceLicense,
  generateOfflineKey,
} from '../lib/master';
import type { MasterDevice, TrialSettings, DeviceStatus, LicenseType } from '../lib/types';
import type { OfflineLicenseKind } from '../lib/master';

function statusBadge(status: DeviceStatus) {
  if (status === 'approved') return <Badge tone="emerald"><CheckCircle2 size={12} /> مفعّل</Badge>;
  if (status === 'blocked') return <Badge tone="rose"><XCircle size={12} /> محظور</Badge>;
  return <Badge tone="amber"><Clock size={12} /> بانتظار الموافقة</Badge>;
}

function licenseBadge(licenseType: LicenseType) {
  if (licenseType === 'full') return <Badge tone="emerald"><Crown size={12} /> تفعيل كامل</Badge>;
  return <Badge tone="amber"><Timer size={12} /> مرحلة تجريبية</Badge>;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });
  } catch {
    return iso;
  }
}

export function MasterPanel() {
  const { showToast } = useToast();
  const { logout } = useAuth();
  const [devices, setDevices] = useState<MasterDevice[]>([]);
  const [trial, setTrial] = useState<TrialSettings>({ trialDays: 7, maxTrialActions: 100, trialEnabled: true, updatedAt: '' });
  const [deleteTarget, setDeleteTarget] = useState<MasterDevice | null>(null);
  const [hashTarget, setHashTarget] = useState<MasterDevice | null>(null);
  const [generatedHash, setGeneratedHash] = useState<string>('');
  const [filter, setFilter] = useState<'all' | DeviceStatus>('all');
  const [extendTarget, setExtendTarget] = useState<MasterDevice | null>(null);
  const [extendDays, setExtendDays] = useState(7);
  const [extendResetActions, setExtendResetActions] = useState(true);
  const [licenseTarget, setLicenseTarget] = useState<MasterDevice | null>(null);
  const [licenseMode, setLicenseMode] = useState<LicenseType>('full');
  const [trialPreset, setTrialPreset] = useState<number>(24);
  const [customHours, setCustomHours] = useState<number>(1);
  const [genDeviceId, setGenDeviceId] = useState('');
  const [genKind, setGenKind] = useState<OfflineLicenseKind>('FULL');
  const [genTrialDays, setGenTrialDays] = useState(3);
  const [generatedOfflineKey, setGeneratedOfflineKey] = useState('');

  const refresh = useCallback(() => {
    setDevices(loadDevices());
    setTrial(loadTrialSettings());
  }, []);

  useEffect(() => {
    registerThisDevice();
    refresh();
  }, [refresh]);

  const handleApprove = (id: string) => {
    const d = devices.find((dev) => dev.id === id);
    if (d) {
      setLicenseTarget(d);
      setLicenseMode('full');
      setTrialPreset(24);
      setCustomHours(1);
    }
  };

  const handleConfirmLicense = () => {
    if (!licenseTarget) return;
    const hours = licenseMode === 'trial' ? (trialPreset > 0 ? trialPreset : customHours) : 0;
    setDeviceLicense(licenseTarget.id, licenseMode, hours);
    refresh();
    setLicenseTarget(null);
    showToast(licenseMode === 'full' ? 'تم تفعيل الجهاز بتفعيل كامل دائم' : 'تم تفعيل الجهاز في المرحلة التجريبية');
  };

  const handleBlock = (id: string) => {
    updateDeviceStatus(id, 'blocked');
    refresh();
    showToast('تم حظر الجهاز', 'error');
  };

  const handleDelete = () => {
    if (!deleteTarget) return;
    deleteDevice(deleteTarget.id);
    refresh();
    setDeleteTarget(null);
    showToast('تم حذف الجهاز من السجل');
  };

  const handleGenerateHash = () => {
    if (!hashTarget) return;
    const hash = generateActivationHash(hashTarget.id);
    setGeneratedHash(hash);
    refresh();
    showToast('تم إنشاء كود التفعيل');
  };

  const copyHash = () => {
    if (!generatedHash) return;
    navigator.clipboard?.writeText(generatedHash).then(() => showToast('تم نسخ الكود')).catch(() => {});
  };

  const handleExtendTrial = () => {
    if (!extendTarget) return;
    extendDeviceTrial(extendTarget.id, extendDays, extendResetActions);
    refresh();
    setExtendTarget(null);
    showToast('تم تمديد الفترة التجريبية للجهاز بنجاح');
  };

  const handleSaveTrial = () => {
    saveTrialSettings(trial);
    refresh();
    showToast('تم حفظ إعدادات الفترة التجريبية');
  };

  const handleGenerateOfflineKey = () => {
    if (!genDeviceId.trim()) {
      showToast('يرجى إدخال رمز الجهاز', 'error');
      return;
    }
    const key = generateOfflineKey(genDeviceId.trim(), genKind, genTrialDays);
    setGeneratedOfflineKey(key);
    showToast('تم إنشاء كود التفعيل الأوفلاين');
  };

  const copyOfflineKey = () => {
    if (!generatedOfflineKey) return;
    navigator.clipboard?.writeText(generatedOfflineKey).then(() => showToast('تم نسخ الكود')).catch(() => {});
  };

  const filtered = filter === 'all' ? devices : devices.filter((d) => d.status === filter);

  const stats = {
    total: devices.length,
    approved: devices.filter((d) => d.status === 'approved').length,
    pending: devices.filter((d) => d.status === 'pending').length,
    blocked: devices.filter((d) => d.status === 'blocked').length,
  };

  return (
    <div className="space-y-5 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="grid place-items-center h-12 w-12 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-950 shadow-lg shrink-0">
            <ShieldCheck size={26} className="text-amber-400" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-brand-900">لوحة تراخيص الأجهزة والتحكم</h1>
            <p className="text-sm text-brand-400">إدارة الأجهزة المسجلة والفترة التجريبية وأكواد التفعيل</p>
          </div>
        </div>
        <Button onClick={logout} variant="danger" size="md">
          <LogOut size={16} />
          تسجيل الخروج
        </Button>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <Monitor size={16} className="text-brand-400" />
            <span className="text-xs font-semibold text-brand-400">إجمالي الأجهزة</span>
          </div>
          <p className="text-2xl font-extrabold text-brand-900">{stats.total}</p>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <CheckCircle2 size={16} className="text-emerald-500" />
            <span className="text-xs font-semibold text-brand-400">المفعّلة</span>
          </div>
          <p className="text-2xl font-extrabold text-emerald-600">{stats.approved}</p>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <Clock size={16} className="text-amber-500" />
            <span className="text-xs font-semibold text-brand-400">بانتظار الموافقة</span>
          </div>
          <p className="text-2xl font-extrabold text-amber-600">{stats.pending}</p>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <XCircle size={16} className="text-rose-500" />
            <span className="text-xs font-semibold text-brand-400">المحظورة</span>
          </div>
          <p className="text-2xl font-extrabold text-rose-600">{stats.blocked}</p>
        </Card>
      </div>

      {/* Trial Settings */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <Settings2 size={20} className="text-brand-500" />
          <h2 className="text-base font-bold text-brand-900">إعدادات الفترة التجريبية</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="flex items-center gap-2 mb-1.5">
              <input
                type="checkbox"
                checked={trial.trialEnabled}
                onChange={(e) => setTrial({ ...trial, trialEnabled: e.target.checked })}
                className="w-4 h-4 rounded accent-brand-600"
              />
              <span className="text-xs sm:text-sm font-semibold text-brand-900">تفعيل الفترة التجريبية</span>
            </label>
          </div>
          <Input
            label="مدة التجربة (أيام)"
            type="number"
            min={1}
            max={365}
            value={String(trial.trialDays)}
            onChange={(e) => setTrial({ ...trial, trialDays: Math.max(1, parseInt(e.target.value) || 1) })}
            disabled={!trial.trialEnabled}
          />
          <Input
            label="أقصى عدد عمليات"
            type="number"
            min={1}
            max={10000}
            value={String(trial.maxTrialActions)}
            onChange={(e) => setTrial({ ...trial, maxTrialActions: Math.max(1, parseInt(e.target.value) || 1) })}
            disabled={!trial.trialEnabled}
          />
        </div>
        <div className="mt-4 flex justify-end">
          <Button onClick={handleSaveTrial} variant="primary" size="md">
            <Settings2 size={16} />
            حفظ الإعدادات
          </Button>
        </div>
      </Card>

      {/* Offline Key Generator */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <Wand2 size={20} className="text-brand-500" />
          <h2 className="text-base font-bold text-brand-900">مولّد كروت التفعيل الأوفلاين</h2>
        </div>
        <div className="space-y-4">
          <Input
            label="رمز الجهاز (Device ID)"
            icon={<Hash size={18} />}
            placeholder="DEV-XXXX-XXXX"
            value={genDeviceId}
            onChange={(e) => setGenDeviceId(e.target.value)}
          />
          <div className="space-y-2">
            <label className="text-xs sm:text-sm font-bold text-brand-900">نوع التفعيل</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setGenKind('FULL')}
                className={`flex-1 rounded-2xl border-2 p-3 text-center transition-all ${
                  genKind === 'FULL'
                    ? 'border-emerald-400 bg-emerald-50'
                    : 'border-slate-200 bg-white/60 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-center gap-2">
                  <Crown size={16} className={genKind === 'FULL' ? 'text-emerald-600' : 'text-slate-400'} />
                  <span className="text-sm font-bold text-brand-900">تفعيل كامل</span>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setGenKind('TRIAL')}
                className={`flex-1 rounded-2xl border-2 p-3 text-center transition-all ${
                  genKind === 'TRIAL'
                    ? 'border-amber-400 bg-amber-50'
                    : 'border-slate-200 bg-white/60 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-center gap-2">
                  <Timer size={16} className={genKind === 'TRIAL' ? 'text-amber-600' : 'text-slate-400'} />
                  <span className="text-sm font-bold text-brand-900">تفعيل تجريبي</span>
                </div>
              </button>
            </div>
          </div>
          {genKind === 'TRIAL' && (
            <Input
              label="عدد أيام التجربة"
              type="number"
              min={1}
              max={365}
              value={String(genTrialDays)}
              onChange={(e) => setGenTrialDays(Math.max(1, parseInt(e.target.value) || 1))}
            />
          )}
          {generatedOfflineKey ? (
            <div className="space-y-3 animate-fade-in">
              <div className="rounded-2xl bg-emerald-50 border-2 border-emerald-200 p-4">
                <p className="text-xs font-semibold text-emerald-600 mb-2">كود التفعيل المُنشأ (8 أحرف):</p>
                <code className="block text-lg font-mono font-bold text-emerald-800 text-center tracking-widest select-all">{generatedOfflineKey}</code>
              </div>
              <div className="flex gap-2">
                <Button onClick={copyOfflineKey} variant="secondary" className="flex-1">
                  <Copy size={16} />
                  نسخ الكود
                </Button>
                <Button onClick={handleGenerateOfflineKey} variant="primary" className="flex-1">
                  <Wand2 size={16} />
                  توليد مرة أخرى
                </Button>
              </div>
            </div>
          ) : (
            <Button onClick={handleGenerateOfflineKey} variant="primary" className="w-full">
              <Wand2 size={18} />
              توليد كود التفعيل
            </Button>
          )}
        </div>
      </Card>

      {/* Device List */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Smartphone size={20} className="text-brand-500" />
            <h2 className="text-base font-bold text-brand-900">الأجهزة المسجلة</h2>
          </div>
          <div className="flex gap-1.5 flex-wrap">
            {(['all', 'approved', 'pending', 'blocked'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  filter === f
                    ? 'gradient-brand text-white shadow-soft'
                    : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
                }`}
              >
                {f === 'all' ? 'الكل' : f === 'approved' ? 'مفعّل' : f === 'pending' ? 'بانتظار' : 'محظور'}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-10 text-brand-400">
            <Monitor size={40} className="mx-auto mb-3 opacity-40" />
            <p className="text-sm font-semibold">لا توجد أجهزة في هذه القائمة</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((d) => (
              <div
                key={d.id}
                className="rounded-2xl border-2 border-slate-100 bg-white/60 p-4 transition-all hover:border-brand-200"
              >
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className={`grid place-items-center h-10 w-10 rounded-xl shrink-0 ${
                      d.status === 'approved' ? 'bg-emerald-100 text-emerald-600'
                      : d.status === 'blocked' ? 'bg-rose-100 text-rose-600'
                      : 'bg-amber-100 text-amber-600'
                    }`}>
                      {d.deviceName.includes('Android') || d.deviceName.includes('iOS') ? <Smartphone size={18} /> : <Monitor size={18} />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <p className="text-sm font-bold text-brand-900">{d.deviceName}</p>
                        {statusBadge(d.status)}
                        {d.status === 'approved' && licenseBadge(d.licenseType)}
                      </div>
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-brand-400">
                        <span className="flex items-center gap-1">
                          <Hash size={11} />
                          <span className="font-mono">{d.deviceId}</span>
                        </span>
                        {d.ipAddress && (
                          <span className="flex items-center gap-1">
                            <Globe size={11} />
                            {d.ipAddress}
                          </span>
                        )}
                        <span className="flex items-center gap-1">
                          <Calendar size={11} />
                          {formatDate(d.firstSeen)}
                        </span>
                        <span className="flex items-center gap-1 font-semibold">
                          <Clock size={11} />
                          {d.actionCount || 0} عملية
                        </span>
                        {d.trialExpired && (
                          <span className="flex items-center gap-1 text-rose-500 font-bold">
                            <AlertTriangle size={11} />
                            منتهي الصلاحية
                          </span>
                        )}
                      </div>
                      {d.activationHash && (
                        <div className="mt-2 flex items-center gap-2">
                          <span className="text-xs font-semibold text-emerald-600">كود التفعيل:</span>
                          <code className="text-xs font-mono bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-lg">{d.activationHash}</code>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1.5 shrink-0 flex-wrap">
                    {d.status !== 'approved' && (
                      <Button size="sm" variant="success" onClick={() => handleApprove(d.id)}>
                        <CheckCircle2 size={14} />
                        تفعيل
                      </Button>
                    )}
                    {d.status === 'approved' && (
                      <Button size="sm" variant="secondary" onClick={() => {
                        setLicenseTarget(d);
                        setLicenseMode(d.licenseType || 'full');
                        setTrialPreset(24);
                        setCustomHours(1);
                      }}>
                        <Settings2 size={14} />
                        نوع التفعيل
                      </Button>
                    )}
                    {d.status !== 'blocked' && (
                      <Button size="sm" variant="danger" onClick={() => handleBlock(d.id)}>
                        <XCircle size={14} />
                        حظر
                      </Button>
                    )}
                    {d.status !== 'approved' && (
                      <Button size="sm" variant="secondary" onClick={() => {
                        setExtendTarget(d);
                        setExtendDays(7);
                        setExtendResetActions(true);
                      }}>
                        <Hourglass size={14} />
                        تمديد
                      </Button>
                    )}
                    <Button size="sm" variant="secondary" onClick={() => { setHashTarget(d); setGeneratedHash(''); }}>
                      <KeyRound size={14} />
                      كود
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setDeleteTarget(d)} className="text-rose-500 hover:bg-rose-50">
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* License type selection modal */}
      {licenseTarget && (
        <div className="fixed inset-0 z-[90] flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-brand-950/40 backdrop-blur-sm animate-fade-in" onClick={() => setLicenseTarget(null)} />
          <div className="relative w-full max-w-md glass rounded-t-3xl sm:rounded-3xl shadow-glass animate-slide-up max-h-[88vh] overflow-y-auto no-scrollbar">
            <div className="sticky top-0 z-10 flex items-center justify-between px-3 sm:px-5 py-3 sm:py-4 glass border-b border-white/40 rounded-t-3xl">
              <h3 className="text-base sm:text-lg font-bold text-brand-900">تحديد نوع التفعيل</h3>
              <button onClick={() => setLicenseTarget(null)} className="grid place-items-center h-8 w-8 sm:h-9 sm:w-9 rounded-xl text-brand-500 hover:bg-brand-50 transition-colors">
                <XCircle size={18} />
              </button>
            </div>
            <div className="p-4 sm:p-5 space-y-4">
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-brand-50">
                <Monitor size={20} className="text-brand-500 shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-bold text-brand-900">{licenseTarget.deviceName}</p>
                  <p className="text-xs font-mono text-brand-400">{licenseTarget.deviceId}</p>
                </div>
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => setLicenseMode('full')}
                  className={`w-full rounded-2xl border-2 p-4 text-right transition-all ${
                    licenseMode === 'full'
                      ? 'border-emerald-400 bg-emerald-50'
                      : 'border-slate-200 bg-white/60 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">\n                    <div className={`grid place-items-center h-10 w-10 rounded-xl shrink-0 ${
                      licenseMode === 'full' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-500'
                    }`}>
                      <Crown size={18} />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-brand-900">تفعيل كامل ومفتوح</p>
                      <p className="text-xs text-brand-400">وصول دائم بدون قيود وقت أو نوافذ تجريبية</p>
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setLicenseMode('trial')}
                  className={`w-full rounded-2xl border-2 p-4 text-right transition-all ${
                    licenseMode === 'trial'
                      ? 'border-amber-400 bg-amber-50'
                      : 'border-slate-200 bg-white/60 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`grid place-items-center h-10 w-10 rounded-xl shrink-0 ${
                      licenseMode === 'trial' ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-500'
                    }`}>
                      <Timer size={18} />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-brand-900">مرحلة تجريبية</p>
                      <p className="text-xs text-brand-400">وصول مؤقت لمدة محددة مع عداد تنازلي</p>
                    </div>
                  </div>
                </button>
              </div>

              {licenseMode === 'trial' && (
                <div className="space-y-3 animate-fade-in">
                  <div className="flex gap-1.5 flex-wrap">
                    {[
                      { label: '1 يوم', hours: 24 },
                      { label: '3 أيام', hours: 72 },
                      { label: '7 أيام', hours: 168 },
                    ].map((preset) => (
                      <button
                        key={preset.hours}
                        type="button"
                        onClick={() => setTrialPreset(preset.hours)}
                        className={`px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                          trialPreset === preset.hours
                            ? 'gradient-brand text-white shadow-soft'
                            : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                  <Input
                    label="أو أدخل مدة مخصصة (ساعات)"
                    type="number"
                    min={1}
                    max={8760}
                    value={String(customHours)}
                    onChange={(e) => {
                      const v = Math.max(1, parseInt(e.target.value) || 1);
                      setCustomHours(v);
                      setTrialPreset(0);
                    }}
                  />
                  <p className="text-xs text-brand-400">
                    سيظهر للجهاز عداد تنازلي في أعلى الشاشة، وعند انتهاء المدة سيتم إغلاق التطبيق تلقائياً.
                  </p>
                </div>
              )}

              <Button onClick={handleConfirmLicense} variant="primary" className="w-full">
                <ShieldCheck size={18} />
                تأكيد نوع التفعيل
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Delete confirmation */}
      <ConfirmDialog
        open={!!deleteTarget}
        title="حذف الجهاز"
        message={`هل أنت متأكد من حذف "${deleteTarget?.deviceName}" من سجل الأجهزة؟ لا يمكن التراجع عن هذا الإجراء.`}
        confirmText="حذف"
        cancelText="إلغاء"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* Trial extension modal */}
      {extendTarget && (
        <div className="fixed inset-0 z-[90] flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-brand-950/40 backdrop-blur-sm animate-fade-in" onClick={() => setExtendTarget(null)} />
          <div className="relative w-full max-w-md glass rounded-t-3xl sm:rounded-3xl shadow-glass animate-slide-up max-h-[88vh] overflow-y-auto no-scrollbar">
            <div className="sticky top-0 z-10 flex items-center justify-between px-3 sm:px-5 py-3 sm:py-4 glass border-b border-white/40 rounded-t-3xl">
              <h3 className="text-base sm:text-lg font-bold text-brand-900">تمديد الفترة التجريبية</h3>
              <button onClick={() => setExtendTarget(null)} className="grid place-items-center h-8 w-8 sm:h-9 sm:w-9 rounded-xl text-brand-500 hover:bg-brand-50 transition-colors">
                <XCircle size={18} />
              </button>
            </div>
            <div className="p-4 sm:p-5 space-y-4">
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-brand-50">
                <Hourglass size={20} className="text-amber-500 shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-bold text-brand-900">{extendTarget.deviceName}</p>
                  <p className="text-xs font-mono text-brand-400">{extendTarget.deviceId}</p>
                </div>
              </div>
              <div className="space-y-3">
                <Input
                  label="عدد أيام التمديد"
                  type="number"
                  min={1}
                  max={365}
                  value={String(extendDays)}
                  onChange={(e) => setExtendDays(Math.max(1, parseInt(e.target.value) || 1))}
                />
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={extendResetActions}
                    onChange={(e) => setExtendResetActions(e.target.checked)}
                    className="w-4 h-4 rounded accent-brand-600"
                  />
                  <span className="text-sm font-semibold text-brand-900">تصفير عداد العمليات</span>
                </label>
                <p className="text-xs text-brand-400">
                  سيتم إعادة ضبط تاريخ أول تشغيل للجهاز إلى الآن، مما يمنحه فترة تجريبية جديدة كاملة.
                </p>
              </div>
              <Button onClick={handleExtendTrial} variant="primary" className="w-full">
                <Hourglass size={18} />
                تأكيد تمديد التجربة
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Activation hash modal */}
      {hashTarget && (
        <div className="fixed inset-0 z-[90] flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-brand-950/40 backdrop-blur-sm animate-fade-in" onClick={() => setHashTarget(null)} />
          <div className="relative w-full max-w-md glass rounded-t-3xl sm:rounded-3xl shadow-glass animate-slide-up max-h-[88vh] overflow-y-auto no-scrollbar">
            <div className="sticky top-0 z-10 flex items-center justify-between px-3 sm:px-5 py-3 sm:py-4 glass border-b border-white/40 rounded-t-3xl">
              <h3 className="text-base sm:text-lg font-bold text-brand-900">كود التفعيل الديناميكي</h3>
              <button onClick={() => setHashTarget(null)} className="grid place-items-center h-8 w-8 sm:h-9 sm:w-9 rounded-xl text-brand-500 hover:bg-brand-50 transition-colors">
                <XCircle size={18} />
              </button>
            </div>
            <div className="p-4 sm:p-5 space-y-4">
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-brand-50">
                <Monitor size={20} className="text-brand-500 shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-bold text-brand-900">{hashTarget.deviceName}</p>
                  <p className="text-xs font-mono text-brand-400">{hashTarget.deviceId}</p>
                </div>
              </div>
              {generatedHash ? (
                <div className="space-y-3">
                  <div className="rounded-2xl bg-emerald-50 border-2 border-emerald-200 p-4">
                    <p className="text-xs font-semibold text-emerald-600 mb-2">كود التفعيل المُنشأ:</p>
                    <code className="block text-sm font-mono text-emerald-800 break-all select-all">{generatedHash}</code>
                  </div>
                  <Button onClick={copyHash} variant="secondary" className="w-full">
                    <Copy size={16} />
                    نسخ الكود
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm text-brand-500 text-center">
                    سيتم إنشاء كود تفعيل فريد لهذا الجهاز. يُستخدم الكود لتفعيل الجهاز في وضع عدم الاتصال بالإنترنت.
                  </p>
                  <Button onClick={handleGenerateHash} variant="primary" className="w-full">
                    <KeyRound size={18} />
                    إنشاء كود التفعيل
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
