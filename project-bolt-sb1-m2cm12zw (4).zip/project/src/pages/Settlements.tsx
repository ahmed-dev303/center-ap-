import { useState, useMemo } from 'react';
import { Landmark, Wallet, PiggyBank, Calendar, ChevronDown, ChevronLeft, GraduationCap, Lock, Save, Receipt } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { getScopedData } from '../lib/scoping';
import { logAction, computeTeacherPayout, arrearFor } from '../lib/finance';
import { formatEGP, currentMonthStr, monthName, todayStr } from '../lib/date';
import type { Teacher, Group } from '../lib/types';

interface GradeRow {
  teacherId: string;
  teacherName: string;
  grade: string;
  groupId: string;
  groupName: string;
  totalStudents: number;
  paidStudents: number;
  pendingStudents: number;
  collectedAmount: number;
  centerShare: number;
  teacherNet: number;
  arrears: number;
  finalTotal: number;
}

const ARABIC_DAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export function Settlements() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { showToast } = useToast();
  const scoped = getScopedData(db, user);
  const isAdmin = user?.role === 'admin';
  const isTeacher = user?.role === 'teacher';

  const [month, setMonth] = useState(currentMonthStr());
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [arrearDrafts, setArrearDrafts] = useState<Record<string, string>>({});

  // Teachers in scope
  const teachers: Teacher[] = useMemo(() => {
    if (isTeacher && user?.teacherId) {
      return db.teachers.filter((t) => t.id === user.teacherId);
    }
    return db.teachers;
  }, [db.teachers, isTeacher, user]);

  // Groups in scope
  const scopedGroups: Group[] = useMemo(() => {
    if (isTeacher && user?.teacherId) {
      return db.groups.filter((g) => g.teacherId === user.teacherId);
    }
    return db.groups;
  }, [db.groups, isTeacher, user]);

  // Build grade rows: one row per (teacher, grade) — grade derived from group's grade field
  const rows: GradeRow[] = useMemo(() => {
    const result: GradeRow[] = [];
    for (const teacher of teachers) {
      const teacherGroups = scopedGroups.filter((g) => g.teacherId === teacher.id);
      for (const group of teacherGroups) {
        const grade = group.grade || group.name || 'غير محدد';
        const groupStudents = scoped.students.filter((s) => s.groupId === group.id);
        const totalStudents = groupStudents.length;
        const groupPayments = scoped.payments.filter(
          (p) => p.groupId === group.id && p.month === month && p.paymentType === 'session'
        );
        const paidStudentIds = new Set(groupPayments.map((p) => p.studentId));
        const paidStudents = paidStudentIds.size;
        const pendingStudents = Math.max(0, totalStudents - paidStudents);
        const collectedAmount = groupPayments.reduce((sum, p) => sum + p.amount, 0);
        const { centerShare, teacherShare } = computeTeacherPayout(db, group, totalStudents, collectedAmount);
        const teacherNet = teacherShare;
        const arrears = arrearFor(db, teacher.id, grade);
        const finalTotal = teacherNet + arrears;
        result.push({
          teacherId: teacher.id,
          teacherName: teacher.name,
          grade,
          groupId: group.id,
          groupName: group.name,
          totalStudents,
          paidStudents,
          pendingStudents,
          collectedAmount,
          centerShare,
          teacherNet,
          arrears,
          finalTotal,
        });
      }
    }
    return result;
  }, [teachers, scopedGroups, scoped.students, scoped.payments, db, month]);

  // Group rows by teacher
  const byTeacher = useMemo(() => {
    const map = new Map<string, GradeRow[]>();
    for (const r of rows) {
      if (!map.has(r.teacherId)) map.set(r.teacherId, []);
      map.get(r.teacherId)!.push(r);
    }
    return Array.from(map.entries());
  }, [rows]);

  // Totals
  const totals = useMemo(() => {
    let totalStudents = 0, paidStudents = 0, pendingStudents = 0;
    let collectedAmount = 0, centerShare = 0, teacherNet = 0, arrears = 0, finalTotal = 0;
    for (const r of rows) {
      totalStudents += r.totalStudents;
      paidStudents += r.paidStudents;
      pendingStudents += r.pendingStudents;
      collectedAmount += r.collectedAmount;
      centerShare += r.centerShare;
      teacherNet += r.teacherNet;
      arrears += r.arrears;
      finalTotal += r.finalTotal;
    }
    return { totalStudents, paidStudents, pendingStudents, collectedAmount, centerShare, teacherNet, arrears, finalTotal };
  }, [rows]);

  // Cashier log: daily inflows for the selected month
  const dailyInflows = useMemo(() => {
    const map = new Map<string, number>();
    for (const p of scoped.payments) {
      if (p.month === month) {
        map.set(p.date, (map.get(p.date) || 0) + p.amount);
      }
    }
    return map;
  }, [scoped.payments, month]);

  const monthDays = useMemo(() => {
    const [y, m] = month.split('-').map(Number);
    const days = new Date(y, m, 0).getDate();
    const arr: { date: string; day: string; amount: number }[] = [];
    for (let d = 1; d <= days; d++) {
      const ds = `${month}-${String(d).padStart(2, '0')}`;
      const dow = new Date(ds + 'T00:00:00').getDay();
      arr.push({ date: ds, day: ARABIC_DAYS[dow], amount: dailyInflows.get(ds) || 0 });
    }
    return arr;
  }, [month, dailyInflows]);

  const activeDays = monthDays.filter((d) => d.amount > 0);

  // KPIs
  const totalCenterDue = totals.centerShare;
  const totalPaidToTeachers = totals.teacherNet;
  const netInSafe = totals.collectedAmount - totalPaidToTeachers;

  const handleSaveArrear = (teacherId: string, grade: string) => {
    const key = `${teacherId}|${grade}`;
    const raw = arrearDrafts[key];
    if (raw === undefined) return;
    const val = Number(raw);
    if (isNaN(val)) {
      showToast('القيمة يجب أن تكون رقماً', 'error');
      return;
    }
    update((d) => {
      const idx = d.teacherArrears.findIndex((a) => a.teacherId === teacherId && a.grade === grade);
      const entry = {
        teacherId,
        grade,
        amount: val,
        note: 'تخلفات شهور سابقة',
        updatedAt: new Date().toISOString(),
      };
      if (idx >= 0) d.teacherArrears[idx] = entry;
      else d.teacherArrears.push(entry);
      logAction(d, 'تعديل التخلفات', `قام ${user?.name || ''} بتعديل تخلفات ${grade} إلى ${val} ج.م.`, user?.name || '', user?.role || 'admin');
    });
    setArrearDrafts((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
    showToast('تم حفظ التخلفات');
  };

  const toggle = (key: string) => setExpanded((p) => ({ ...p, [key]: !p[key] }));

  return (
    <div className="min-h-[calc(100vh-2rem)] -mx-4 lg:-mx-6 -mt-1 px-4 lg:px-6 pt-4 pb-28 lg:pb-6 bg-slate-950 text-slate-100 rounded-none lg:rounded-3xl">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap mb-5">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
            <Landmark size={24} className="text-emerald-400" /> تصفية الحسابات وعهدة المجموعات
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">كشف حساب المدرسين والمبالغ المستحقة للسنتر</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Calendar size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <input
              type="month"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
              className="h-11 rounded-xl bg-slate-900 border-2 border-slate-800 text-slate-100 pr-10 pl-3 text-sm font-bold focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* Read-only banner for teacher */}
      {isTeacher && (
        <div className="flex items-center gap-2 rounded-2xl bg-amber-500/10 border border-amber-500/30 px-4 py-2.5 text-sm font-semibold text-amber-300 mb-5">
          <Lock size={16} /> وضع العرض فقط — يمكنك الاطلاع على كشف حسابك دون تعديله
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        <div className="rounded-3xl bg-gradient-to-br from-emerald-600/20 to-emerald-800/10 border border-emerald-500/30 p-5">
          <div className="flex items-center gap-2 mb-2">
            <div className="grid place-items-center h-10 w-10 rounded-2xl bg-emerald-500/20 text-emerald-400">
              <PiggyBank size={20} />
            </div>
            <span className="text-xs font-bold text-emerald-300">إجمالي عهدة السنتر المستحقة</span>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-white">{formatEGP(totalCenterDue)}</p>
          <p className="text-xs text-slate-400 mt-1">{totals.totalStudents} طالب × عهدة ثابتة</p>
        </div>

        <div className="rounded-3xl bg-gradient-to-br from-rose-600/20 to-rose-800/10 border border-rose-500/30 p-5">
          <div className="flex items-center gap-2 mb-2">
            <div className="grid place-items-center h-10 w-10 rounded-2xl bg-rose-500/20 text-rose-400">
              <Wallet size={20} />
            </div>
            <span className="text-xs font-bold text-rose-300">المبالغ المسلمة للمدرسين</span>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-white">{formatEGP(totalPaidToTeachers)}</p>
          <p className="text-xs text-slate-400 mt-1">صافي مستحق المدرسين بعد خصم العهدة</p>
        </div>

        <div className="rounded-3xl bg-gradient-to-br from-brand-600/20 to-brand-800/10 border border-brand-500/30 p-5">
          <div className="flex items-center gap-2 mb-2">
            <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-500/20 text-brand-300">
              <Landmark size={20} />
            </div>
            <span className="text-xs font-bold text-brand-300">الصافي في خزينة السنتر</span>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-white">{formatEGP(netInSafe)}</p>
          <p className="text-xs text-slate-400 mt-1">المحصّ - المسلّم للمدرسين</p>
        </div>
      </div>

      {/* Teacher Accounts Matrix */}
      <div className="rounded-3xl bg-slate-900/60 border border-slate-800 overflow-hidden mb-6">
        <div className="px-5 py-4 border-b border-slate-800 flex items-center gap-2">
          <GraduationCap size={20} className="text-emerald-400" />
          <h3 className="font-bold text-white">كشف حساب المجموعات والمدرسين</h3>
        </div>

        {/* Desktop table */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-800/60 text-slate-300">
                <th className="px-3 py-3 text-right font-bold">المعلم / الصف</th>
                <th className="px-3 py-3 text-center font-bold">إجمالي الطلاب</th>
                <th className="px-3 py-3 text-center font-bold">تم التحصيل</th>
                <th className="px-3 py-3 text-center font-bold">جاري التحصيل</th>
                <th className="px-3 py-3 text-center font-bold">المبلغ المحصل</th>
                <th className="px-3 py-3 text-center font-bold">عهدة السنتر</th>
                <th className="px-3 py-3 text-center font-bold">صافي المستحق</th>
                <th className="px-3 py-3 text-center font-bold">تخلفات سابقة</th>
                <th className="px-3 py-3 text-center font-bold">الإجمالي النهائي</th>
              </tr>
            </thead>
            <tbody>
              {byTeacher.map(([teacherId, teacherRows]) => {
                const teacher = teachers.find((t) => t.id === teacherId);
                const tTotals = teacherRows.reduce(
                  (acc, r) => {
                    acc.totalStudents += r.totalStudents;
                    acc.paidStudents += r.paidStudents;
                    acc.pendingStudents += r.pendingStudents;
                    acc.collectedAmount += r.collectedAmount;
                    acc.centerShare += r.centerShare;
                    acc.teacherNet += r.teacherNet;
                    acc.arrears += r.arrears;
                    acc.finalTotal += r.finalTotal;
                    return acc;
                  },
                  { totalStudents: 0, paidStudents: 0, pendingStudents: 0, collectedAmount: 0, centerShare: 0, teacherNet: 0, arrears: 0, finalTotal: 0 }
                );
                return (
                  <>
                    <tr key={teacherId} className="bg-slate-800/40">
                      <td colSpan={9} className="px-3 py-2.5 font-extrabold text-emerald-300">
                        {teacher?.name || 'غير معروف'}
                      </td>
                    </tr>
                    {teacherRows.map((r) => {
                      const key = `${r.teacherId}|${r.grade}`;
                      const draftVal = arrearDrafts[key] ?? String(r.arrears);
                      return (
                        <tr key={r.groupId} className="border-t border-slate-800 hover:bg-slate-800/30">
                          <td className="px-3 py-3">
                            <div className="font-bold text-slate-100">{r.grade}</div>
                            <div className="text-xs text-slate-400">{r.groupName}</div>
                          </td>
                          <td className="px-3 py-3 text-center font-bold text-slate-200">{r.totalStudents}</td>
                          <td className="px-3 py-3 text-center">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-300 text-xs font-bold">
                              {r.paidStudents}
                            </span>
                          </td>
                          <td className="px-3 py-3 text-center">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/15 text-amber-300 text-xs font-bold">
                              {r.pendingStudents}
                            </span>
                          </td>
                          <td className="px-3 py-3 text-center font-bold text-emerald-300">{formatEGP(r.collectedAmount)}</td>
                          <td className="px-3 py-3 text-center font-bold text-rose-300">{formatEGP(r.centerShare)}</td>
                          <td className="px-3 py-3 text-center font-bold text-slate-100">{formatEGP(r.teacherNet)}</td>
                          <td className="px-3 py-3 text-center">
                            <div className="flex items-center justify-center gap-1">
                              <input
                                type="number"
                                value={draftVal}
                                disabled={!isAdmin}
                                onChange={(e) => setArrearDrafts((p) => ({ ...p, [key]: e.target.value }))}
                                className="w-20 h-9 rounded-lg bg-slate-800 border border-slate-700 text-slate-100 px-2 text-center text-sm font-bold focus:outline-none focus:border-emerald-500 disabled:opacity-60"
                              />
                              {isAdmin && arrearDrafts[key] !== undefined && (
                                <button
                                  onClick={() => handleSaveArrear(r.teacherId, r.grade)}
                                  className="grid place-items-center h-9 w-9 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30"
                                >
                                  <Save size={14} />
                                </button>
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-3 text-center">
                            <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 text-white text-sm font-extrabold">
                              {formatEGP(r.finalTotal)}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="bg-slate-800/60 border-t-2 border-slate-700">
                      <td className="px-3 py-3 font-extrabold text-white">الإجمالي العام — {teacher?.name}</td>
                      <td className="px-3 py-3 text-center font-extrabold text-white">{tTotals.totalStudents}</td>
                      <td className="px-3 py-3 text-center font-extrabold text-emerald-300">{tTotals.paidStudents}</td>
                      <td className="px-3 py-3 text-center font-extrabold text-amber-300">{tTotals.pendingStudents}</td>
                      <td className="px-3 py-3 text-center font-extrabold text-emerald-300">{formatEGP(tTotals.collectedAmount)}</td>
                      <td className="px-3 py-3 text-center font-extrabold text-rose-300">{formatEGP(tTotals.centerShare)}</td>
                      <td className="px-3 py-3 text-center font-extrabold text-white">{formatEGP(tTotals.teacherNet)}</td>
                      <td className="px-3 py-3 text-center font-extrabold text-amber-300">{formatEGP(tTotals.arrears)}</td>
                      <td className="px-3 py-3 text-center">
                        <span className="inline-flex px-3 py-1.5 rounded-lg bg-gradient-to-r from-brand-500 to-brand-600 text-white text-sm font-extrabold">
                          {formatEGP(tTotals.finalTotal)}
                        </span>
                      </td>
                    </tr>
                  </>
                );
              })}
            </tbody>
            {rows.length > 0 && (
              <tfoot>
                <tr className="bg-gradient-to-r from-emerald-700/30 to-emerald-800/20 border-t-2 border-emerald-600">
                  <td className="px-3 py-4 font-extrabold text-emerald-200">الإجمالي العام لكل المدرسين</td>
                  <td className="px-3 py-4 text-center font-extrabold text-white">{totals.totalStudents}</td>
                  <td className="px-3 py-4 text-center font-extrabold text-emerald-300">{totals.paidStudents}</td>
                  <td className="px-3 py-4 text-center font-extrabold text-amber-300">{totals.pendingStudents}</td>
                  <td className="px-3 py-4 text-center font-extrabold text-emerald-300">{formatEGP(totals.collectedAmount)}</td>
                  <td className="px-3 py-4 text-center font-extrabold text-rose-300">{formatEGP(totals.centerShare)}</td>
                  <td className="px-3 py-4 text-center font-extrabold text-white">{formatEGP(totals.teacherNet)}</td>
                  <td className="px-3 py-4 text-center font-extrabold text-amber-300">{formatEGP(totals.arrears)}</td>
                  <td className="px-3 py-4 text-center">
                    <span className="inline-flex px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 text-white text-sm font-extrabold">
                      {formatEGP(totals.finalTotal)}
                    </span>
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Mobile collapsible cards */}
        <div className="lg:hidden divide-y divide-slate-800">
          {byTeacher.map(([teacherId, teacherRows]) => {
            const teacher = teachers.find((t) => t.id === teacherId);
            const tFinal = teacherRows.reduce((s, r) => s + r.finalTotal, 0);
            return (
              <div key={teacherId} className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-extrabold text-emerald-300">{teacher?.name}</h4>
                  <span className="inline-flex px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 text-white text-xs font-extrabold">
                    {formatEGP(tFinal)}
                  </span>
                </div>
                <div className="space-y-2">
                  {teacherRows.map((r) => {
                    const key = `${r.teacherId}|${r.grade}`;
                    const cardKey = `${r.groupId}`;
                    const draftVal = arrearDrafts[key] ?? String(r.arrears);
                    const isOpen = !!expanded[cardKey];
                    return (
                      <div key={r.groupId} className="rounded-2xl bg-slate-800/50 border border-slate-700/60 overflow-hidden">
                        <button
                          onClick={() => toggle(cardKey)}
                          className="w-full flex items-center justify-between gap-2 px-4 py-3"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <div className="grid place-items-center h-9 w-9 rounded-xl bg-slate-700 text-emerald-300">
                              <GraduationCap size={18} />
                            </div>
                            <div className="min-w-0 text-right">
                              <p className="font-bold text-slate-100 text-sm truncate">{r.grade}</p>
                              <p className="text-[10px] text-slate-400 truncate">{r.groupName}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="inline-flex px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 text-white text-xs font-extrabold">
                              {formatEGP(r.finalTotal)}
                            </span>
                            {isOpen ? <ChevronDown size={18} className="text-slate-400" /> : <ChevronLeft size={18} className="text-slate-400" />}
                          </div>
                        </button>
                        {isOpen && (
                          <div className="px-4 pb-4 space-y-2.5 animate-fade-in">
                            <MobileRow label="إجمالي الطلاب" value={String(r.totalStudents)} tone="slate" />
                            <MobileRow label="تم التحصيل" value={String(r.paidStudents)} tone="emerald" />
                            <MobileRow label="جاري التحصيل" value={String(r.pendingStudents)} tone="amber" />
                            <MobileRow label="المبلغ المحصل" value={formatEGP(r.collectedAmount)} tone="emerald" />
                            <MobileRow label="عهدة السنتر" value={formatEGP(r.centerShare)} tone="rose" />
                            <MobileRow label="صافي المستحق" value={formatEGP(r.teacherNet)} tone="slate" />
                            <div className="flex items-center justify-between gap-2 pt-1">
                              <span className="text-xs font-semibold text-slate-300">تخلفات سابقة</span>
                              <div className="flex items-center gap-1">
                                <input
                                  type="number"
                                  value={draftVal}
                                  disabled={!isAdmin}
                                  onChange={(e) => setArrearDrafts((p) => ({ ...p, [key]: e.target.value }))}
                                  className="w-24 h-9 rounded-lg bg-slate-800 border border-slate-700 text-slate-100 px-2 text-center text-sm font-bold focus:outline-none focus:border-emerald-500 disabled:opacity-60"
                                />
                                {isAdmin && arrearDrafts[key] !== undefined && (
                                  <button
                                    onClick={() => handleSaveArrear(r.teacherId, r.grade)}
                                    className="grid place-items-center h-9 w-9 rounded-lg bg-emerald-500/20 text-emerald-300 active:scale-95"
                                  >
                                    <Save size={14} />
                                  </button>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center justify-between pt-2 border-t border-slate-700/60">
                              <span className="text-sm font-bold text-white">الإجمالي النهائي</span>
                              <span className="inline-flex px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 text-white text-sm font-extrabold">
                                {formatEGP(r.finalTotal)}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
          {rows.length === 0 && (
            <div className="p-8 text-center text-slate-400 text-sm">لا توجد بيانات لهذا الشهر</div>
          )}
        </div>
      </div>

      {/* Central Cashier Log / Daily Safe */}
      <div className="rounded-3xl bg-slate-900/60 border border-slate-800 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-800 flex items-center gap-2">
          <Receipt size={20} className="text-emerald-400" />
          <h3 className="font-bold text-white">تصفية عهدة السنتر اليومية — {monthName(month)}</h3>
        </div>
        <div className="p-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
            <div className="rounded-2xl bg-slate-800/50 border border-slate-700/60 p-3">
              <p className="text-[10px] font-bold text-slate-400 mb-1">إجمالي المحصّ</p>
              <p className="text-lg font-extrabold text-emerald-300">{formatEGP(totals.collectedAmount)}</p>
            </div>
            <div className="rounded-2xl bg-slate-800/50 border border-slate-700/60 p-3">
              <p className="text-[10px] font-bold text-slate-400 mb-1">عهدة السنتر</p>
              <p className="text-lg font-extrabold text-rose-300">{formatEGP(totalCenterDue)}</p>
            </div>
            <div className="rounded-2xl bg-slate-800/50 border border-slate-700/60 p-3">
              <p className="text-[10px] font-bold text-slate-400 mb-1">للمدرسين</p>
              <p className="text-lg font-extrabold text-amber-300">{formatEGP(totalPaidToTeachers)}</p>
            </div>
            <div className="rounded-2xl bg-gradient-to-br from-emerald-600/20 to-emerald-800/10 border border-emerald-500/30 p-3">
              <p className="text-[10px] font-bold text-emerald-300 mb-1">صافي الخزينة</p>
              <p className="text-lg font-extrabold text-white">{formatEGP(netInSafe)}</p>
            </div>
          </div>

          {/* Daily calendar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
            {monthDays.map((d) => {
              const isToday = d.date === todayStr();
              const hasFlow = d.amount > 0;
              return (
                <div
                  key={d.date}
                  className={`rounded-2xl p-3 border ${
                    isToday
                      ? 'bg-emerald-500/15 border-emerald-500/50'
                      : hasFlow
                      ? 'bg-slate-800/60 border-slate-700'
                      : 'bg-slate-900/40 border-slate-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-bold text-slate-400">{d.day}</span>
                    <span className="text-[10px] font-bold text-slate-500">{Number(d.date.slice(-2))}</span>
                  </div>
                  <p className={`text-xs font-extrabold ${hasFlow ? 'text-emerald-300' : 'text-slate-500'}`}>
                    {hasFlow ? formatEGP(d.amount) : '—'}
                  </p>
                </div>
              );
            })}
          </div>

          {activeDays.length > 0 && (
            <div className="mt-5">
              <h4 className="text-sm font-bold text-slate-200 mb-2">أيام التحصيل النشطة</h4>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {activeDays.map((d) => (
                  <div key={d.date} className="flex items-center justify-between rounded-xl bg-slate-800/40 px-3 py-2">
                    <span className="text-xs font-semibold text-slate-300">{d.day} — {Number(d.date.slice(-2))}</span>
                    <span className="text-sm font-extrabold text-emerald-300">{formatEGP(d.amount)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function MobileRow({ label, value, tone }: { label: string; value: string; tone: 'slate' | 'emerald' | 'amber' | 'rose' }) {
  const toneClass = {
    slate: 'text-slate-100',
    emerald: 'text-emerald-300',
    amber: 'text-amber-300',
    rose: 'text-rose-300',
  }[tone];
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs font-semibold text-slate-300">{label}</span>
      <span className={`text-sm font-extrabold ${toneClass}`}>{value}</span>
    </div>
  );
}
