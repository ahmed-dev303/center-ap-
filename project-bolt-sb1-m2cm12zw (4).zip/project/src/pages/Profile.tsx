import { useState } from 'react';
import { UserCircle, Eye, EyeOff, Save, KeyRound, ShieldCheck } from 'lucide-react';
import { useAuth, roleLabel } from '../context/AuthContext';
import { useDB } from '../context/DBContext';
import { useToast } from '../context/ToastContext';
import { logAction } from '../lib/finance';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';

export function Profile() {
  const { user, updateProfile } = useAuth();
  const { db, update } = useDB();
  const { showToast } = useToast();

  const [usernameDraft, setUsernameDraft] = useState(user?.username ?? '');
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [saving, setSaving] = useState(false);

  if (!user) return null;

  const handleSave = () => {
    setSaving(true);
    try {
      if (!currentPw) {
        showToast('يرجى إدخال كلمة المرور الحالية', 'error');
        return;
      }
      if (currentPw !== user.password) {
        showToast('كلمة المرور الحالية غير صحيحة', 'error');
        return;
      }

      const trimmedUsername = usernameDraft.trim();
      if (!trimmedUsername) {
        showToast('اسم المستخدم لا يمكن أن يكون فارغاً', 'error');
        return;
      }
      const duplicate = db.users.find(
        (u) => u.username === trimmedUsername && u.id !== user.id
      );
      if (duplicate) {
        showToast('اسم المستخدم مستخدم بالفعل من قبل حساب آخر', 'error');
        return;
      }

      const changingPassword = newPw.length > 0 || confirmPw.length > 0;
      if (changingPassword) {
        if (newPw.length < 4) {
          showToast('كلمة المرور الجديدة يجب أن تكون 4 أحرف على الأقل', 'error');
          return;
        }
        if (newPw !== confirmPw) {
          showToast('كلمة المرور الجديدة وتأكيدها غير متطابقين', 'error');
          return;
        }
      }

      const newUsername = trimmedUsername !== user.username ? trimmedUsername : user.username;
      const newPassword = changingPassword ? newPw : user.password;

      update((d) => {
        const u = d.users.find((x) => x.id === user.id);
        if (u) {
          u.username = newUsername;
          u.password = newPassword;
        }
        logAction(
          d,
          'تعديل بيانات الحساب',
          `قام ${user.name} بتحديث بيانات حسابه${changingPassword ? ' وكلمة المرور' : ''}.`,
          user.name,
          user.role
        );
      });

      updateProfile({ username: newUsername, password: newPassword });

      setCurrentPw('');
      setNewPw('');
      setConfirmPw('');
      showToast('تم تحديث بيانات الحساب بنجاح! 🔒', 'success');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      <Card className="p-6">
        <div className="flex items-center gap-4">
          <div className="grid place-items-center h-16 w-16 rounded-3xl gradient-brand shadow-glow">
            <UserCircle size={34} className="text-white" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-brand-900">{user.name}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="inline-flex items-center gap-1 rounded-full bg-brand-100 px-2.5 py-0.5 text-xs font-bold text-brand-700">
                <ShieldCheck size={12} /> {roleLabel(user.role)}
              </span>
              <span className="text-xs text-brand-400">@{user.username}</span>
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-5">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-700">
            <KeyRound size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">إعدادات الحساب</h3>
            <p className="text-xs text-brand-400">عدّل اسم المستخدم وكلمة المرور الخاصة بك</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-brand-700 mb-1.5">
              تعديل اسم المستخدم
            </label>
            <input
              type="text"
              value={usernameDraft}
              onChange={(e) => setUsernameDraft(e.target.value)}
              className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white px-4 text-sm font-semibold text-brand-900 focus:outline-none focus:border-brand-500"
              placeholder="اسم المستخدم"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-brand-700 mb-1.5">
              كلمة المرور الحالية
            </label>
            <div className="relative">
              <input
                type={showCurrent ? 'text' : 'password'}
                value={currentPw}
                onChange={(e) => setCurrentPw(e.target.value)}
                className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white px-4 pl-11 text-sm font-semibold text-brand-900 focus:outline-none focus:border-brand-500"
                placeholder="كلمة المرور الحالية"
              />
              <button
                type="button"
                onClick={() => setShowCurrent((v) => !v)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-400 hover:text-brand-600"
              >
                {showCurrent ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <p className="text-xs text-brand-400 mt-1">مطلوبة لتأكيد أي تغيير</p>
          </div>

          <div>
            <label className="block text-sm font-semibold text-brand-700 mb-1.5">
              كلمة المرور الجديدة
            </label>
            <div className="relative">
              <input
                type={showNew ? 'text' : 'password'}
                value={newPw}
                onChange={(e) => setNewPw(e.target.value)}
                className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white px-4 pl-11 text-sm font-semibold text-brand-900 focus:outline-none focus:border-brand-500"
                placeholder="اتركها فارغة إذا لم ترد التغيير"
              />
              <button
                type="button"
                onClick={() => setShowNew((v) => !v)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-400 hover:text-brand-600"
              >
                {showNew ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-brand-700 mb-1.5">
              تأكيد كلمة المرور الجديدة
            </label>
            <div className="relative">
              <input
                type={showConfirm ? 'text' : 'password'}
                value={confirmPw}
                onChange={(e) => setConfirmPw(e.target.value)}
                className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white px-4 pl-11 text-sm font-semibold text-brand-900 focus:outline-none focus:border-brand-500"
                placeholder="أعد كتابة كلمة المرور الجديدة"
              />
              <button
                type="button"
                onClick={() => setShowConfirm((v) => !v)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-400 hover:text-brand-600"
              >
                {showConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <div className="pt-2">
            <Button onClick={handleSave} disabled={saving} className="w-full sm:w-auto">
              <Save size={18} /> حفظ التغييرات
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
