import { useState } from 'react';
import { UserCog, Trash2, Lock, ShieldCheck, Building2, Banknote } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth, roleLabel } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { logAction } from '../lib/finance';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { formatEGP } from '../lib/date';
import type { StaffPayModel } from '../lib/types';

const PAY_MODEL_LABELS: Record<StaffPayModel, string> = {
  hourly: 'بالساعة',
  per_session: 'بالحصة',
  fixed_monthly: 'شهري',
  percentage: 'نسبة مئوية',
};

export function Accounts() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { showToast } = useToast();

  const [deleteId, setDeleteId] = useState<string | null>(null);

  const accounts = db.users;

  const handleDelete = () => {
    if (!deleteId) return;
    const acct = db.users.find((u) => u.id === deleteId);
    if (!acct) return;
    update((d) => {
      d.users = d.users.filter((u) => u.id !== deleteId);
      d.staff = d.staff.filter((s) => s.userId !== deleteId);
      logAction(d, 'حذف حساب', `قام ${user?.name || ''} بحذف حساب ${acct.name} (${acct.username}).`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف الحساب', 'info');
    setDeleteId(null);
  };

  const getBranchNames = (branchIds?: string[]): string[] => {
    if (!branchIds || branchIds.length === 0) return [];
    return db.branches.filter((b) => branchIds.includes(b.id)).map((b) => b.name);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 flex items-center gap-2">
            <UserCog size={24} /> إدارة الحسابات
            <Lock size={16} className="text-brand-400" />
          </h2>
          <p className="text-sm text-brand-400 mt-0.5">{accounts.length} حساب مسجل — يتم إنشاء الحسابات من صفحة الإعدادات</p>
        </div>
      </div>

      {/* Desktop table */}
      <Card className="hidden lg:block overflow-hidden" glass={false}>
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-brand-50 text-brand-700 text-right">
              <th className="px-4 py-3 font-bold">الاسم بالكامل</th>
              <th className="px-4 py-3 font-bold">اسم المستخدم</th>
              <th className="px-4 py-3 font-bold">النوع</th>
              <th className="px-4 py-3 font-bold">الفروع</th>
              <th className="px-4 py-3 font-bold">نظام الأجر</th>
              <th className="px-4 py-3 font-bold">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {accounts.map((u) => {
              const isAdmin = u.username === 'admin';
              const branchNames = getBranchNames(u.branchIds);
              return (
                <tr key={u.id} className="hover:bg-brand-50/40 transition-colors">
                  <td className="px-4 py-3 font-bold text-brand-900">{u.name}</td>
                  <td className="px-4 py-3 text-brand-600">{u.username}</td>
                  <td className="px-4 py-3">
                    <Badge tone={u.role === 'admin' ? 'violet' : u.role === 'secretary' ? 'brand' : u.role === 'assistant' ? 'amber' : u.role === 'supervisor' ? 'sky' : 'emerald'}>
                      {roleLabel(u.role)}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    {u.role === 'teacher' ? (
                      branchNames.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {branchNames.map((n) => (
                            <Badge key={n} tone="slate" className="text-[10px]">{n}</Badge>
                          ))}
                        </div>
                      ) : (
                        <span className="text-brand-300 text-xs">لا توجد فروع</span>
                      )
                    ) : (
                      <span className="text-brand-300 text-xs">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-xs text-brand-500">
                    {u.payModel ? (
                      <span className="flex items-center gap-1">
                        <Banknote size={12} /> {PAY_MODEL_LABELS[u.payModel]} {u.rate != null ? `• ${formatEGP(u.rate)}` : ''}
                      </span>
                    ) : '—'}
                  </td>
                  <td className="px-4 py-3">
                    {isAdmin ? (
                      <Badge tone="violet" className="text-xs flex items-center gap-1 w-fit">
                        <ShieldCheck size={12} /> محمي
                      </Badge>
                    ) : (
                      <button
                        onClick={() => setDeleteId(u.id)}
                        className="grid place-items-center h-8 w-8 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors"
                        title="حذف"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>

      {/* Mobile cards */}
      <div className="lg:hidden space-y-3">
        {accounts.map((u) => {
          const isAdmin = u.username === 'admin';
          const branchNames = getBranchNames(u.branchIds);
          return (
            <Card key={u.id} className="p-4" hover>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="grid place-items-center h-12 w-12 rounded-2xl gradient-brand text-white font-extrabold text-lg shadow-soft">
                    {u.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-brand-900">{u.name}</h3>
                    <p className="text-xs text-brand-400">@{u.username}</p>
                  </div>
                </div>
                <Badge tone={u.role === 'admin' ? 'violet' : u.role === 'secretary' ? 'brand' : u.role === 'assistant' ? 'amber' : u.role === 'supervisor' ? 'sky' : 'emerald'}>
                  {roleLabel(u.role)}
                </Badge>
              </div>
              {u.role === 'teacher' && (
                <div className="mb-3">
                  <p className="text-xs text-brand-400 font-semibold mb-1 flex items-center gap-1">
                    <Building2 size={12} /> الفروع المخصصة
                  </p>
                  {branchNames.length > 0 ? (
                    <div className="flex flex-wrap gap-1">
                      {branchNames.map((n) => (
                        <Badge key={n} tone="slate" className="text-[10px]">{n}</Badge>
                      ))}
                    </div>
                  ) : (
                    <span className="text-xs text-brand-300">لا توجد فروع مخصصة</span>
                  )}
                </div>
              )}
              {u.payModel && (
                <div className="mb-3 text-xs text-brand-500 flex items-center gap-1">
                  <Banknote size={12} /> {PAY_MODEL_LABELS[u.payModel]} {u.rate != null ? `• ${formatEGP(u.rate)}` : ''}
                </div>
              )}
              <div className="flex justify-end pt-3 border-t border-slate-100">
                {isAdmin ? (
                  <Badge tone="violet" className="text-xs flex items-center gap-1">
                    <ShieldCheck size={12} /> حساب محمي
                  </Badge>
                ) : (
                  <Button size="sm" variant="ghost" className="text-rose-500" onClick={() => setDeleteId(u.id)}>
                    <Trash2 size={15} /> حذف
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      <ConfirmDialog
        open={deleteId !== null}
        title="حذف الحساب"
        message="سيتم حذف هذا الحساب نهائياً ولن يتمكن المستخدم من تسجيل الدخول. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}
