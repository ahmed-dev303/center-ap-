import { useMemo } from 'react';
import {
  Lock, TrendingUp, TrendingDown, Wallet, Banknote, Landmark,
  BookOpen, CreditCard, Calendar, Receipt, Users,
} from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { formatEGP, formatDate } from '../lib/date';
import { computeSharesForPrice } from '../lib/finance';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';

export function SecretProfits() {
  const { user } = useAuth();
  const { db } = useDB();

  if (user?.role !== 'admin') {
    return (
      <div className="grid place-items-center py-20">
        <div className="text-center">
          <div className="grid place-items-center h-20 w-20 rounded-3xl bg-rose-50 text-rose-400 mx-auto mb-4">
            <Lock size={36} />
          </div>
          <h3 className="text-lg font-bold text-brand-900 mb-1">صلاحية محظورة</h3>
          <p className="text-sm text-brand-400">هذه الصفحة متاحة للمدير فقط.</p>
        </div>
      </div>
    );
  }

  const { centerRevenue, sessionRevenue, bookRevenue, idRevenue, totalExpenses, totalSalaries, netProfit, revenueBreakdown } = useMemo(() => {
    const sessionRev = db.payments
      .filter((p) => p.paymentType === 'session')
      .reduce((sum, p) => sum + computeSharesForPrice(db, p.amount).centerShare, 0);

    const bookRev = db.payments
      .filter((p) => p.paymentType === 'book')
      .reduce((sum, p) => sum + p.amount, 0);

    const idRev = db.payments
      .filter((p) => p.paymentType === 'id')
      .reduce((sum, p) => sum + p.amount, 0);

    const centerRev = sessionRev + bookRev + idRev;
    const expenses = db.expenses.reduce((sum, e) => sum + e.amount, 0);
    const salaries = db.salaries.reduce((sum, s) => sum + s.net, 0);
    const adjustmentsDeduction = (db.staffAdjustments || []).reduce((sum, a) => sum + (a.type === 'reward' ? -a.amount : a.amount), 0);
    const net = centerRev - expenses - salaries - adjustmentsDeduction;

    const breakdown = [
      { label: 'حصة السنتر من الحصص', amount: sessionRev, icon: Calendar, tone: 'brand' as const },
      { label: 'مبيعات المذكرات والكتب', amount: bookRev, icon: BookOpen, tone: 'emerald' as const },
      { label: 'رسوم كارت الـ ID', amount: idRev, icon: CreditCard, tone: 'amber' as const },
    ];

    return { centerRevenue: centerRev, sessionRevenue: sessionRev, bookRevenue: bookRev, idRevenue: idRev, totalExpenses: expenses, totalSalaries: salaries, netProfit: net, revenueBreakdown: breakdown };
  }, [db.payments, db.expenses, db.salaries, db]);

  const profitMargin = centerRevenue > 0 ? Math.round((netProfit / centerRevenue) * 100) : 0;
  const maxRevenue = Math.max(sessionRevenue, bookRevenue, idRevenue, 1);

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="grid place-items-center h-12 w-12 rounded-2xl bg-brand-600 text-white shadow-soft">
          <Lock size={24} />
        </div>
        <div>
          <h1 className="text-2xl font-extrabold text-brand-900">الأرباح السرية</h1>
          <p className="text-sm text-brand-400 font-semibold">لوحة مالية شاملة — للمدير فقط</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5 relative overflow-hidden" hover>
          <div className="absolute -top-6 -left-6 h-24 w-24 rounded-full bg-brand-100/50 blur-2xl" />
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <div className="grid place-items-center h-11 w-11 rounded-2xl bg-brand-100 text-brand-600"><Landmark size={22} /></div>
              <TrendingUp size={18} className="text-emerald-500" />
            </div>
            <p className="text-xs font-bold text-brand-400 mb-1">إجمالي إيرادات السنتر</p>
            <p className="text-2xl font-extrabold text-brand-900">{formatEGP(centerRevenue)}</p>
            <p className="text-[10px] text-brand-300 mt-1">حصة السنتر وفق نظام المكسب العام</p>
          </div>
        </Card>

        <Card className="p-5 relative overflow-hidden" hover>
          <div className="absolute -top-6 -left-6 h-24 w-24 rounded-full bg-rose-100/50 blur-2xl" />
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <div className="grid place-items-center h-11 w-11 rounded-2xl bg-rose-100 text-rose-600"><Receipt size={22} /></div>
              <TrendingDown size={18} className="text-rose-500" />
            </div>
            <p className="text-xs font-bold text-brand-400 mb-1">إجمالي المصروفات</p>
            <p className="text-2xl font-extrabold text-brand-900">{formatEGP(totalExpenses)}</p>
            <p className="text-[10px] text-brand-300 mt-1">{db.expenses.length} عملية</p>
          </div>
        </Card>

        <Card className="p-5 relative overflow-hidden" hover>
          <div className="absolute -top-6 -left-6 h-24 w-24 rounded-full bg-amber-100/50 blur-2xl" />
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <div className="grid place-items-center h-11 w-11 rounded-2xl bg-amber-100 text-amber-600"><Users size={22} /></div>
              <Banknote size={18} className="text-amber-500" />
            </div>
            <p className="text-xs font-bold text-brand-400 mb-1">مرتبات السكرتارية</p>
            <p className="text-2xl font-extrabold text-brand-900">{formatEGP(totalSalaries)}</p>
            <p className="text-[10px] text-brand-300 mt-1">{db.salaries.length} دفعة</p>
          </div>
        </Card>

        <Card className={`p-5 relative overflow-hidden border-2 ${netProfit >= 0 ? 'border-emerald-200' : 'border-rose-200'}`} hover>
          <div className={`absolute -top-6 -left-6 h-24 w-24 rounded-full blur-2xl ${netProfit >= 0 ? 'bg-emerald-100/50' : 'bg-rose-100/50'}`} />
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <div className={`grid place-items-center h-11 w-11 rounded-2xl ${netProfit >= 0 ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}><Wallet size={22} /></div>
              {netProfit >= 0 ? <TrendingUp size={18} className="text-emerald-500" /> : <TrendingDown size={18} className="text-rose-500" />}
            </div>
            <p className="text-xs font-bold text-brand-400 mb-1">صافي أرباح السنتر</p>
            <p className={`text-2xl font-extrabold ${netProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{formatEGP(netProfit)}</p>
            <p className="text-[10px] text-brand-300 mt-1">هامش الربح: {profitMargin}%</p>
          </div>
        </Card>
      </div>

      <Card className="p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-brand-900">هامش الربح</h3>
          <Badge tone={profitMargin >= 50 ? 'emerald' : profitMargin >= 20 ? 'amber' : 'rose'}>{profitMargin}%</Badge>
        </div>
        <div className="h-4 rounded-full bg-slate-100 overflow-hidden">
          <div className={`h-full rounded-full transition-all duration-700 ${profitMargin >= 50 ? 'bg-gradient-to-l from-emerald-400 to-emerald-600' : profitMargin >= 20 ? 'bg-gradient-to-l from-amber-400 to-amber-600' : 'bg-gradient-to-l from-rose-400 to-rose-600'}`} style={{ width: `${Math.max(0, Math.min(100, profitMargin))}%` }} />
        </div>
        <div className="flex justify-between text-[10px] text-brand-300 mt-2 font-semibold"><span>0%</span><span>50%</span><span>100%</span></div>
      </Card>

      <Card className="p-5">
        <h3 className="text-sm font-bold text-brand-900 mb-4">تفصيل مصادر الإيرادات</h3>
        <div className="space-y-3">
          {revenueBreakdown.map((item, idx) => (
            <div key={idx} className="flex items-center gap-3">
              <div className={`grid place-items-center h-10 w-10 rounded-2xl shrink-0 ${item.tone === 'brand' ? 'bg-brand-100 text-brand-600' : item.tone === 'emerald' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                <item.icon size={18} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-bold text-brand-900">{item.label}</span>
                  <span className="text-sm font-extrabold text-brand-900">{formatEGP(item.amount)}</span>
                </div>
                <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div className={`h-full rounded-full transition-all duration-500 ${item.tone === 'brand' ? 'bg-brand-500' : item.tone === 'emerald' ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${(item.amount / maxRevenue) * 100}%` }} />
                </div>
              </div>
            </div>
          ))}
          <div className="border-t border-slate-100 pt-3 flex items-center justify-between">
            <span className="text-sm font-bold text-brand-900">الإجمالي</span>
            <span className="text-lg font-extrabold text-brand-900">{formatEGP(centerRevenue)}</span>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5">
          <h3 className="text-sm font-bold text-brand-900 mb-3">أحدث المصروفات</h3>
          {db.expenses.length === 0 ? (
            <p className="text-sm text-brand-300 text-center py-6">لا توجد مصروفات</p>
          ) : (
            <div className="space-y-2">
              {[...db.expenses].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5).map((exp) => (
                <div key={exp.id} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                  <div><p className="text-sm font-semibold text-brand-900">{exp.categoryLabel}</p><p className="text-[10px] text-brand-300">{formatDate(exp.date)}</p></div>
                  <Badge tone="rose">{formatEGP(exp.amount)}</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
        <Card className="p-5">
          <h3 className="text-sm font-bold text-brand-900 mb-3">أحدث مرتبات السكرتارية</h3>
          {db.salaries.length === 0 ? (
            <p className="text-sm text-brand-300 text-center py-6">لا توجد مرتبات مسجلة</p>
          ) : (
            <div className="space-y-2">
              {[...db.salaries].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5).map((sal) => (
                <div key={sal.id} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                  <div><p className="text-sm font-semibold text-brand-900">{sal.userName}</p><p className="text-[10px] text-brand-300">{formatDate(sal.date)}</p></div>
                  <Badge tone="amber">{formatEGP(sal.net)}</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
