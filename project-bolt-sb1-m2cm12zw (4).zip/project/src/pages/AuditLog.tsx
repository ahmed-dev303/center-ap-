import { useState, useMemo } from 'react';
import { History, Search, User, Clock, Activity, Lock, Calendar, RefreshCw } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth, roleLabel } from '../context/AuthContext';
import { Card } from '../components/ui/Card';
import { Input, Select } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { EmptyState } from '../components/ui/EmptyState';

export function AuditLog() {
  const { db } = useDB();
  const { user } = useAuth();

  if (user?.role !== 'admin') {
    return (
      <div className="grid place-items-center py-20">
        <div className="text-center">
          <div className="grid place-items-center h-20 w-20 rounded-3xl bg-rose-50 text-rose-400 mx-auto mb-4">
            <Lock size={36} />
          </div>
          <h3 className="text-lg font-bold text-brand-900 mb-1">صلاحية محظورة</h3>
          <p className="text-sm text-brand-400">هذه الصفحة متاحة للمدير فقط.</p>
        </div>
      </div>
    );
  }

  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const actionTypes = useMemo(() => {
    const set = new Set(db.auditLog.map((a) => a.action));
    return Array.from(set).sort();
  }, [db.auditLog]);

  const filtered = useMemo(() => {
    return db.auditLog
      .filter((a) => {
        if (actionFilter && a.action !== actionFilter) return false;
        if (search && !a.detail.includes(search) && !a.actorName.includes(search)) return false;
        const entryDate = a.timestamp.slice(0, 10);
        if (dateFrom && entryDate < dateFrom) return false;
        if (dateTo && entryDate > dateTo) return false;
        return true;
      })
      .sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }, [db.auditLog, search, actionFilter, dateFrom, dateTo]);

  const resetFilters = () => {
    setSearch('');
    setActionFilter('');
    setDateFrom('');
    setDateTo('');
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 flex items-center gap-2">
          <History size={24} /> سجل الحركات والأمان
        </h2>
        <p className="text-sm text-brand-400 mt-0.5">{filtered.length} حركة مسجلة</p>
      </div>

      <div className="rounded-2xl bg-rose-50 border border-rose-200 px-4 py-2.5 flex items-center gap-2">
        <Lock size={16} className="text-rose-600" />
        <span className="text-xs font-semibold text-rose-700">هذا السجل للقراءة فقط ولا يمكن تعديله أو مسحه من قبل المستخدمين العاديين.</span>
      </div>

      <Card className="p-4" glass={false}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <Input icon={<Search size={18} />} placeholder="بحث في التفاصيل أو اسم المستخدم..." value={search} onChange={(e) => setSearch(e.target.value)} />
          <Select value={actionFilter} onChange={(e) => setActionFilter(e.target.value)}>
            <option value="">كل الحركات</option>
            {actionTypes.map((a) => <option key={a} value={a}>{a}</option>)}
          </Select>
          <Input label="" type="date" icon={<Calendar size={18} />} value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
          <Input label="" type="date" icon={<Calendar size={18} />} value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
        </div>
        {(search || actionFilter || dateFrom || dateTo) && (
          <button onClick={resetFilters} className="mt-3 text-xs font-bold text-brand-500 hover:text-brand-700 flex items-center gap-1 transition-colors">
            <RefreshCw size={12} /> إلغاء الفلاتر
          </button>
        )}
      </Card>

      {filtered.length === 0 ? (
        <EmptyState icon={<Activity size={36} />} title="لا توجد حركات مسجلة" description="ستظهر هنا جميع العمليات التي يتم تنفيذها في النظام" />
      ) : (
        <div className="space-y-2.5">
          {filtered.map((entry) => (
            <Card key={entry.id} className="p-4" hover>
              <div className="flex items-start gap-3">
                <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-600 shrink-0">
                  <Activity size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge tone="brand" className="text-xs">{entry.action}</Badge>
                    <span className="text-xs text-brand-400 flex items-center gap-1">
                      <User size={12} /> {entry.actorName} ({roleLabel(entry.actorRole)})
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-brand-900 mt-1">{entry.detail}</p>
                  <p className="text-[10px] text-brand-300 mt-1 flex items-center gap-1">
                    <Clock size={10} /> {new Date(entry.timestamp).toLocaleString('ar-EG')}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
