import { useState, useMemo } from 'react';
import { Wallet, Plus, Search, Trash2, X, TrendingUp, Calendar, BookOpen, CreditCard, CalendarCheck, Users2, Users, Printer, Lock } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { useCenter } from '../context/CenterContext';
import { useToast } from '../context/ToastContext';
import { getScopedData, filterByCenter, canSecretaryAccessFeature, studentGroupIds } from '../lib/scoping';
import { todayStr, currentMonthStr, formatEGP, formatDate, monthName, uid } from '../lib/date';
import { logAction, discountedSessionFee } from '../lib/finance';
import { printReceipt } from '../lib/receipt';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { StudentSearch } from '../components/StudentSearch';
import type { Payment, PaymentType, StudyMaterial } from '../lib/types';
import type { Student, Group } from '../lib/types';

export function Payments() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { selectedCenterId } = useCenter();
  const { showToast } = useToast();
  const roleScoped = getScopedData(db, user);
  const scoped = {
    students: filterByCenter(roleScoped.students, selectedCenterId),
    groups: filterByCenter(roleScoped.groups, selectedCenterId),
    attendance: roleScoped.attendance,
    payments: filterByCenter(roleScoped.payments, selectedCenterId),
    materials: roleScoped.materials,
    auditLog: roleScoped.auditLog,
  };

  if (!canSecretaryAccessFeature(user, 'payments')) {
    return (
      <div className="grid place-items-center py-20">
        <div className="text-center">
          <div className="grid place-items-center h-20 w-20 rounded-3xl bg-amber-50 text-amber-400 mx-auto mb-4">
            <Lock size={36} />
          </div>
          <h3 className="text-lg font-bold text-brand-900 mb-1">خاصية غير متاحة</h3>
          <p className="text-sm text-brand-400">⚠️ هذه الخاصية غير متاحة لنوع ربط السكرتير بهذا المدرس</p>
        </div>
      </div>
    );
  }

  const [search, setSearch] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [groupFilter, setGroupFilter] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const months = useMemo(() => {
    const set = new Set(scoped.payments.map((p) => p.month));
    return Array.from(set).sort().reverse();
  }, [scoped.payments]);

  const filtered = useMemo(() => {
    return [...scoped.payments]
      .filter((p) => {
        if (monthFilter && p.month !== monthFilter) return false;
        if (groupFilter && p.groupId !== groupFilter) return false;
        if (search) {
          const student = scoped.students.find((s) => s.id === p.studentId);
          if (!student?.name.includes(search) && !String(p.studentId).includes(search)) return false;
        }
        return true;
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [scoped.payments, scoped.students, search, monthFilter, groupFilter]);

  const totalRevenue = filtered.reduce((sum, p) => sum + p.amount, 0);

  const handleSave = (data: Omit<Payment, 'id' | 'createdAt'>, materialId?: string) => {
    const branchId = selectedCenterId || data.branchId || (data.studentId ? db.students.find((s) => s.id === data.studentId)?.branchId ?? null : null);
    const groupName = data.groupId ? db.groups.find((g) => g.id === data.groupId)?.name || '' : '';
    update((d) => {
      d.payments.push({ ...data, groupName, branchId, collectedBy: user?.name || '', id: uid('pay'), createdAt: new Date().toISOString() });
      if (materialId) {
        const mat = d.materials.find((m) => m.id === materialId);
        if (mat) mat.stock = Math.max(0, mat.stock - 1);
      }
      const sname = d.students.find((s) => s.id === data.studentId)?.name || '';
      const gname = groupName ? ` في مجموعة ${groupName}` : '';
      let typeLabel: string;
      if (data.paymentType === 'session') {
        typeLabel = `تم تحصيل مبلغ ${formatEGP(data.amount)} ج.م (دفع شهري) من الطالب ${sname}${gname} بواسطة ${user?.name || ''}`;
      } else if (data.paymentType === 'book') {
        typeLabel = `تم بيع ${data.bookTitle || 'مذكرة'} بمبلغ ${formatEGP(data.amount)} ج.م للطالب ${sname}${gname} بواسطة ${user?.name || ''}`;
      } else {
        typeLabel = `تم تحصيل رسوم كارت الـ ID بقيمة ${formatEGP(data.amount)} ج.م للطالب ${sname}${gname} بواسطة ${user?.name || ''}`;
      }
      logAction(d, 'تسجيل دفعة', typeLabel, user?.name || '', user?.role || 'admin');
    });
    showToast('تم تسجيل الدفعة بنجاح');
    setShowForm(false);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    update((d) => {
      const p = d.payments.find((pp) => pp.id === deleteId);
      const sname = p ? d.students.find((s) => s.id === p.studentId)?.name || '' : '';
      if (p && p.paymentType === 'book' && p.bookTitle) {
        const mat = d.materials.find((m) => m.title === p.bookTitle);
        if (mat) mat.stock += 1;
      }
      d.payments = d.payments.filter((p) => p.id !== deleteId);
      logAction(d, 'حذف دفعة', `حذف دفعة ${p ? formatEGP(p.amount) : ''} للطالب ${sname}`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف الدفعة', 'info');
    setDeleteId(null);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900">سجل المدفوعات</h2>
          <p className="text-sm text-brand-400 mt-0.5">{filtered.length} دفعة</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus size={18} /> دفعة جديدة
        </Button>
      </div>

      {/* Revenue summary — hidden from secretary (financially blind) */}
      {user?.role !== 'secretary' && (
        <Card className="p-5 relative overflow-hidden">
          <div className="absolute top-0 left-0 h-32 w-32 rounded-full bg-emerald-300/20 blur-2xl" />
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="grid place-items-center h-12 w-12 rounded-2xl bg-emerald-100 text-emerald-600">
                <TrendingUp size={24} />
              </div>
              <div>
                <p className="text-sm text-brand-400 font-semibold">إجمالي المدفوعات (النتائج المصفاة)</p>
                <p className="text-2xl sm:text-3xl font-extrabold text-emerald-600">{formatEGP(totalRevenue)}</p>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Filters */}
      <Card className="p-4" glass={false}>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <Input icon={<Search size={18} />} placeholder="بحث باسم الطالب أو الكود..." value={search} onChange={(e) => setSearch(e.target.value)} />
          <Select value={groupFilter} onChange={(e) => setGroupFilter(e.target.value)}>
            <option value="">كل المجموعات</option>
            {scoped.groups.map((g) => (
              <option key={g.id} value={g.id}>{g.name}</option>
            ))}
          </Select>
          <Select value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)}>
            <option value="">كل الشهور</option>
            {months.map((m) => (
              <option key={m} value={m}>{monthName(m)}</option>
            ))}
          </Select>
        </div>
      </Card>

      {/* Payments list */}
      {filtered.length === 0 ? (
        <EmptyState icon={<Wallet size={36} />} title="لا توجد مدفوعات" description="سجل أول دفعة لطالب" action={<Button onClick={() => setShowForm(true)}><Plus size={18} /> دفعة جديدة</Button>} />
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden lg:block overflow-hidden" glass={false}>
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-brand-50 text-brand-700 text-right">
                  <th className="px-4 py-3 font-bold">الكود</th>
                  <th className="px-4 py-3 font-bold">الطالب</th>
                  <th className="px-4 py-3 font-bold">المجموعة</th>
                  <th className="px-4 py-3 font-bold">المبلغ</th>
                  <th className="px-4 py-3 font-bold">نوع الدفع</th>
                  <th className="px-4 py-3 font-bold">الشهر</th>
                  <th className="px-4 py-3 font-bold">التاريخ</th>
                  <th className="px-4 py-3 font-bold">المستلم</th>
                  <th className="px-4 py-3 font-bold">طريقة الدفع</th>
                  <th className="px-4 py-3 font-bold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((p) => {
                  const student = scoped.students.find((s) => s.id === p.studentId);
                  return (
                    <tr key={p.id} className="hover:bg-brand-50/40 transition-colors">
                      <td className="px-4 py-3"><Badge tone="brand">{p.studentId}</Badge></td>
                      <td className="px-4 py-3 font-bold text-brand-900">{student?.name || 'طالب محذوف'}</td>
                      <td className="px-4 py-3"><Badge tone="brand" className="text-[10px]">{scoped.groups.find((g) => g.id === p.groupId)?.name || '—'}</Badge></td>
                      <td className="px-4 py-3"><Badge tone="emerald">{formatEGP(p.amount)}</Badge></td>
                      <td className="px-4 py-3">{paymentTypeBadge(p.paymentType, p.bookTitle)}</td>
                      <td className="px-4 py-3 text-brand-600">{monthName(p.month)}</td>
                      <td className="px-4 py-3 text-brand-600">{formatDate(p.date)}</td>
                      <td className="px-4 py-3 text-brand-600 text-xs font-semibold">{p.note && p.note.includes('بواسطة') ? p.note.split('بواسطة')[1]?.trim() || '—' : '—'}</td>
                      <td className="px-4 py-3 text-brand-600">{p.method === 'cash' ? 'نقدي' : p.method === 'card' ? 'بطاقة' : 'تحويل'}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <button onClick={() => printReceipt(p, student, scoped.groups.find((g) => g.id === p.groupId))} className="grid place-items-center h-8 w-8 rounded-lg bg-brand-50 text-brand-600 hover:bg-brand-100" title="طباعة إيصال">
                            <Printer size={16} />
                          </button>
                          <button onClick={() => setDeleteId(p.id)} className="grid place-items-center h-8 w-8 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100" title="حذف">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards */}
          <div className="lg:hidden space-y-3">
            {filtered.map((p) => {
              const student = scoped.students.find((s) => s.id === p.studentId);
              return (
                <Card key={p.id} className="p-4" hover>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="grid place-items-center h-11 w-11 rounded-2xl bg-emerald-100 text-emerald-700 font-bold">
                        {student?.name?.charAt(0) || '?'}
                      </div>
                      <div>
                        <h3 className="font-bold text-brand-900">{student?.name || 'طالب محذوف'}</h3>
                        <Badge tone="brand" className="text-[10px]">#{p.studentId}</Badge>
                      </div>
                    </div>
                    <Badge tone="emerald">{formatEGP(p.amount)}</Badge>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    {paymentTypeBadge(p.paymentType, p.bookTitle)}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-brand-600">
                    <Users size={14} className="text-brand-400" />
                    {scoped.groups.find((g) => g.id === p.groupId)?.name || '—'}
                  </div>
                  <div className="flex items-center justify-between text-xs text-brand-400 font-semibold">
                    <span className="flex items-center gap-1"><Calendar size={12} /> {monthName(p.month)}</span>
                    <span>{p.method === 'cash' ? 'نقدي' : p.method === 'card' ? 'بطاقة' : 'تحويل'}</span>
                    <span>{formatDate(p.date)}</span>
                  </div>
                  <div className="flex gap-2 mt-2">
                    <button onClick={() => printReceipt(p, student, scoped.groups.find((g) => g.id === p.groupId))} className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-brand-50 text-brand-600 text-xs font-bold hover:bg-brand-100 transition-colors">
                      <Printer size={14} /> طباعة إيصال
                    </button>
                    <button onClick={() => setDeleteId(p.id)} className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-rose-50 text-rose-500 text-xs font-bold hover:bg-rose-100 transition-colors">
                      <Trash2 size={14} /> حذف
                    </button>
                  </div>
                </Card>
              );
            })}
          </div>
        </>
      )}

      {showForm && (
        <PaymentForm students={scoped.students} groups={scoped.groups} gradePrices={db.gradePrices} materials={db.materials} idCardPrice={db.idCardPrice} isAdmin={user?.role === 'admin'} onClose={() => setShowForm(false)} onSave={handleSave} />
      )}
      <ConfirmDialog open={deleteId !== null} title="حذف الدفعة" message="سيتم حذف سجل هذه الدفعة. هل أنت متأكد؟" confirmText="حذف" danger onConfirm={handleDelete} onCancel={() => setDeleteId(null)} />
    </div>
  );
}

function paymentTypeBadge(type: PaymentType, bookTitle?: string) {
  if (type === 'session') return <Badge tone="brand" className="text-[10px] flex items-center gap-1 w-fit"><CalendarCheck size={10} /> رسوم شهرية</Badge>;
  if (type === 'book') return <Badge tone="violet" className="text-[10px] flex items-center gap-1 w-fit"><BookOpen size={10} /> {bookTitle || 'كتب'}</Badge>;
  return <Badge tone="amber" className="text-[10px] flex items-center gap-1 w-fit"><CreditCard size={10} /> كارت ID</Badge>;
}

function PaymentForm({ students, groups, gradePrices, materials, idCardPrice, isAdmin, onClose, onSave }: {
  students: Student[];
  groups: Group[];
  gradePrices: { grade: string; price: number }[];
  materials: StudyMaterial[];
  idCardPrice: number;
  isAdmin: boolean;
  onClose: () => void;
  onSave: (data: Omit<Payment, 'id' | 'createdAt'>, materialId?: string) => void;
}) {
  const [studentId, setStudentId] = useState<number | ''>('');
  const [paymentType, setPaymentType] = useState<PaymentType>('session');
  const [amount, setAmount] = useState('');
  const [month, setMonth] = useState(currentMonthStr());
  const [date, setDate] = useState(todayStr());
  const [method, setMethod] = useState<Payment['method']>('cash');
  const [note, setNote] = useState('');
  const [selectedBookId, setSelectedBookId] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState<string>('');

  const selectedStudent = students.find((s) => s.id === studentId);
  const defaultPrice = selectedStudent ? gradePrices.find((gp) => gp.grade === selectedStudent.grade) : null;
  const studentGroups = selectedStudent ? studentGroupIds(selectedStudent).map((gid) => groups.find((g) => g.id === gid)).filter(Boolean) as Group[] : [];
  const groupMaterials = selectedStudent ? materials.filter((m) => studentGroupIds(selectedStudent).includes(m.groupId)) : [];

  const handleStudentSelect = (student: Student) => {
    setStudentId(student.id);
    const sGids = studentGroupIds(student);
    if (sGids.length === 1) {
      setSelectedGroupId(sGids[0]);
    } else {
      setSelectedGroupId('');
    }
    if (paymentType === 'session') {
      const price = gradePrices.find((gp) => gp.grade === student.grade);
      if (price) setAmount(String(discountedSessionFee(price.price, student)));
    }
  };

  const handleTypeChange = (type: PaymentType) => {
    setPaymentType(type);
    setSelectedBookId('');
    if (type === 'session') {
      if (selectedStudent) {
        const price = gradePrices.find((gp) => gp.grade === selectedStudent.grade);
        if (price) setAmount(String(discountedSessionFee(price.price, selectedStudent)));
      }
    } else if (type === 'id') {
      setAmount(String(idCardPrice));
    } else {
      setAmount('');
    }
  };

  const handleBookSelect = (bookId: string) => {
    setSelectedBookId(bookId);
    const book = groupMaterials.find((m) => m.id === bookId);
    if (book) setAmount(String(book.price));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId || !amount) return;
    const student = students.find((s) => s.id === studentId);
    const book = selectedBookId ? groupMaterials.find((m) => m.id === selectedBookId) : undefined;
    onSave({
      studentId: Number(studentId),
      groupId: selectedGroupId || null,
      branchId: student?.branchId ?? null,
      amount: Number(amount),
      date,
      month,
      method,
      paymentType,
      bookTitle: paymentType === 'book' ? book?.title : undefined,
      note: note.trim(),
      discountType: student?.discountType ?? 'none',
      discountPercent: student?.hasSiblingDiscount ? student.discountPercent : undefined,
    }, paymentType === 'book' ? selectedBookId : undefined);
  };

  const typeOptions: { value: PaymentType; label: string; icon: typeof Wallet }[] = [
    { value: 'session', label: 'رسوم شهرية', icon: CalendarCheck },
    { value: 'book', label: 'كتب / مذكرات', icon: BookOpen },
    { value: 'id', label: 'كارت ID', icon: CreditCard },
  ];

  return (
    <Modal open onClose={onClose} title="تسجيل دفعة جديدة" size="md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-brand-700 mb-1.5">الطالب</label>
          {studentId ? (
            <div className="flex items-center justify-between rounded-xl border-2 border-brand-500 bg-brand-50 px-4 py-3">
              <div className="flex items-center gap-2">
                <span className="font-bold text-brand-900">{selectedStudent?.name}</span>
                <Badge tone="brand" className="text-[10px]">#{studentId}</Badge>
              </div>
              <button type="button" onClick={() => setStudentId('')} className="text-brand-400 hover:text-rose-500">
                <X size={18} />
              </button>
            </div>
          ) : (
            <StudentSearch students={students} groups={groups} onSelect={handleStudentSelect} placeholder="ابحث بالاسم أو الكود لاختيار الطالب..." />
          )}
        </div>

        {/* Group selection */}
        {selectedStudent && studentGroups.length > 0 && (
          <div className="animate-fade-in">
            <Select
              label="المجموعة (مطلوب)"
              value={selectedGroupId}
              onChange={(e) => setSelectedGroupId(e.target.value)}
              required
            >
              <option value="">اختر المجموعة...</option>
              {studentGroups.map((g) => (
                <option key={g.id} value={g.id}>{g.name}</option>
              ))}
            </Select>
            {studentGroups.length > 1 && (
              <p className="text-xs text-brand-400 mt-1">الطالب مسجل في {studentGroups.length} مجموعات — اختر المجموعة المستهدف لها الدفع</p>
            )}
          </div>
        )}

        {/* Payment Type Selector */}
        <div>
          <span className="block mb-2 text-sm font-semibold text-brand-900">نوع الدفع</span>
          <div className="grid grid-cols-3 gap-2">
            {typeOptions.map((opt) => {
              const active = paymentType === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => handleTypeChange(opt.value)}
                  className={`flex flex-col items-center gap-1.5 rounded-2xl p-3 transition-all duration-200 border-2 ${
                    active
                      ? 'gradient-brand text-white shadow-soft border-transparent'
                      : 'bg-brand-50/50 text-brand-600 border-transparent hover:bg-brand-50'
                  }`}
                >
                  <opt.icon size={20} />
                  <span className="text-xs font-bold">{opt.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {paymentType === 'book' && (
          <div className="animate-fade-in">
            {groupMaterials.length === 0 ? (
              <div className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-3 text-sm font-semibold text-amber-700">
                لا توجد كتب/مذكرات مخصصة لمجموعة هذا الطالب
              </div>
            ) : (
              <Select label="اختر الكتاب / المذكرة" value={selectedBookId} onChange={(e) => handleBookSelect(e.target.value)} required>
                <option value="">اختر كتاب...</option>
                {groupMaterials.map((m) => (
                  <option key={m.id} value={m.id} disabled={m.stock <= 0}>
                    {m.title} — {m.price} ج.م ({m.stock > 0 ? `${m.stock} متوفر` : 'نفد'})
                  </option>
                ))}
              </Select>
            )}
          </div>
        )}

        {defaultPrice && paymentType === 'session' && (
          <div className="rounded-2xl bg-brand-50 px-4 py-2.5 flex items-center justify-between">
            <span className="text-sm font-semibold text-brand-600">الرسوم المستحقة</span>
            <Badge tone="brand">{formatEGP(selectedStudent ? discountedSessionFee(defaultPrice.price, selectedStudent) : defaultPrice.price)}</Badge>
          </div>
        )}
        {isAdmin && selectedStudent?.hasSiblingDiscount && selectedStudent.discountPercent ? (
          <div className={`rounded-2xl border px-4 py-2.5 flex items-center gap-2 ${selectedStudent.discountType === 'twin' ? 'bg-violet-50 border-violet-200' : 'bg-amber-50 border-amber-200'}`}>
            {selectedStudent.discountType === 'twin' ? <Users size={16} className="text-violet-600" /> : <Users2 size={16} className="text-amber-600" />}
            <span className={`text-sm font-semibold ${selectedStudent.discountType === 'twin' ? 'text-violet-700' : 'text-amber-700'}`}>
              {selectedStudent.discountType === 'twin' ? 'خصم توأم' : 'خصم أشقاء'} {selectedStudent.discountPercent}% مطبّق على هذا الطالب
            </span>
          </div>
        ) : null}
        <Input label="المبلغ (ج.م)" type="number" placeholder="0" value={amount} onChange={(e) => setAmount(e.target.value)} required />
        <div className="grid grid-cols-2 gap-3">
          <Input label="الشهر" type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
          <Input label="التاريخ" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        <Select label="طريقة الدفع" value={method} onChange={(e) => setMethod(e.target.value as Payment['method'])}>
          <option value="cash">نقدي</option>
          <option value="card">بطاقة</option>
          <option value="transfer">تحويل</option>
        </Select>
        <Input label="ملاحظات" placeholder="اختياري" value={note} onChange={(e) => setNote(e.target.value)} />
        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إلغاء</Button>
          <Button type="submit" className="flex-1">تسجيل الدفعة</Button>
        </div>
      </form>
    </Modal>
  );
}
