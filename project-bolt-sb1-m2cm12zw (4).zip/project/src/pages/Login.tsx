import { useState, useRef } from 'react';
import { GraduationCap, User, Lock, LogIn, Upload, Database, ShieldCheck, KeyRound } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { saveDB } from '../lib/db';
import { useFiveClickGesture } from '../hooks/useFiveClickGesture';
import type { Database as DBType } from '../lib/types';

export function Login() {
  const { login, loginMaster } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const [masterModalOpen, setMasterModalOpen] = useState(false);
  const [masterPin, setMasterPin] = useState('');
  const [masterError, setMasterError] = useState('');

  const handleLogoClicks = useFiveClickGesture(() => setMasterModalOpen(true));

  const handleMasterLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setMasterError('');
    const ok = loginMaster(masterPin);
    if (!ok) {
      setMasterError('الكود السري غير صحيح');
      setMasterPin('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    (async () => {
      try {
        const ok = await login(username, password);
        if (!ok) setError('اسم المستخدم أو كلمة المرور غير صحيحة');
      } catch {
        setError('حدث خطأ أثناء تسجيل الدخول');
      } finally {
        setLoading(false);
      }
    })();
  };

  const fileRef = useRef<HTMLInputElement>(null);
  const [importMsg, setImportMsg] = useState('');
  const [importing, setImporting] = useState(false);

  const handleImportFile = async (file: File) => {
    setImporting(true);
    setImportMsg('');
    try {
      const text = await file.text();
      const incoming = JSON.parse(text) as DBType;
      if (!incoming.users || !incoming.students) {
        setImportMsg('ملف غير صالح — تأكد من أنه نسخة احتياطية صحيحة');
        setImporting(false);
        return;
      }
      saveDB(incoming);
      setImportMsg('تم استيراد قاعدة البيانات بنجاح! يمكنك تسجيل الدخول الآن');
    } catch {
      setImportMsg('فشل قراءة الملف');
      setImporting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImportFile(file);
    if (fileRef.current) fileRef.current.value = '';
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative blobs */}
      <div className="absolute -top-32 -right-32 h-80 w-80 rounded-full bg-brand-400/30 blur-3xl" />
      <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-violet-400/30 blur-3xl" />
      <div className="absolute top-1/2 left-1/3 h-64 w-64 rounded-full bg-brand-300/20 blur-3xl" />

      <div className="relative w-full max-w-md animate-scale-in">
        {/* Logo header */}
        <div className="text-center mb-8">
          <div
            className="inline-grid place-items-center h-20 w-20 rounded-3xl gradient-brand shadow-glow mb-4 cursor-pointer select-none"
            onClick={handleLogoClicks}
            title="—"
          >
            <GraduationCap size={40} className="text-white" />
          </div>
          <h1 className="text-2xl font-extrabold text-brand-900">سنتر الأفضل</h1>
          <p className="text-sm text-brand-400 mt-1">برنامج إدارة متكامل للسنتر التعليمي</p>
        </div>

        {/* Login card */}
        <div className="glass rounded-3xl shadow-glass p-6 sm:p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="اسم المستخدم"
              icon={<User size={18} />}
              placeholder="أدخل اسم المستخدم"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="off"
              required
            />
            <Input
              label="كلمة المرور"
              icon={<Lock size={18} />}
              type="password"
              placeholder="أدخل كلمة المرور"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            {error && (
              <div className="animate-fade-in rounded-2xl bg-rose-50 border border-rose-200 px-4 py-2.5 text-sm font-semibold text-rose-600">
                {error}
              </div>
            )}

            <Button type="submit" size="lg" className="w-full" disabled={loading}>
              <LogIn size={20} />
              {loading ? 'جاري الدخول...' : 'تسجيل الدخول'}
            </Button>
          </form>

          {/* Import backup before login */}
          <div className="mt-6 pt-5 border-t border-white/40">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={importing}
              className="w-full rounded-2xl border-2 border-brand-200 bg-brand-50/50 px-4 py-3.5 flex items-center gap-3 text-right transition-all hover:bg-brand-50 hover:border-brand-300 active:scale-[0.98] disabled:opacity-50"
            >
              <div className="grid place-items-center h-10 w-10 rounded-xl bg-brand-100 text-brand-600 shrink-0">
                {importing ? <Database size={18} className="animate-pulse" /> : <Upload size={18} />}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-brand-900">استيراد قاعدة البيانات (Import Backup)</p>
                <p className="text-xs text-brand-400">استعادة نسختك الاحتياطية على جهاز جديد قبل الدخول</p>
              </div>
            </button>
            <input ref={fileRef} type="file" accept="application/json,.json" onChange={handleFileChange} className="hidden" />
            {importMsg && (
              <div className={`mt-2.5 rounded-2xl px-4 py-2.5 text-sm font-semibold animate-fade-in ${importMsg.includes('بنجاح') ? 'bg-emerald-50 border border-emerald-200 text-emerald-700' : 'bg-rose-50 border border-rose-200 text-rose-600'}`}>
                {importMsg}
              </div>
            )}
          </div>

        </div>

        <p className="text-center text-xs text-brand-300 mt-6">
          © 2026 سنتر الأفضل — جميع الحقوق محفوظة
        </p>
      </div>

      {/* Master PIN Modal */}
      <Modal open={masterModalOpen} onClose={() => { setMasterModalOpen(false); setMasterPin(''); setMasterError(''); }} title="دخول المالك الفائق" size="sm">
        <form onSubmit={handleMasterLogin} className="space-y-4">
          <div className="flex flex-col items-center gap-3 py-2">
            <div className="grid place-items-center h-16 w-16 rounded-3xl bg-gradient-to-br from-slate-800 to-slate-950 shadow-lg">
              <ShieldCheck size={32} className="text-amber-400" />
            </div>
            <p className="text-sm text-center text-brand-500 font-semibold">
              أدخل الكود السري للمالك للوصول إلى لوحة تحكم الأجهزة والتراخيص
            </p>
          </div>
          <Input
            label="الكود السري"
            icon={<KeyRound size={18} />}
            type="password"
            placeholder="••••••"
            value={masterPin}
            onChange={(e) => setMasterPin(e.target.value)}
            autoFocus
            required
          />
          {masterError && (
            <div className="animate-fade-in rounded-2xl bg-rose-50 border border-rose-200 px-4 py-2.5 text-sm font-semibold text-rose-600">
              {masterError}
            </div>
          )}
          <Button type="submit" size="lg" className="w-full">
            <ShieldCheck size={20} />
            دخول المالك الفائق
          </Button>
        </form>
      </Modal>
    </div>
  );
}
