import { useState, useMemo } from 'react';
import { FileStack, Plus, Search, Trash2, Edit3, X, BookOpen, FileText, Package, DollarSign, ShoppingCart, Lock } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth, canManageMaterials, canSellMaterials } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { getScopedData, canSecretaryAccessFeature } from '../lib/scoping';
import { uid, formatDate, todayStr, currentMonthStr, formatEGP } from '../lib/date';
import { logAction } from '../lib/finance';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select, Textarea } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { StudentSearch } from '../components/StudentSearch';
import type { StudyMaterial, Student, Payment } from '../lib/types';

export function Materials() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { showToast } = useToast();
  const scoped = getScopedData(db, user);
  const canManage = canManageMaterials(user?.role);
  const canSell = canSellMaterials(user?.role);

  if (!canSecretaryAccessFeature(user, 'payments')) {
    return (
      <div className="grid place-items-center py-20">
        <div className="text-center">
          <div className="grid place-items-center h-20 w-20 rounded-3xl bg-amber-50 text-amber-400 mx-auto mb-4">
            <Lock size={36} />
          </div>
          <h3 className="text-lg font-bold text-brand-900 mb-1">خاصية غير متاحة</h3>
          <p className="text-sm text-brand-400">⚠️ هذه الخاصية غير متاحة لنوع ربط السكرتير بهذا المدرس</p>
        </div>
      </div>
    );
  }

  const [search, setSearch] = useState('');
  const [groupFilter, setGroupFilter] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<StudyMaterial | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [sellMaterial, setSellMaterial] = useState<StudyMaterial | null>(null);

  const availableGroups = scoped.groups;

  const filtered = useMemo(() => {
    return scoped.materials
      .filter((m) => {
        if (groupFilter && m.groupId !== groupFilter) return false;
        if (search && !m.title.includes(search)) return false;
        return true;
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [scoped.materials, search, groupFilter]);

  const handleSave = (data: Omit<StudyMaterial, 'id' | 'createdAt'> & { id?: string }) => {
    update((d) => {
      if (editing) {
        const idx = d.materials.findIndex((m) => m.id === editing.id);
        if (idx >= 0) d.materials[idx] = { ...d.materials[idx], ...data };
        logAction(d, 'تعديل مذكرة', `تم تعديل المذكرة: ${data.title}`, user?.name || '', user?.role || 'admin');
      } else {
        d.materials.push({ ...data, id: uid('mat'), createdAt: new Date().toISOString() } as StudyMaterial);
        logAction(d, 'إضافة مذكرة', `تم إضافة المذكرة: ${data.title}`, user?.name || '', user?.role || 'admin');
      }
    });
    showToast(editing ? 'تم تحديث المذكرة' : 'تم إضافة المذكرة بنجاح');
    setShowForm(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const mtitle = db.materials.find((m) => m.id === deleteId)?.title || '';
    update((d) => {
      d.materials = d.materials.filter((m) => m.id !== deleteId);
      logAction(d, 'حذف مذكرة', `تم حذف المذكرة: ${mtitle}`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف المذكرة', 'info');
    setDeleteId(null);
  };

  const handleSellNote = (material: StudyMaterial, student: Student) => {
    if (material.stock <= 0) {
      showToast('⚠️ المخزون نفد — لا يمكن بيع هذه المذكرة', 'error');
      return;
    }
    update((d) => {
      const mat = d.materials.find((m) => m.id === material.id);
      if (mat) mat.stock = Math.max(0, mat.stock - 1);
      const payment: Omit<Payment, 'id' | 'createdAt'> = {
        studentId: student.id,
        groupId: student.groupId,
        branchId: student.branchId ?? null,
        amount: material.price,
        date: todayStr(),
        month: currentMonthStr(),
        method: 'cash',
        paymentType: 'book',
        bookTitle: material.title,
        note: `بيع مذكرة: ${material.title}`,
      };
      d.payments.push({ ...payment, id: uid('pay'), createdAt: new Date().toISOString() });
      logAction(d, 'بيع مذكرة', `قام ${user?.name || ''} ببيع مذكرة "${material.title}" للطالب ${student.name} بمبلغ ${formatEGP(material.price)} ج.م.`, user?.name || '', user?.role || 'admin');
    });
    showToast(`تم بيع مذكرة "${material.title}" للطالب ${student.name} بنجاح`);
    setSellMaterial(null);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 flex items-center gap-2">
            <FileStack size={24} /> المذكرات الدراسية
          </h2>
          <p className="text-sm text-brand-400 mt-0.5">{filtered.length} مذكرة</p>
        </div>
        {canManage && (
          <Button onClick={() => { setEditing(null); setShowForm(true); }}>
            <Plus size={18} /> مذكرة جديدة
          </Button>
        )}
      </div>

      {user?.role === 'secretary' && (
        <div className="flex items-center gap-2 rounded-2xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-sm font-semibold text-amber-700">
          <Lock size={16} />
          يمكنك بيع المذكرات للطلاب فقط — إنشاء وتعديل المذكرات متاح للمعلمين والمدير
        </div>
      )}

      <Card className="p-4" glass={false}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input icon={<Search size={18} />} placeholder="بحث بالاسم..." value={search} onChange={(e) => setSearch(e.target.value)} />
          <Select value={groupFilter} onChange={(e) => setGroupFilter(e.target.value)}>
            <option value="">كل المجموعات</option>
            {availableGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
          </Select>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <EmptyState icon={<FileStack size={36} />} title="لا توجد مذكرات" description="أضف مذكرات دراسية مرتبطة بالمجموعات"
          action={canManage ? <Button onClick={() => { setEditing(null); setShowForm(true); }}><Plus size={18} /> إضافة مذكرة</Button> : undefined} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((m) => {
            const group = db.groups.find((g) => g.id === m.groupId);
            return (
              <Card key={m.id} className="p-5" hover>
                <div className="flex items-start justify-between mb-3">
                  <div className="grid place-items-center h-12 w-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-brand-700 text-white shadow-soft">
                    <FileText size={24} />
                  </div>
                  <div className="flex gap-1">
                    {canSell && m.stock > 0 && (
                      <button onClick={() => setSellMaterial(m)} className="grid place-items-center h-8 w-8 rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100" title="بيع مذكرة لطالب">
                        <ShoppingCart size={15} />
                      </button>
                    )}
                    {canManage && (
                      <>
                        <button onClick={() => { setEditing(m); setShowForm(true); }} className="grid place-items-center h-8 w-8 rounded-lg bg-amber-50 text-amber-600 hover:bg-amber-100">
                          <Edit3 size={15} />
                        </button>
                        <button onClick={() => setDeleteId(m.id)} className="grid place-items-center h-8 w-8 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100">
                          <Trash2 size={15} />
                        </button>
                      </>
                    )}
                  </div>
                </div>
                <h3 className="font-bold text-brand-900 mb-1">{m.title}</h3>
                {m.description && <p className="text-xs text-brand-400 mb-2">{m.description}</p>}
                <div className="flex items-center gap-2 text-sm text-brand-600">
                  <BookOpen size={14} className="text-brand-400" /> {group?.name || 'بدون مجموعة'}
                </div>
                <div className="flex items-center gap-3 mt-2">
                  {m.price > 0 && (
                    <span className="flex items-center gap-1 text-xs font-bold text-emerald-600">
                      <DollarSign size={12} /> {m.price} ج.م
                    </span>
                  )}
                  <span className={`flex items-center gap-1 text-xs font-bold ${m.stock > 0 ? 'text-brand-500' : 'text-rose-500'}`}>
                    <Package size={12} /> {m.stock > 0 ? `${m.stock} متوفر` : 'نفد المخزون'}
                  </span>
                </div>
                <p className="text-[10px] text-brand-300 mt-2">{formatDate(m.createdAt)}</p>
              </Card>
            );
          })}
        </div>
      )}

      {showForm && (
        <MaterialForm
          material={editing}
          groups={availableGroups}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSave={handleSave}
        />
      )}

      {sellMaterial && (
        <SellNoteModal
          material={sellMaterial}
          students={scoped.students}
          onClose={() => setSellMaterial(null)}
          onConfirm={(student) => handleSellNote(sellMaterial, student)}
        />
      )}

      <ConfirmDialog
        open={deleteId !== null}
        title="حذف المذكرة"
        message="سيتم حذف هذه المذكرة نهائياً. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function SellNoteModal({ material, students, onClose, onConfirm }: {
  material: StudyMaterial;
  students: Student[];
  onClose: () => void;
  onConfirm: (student: Student) => void;
}) {
  const [selected, setSelected] = useState<Student | null>(null);

  return (
    <Modal open onClose={onClose} title={`بيع مذكرة: ${material.title}`} size="md">
      <div className="space-y-4">
        <div className="rounded-2xl bg-brand-50 p-3 flex items-center justify-between">
          <div>
            <p className="text-sm font-bold text-brand-900">{material.title}</p>
            <p className="text-xs text-brand-400">المتبقي: {material.stock} نسخة</p>
          </div>
          <Badge tone="emerald">{formatEGP(material.price)} ج.م</Badge>
        </div>
        {material.stock <= 0 ? (
          <div className="rounded-2xl bg-rose-50 border border-rose-200 px-4 py-3 text-sm font-bold text-rose-700 text-center">
            ⚠️ المخزون نفد — لا يمكن بيع هذه المذكرة
          </div>
        ) : (
          <>
            <div>
              <label className="block text-sm font-semibold text-brand-900 mb-2">اختر الطالب</label>
              <StudentSearch students={students} groups={[]} onSelect={(s) => setSelected(s)} />
            </div>
            {selected && (
              <div className="rounded-2xl bg-emerald-50 border border-emerald-200 px-4 py-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-brand-900">{selected.name}</p>
                  <p className="text-xs text-brand-400">#{selected.id}</p>
                </div>
                <Badge tone="brand">{formatEGP(material.price)} ج.م</Badge>
              </div>
            )}
            <div className="flex gap-3 pt-2">
              <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إلغاء</Button>
              <Button className="flex-1" disabled={!selected} onClick={() => selected && onConfirm(selected)}>
                <ShoppingCart size={18} /> تأكيد البيع
              </Button>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}

function MaterialForm({ material, groups, onClose, onSave }: {
  material: StudyMaterial | null;
  groups: { id: string; name: string }[];
  onClose: () => void;
  onSave: (data: Omit<StudyMaterial, 'id' | 'createdAt'> & { id?: string }) => void;
}) {
  const [title, setTitle] = useState(material?.title || '');
  const [groupId, setGroupId] = useState(material?.groupId || '');
  const [description, setDescription] = useState(material?.description || '');
  const [price, setPrice] = useState(String(material?.price ?? ''));
  const [stock, setStock] = useState(String(material?.stock ?? ''));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupId) return;
    onSave({ id: material?.id, title: title.trim(), groupId, description: description.trim(), price: Number(price) || 0, stock: Number(stock) || 0 });
  };

  return (
    <Modal open onClose={onClose} title={material ? 'تعديل مذكرة' : 'إضافة مذكرة جديدة'} size="md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input label="عنوان المذكرة" placeholder="مثال: مذكرة الفصل الأول - الجبر" value={title} onChange={(e) => setTitle(e.target.value)} required />
        <Select label="المجموعة (مطلوب)" value={groupId} onChange={(e) => setGroupId(e.target.value)} required>
          <option value="">اختر المجموعة</option>
          {groups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
        </Select>
        <Textarea label="الوصف" placeholder="وصف مختصر للمذكرة..." value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
        <div className="grid grid-cols-2 gap-3">
          <Input label="السعر (ج.م)" type="number" placeholder="0" value={price} onChange={(e) => setPrice(e.target.value)} />
          <Input label="المخزون (عدد النسخ)" type="number" placeholder="0" value={stock} onChange={(e) => setStock(e.target.value)} />
        </div>
        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إلغاء</Button>
          <Button type="submit" className="flex-1">{material ? 'حفظ' : 'إضافة'}</Button>
        </div>
      </form>
    </Modal>
  );
}
