import { useState, useMemo } from 'react';
import { Users, UserPlus, Search, Phone, PhoneCall, BookOpen, CreditCard, Trash2, Edit3, X, StickyNote, Lock, Printer, Users2, Radar, AlertCircle, QrCode, Download, ChevronDown, ChevronUp } from 'lucide-react';
import { WhatsAppButton } from '../components/ui/WhatsAppButton';
import { useDB } from '../context/DBContext';
import { useAuth, canManageStudents } from '../context/AuthContext';
import { useCenter } from '../context/CenterContext';
import { useToast } from '../context/ToastContext';
import { getScopedData, filterByCenter } from '../lib/scoping';
import { getAcademicGrades } from '../lib/db';
import { formatEGP, uid, todayStr } from '../lib/date';
import { logAction, discountedSessionFee, findSiblings, resolveDiscountPercent, DISCOUNT_TYPE_LABELS } from '../lib/finance';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select, Textarea } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { StudentCard } from '../components/StudentCard';
import { MultiGroupSelect } from '../components/ui/MultiGroupSelect';
import { printIDCards } from '../lib/idcard';
import { computeUnpaidRadar, exportGroupDefaultersExcel } from '../lib/excel';
import { currentMonthStr } from '../lib/date';
import { isQrCodeUnique, generateStudentCode } from '../lib/qr';
import { studentGroupIds } from '../lib/scoping';
import type { Student } from '../lib/types';

function ContactNotesSection({ studentId }: { studentId: number }) {
  const { db, update } = useDB();
  const { showToast } = useToast();
  const [text, setText] = useState('');

  const notes = (db.contactNotes || []).filter((n) => n.studentId === studentId);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    update((d) => {
      d.contactNotes = d.contactNotes || [];
      d.contactNotes.push({
        id: uid('note'),
        studentId,
        text: text.trim(),
        date: todayStr(),
        active: true,
        createdAt: new Date().toISOString(),
      });
    });
    setText('');
    showToast('تم حفظ ملاحظة ولي الأمر');
  };

  const toggleActive = (id: string) => {
    update((d) => {
      d.contactNotes = (d.contactNotes || []).map((n) => (n.id === id ? { ...n, active: !n.active } : n));
    });
  };

  const handleDelete = (id: string) => {
    update((d) => {
      d.contactNotes = (d.contactNotes || []).filter((n) => n.id !== id);
    });
  };

  return (
    <div className="mt-5 pt-4 border-t border-slate-100">
      <div className="flex items-center gap-2 mb-3">
        <PhoneCall size={18} className="text-amber-500" />
        <h4 className="font-bold text-brand-900 text-sm">سجل تواصل أولياء الأمور</h4>
      </div>
      <form onSubmit={handleAdd} className="flex gap-2 mb-3">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="مثال: اتصل والد الطالب واعتذر عن غيابه اليوم لمرضه"
          className="flex-1 rounded-2xl border-2 border-slate-200 px-3 py-2 text-sm focus:border-brand-400 focus:outline-none"
        />
        <Button type="submit" size="sm" className="shrink-0">
          <StickyNote size={16} /> حفظ
        </Button>
      </form>
      {notes.length === 0 ? (
        <p className="text-xs text-brand-400">لا توجد ملاحظات مسجلة</p>
      ) : (
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {notes.map((n) => (
            <div
              key={n.id}
              className={`rounded-2xl px-3 py-2 text-sm border ${
                n.active ? 'bg-amber-50 border-amber-200' : 'bg-slate-50 border-slate-200 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <p className="font-semibold text-brand-800 flex-1">{n.text}</p>
                <div className="flex gap-1 shrink-0">
                  <button
                    onClick={() => toggleActive(n.id)}
                    className="text-xs font-bold text-amber-600 hover:underline"
                  >
                    {n.active ? 'تعطيل' : 'تفعيل'}
                  </button>
                  <button onClick={() => handleDelete(n.id)} className="text-rose-500 hover:text-rose-700">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <p className="text-[10px] text-brand-400 mt-1">{n.date}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function Students() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { selectedCenterId } = useCenter();
  const { showToast } = useToast();
  const roleScoped = getScopedData(db, user);
  const scoped = {
    students: filterByCenter(roleScoped.students, selectedCenterId),
    groups: filterByCenter(roleScoped.groups, selectedCenterId),
    attendance: roleScoped.attendance,
    payments: filterByCenter(roleScoped.payments, selectedCenterId),
    materials: roleScoped.materials,
    auditLog: roleScoped.auditLog,
  };
  const canManage = canManageStudents(user?.role);

  const [search, setSearch] = useState('');
  const [gradeFilter, setGradeFilter] = useState('');
  const [groupFilter, setGroupFilter] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [cardStudent, setCardStudent] = useState<Student | null>(null);
  const [showRadar, setShowRadar] = useState(false);

  const grades = getAcademicGrades();
  const radarData = useMemo(() => computeUnpaidRadar(db, currentMonthStr()), [db]);
  const availableGroups = scoped.groups;

  const filtered = useMemo(() => {
    return scoped.students.filter((s) => {
      if (search && !s.name.includes(search) && !String(s.id).includes(search)) return false;
      if (gradeFilter && s.grade !== gradeFilter) return false;
      if (groupFilter && !studentGroupIds(s).includes(groupFilter)) return false;
      return true;
    });
  }, [scoped.students, search, gradeFilter, groupFilter]);

  const handleSave = (data: Omit<Student, 'id' | 'createdAt'> & { id?: number }) => {
    for (const gid of data.groupIds || []) {
      const targetGroup = db.groups.find((g) => g.id === gid);
      if (targetGroup && targetGroup.grade !== data.grade) {
        showToast(`لا يمكن تسجيل الطالب في مجموعة لا تطابق صفه. صف الطالب: ${data.grade}، صف المجموعة: ${targetGroup.grade}`, 'error');
        return;
      }
    }
    const primaryGroup = data.groupIds?.[0] || null;
    const branchId = selectedCenterId || data.branchId || (primaryGroup ? db.groups.find((g) => g.id === primaryGroup)?.branchId ?? null : null);
    update((d) => {
      if (editing) {
        const idx = d.students.findIndex((s) => s.id === editing.id);
        if (idx >= 0) {
          const oldGroupIds = studentGroupIds(d.students[idx]);
          d.students[idx] = { ...d.students[idx], ...data, groupId: primaryGroup, branchId };
          const newGroupIds = data.groupIds || [];
          const changed = JSON.stringify([...oldGroupIds].sort()) !== JSON.stringify([...newGroupIds].sort());
          if (changed) {
            const groupNames = newGroupIds.map((id) => d.groups.find((g) => g.id === id)?.name).filter(Boolean).join('، ');
            logAction(d, 'تعديل طالب', `قام ${user?.name || ''} بتعديل مجموعات الطالب ${data.name}: ${groupNames || 'بدون مجموعة'}.`, user?.name || '', user?.role || 'admin');
          } else {
            logAction(d, 'تعديل طالب', `قام ${user?.name || ''} بتعديل بيانات الطالب: ${data.name}.`, user?.name || '', user?.role || 'admin');
          }
        }
      } else {
        const id = d.meta.nextStudentId;
        const qrCode = data.qrCode || generateStudentCode(id);
        d.students.push({ ...data, groupId: primaryGroup, qrCode, branchId, id, createdAt: new Date().toISOString() } as Student);
        d.meta.nextStudentId = id + 1;
        logAction(d, 'تسجيل طالب', `قام ${user?.name || ''} بتسجيل الطالب الجديد ${data.name} في الصف ${data.grade}.`, user?.name || '', user?.role || 'admin');
      }
    });
    showToast(editing ? 'تم تحديث بيانات الطالب' : 'تم تسجيل الطالب بنجاح');
    setShowForm(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (deleteId === null) return;
    const sname = db.students.find((s) => s.id === deleteId)?.name || '';
    update((d) => {
      d.students = d.students.filter((s) => s.id !== deleteId);
      d.attendance = d.attendance.filter((a) => a.studentId !== deleteId);
      d.payments = d.payments.filter((p) => p.studentId !== deleteId);
      logAction(d, 'حذف طالب', `قام ${user?.name || ''} بحذف الطالب: ${sname}.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف الطالب', 'info');
    setDeleteId(null);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900">سجل الطلاب</h2>
          <p className="text-sm text-brand-400 mt-0.5">{filtered.length} طالب</p>
        </div>
        {canManage && (
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => printIDCards(filtered, db.groups)} disabled={filtered.length === 0}>
              <Printer size={18} /> طباعة الكروت
            </Button>
            <Button variant="secondary" onClick={() => setShowRadar(true)}>
              <Radar size={18} /> رادار المتأخرات
            </Button>
            <Button onClick={() => { setEditing(null); setShowForm(true); }}>
              <UserPlus size={18} /> طالب جديد
            </Button>
          </div>
        )}
      </div>

      {!canManage && (
        <div className="flex items-center gap-2 rounded-2xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-sm font-semibold text-amber-700">
          <Lock size={16} /> وضع العرض فقط — يمكنك الاطلاع على بيانات الطلاب دون تعديلها
        </div>
      )}

      <Card className="p-4" glass={false}>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <Input icon={<Search size={18} />} placeholder="بحث بالاسم أو الكود..." value={search} onChange={(e) => setSearch(e.target.value)} />
          <Select value={gradeFilter} onChange={(e) => setGradeFilter(e.target.value)}>
            <option value="">كل الصفوف</option>
            {grades.map((g) => <option key={g} value={g}>{g}</option>)}
          </Select>
          <Select value={groupFilter} onChange={(e) => setGroupFilter(e.target.value)}>
            <option value="">كل المجموعات</option>
            {availableGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
          </Select>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <EmptyState icon={<Users size={36} />} title="لا يوجد طلاب" description="ابدأ بتسجيل أول طالب في السنتر"
          action={canManage ? <Button onClick={() => { setEditing(null); setShowForm(true); }}><UserPlus size={18} /> تسجيل طالب</Button> : undefined} />
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden lg:block overflow-hidden" glass={false}>
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-brand-50 text-brand-700 text-right">
                  <th className="px-4 py-3 font-bold">الكود</th>
                  <th className="px-4 py-3 font-bold">الاسم</th>
                  <th className="px-4 py-3 font-bold">الهاتف</th>
                  <th className="px-4 py-3 font-bold">ولي الأمر</th>
                  <th className="px-4 py-3 font-bold">الصف</th>
                  <th className="px-4 py-3 font-bold">المجموعة</th>
                  <th className="px-4 py-3 font-bold">ملاحظة</th>
                  <th className="px-4 py-3 font-bold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((s) => {
                  const sGroups = studentGroupIds(s).map((id) => db.groups.find((g) => g.id === id)).filter(Boolean);
                  const hasNote = (db.contactNotes || []).some((n) => n.studentId === s.id && n.active);
                  return (
                    <tr key={s.id} className="hover:bg-brand-50/40 transition-colors">
                      <td className="px-4 py-3"><Badge tone="brand">{s.id}</Badge></td>
                      <td className="px-4 py-3 font-bold text-brand-900">
                        {s.name}
                        {user?.role === 'admin' && s.hasSiblingDiscount && s.discountPercent ? (
                          <Badge tone={s.discountType === 'twin' ? 'violet' : 'amber'} className="mr-2 text-[10px]"><Users2 size={10} className="inline" /> {s.discountType === 'twin' ? 'خصم توأم' : 'خصم أشقاء'} {s.discountPercent}%</Badge>
                        ) : null}
                        {user?.role === 'admin' && s.hasSpecialDiscount && s.specialDiscountPercent ? (
                          <Badge tone="rose" className="mr-2 text-[10px]">خصم خاص {s.specialDiscountPercent}%</Badge>
                        ) : null}
                      </td>
                      <td className="px-4 py-3 text-brand-600">{s.phone}</td>
                      <td className="px-4 py-3 text-brand-600">{s.parentPhone}</td>
                      <td className="px-4 py-3 text-brand-600">{s.grade}</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {sGroups.length > 0 ? sGroups.map((g) => (
                            <Badge key={g!.id} tone="brand" className="text-[10px]">{g!.name}</Badge>
                          )) : <span className="text-brand-300">—</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {hasNote ? <StickyNote size={16} className="text-amber-500" /> : <span className="text-brand-300">—</span>}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <button onClick={() => setCardStudent(s)} className="grid place-items-center h-8 w-8 rounded-lg bg-brand-50 text-brand-600 hover:bg-brand-100" title="بطاقة الطالب">
                            <CreditCard size={16} />
                          </button>
                          <WhatsAppButton student={s} centerName={db.centerName} groupName={sGroups[0]?.name} size="sm" />
                          {canManage && (
                            <>
                              <button onClick={() => { setEditing(s); setShowForm(true); }} className="grid place-items-center h-8 w-8 rounded-lg bg-amber-50 text-amber-600 hover:bg-amber-100" title="تعديل">
                                <Edit3 size={16} />
                              </button>
                              <button onClick={() => setDeleteId(s.id)} className="grid place-items-center h-8 w-8 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100" title="حذف">
                                <Trash2 size={16} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards */}
          <div className="lg:hidden space-y-3">
            {filtered.map((s) => {
              const sGroups = studentGroupIds(s).map((id) => db.groups.find((g) => g.id === id)).filter(Boolean);
              const price = db.gradePrices.find((gp) => gp.grade === s.grade);
              const hasNote = (db.contactNotes || []).some((n) => n.studentId === s.id && n.active);
              return (
                <Card key={s.id} className="p-4" hover>
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="grid place-items-center h-12 w-12 rounded-2xl gradient-brand text-white font-extrabold text-lg shadow-soft">
                        {s.name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="font-bold text-brand-900">{s.name}</h3>
                        <div className="flex items-center gap-1 mt-0.5">
                          <Badge tone="brand">#{s.id}</Badge>
                          {user?.role === 'admin' && s.hasSiblingDiscount && s.discountPercent ? (
                            <Badge tone={s.discountType === 'twin' ? 'violet' : 'amber'} className="text-[10px]"><Users2 size={10} /> {s.discountType === 'twin' ? 'توأم' : 'أشقاء'} {s.discountPercent}%</Badge>
                          ) : null}
                          {user?.role === 'admin' && s.hasSpecialDiscount && s.specialDiscountPercent ? (
                            <Badge tone="rose" className="text-[10px]">خصم خاص {s.specialDiscountPercent}%</Badge>
                          ) : null}
                        </div>
                      </div>
                    </div>
                    {price && <Badge tone="emerald">{formatEGP(price.price)}</Badge>}
                  </div>
                  <div className="space-y-1.5 text-sm">
                    <div className="flex items-center gap-2 text-brand-600"><Phone size={14} className="text-brand-400" /> {s.phone}</div>
                    <div className="flex items-center gap-2 text-brand-600"><PhoneCall size={14} className="text-brand-400" /> {s.parentPhone}</div>
                    <div className="flex items-center gap-2 text-brand-600"><BookOpen size={14} className="text-brand-400" /> {s.grade}</div>
                    {sGroups.length > 0 && (
                      <div className="flex items-start gap-2 text-brand-600">
                        <Users size={14} className="text-brand-400 mt-0.5 shrink-0" />
                        <div className="flex flex-wrap gap-1">
                          {sGroups.map((g) => (
                            <Badge key={g!.id} tone="brand" className="text-[10px]">{g!.name}</Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {hasNote && (
                      <div className="flex items-start gap-2 text-amber-600 bg-amber-50 rounded-xl px-3 py-1.5 mt-1">
                        <StickyNote size={14} className="shrink-0 mt-0.5" /> <span className="text-xs font-semibold">يوجد ملاحظة ولي الأمر — افتح البطاقة</span>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 mt-3 pt-3 border-t border-slate-100">
                    <Button size="sm" variant="secondary" className="flex-1" onClick={() => setCardStudent(s)}>
                      <CreditCard size={15} /> البطاقة
                    </Button>
                    <WhatsAppButton student={s} centerName={db.centerName} groupName={sGroups[0]?.name} size="sm" label="واتساب" />
                    {canManage && (
                      <>
                        <Button size="sm" variant="ghost" onClick={() => { setEditing(s); setShowForm(true); }}><Edit3 size={15} /></Button>
                        <Button size="sm" variant="ghost" className="text-rose-500" onClick={() => setDeleteId(s.id)}><Trash2 size={15} /></Button>
                      </>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        </>
      )}

      {showForm && (
        <StudentForm
          student={editing}
          groups={availableGroups}
          grades={grades}
          gradePrices={db.gradePrices}
          allStudents={db.students}
          siblingDiscountPercent={db.siblingDiscountPercent}
          twinDiscountPercent={db.twinDiscountPercent}
          qrEnabled={db.qrEnabled}
          nextStudentId={db.meta.nextStudentId}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSave={handleSave}
          onQrDuplicate={() => showToast('⚠️ كود الـ QR مستخدم بالفعل لطالب آخر!', 'error')}
          isAdmin={user?.role === 'admin'}
        />
      )}

      <ConfirmDialog
        open={deleteId !== null}
        title="حذف الطالب"
        message="سيتم حذف الطالب وجميع سجلات الحضور والمدفوعات الخاصة به. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />

      {showRadar && (
        <RadarModal
          db={db}
          radarData={radarData}
          availableGroups={availableGroups}
          onClose={() => setShowRadar(false)}
        />
      )}

      {cardStudent && (
        <Modal open onClose={() => setCardStudent(null)} title="بطاقة الطالب" size="md">
          <StudentCard student={cardStudent} groups={db.groups} gradePrice={db.gradePrices.find((gp) => gp.grade === cardStudent.grade)} qrEnabled={db.qrEnabled} isAdmin={user?.role === 'admin'} />
          <ContactNotesSection studentId={cardStudent.id} />
        </Modal>
      )}
    </div>
  );
}

interface StudentFormProps {
  student: Student | null;
  groups: { id: string; name: string; grade: string }[];
  grades: string[];
  gradePrices: { grade: string; price: number }[];
  allStudents: Student[];
  siblingDiscountPercent: number;
  twinDiscountPercent: number;
  qrEnabled: boolean;
  nextStudentId: number;
  onClose: () => void;
  onSave: (data: Omit<Student, 'id' | 'createdAt'> & { id?: number }) => void;
  onQrDuplicate: () => void;
  isAdmin: boolean;
}

function StudentForm({ student, groups, grades, gradePrices, allStudents, siblingDiscountPercent, twinDiscountPercent, qrEnabled, nextStudentId, onClose, onSave, onQrDuplicate, isAdmin }: StudentFormProps) {
  const [firstName, setFirstName] = useState(student?.firstName || (student ? student.name.split(' ')[0] : ''));
  const [lastName, setLastName] = useState(student?.lastName || (student ? student.name.split(' ').slice(1).join(' ') : ''));
  const [phone, setPhone] = useState(student?.phone || '');
  const [parentPhone, setParentPhone] = useState(student?.parentPhone || '');
  const [parentName, setParentName] = useState(student?.parentName || '');
  const [motherPhone, setMotherPhone] = useState(student?.motherPhone || '');
  const [grade, setGrade] = useState(student?.grade || grades[6]);
  const [groupIds, setGroupIds] = useState<string[]>(student ? studentGroupIds(student) : []);
  const [note, setNote] = useState(student?.note || '');
  const [siblingNotice, setSiblingNotice] = useState<{ count: number } | null>(
    student?.hasSiblingDiscount ? { count: 0 } : null
  );
  const [discountType, setDiscountType] = useState<'none' | 'sibling' | 'twin'>(
    student?.discountType ?? (student?.hasSiblingDiscount ? 'sibling' : 'none')
  );
  const [hasSpecialDiscount, setHasSpecialDiscount] = useState(student?.hasSpecialDiscount ?? false);
  const [specialDiscountPercent, setSpecialDiscountPercent] = useState(String(student?.specialDiscountPercent ?? ''));
  const [specialDiscountNote, setSpecialDiscountNote] = useState(student?.specialDiscountNote ?? '');
  const [qrCode, setQrCode] = useState(student?.qrCode ?? '');
  const [qrError, setQrError] = useState('');

  const price = gradePrices.find((gp) => gp.grade === grade);
  const filteredGroups = groups.filter((g) => g.grade === grade);
  const fullName = useMemo(() => `${firstName.trim()} ${lastName.trim()}`.trim(), [firstName, lastName]);

  const detectSiblings = (last: string, phone: string) => {
    const matches = findSiblings(allStudents, { id: student?.id, lastName: last, parentPhone: phone });
    if (matches.length > 0) {
      setSiblingNotice({ count: matches.length });
      if (discountType === 'none') setDiscountType('sibling');
    } else {
      setSiblingNotice(null);
      if (discountType !== 'none') setDiscountType('none');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim()) return;
    if (qrEnabled && qrCode.trim()) {
      if (!isQrCodeUnique(allStudents, qrCode.trim(), student?.id)) {
        setQrError('كود الـ QR مستخدم بالفعل لطالب آخر!');
        onQrDuplicate();
        return;
      }
    }
    setQrError('');
    const hasDiscount = discountType !== 'none';
    const discountPercent = hasDiscount ? resolveDiscountPercent(discountType, siblingDiscountPercent, twinDiscountPercent) : 0;
    const specialPercent = hasSpecialDiscount && specialDiscountPercent ? Number(specialDiscountPercent) : undefined;
    onSave({
      id: student?.id,
      name: fullName,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      phone: phone.trim(),
      parentPhone: parentPhone.trim(),
      parentName: parentName.trim() || undefined,
      motherPhone: motherPhone.trim() || undefined,
      grade,
      groupId: groupIds[0] || null,
      groupIds,
      branchId: student?.branchId ?? null,
      note: note.trim(),
      hasSiblingDiscount: hasDiscount,
      discountPercent: hasDiscount ? discountPercent : undefined,
      discountType: hasDiscount ? discountType : 'none',
      hasSpecialDiscount: hasSpecialDiscount && (specialPercent ?? 0) > 0,
      specialDiscountPercent: specialPercent,
      specialDiscountNote: hasSpecialDiscount && specialDiscountNote.trim() ? specialDiscountNote.trim() : undefined,
      qrCode: qrEnabled && qrCode.trim() ? qrCode.trim() : undefined,
    });
  };

  return (
    <Modal open onClose={onClose} title={student ? 'تعديل بيانات الطالب' : 'تسجيل طالب جديد'} size="md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input label="الاسم الأول" placeholder="مثال: أحمد" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
          <Input label="باقي الاسم الرباعي" placeholder="مثال: محمد محمود السيد" value={lastName} onChange={(e) => { setLastName(e.target.value); if (isAdmin) detectSiblings(e.target.value, parentPhone); }} onBlur={() => { if (isAdmin) detectSiblings(lastName, parentPhone); }} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Input label="هاتف الطالب" placeholder="01xxxxxxxxx" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <Input label="هاتف ولي الأمر" placeholder="01xxxxxxxxx" value={parentPhone} onChange={(e) => { setParentPhone(e.target.value); if (isAdmin) detectSiblings(lastName, e.target.value); }} required />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input label="اسم ولي الأمر" placeholder="مثال: السيد محمد علي" value={parentName} onChange={(e) => setParentName(e.target.value)} />
          <Input label="هاتف الأم (طوارئ)" placeholder="01xxxxxxxxx (اختياري)" value={motherPhone} onChange={(e) => setMotherPhone(e.target.value)} />
        </div>
        {isAdmin && siblingNotice && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-3 flex items-start gap-2 animate-fade-in">
            <Users2 size={18} className="text-amber-600 shrink-0 mt-0.5" />
            <p className="text-sm font-semibold text-amber-700">
              تم اكتشاف {siblingNotice.count > 0 ? `${siblingNotice.count} من ` : ''}الأشقاء المسجلين! برجاء اختيار نوع الخصم المستحق بالأسفل.
            </p>
          </div>
        )}
        <Select label="الصف الدراسي" value={grade} onChange={(e) => { setGrade(e.target.value); setGroupIds([]); }}>
          {grades.map((g) => <option key={g} value={g}>{g}</option>)}
        </Select>
        {price && (
          <div className="rounded-2xl bg-emerald-50 border border-emerald-200 px-4 py-2.5 flex items-center justify-between">
            <span className="text-sm font-semibold text-emerald-700">الرسوم الافتراضية للصف</span>
            <div className="flex items-center gap-2">
              {isAdmin && discountType !== 'none' ? (
                <span className="text-xs text-amber-600 line-through">{formatEGP(price.price)}</span>
              ) : null}
              <Badge tone="emerald">{formatEGP(isAdmin && discountType !== 'none' ? discountedSessionFee(price.price, { hasSiblingDiscount: true, discountPercent: resolveDiscountPercent(discountType, siblingDiscountPercent, twinDiscountPercent) }) : price.price)}</Badge>
            </div>
          </div>
        )}

        {isAdmin && (
        <div className="rounded-2xl border-2 border-slate-100 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-brand-900">نوع الخصم المستحق</span>
            {siblingNotice && <Badge tone="amber" className="text-[10px]">أشقاء مكتشفون</Badge>}
          </div>
          <div className="grid grid-cols-3 gap-2">
            {([
              { value: 'sibling', label: 'خصم أشقاء', percent: siblingDiscountPercent, icon: Users2, tone: 'amber' as const },
              { value: 'twin', label: 'خصم توأم', percent: twinDiscountPercent, icon: Users, tone: 'violet' as const },
              { value: 'none', label: 'بدون خصم', percent: 0, icon: X, tone: 'slate' as const },
            ] as const).map((opt) => {
              const active = discountType === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setDiscountType(opt.value)}
                  className={`flex flex-col items-center gap-1.5 rounded-2xl p-3 transition-all duration-200 border-2 ${
                    active
                      ? opt.tone === 'amber'
                        ? 'bg-amber-50 text-amber-700 border-amber-300 shadow-soft'
                        : opt.tone === 'violet'
                          ? 'bg-violet-50 text-violet-700 border-violet-300 shadow-soft'
                          : 'bg-slate-50 text-slate-600 border-slate-300 shadow-soft'
                      : 'bg-brand-50/30 text-brand-400 border-transparent hover:bg-brand-50'
                  }`}
                >
                  <opt.icon size={20} />
                  <span className="text-xs font-bold">{opt.label}</span>
                  {opt.percent > 0 && (
                    <span className="text-[10px] font-semibold opacity-80">{opt.percent}%</span>
                  )}
                </button>
              );
            })}
          </div>
          {discountType !== 'none' && price && (
            <div className="rounded-xl bg-amber-50 border border-amber-100 px-3 py-2 flex items-center justify-between animate-fade-in">
              <span className="text-xs font-semibold text-amber-600">السعر بعد {DISCOUNT_TYPE_LABELS[discountType]}</span>
              <div className="flex items-center gap-2">
                <span className="text-xs text-amber-400 line-through">{formatEGP(price.price)}</span>
                <Badge tone="amber">{formatEGP(discountedSessionFee(price.price, { hasSiblingDiscount: true, discountPercent: resolveDiscountPercent(discountType, siblingDiscountPercent, twinDiscountPercent) }))}</Badge>
              </div>
            </div>
          )}
        </div>
        )}
        <div>
          <MultiGroupSelect
            groups={filteredGroups}
            selectedIds={groupIds}
            onChange={setGroupIds}
            placeholder="بدون مجموعة"
            label="المجموعات (يجب أن تطابق الصف)"
          />
          {filteredGroups.length === 0 && (
            <p className="text-xs text-amber-600 font-semibold mt-1">لا توجد مجموعات متاحة لهذا الصف</p>
          )}
        </div>
        <Textarea label="ملاحظات ولي الأمر" placeholder="مثال: ولي الأمر طلب متابعة المستوى..." value={note} onChange={(e) => setNote(e.target.value)} rows={2} />

        {isAdmin && (
        <div className="rounded-2xl border-2 border-slate-100 p-4 space-y-3">
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={hasSpecialDiscount}
              onChange={(e) => setHasSpecialDiscount(e.target.checked)}
              className="h-4 w-4 rounded accent-brand-500"
            />
            <span className="text-sm font-bold text-brand-900">خصم خاص</span>
            <Badge tone="rose" className="text-[10px]">اختياري</Badge>
          </label>
          {hasSpecialDiscount && (
            <div className="space-y-3 animate-fade-in">
              <Input
                label="نسبة الخصم الخاص (%)"
                type="number"
                placeholder="مثال: 15"
                value={specialDiscountPercent}
                onChange={(e) => setSpecialDiscountPercent(e.target.value)}
              />
              <Input
                label="سبب الخصم"
                placeholder="مثال: تفوق دراسي / ظرف خاص"
                value={specialDiscountNote}
                onChange={(e) => setSpecialDiscountNote(e.target.value)}
              />
              {price && specialDiscountPercent && Number(specialDiscountPercent) > 0 && (
                <div className="rounded-xl bg-rose-50 border border-rose-100 px-3 py-2 flex items-center justify-between">
                  <span className="text-xs font-semibold text-rose-600">السعر بعد الخصم الخاص</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-rose-400 line-through">{formatEGP(price.price)}</span>
                    <Badge tone="rose">{formatEGP(Math.round(price.price * (1 - Number(specialDiscountPercent) / 100)))}</Badge>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        )}

        {/* QR Code Section */}
        {qrEnabled && (
          <div className="rounded-2xl border-2 border-violet-100 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-brand-900 flex items-center gap-1.5">
                <QrCode size={16} className="text-violet-500" /> كود الـ QR / الباركود
              </span>
              <Button type="button" variant="secondary" size="sm" onClick={() => setQrCode(generateStudentCode(student?.id ?? nextStudentId))}>
                توليد تلقائي
              </Button>
            </div>
            <Input
              label="كود فريد للطالب"
              placeholder="مثال: STD-01001"
              value={qrCode}
              onChange={(e) => { setQrCode(e.target.value); setQrError(''); }}
            />
            {qrError && (
              <div className="rounded-xl bg-rose-50 border border-rose-200 px-3 py-2 text-sm font-semibold text-rose-600 animate-fade-in">
                {qrError}
              </div>
            )}
            <p className="text-xs text-brand-400">هذا الكود فريد لكل طالب ويُستخدم في المسح السريع بالباركود ويظهر على كارت الطالب.</p>
          </div>
        )}

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إلغاء</Button>
          <Button type="submit" className="flex-1">{student ? 'حفظ التعديلات' : 'تسجيل'}</Button>
        </div>
      </form>
    </Modal>
  );
}

// ---- Defaulters Radar Modal (grouped by group) ----

import type { Database } from '../lib/types';
import type { UnpaidStudent } from '../lib/excel';

function RadarModal({ db, radarData, availableGroups, onClose }: {
  db: Database;
  radarData: UnpaidStudent[];
  availableGroups: { id: string; name: string }[];
  onClose: () => void;
}) {
  const { showToast } = useToast();
  const [groupFilter, setGroupFilter] = useState('');
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());

  const filteredRadar = useMemo(() => {
    if (!groupFilter) return radarData;
    return radarData.filter((r) => r.groupId === groupFilter);
  }, [radarData, groupFilter]);

  const groupedByGroup = useMemo(() => {
    const map = new Map<string, { groupId: string; groupName: string; defaulters: UnpaidStudent[]; totalDue: number }>();
    for (const r of filteredRadar) {
      const key = r.groupId || 'unassigned';
      if (!map.has(key)) {
        map.set(key, { groupId: key, groupName: r.groupName, defaulters: [], totalDue: 0 });
      }
      const g = map.get(key)!;
      g.defaulters.push(r);
      g.totalDue += r.amountDue;
    }
    return Array.from(map.values()).sort((a, b) => b.totalDue - a.totalDue);
  }, [filteredRadar]);

  const totalDue = useMemo(() => filteredRadar.reduce((s, r) => s + r.amountDue, 0), [filteredRadar]);

  const toggleGroup = (gid: string) => {
    setExpandedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(gid)) next.delete(gid);
      else next.add(gid);
      return next;
    });
  };

  const handleExportGroup = async (group: { groupId: string; groupName: string; defaulters: UnpaidStudent[] }) => {
    try {
      await exportGroupDefaultersExcel(db.centerName, group.groupName, group.defaulters);
      showToast(`تم تصدير متأخرات ${group.groupName}`);
    } catch {
      showToast('فشل التصدير', 'error');
    }
  };

  const handlePrintGroup = (group: { groupId: string; groupName: string; defaulters: UnpaidStudent[] }) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) { showToast('يرجى السماح بالنوافذ المنبثقة', 'error'); return; }
    const rows = group.defaulters.map((u) => `
      <tr>
        <td>${u.id}</td>
        <td>${u.name}</td>
        <td>${u.parentPhone}</td>
        <td>${u.grade}</td>
        <td>${u.amountDue.toLocaleString('en-US')} ج.م</td>
        <td>${u.monthsOverdue > 0 ? u.monthsOverdue + ' شهر' : 'هذا الشهر'}</td>
        <td>${u.status}</td>
      </tr>`).join('');
    printWindow.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>متأخرات ${group.groupName}</title>
      <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; padding: 24px; }
        h1 { color: #1e293b; font-size: 20px; margin-bottom: 4px; }
        .meta { color: #64748b; font-size: 13px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th { background: #f1f5f9; padding: 10px 8px; text-align: right; font-weight: 700; color: #334155; }
        td { padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: right; color: #1e293b; }
        .total { margin-top: 16px; font-size: 15px; font-weight: 700; color: #e11d48; }
      </style></head><body>
      <h1>تقرير متأخرات — ${group.groupName}</h1>
      <div class="meta">${db.centerName || ''} — ${new Date().toLocaleDateString('ar-EG')}</div>
      <table><thead><tr><th>الكود</th><th>الاسم</th><th>ولي الأمر</th><th>الصف</th><th>المبلغ</th><th>مدة التأخر</th><th>الحالة</th></tr></thead>
      <tbody>${rows}</tbody></table>
      <div class="total">إجمالي المتأخرات: ${group.totalDue.toLocaleString('en-US')} ج.م — عدد الطلاب: ${group.defaulters.length}</div>
      </body></html>`);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => printWindow.print(), 300);
  };

  return (
    <Modal open onClose={onClose} title="رادار المتأخرات المالية" size="xl">
      {radarData.length === 0 ? (
        <EmptyState icon={<AlertCircle size={36} />} title="لا توجد متأخرات" description="جميع الطلاب سددوا رسوم الشهر الحالي" />
      ) : (
        <div className="space-y-4">
          {/* Header summary + filter */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Badge tone="rose">{filteredRadar.length} طالب متأخر</Badge>
              <Badge tone="brand">إجمالي: {formatEGP(totalDue)}</Badge>
              <Badge tone="amber">{groupedByGroup.length} مجموعة</Badge>
            </div>
            <div className="w-full sm:w-56">
              <Select value={groupFilter} onChange={(e) => setGroupFilter(e.target.value)}>
                <option value="">جميع المجموعات</option>
                {availableGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
              </Select>
            </div>
          </div>

          {/* Grouped accordion sections */}
          <div className="space-y-3">
            {groupedByGroup.map((group) => {
              const expanded = expandedGroups.has(group.groupId);
              return (
                <div key={group.groupId} className="rounded-2xl border-2 border-slate-100 overflow-hidden">
                  {/* Group header */}
                  <button
                    onClick={() => toggleGroup(group.groupId)}
                    className="w-full flex items-center justify-between gap-3 px-4 py-3 bg-brand-50/60 hover:bg-brand-50 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="grid place-items-center h-9 w-9 rounded-xl gradient-brand text-white shrink-0">
                        <Users size={16} />
                      </div>
                      <div className="text-right min-w-0">
                        <p className="font-bold text-brand-900 text-sm truncate">{group.groupName}</p>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] font-semibold text-rose-600">{group.defaulters.length} متأخر</span>
                          <span className="text-[10px] font-semibold text-brand-400">·</span>
                          <span className="text-[10px] font-bold text-rose-600">{formatEGP(group.totalDue)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {expanded ? <ChevronUp size={18} className="text-brand-400" /> : <ChevronDown size={18} className="text-brand-400" />}
                    </div>
                  </button>

                  {/* Expanded content */}
                  {expanded && (
                    <div className="p-3 sm:p-4 space-y-3 animate-fade-in">
                      {/* Per-group action buttons */}
                      <div className="flex flex-col sm:flex-row gap-2">
                        <Button size="sm" variant="secondary" className="flex-1" onClick={() => handlePrintGroup(group)}>
                          <Printer size={15} /> طباعة تقرير المجموعة
                        </Button>
                        <Button size="sm" variant="secondary" className="flex-1" onClick={() => handleExportGroup(group)}>
                          <Download size={15} /> تصدير إكسيل للمجموعة
                        </Button>
                      </div>

                      {/* Desktop table */}
                      <div className="hidden md:block overflow-x-auto rounded-xl border border-slate-100">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="bg-slate-50 text-brand-700 text-right">
                              <th className="px-3 py-2 font-bold">الكود</th>
                              <th className="px-3 py-2 font-bold">الاسم</th>
                              <th className="px-3 py-2 font-bold">ولي الأمر</th>
                              <th className="px-3 py-2 font-bold">الصف</th>
                              <th className="px-3 py-2 font-bold">المبلغ</th>
                              <th className="px-3 py-2 font-bold">مدة التأخر</th>
                              <th className="px-3 py-2 font-bold">الحالة</th>
                              <th className="px-3 py-2 font-bold">واتساب</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {group.defaulters.map((u) => (
                              <tr key={u.id} className="hover:bg-brand-50/40 transition-colors">
                                <td className="px-3 py-2"><Badge tone="brand">{u.id}</Badge></td>
                                <td className="px-3 py-2 font-bold text-brand-900">{u.name}</td>
                                <td className="px-3 py-2 text-brand-600">{u.parentPhone}</td>
                                <td className="px-3 py-2 text-brand-600">{u.grade}</td>
                                <td className="px-3 py-2 font-bold text-rose-600">{formatEGP(u.amountDue)}</td>
                                <td className="px-3 py-2 text-brand-500 text-xs">{u.monthsOverdue > 0 ? `${u.monthsOverdue} شهر` : 'هذا الشهر'}</td>
                                <td className="px-3 py-2">
                                  <Badge tone={u.status === 'متابعة نشطة' ? 'amber' : u.status === 'متأخر جديد' ? 'rose' : 'brand'}>{u.status}</Badge>
                                </td>
                                <td className="px-3 py-2">
                                  <WhatsAppButton
                                    student={{ id: u.id, name: u.name, parentPhone: u.parentPhone } as Student}
                                    template="unpaid"
                                    centerName={db.centerName}
                                    groupName={u.groupName}
                                    amountDue={u.amountDue}
                                    size="sm"
                                    label="تذكير"
                                  />
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* Mobile cards */}
                      <div className="md:hidden space-y-2">
                        {group.defaulters.map((u) => (
                          <div key={u.id} className="rounded-xl border border-slate-100 p-3">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div className="min-w-0">
                                <p className="font-bold text-brand-900 text-sm truncate">{u.name}</p>
                                <div className="flex items-center gap-1.5 mt-0.5">
                                  <Badge tone="brand" className="text-[10px]">#{u.id}</Badge>
                                  <span className="text-[10px] text-brand-400">{u.grade}</span>
                                </div>
                              </div>
                              <Badge tone="rose" className="text-xs">{formatEGP(u.amountDue)}</Badge>
                            </div>
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <Badge tone={u.status === 'متابعة نشطة' ? 'amber' : u.status === 'متأخر جديد' ? 'rose' : 'brand'} className="text-[10px]">{u.status}</Badge>
                                <span className="text-[10px] text-brand-400">{u.monthsOverdue > 0 ? `${u.monthsOverdue} شهر` : 'هذا الشهر'}</span>
                              </div>
                              <WhatsAppButton
                                student={{ id: u.id, name: u.name, parentPhone: u.parentPhone } as Student}
                                template="unpaid"
                                centerName={db.centerName}
                                groupName={u.groupName}
                                amountDue={u.amountDue}
                                size="sm"
                                label="تذكير"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </Modal>
  );
}
