import { useState, useRef } from 'react';
import { Settings as SettingsIcon, Download, Upload, DollarSign, Save, AlertTriangle, Database, RotateCcw, Lock, CreditCard, Trash2, UserCog, Users2, Users, Image as ImageIcon, RotateCcw as ResetIcon, Building2, Plus, Edit3, X, Star, QrCode, Smartphone, Shield, GraduationCap, KeyRound, Banknote, Clock } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth, canExport, canImport, canEditGradePrices, canEditSettings, roleLabel } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { getAcademicGrades } from '../lib/db';
import { exportDB, exportFilename, importDB, formatMergeResult } from '../lib/merge';
import { logAction } from '../lib/finance';
import { wipeDemoData, resetDB } from '../lib/db';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { Modal } from '../components/ui/Modal';
import { computeSharesForPrice, PAYOUT_TYPE_LABELS } from '../lib/finance';
import { formatEGP } from '../lib/date';
import type { Database as DBType, SecretarySpecialty, PayoutType, StaffPayModel, Staff as StaffType } from '../lib/types';
import { uid } from '../lib/date';

export function Settings() {
  const { db, update, replace } = useDB();
  const { user } = useAuth();
  const { showToast } = useToast();
  const allowExport = canExport(user?.role);
  const allowImport = canImport(user?.role);
  const canEditPrices = canEditGradePrices(user?.role);
  const canEditCenter = canEditSettings(user?.role);

  const [salaryDraft, setSalaryDraft] = useState<Record<string, string>>(
    Object.fromEntries(db.secretarySalaries.map((s) => [s.userId, String(s.amount)]))
  );
  const [idCardDraft, setIdCardDraft] = useState(String(db.idCardPrice));
  const [siblingDraft, setSiblingDraft] = useState(String(db.siblingDiscountPercent ?? 10));
  const [twinDraft, setTwinDraft] = useState(String(db.twinDiscountPercent ?? 20));
  const [openingBufferDraft, setOpeningBufferDraft] = useState(String(db.attendanceOpeningBuffer ?? 10));
  const [closingPercentDraft, setClosingPercentDraft] = useState(String(db.attendanceClosingPercent ?? 50));
  const [centerNameDraft, setCenterNameDraft] = useState(db.centerName ?? 'سنتر الأفضل');
  const [logoDraft, setLogoDraft] = useState<string | null>(db.centerLogo ?? null);
  const logoRef = useRef<HTMLInputElement>(null);
  const [priceDraft, setPriceDraft] = useState<Record<string, string>>(
    Object.fromEntries(db.gradePrices.map((gp) => [gp.grade, String(gp.price)]))
  );
  const [profitModelDraft, setProfitModelDraft] = useState<PayoutType>(db.globalProfitModel ?? 'percentage');
  const [profitValueDraft, setProfitValueDraft] = useState(String(db.globalProfitValue ?? 20));
  const [showReset, setShowReset] = useState(false);
  const [showWipe, setShowWipe] = useState(false);
  const [showBranchModal, setShowBranchModal] = useState(false);
  const [editingBranch, setEditingBranch] = useState<{ id: string; name: string } | null>(null);
  const [branchName, setBranchName] = useState('');
  const [deleteBranchId, setDeleteBranchId] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // User management state
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [userForm, setUserForm] = useState({
    username: '',
    password: '',
    name: '',
    role: 'secretary' as 'admin' | 'secretary' | 'teacher' | 'assistant' | 'supervisor',
    teacherId: '',
    branchIds: '',
    linkedTeacherId: '',
    linkType: 'both' as 'attendance' | 'payments' | 'both',
    specialty: 'full' as SecretarySpecialty,
    phone: '',
    payModel: 'fixed_monthly' as StaffPayModel,
    rate: '',
  });
  const [deleteUserId, setDeleteUserId] = useState<string | null>(null);

  const { canInstall, promptInstall } = usePWAInstall();

  const grades = getAcademicGrades();
  const branches = db.branches || [];

  const openAddBranch = () => {
    setEditingBranch(null);
    setBranchName('');
    setShowBranchModal(true);
  };

  const openEditBranch = (b: { id: string; name: string }) => {
    setEditingBranch(b);
    setBranchName(b.name);
    setShowBranchModal(true);
  };

  const handleSaveBranch = () => {
    const name = branchName.trim();
    if (!name) {
      showToast('الاسم مطلوب', 'error');
      return;
    }
    update((d) => {
      if (!d.branches) d.branches = [];
      if (editingBranch) {
        const idx = d.branches.findIndex((b) => b.id === editingBranch.id);
        if (idx >= 0) d.branches[idx].name = name;
      } else {
        d.branches.push({ id: `b${Date.now()}`, name, address: '', createdAt: new Date().toISOString() });
      }
      logAction(d, 'إدارة الفروع', `قام ${user?.name || ''} بحفظ فرع (${name}).`, user?.name || '', user?.role || 'admin');
    });
    setShowBranchModal(false);
    showToast(editingBranch ? 'تم تعديل الفرع' : 'تم إضافة الفرع');
  };

  const handleDeleteBranch = () => {
    if (!deleteBranchId) return;
    const branch = branches.find((b) => b.id === deleteBranchId);
    update((d) => {
      d.branches = (d.branches || []).filter((b) => b.id !== deleteBranchId);
      d.students.forEach((s) => { if (s.branchId === deleteBranchId) s.branchId = null; });
      d.teachers.forEach((t) => { if (t.branchId === deleteBranchId) t.branchId = null; });
      d.groups.forEach((g) => { if (g.branchId === deleteBranchId) g.branchId = null; });
      d.payments.forEach((p) => { if (p.branchId === deleteBranchId) p.branchId = null; });
      d.expenses.forEach((e) => { if (e.branchId === deleteBranchId) e.branchId = null; });
      logAction(d, 'إدارة الفروع', `قام ${user?.name || ''} بحذف فرع (${branch?.name || ''}).`, user?.name || '', user?.role || 'admin');
    });
    setDeleteBranchId(null);
    showToast('تم حذف الفرع');
  };

  const handleSaveIdCard = () => {
    const val = Number(idCardDraft);
    if (isNaN(val) || val < 0) {
      showToast('السعر يجب أن يكون رقماً صحيحاً', 'error');
      return;
    }
    update((d) => {
      d.idCardPrice = val;
      logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بتعديل الإعدادات المركزية (سعر كارت ID إلى ${val} ج.م).`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حفظ سعر كارت ID');
  };

  const handleSaveSibling = () => {
    const val = Number(siblingDraft);
    if (isNaN(val) || val < 0 || val > 100) {
      showToast('النسبة يجب أن تكون بين 0 و 100', 'error');
      return;
    }
    update((d) => {
      d.siblingDiscountPercent = val;
      logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بتعديل نسبة خصم الأشقاء إلى ${val}%.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حفظ نسبة خصم الأشقاء');
  };

  const handleSaveTwin = () => {
    const val = Number(twinDraft);
    if (isNaN(val) || val < 0 || val > 100) {
      showToast('النسبة يجب أن تكون بين 0 و 100', 'error');
      return;
    }
    update((d) => {
      d.twinDiscountPercent = val;
      logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بتعديل نسبة خصم التوأم إلى ${val}%.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حفظ نسبة خصم التوأم');
  };

  const handleSaveAttendanceWindow = () => {
    const buffer = Number(openingBufferDraft);
    const percent = Number(closingPercentDraft);
    if (isNaN(buffer) || buffer < 0 || buffer > 120) {
      showToast('مدة الفتح يجب أن تكون بين 0 و 120 دقيقة', 'error');
      return;
    }
    if (isNaN(percent) || percent < 10 || percent > 100) {
      showToast('نسبة الغلق يجب أن تكون بين 10 و 100', 'error');
      return;
    }
    update((d) => {
      d.attendanceOpeningBuffer = buffer;
      d.attendanceClosingPercent = percent;
      logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بتعديل إعدادات وقت الحضور (الفتح قبل الحصة بـ ${buffer} دقيقة، الغلق عند ${percent}% من مدة الحصة).`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حفظ إعدادات وقت الحضور');
  };

  const handleSaveBranding = () => {
    const name = centerNameDraft.trim() || 'سنتر الأفضل';
    update((d) => {
      d.centerName = name;
      d.centerLogo = logoDraft;
      logAction(d, 'تعديل الهوية', `قام ${user?.name || ''} بتعديل هوية السنتر (الاسم: ${name}).`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حفظ هوية السنتر');
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 800 * 1024) {
      showToast('حجم اللوجو يجب أن يكون أقل من 800 ك.ب', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setLogoDraft(reader.result);
    };
    reader.readAsDataURL(file);
    if (logoRef.current) logoRef.current.value = '';
  };

  const handleResetLogo = () => {
    setLogoDraft(null);
  };

  const handleSaveSalaries = () => {
    update((d) => {
      d.secretarySalaries = [];
      for (const u of d.users) {
        if (u.role !== 'secretary') continue;
        const raw = salaryDraft[u.id];
        if (raw === undefined || raw === '') continue;
        const val = Number(raw);
        if (!isNaN(val) && val >= 0) {
          d.secretarySalaries.push({ userId: u.id, amount: val, locked: true, updatedAt: new Date().toISOString() });
        }
      }
      logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بتعديل رواتب السكرتارية.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حفظ رواتب السكرتارية');
  };

  const handleSavePrices = () => {
    update((d) => {
      for (const gp of d.gradePrices) {
        const val = priceDraft[gp.grade];
        if (val !== undefined) gp.price = Number(val) || 0;
      }
      for (const grade of grades) {
        if (!d.gradePrices.find((gp) => gp.grade === grade)) {
          const val = priceDraft[grade];
          if (val) d.gradePrices.push({ grade, price: Number(val) });
        }
      }
      logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بتعديل الإعدادات المركزية (الأسعار الموحدة للصفوف).`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حفظ أسعار الصفوف بنجاح');
  };

  const handleSaveProfitModel = () => {
    const val = Number(profitValueDraft);
    if (isNaN(val) || val < 0) {
      showToast('القيمة يجب أن تكون رقماً صحيحاً', 'error');
      return;
    }
    if (profitModelDraft === 'percentage' && val > 100) {
      showToast('النسبة المئوية يجب أن تكون بين 0 و 100', 'error');
      return;
    }
    update((d) => {
      d.globalProfitModel = profitModelDraft;
      d.globalProfitValue = val;
      logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بتعديل نظام مكسب السنتر العام إلى ${PAYOUT_TYPE_LABELS[profitModelDraft]} (${val}).`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حفظ نظام مكسب السنتر العام');
  };

  const toggleProfitOverride = () => {
    update((d) => {
      d.allowProfitOverride = !d.allowProfitOverride;
      logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بـ${d.allowProfitOverride ? 'تفعيل' : 'تعطيل'} التخصيص الفردي لمكسب المعلمين والمجموعات.`, user?.name || '', user?.role || 'admin');
    });
    showToast(db.allowProfitOverride ? 'تم تعطيل التخصيص الفردي — سيُستخدم النظام العام لجميع المعلمين والمجموعات' : 'تم تفعيل التخصيص الفردي — يمكن تخصيص المكسب لكل معلم أو مجموعة بشكل منفرد');
  };

  const handleExport = () => {
    const json = exportDB(db, user?.name || user?.username || 'unknown');
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = exportFilename();
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('تم تصدير البيانات بنجاح');
  };

  const handleImport = async (file: File) => {
    try {
      const text = await file.text();
      const incoming = JSON.parse(text) as DBType;
      if (!incoming.students || !incoming.teachers) {
        showToast('ملف غير صالح', 'error');
        return;
      }
      const { db: merged, result } = importDB(db, incoming);
      // Stamp sync info
      merged.syncStamp = {
        lastImportTime: new Date().toISOString(),
        lastImportActor: user?.name || null,
      };
      logAction(merged, 'استيراد بيانات', 'تم استيراد نسخة احتياطية', user?.name || '', user?.role || 'admin');
      replace(merged);
      showToast(formatMergeResult(result), 'success');
    } catch {
      showToast('فشل قراءة الملف', 'error');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImport(file);
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleReset = () => {
    const fresh = resetDB();
    replace(fresh);
    setShowReset(false);
    showToast('تمت العودة للمرحلة التجريبية وإعادة ضبط البيانات الأولية بنجاح 🔄', 'success');
  };

  const handleWipe = () => {
    const fresh = wipeDemoData();
    replace(fresh);
    setShowWipe(false);
    showToast('تم تصفير النظام بنجاح — جاهز للبدء الفعلي', 'success');
  };

  const openAddUser = () => {
    setEditingUser(null);
    setUserForm({
      username: '',
      password: '',
      name: '',
      role: 'secretary',
      teacherId: '',
      branchIds: '',
      linkedTeacherId: '',
      linkType: 'both',
      specialty: 'full',
      phone: '',
      payModel: 'fixed_monthly',
      rate: '',
    });
    setShowUserModal(true);
  };

  const openEditUser = (id: string) => {
    const u = db.users.find((x) => x.id === id);
    if (!u) return;
    setEditingUser(id);
    setUserForm({
      username: u.username,
      password: u.password,
      name: u.name,
      role: u.role,
      teacherId: u.teacherId || '',
      branchIds: (u.branchIds || []).join(','),
      linkedTeacherId: u.linkedTeacherId || '',
      linkType: u.linkType || 'both',
      specialty: u.specialty || 'full',
      phone: u.phone || '',
      payModel: u.payModel || 'fixed_monthly',
      rate: u.rate != null ? String(u.rate) : '',
    });
    setShowUserModal(true);
  };

  const handleSaveUser = () => {
    if (!userForm.username.trim() || !userForm.name.trim() || !userForm.password.trim()) {
      showToast('الاسم واسم المستخدم وكلمة المرور مطلوبة', 'error');
      return;
    }
    const dup = db.users.find((u) => u.username === userForm.username.trim() && u.id !== editingUser);
    if (dup) {
      showToast('اسم المستخدم مستخدم بالفعل', 'error');
      return;
    }
    const needsStaff = userForm.role === 'assistant' || userForm.role === 'supervisor' || userForm.role === 'secretary';
    update((d) => {
      const branchIds = userForm.branchIds ? userForm.branchIds.split(',').filter(Boolean) : undefined;
      if (editingUser) {
        const idx = d.users.findIndex((u) => u.id === editingUser);
        if (idx >= 0) {
          d.users[idx] = {
            ...d.users[idx],
            username: userForm.username.trim(),
            password: userForm.password.trim(),
            name: userForm.name.trim(),
            role: userForm.role,
            teacherId: userForm.role === 'teacher' ? (userForm.teacherId || undefined) : undefined,
            branchIds,
            linkedTeacherId: userForm.role === 'secretary' ? (userForm.linkedTeacherId || undefined) : undefined,
            linkType: userForm.role === 'secretary' && userForm.linkedTeacherId ? userForm.linkType : undefined,
            specialty: userForm.role === 'secretary' ? userForm.specialty : undefined,
            phone: needsStaff ? userForm.phone.trim() : undefined,
            payModel: needsStaff ? userForm.payModel : undefined,
            rate: needsStaff ? Number(userForm.rate) || 0 : undefined,
          };
          if (needsStaff) {
            const staffIdx = d.staff.findIndex((s) => s.userId === editingUser);
            if (staffIdx >= 0) {
              d.staff[staffIdx] = { ...d.staff[staffIdx], name: userForm.name.trim(), phone: userForm.phone.trim(), role: userForm.role === 'secretary' ? 'assistant' : userForm.role, payModel: userForm.payModel, rate: Number(userForm.rate) || 0, branchId: branchIds && branchIds[0] ? branchIds[0] : null };
            } else {
              d.staff.push({ id: uid('staff'), userId: editingUser, name: userForm.name.trim(), phone: userForm.phone.trim(), role: userForm.role === 'secretary' ? 'assistant' : userForm.role, payModel: userForm.payModel, rate: Number(userForm.rate) || 0, branchId: branchIds && branchIds[0] ? branchIds[0] : null, active: true, createdAt: new Date().toISOString() } as StaffType);
            }
          }
        }
        logAction(d, 'تعديل مستخدم', `قام ${user?.name || ''} بتعديل حساب ${userForm.name}.`, user?.name || '', user?.role || 'admin');
      } else {
        const newId = `u${Date.now()}`;
        d.users.push({
          id: newId,
          username: userForm.username.trim(),
          password: userForm.password.trim(),
          name: userForm.name.trim(),
          role: userForm.role,
          teacherId: userForm.role === 'teacher' ? (userForm.teacherId || undefined) : undefined,
          branchIds,
          linkedTeacherId: userForm.role === 'secretary' ? (userForm.linkedTeacherId || undefined) : undefined,
          linkType: userForm.role === 'secretary' && userForm.linkedTeacherId ? userForm.linkType : undefined,
          specialty: userForm.role === 'secretary' ? userForm.specialty : undefined,
          phone: needsStaff ? userForm.phone.trim() : undefined,
          payModel: needsStaff ? userForm.payModel : undefined,
          rate: needsStaff ? Number(userForm.rate) || 0 : undefined,
        });
        if (needsStaff) {
          d.staff.push({ id: uid('staff'), userId: newId, name: userForm.name.trim(), phone: userForm.phone.trim(), role: userForm.role === 'secretary' ? 'assistant' : userForm.role, payModel: userForm.payModel, rate: Number(userForm.rate) || 0, branchId: branchIds && branchIds[0] ? branchIds[0] : null, active: true, createdAt: new Date().toISOString() } as StaffType);
        }
        logAction(d, 'إضافة مستخدم', `قام ${user?.name || ''} بإنشاء حساب ${userForm.name} بصلاحية ${roleLabel(userForm.role)}.`, user?.name || '', user?.role || 'admin');
      }
    });
    showToast(editingUser ? 'تم تحديث الحساب' : 'تم إنشاء الحساب بنجاح');
    setShowUserModal(false);
    setEditingUser(null);
  };

  const handleDeleteUser = () => {
    if (!deleteUserId) return;
    const u = db.users.find((x) => x.id === deleteUserId);
    if (u?.role === 'admin' && db.users.filter((x) => x.role === 'admin').length <= 1) {
      showToast('لا يمكن حذف آخر حساب مدير', 'error');
      setDeleteUserId(null);
      return;
    }
    update((d) => {
      d.users = d.users.filter((x) => x.id !== deleteUserId);
      d.staff = d.staff.filter((s) => s.userId !== deleteUserId);
      logAction(d, 'حذف مستخدم', `قام ${user?.name || ''} بحذف حساب ${u?.name || ''}.`, user?.name || '', user?.role || 'admin');
    });
    showToast('تم حذف الحساب', 'info');
    setDeleteUserId(null);
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 flex items-center gap-2">
          <SettingsIcon size={24} /> الإعدادات
        </h2>
        <p className="text-sm text-brand-400 mt-0.5">إدارة الإعدادات المركزية والنسخ الاحتياطي</p>
      </div>

      {/* Centers / Branches Management */}
      {canEditCenter && (
        <Card className="p-5">
          <div className="flex items-center justify-between gap-2 mb-4">
            <div className="flex items-center gap-2">
              <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-600">
                <Building2 size={20} />
              </div>
              <div>
                <h3 className="font-bold text-brand-900">إدارة الفروع والمراكز</h3>
                <p className="text-xs text-brand-400">إضافة وتعديل الفروع (مثال: فرع المهندسين، فرع مدينة نصر)</p>
              </div>
            </div>
            <Button variant="secondary" size="sm" onClick={openAddBranch}>
              <Plus size={16} /> فرع جديد
            </Button>
          </div>

          {branches.length === 0 ? (
            <div className="rounded-2xl bg-brand-50/50 px-4 py-6 text-center">
              <Building2 size={32} className="mx-auto text-brand-300 mb-2" />
              <p className="text-sm font-semibold text-brand-500">لا توجد فروع بعد</p>
              <p className="text-xs text-brand-400 mt-1">أضف فرعًا للبدء في تنظيم البيانات حسب الموقع</p>
            </div>
          ) : (
            <div className="space-y-2">
              {branches.map((b) => {
                const studentCount = db.students.filter((s) => s.branchId === b.id).length;
                const groupCount = db.groups.filter((g) => g.branchId === b.id).length;
                return (
                  <div key={b.id} className="flex items-center gap-3 rounded-2xl bg-brand-50/50 px-4 py-3">
                    <div className="grid place-items-center h-9 w-9 rounded-xl bg-brand-100 text-brand-600 shrink-0">
                      <Building2 size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-brand-900 truncate">{b.name}</p>
                      <p className="text-xs text-brand-400">{studentCount} طالب · {groupCount} مجموعة</p>
                    </div>
                    <button
                      onClick={() => openEditBranch(b)}
                      className="grid place-items-center h-8 w-8 rounded-lg bg-white text-brand-500 hover:bg-brand-100 transition-colors"
                    >
                      <Edit3 size={14} />
                    </button>
                    <button
                      onClick={() => setDeleteBranchId(b.id)}
                      className="grid place-items-center h-8 w-8 rounded-lg bg-white text-rose-500 hover:bg-rose-50 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      )}

      {/* Center Branding */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-violet-100 text-violet-600">
            <ImageIcon size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">هوية السنتر والطباعة</h3>
            <p className="text-xs text-brand-400">اسم السنتر ولوجو يظهران في الترويسة وكروت الطلاب والإيصالات</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-brand-900 mb-1.5">اسم السنتر</label>
            <input
              type="text"
              value={centerNameDraft}
              disabled={!canEditCenter}
              onChange={(e) => setCenterNameDraft(e.target.value)}
              placeholder="سنتر الأفضل"
              className="w-full h-11 rounded-xl border-2 border-slate-200 bg-white px-4 text-sm font-bold text-brand-900 disabled:opacity-60 focus:outline-none focus:border-brand-500"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-brand-900 mb-1.5">لوجو السنتر</label>
            <div className="flex items-center gap-3">
              <div className="grid place-items-center h-16 w-16 rounded-2xl border-2 border-slate-200 bg-brand-50 overflow-hidden shrink-0">
                {logoDraft ? (
                  <img src={logoDraft} alt="logo" className="h-full w-full object-contain" />
                ) : (
                  <ImageIcon size={28} className="text-brand-300" />
                )}
              </div>
              <div className="flex flex-col gap-2">
                {canEditCenter && (
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm" onClick={() => logoRef.current?.click()}>
                      <ImageIcon size={14} /> اختيار صورة
                    </Button>
                    {logoDraft && (
                      <Button variant="outline" size="sm" onClick={handleResetLogo}>
                        <ResetIcon size={14} /> الافتراضي
                      </Button>
                    )}
                  </div>
                )}
                <p className="text-xs text-brand-400">PNG أو JPG، أقل من 800 ك.ب</p>
              </div>
            </div>
            <input ref={logoRef} type="file" accept="image/png,image/jpeg" onChange={handleLogoChange} className="hidden" />
          </div>

          {canEditCenter && (
            <Button onClick={handleSaveBranding}>
              <Save size={18} /> حفظ الهوية
            </Button>
          )}
        </div>
      </Card>

      {/* User Management & Permissions */}
      {canEditSettings(user?.role) && (
        <Card className="p-5">
          <div className="flex items-center justify-between gap-2 mb-4">
            <div className="flex items-center gap-2">
              <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-600">
                <Shield size={20} />
              </div>
              <div>
                <h3 className="font-bold text-brand-900">إدارة المستخدمين والصلاحيات</h3>
                <p className="text-xs text-brand-400">إنشاء حسابات وتعيين الأدوار والفروع — المدير يرى الكل، السكرتير مقتصر على فرعه، المعلم على مجموعاته</p>
              </div>
            </div>
            <Button variant="secondary" size="sm" onClick={openAddUser}>
              <Plus size={16} /> حساب جديد
            </Button>
          </div>

          <div className="space-y-2">
            {db.users.map((u) => {
              const teacher = u.teacherId ? db.teachers.find((t) => t.id === u.teacherId) : null;
              const linkedTeacher = u.linkedTeacherId ? db.teachers.find((t) => t.id === u.linkedTeacherId) : null;
              const branches = (u.branchIds || []).map((bid) => db.branches.find((b) => b.id === bid)?.name).filter(Boolean);
              const linkTypeLabel = u.linkType === 'attendance' ? 'حضور فقط' : u.linkType === 'payments' ? 'دفع فقط' : 'شامل';
              const specialtyLabel = u.specialty === 'attendance' ? 'حضور' : u.specialty === 'collection' ? 'تحصيل' : u.specialty === 'materials' ? 'مذكرات' : 'شامل';
              return (
                <div key={u.id} className="flex items-center gap-3 rounded-2xl bg-brand-50/50 px-4 py-3">
                  <div className={`grid place-items-center h-9 w-9 rounded-xl shrink-0 ${u.role === 'admin' ? 'bg-rose-100 text-rose-600' : u.role === 'teacher' ? 'bg-emerald-100 text-emerald-600' : u.role === 'supervisor' ? 'bg-sky-100 text-sky-600' : 'bg-brand-100 text-brand-600'}`}>
                    {u.role === 'admin' ? <Shield size={16} /> : u.role === 'teacher' ? <GraduationCap size={16} /> : u.role === 'supervisor' ? <Users size={16} /> : <UserCog size={16} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-bold text-brand-900 truncate">{u.name}</p>
                      {u.role === 'secretary' && u.specialty && u.specialty !== 'full' && (
                        <Badge tone={u.specialty === 'attendance' ? 'amber' : u.specialty === 'collection' ? 'emerald' : 'violet'} className="text-[9px]">{specialtyLabel}</Badge>
                      )}
                      {u.role === 'secretary' && linkedTeacher && (
                        <Badge tone="brand" className="text-[9px]">{linkedTeacher.name} — {linkTypeLabel}</Badge>
                      )}
                    </div>
                    <p className="text-xs text-brand-400 truncate">
                      {roleLabel(u.role)}
                      {teacher ? ` — ${teacher.name}` : ''}
                      {branches.length > 0 ? ` — ${branches.join('، ')}` : u.role === 'admin' ? ' — كل الفروع' : ''}
                    </p>
                  </div>
                  <button onClick={() => openEditUser(u.id)} className="grid place-items-center h-8 w-8 rounded-lg bg-white text-brand-500 hover:bg-brand-100 transition-colors" title="تعديل">
                    <Edit3 size={14} />
                  </button>
                  {u.role !== 'admin' && (
                    <button onClick={() => setDeleteUserId(u.id)} className="grid place-items-center h-8 w-8 rounded-lg bg-white text-rose-500 hover:bg-rose-50 transition-colors" title="حذف">
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      )}


      {/* Secretary Salaries */}
      {canEditSettings(user?.role) && db.users.filter((u) => u.role === 'secretary').length > 0 && (
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-600">
              <UserCog size={20} />
            </div>
            <div>
              <h3 className="font-bold text-brand-900">رواتب السكرتارية</h3>
              <p className="text-xs text-brand-400">تحديد الراتب الشهري الثابت لكل سكرتارية — يظهر لها كقيمة للقراءة فقط</p>
            </div>
          </div>
          <div className="space-y-2">
            {db.users.filter((u) => u.role === 'secretary').map((u) => {
              const existing = db.secretarySalaries.find((s) => s.userId === u.id);
              const val = salaryDraft[u.id] ?? (existing ? String(existing.amount) : '');
              return (
                <div key={u.id} className="flex items-center gap-3 rounded-2xl bg-brand-50/50 px-3 py-2.5">
                  <div className="grid place-items-center h-9 w-9 rounded-xl bg-brand-100 text-brand-600 shrink-0">
                    <UserCog size={16} />
                  </div>
                  <span className="flex-1 text-sm font-bold text-brand-900 truncate">{u.name}</span>
                  <div className="relative w-32">
                    <input
                      type="number"
                      value={val}
                      onChange={(e) => setSalaryDraft((prev) => ({ ...prev, [u.id]: e.target.value }))}
                      className="w-full h-10 rounded-xl border-2 border-slate-200 bg-white px-3 pl-9 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500"
                      placeholder="0"
                      min="0"
                    />
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] font-bold text-brand-400">ج.م</span>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-3">
            <Button onClick={handleSaveSalaries}>
              <Save size={18} /> حفظ الرواتب
            </Button>
          </div>
        </Card>
      )}

      {/* ID Card Price */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-amber-100 text-amber-600">
            <CreditCard size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">سعر كارت ID</h3>
            <p className="text-xs text-brand-400">السعر الافتراضي لرسوم كارت الهوية للطالب</p>
          </div>
        </div>

        {!canEditCenter && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-sm font-semibold text-amber-700 mb-4 flex items-center gap-2">
            <Lock size={14} /> يمكنك العرض فقط — التعديل متاح للمدير
          </div>
        )}

        <div className="flex items-center gap-3 max-w-xs">
          <div className="relative flex-1">
            <input
              type="number"
              value={idCardDraft}
              disabled={!canEditCenter}
              onChange={(e) => setIdCardDraft(e.target.value)}
              className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white px-4 pl-12 text-lg font-bold text-brand-900 disabled:opacity-60 focus:outline-none focus:border-brand-500"
              min="0"
            />
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-brand-400">ج.م</span>
          </div>
          {canEditCenter && (
            <Button onClick={handleSaveIdCard}>
              <Save size={18} /> حفظ
            </Button>
          )}
        </div>
      </Card>

      {/* Sibling Discount */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-amber-100 text-amber-600">
            <Users2 size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">نظام الخصومات</h3>
            <p className="text-xs text-brand-400">خصم الأشقاء تلقائياً + خصم التوأم + خصومات خاصة لكل طالب</p>
          </div>
        </div>

        {!canEditCenter && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-sm font-semibold text-amber-700 mb-4 flex items-center gap-2">
            <Lock size={14} /> يمكنك العرض فقط — التعديل متاح للمدير
          </div>
        )}

        {/* Sibling discount config */}
        <div className="rounded-2xl bg-amber-50/50 border border-amber-100 p-4 mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-brand-900 flex items-center gap-1.5">
              <Users2 size={16} className="text-amber-500" /> خصم الأشقاء
            </span>
            <Badge tone="amber">تلقائي</Badge>
          </div>
          <p className="text-xs text-brand-400 mb-3">عند تسجيل طالب جديد يطابق اسم العائلة أو هاتف ولي الأمر طالباً موجوداً، سيُطبّق هذا الخصم تلقائياً على رسومه.</p>
          <div className="flex items-center gap-3 max-w-xs">
            <div className="relative flex-1">
              <input
                type="number"
                value={siblingDraft}
                disabled={!canEditCenter}
                onChange={(e) => setSiblingDraft(e.target.value)}
                className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white px-4 pl-12 text-lg font-bold text-brand-900 disabled:opacity-60 focus:outline-none focus:border-brand-500"
                min="0"
                max="100"
              />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-brand-400">%</span>
            </div>
            {canEditCenter && (
              <Button onClick={handleSaveSibling}>
                <Save size={18} /> حفظ
              </Button>
            )}
          </div>
        </div>

        {/* Twin discount config */}
        <div className="rounded-2xl bg-violet-50/50 border border-violet-100 p-4 mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-brand-900 flex items-center gap-1.5">
              <Users size={16} className="text-violet-500" /> خصم التوأم
            </span>
            <Badge tone="violet">يدوي</Badge>
          </div>
          <p className="text-xs text-brand-400 mb-3">عند اكتشاف أشقاء يمكن للمسؤول اختيار نوع الخصم (أشقاء أو توأم). خصم التوأم يكون عادةً أعلى من خصم الأشقاء العادي.</p>
          <div className="flex items-center gap-3 max-w-xs">
            <div className="relative flex-1">
              <input
                type="number"
                value={twinDraft}
                disabled={!canEditCenter}
                onChange={(e) => setTwinDraft(e.target.value)}
                className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white px-4 pl-12 text-lg font-bold text-brand-900 disabled:opacity-60 focus:outline-none focus:border-brand-500"
                min="0"
                max="100"
              />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-brand-400">%</span>
            </div>
            {canEditCenter && (
              <Button onClick={handleSaveTwin}>
                <Save size={18} /> حفظ
              </Button>
            )}
          </div>
        </div>

        {/* Special discount info */}
        <div className="rounded-2xl bg-rose-50/50 border border-rose-100 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-brand-900 flex items-center gap-1.5">
              <Star size={16} className="text-rose-500" /> الخصم الخاص
            </span>
            <Badge tone="rose">لكل طالب</Badge>
          </div>
          <p className="text-xs text-brand-400 mb-3">يمكن منح خصم خاص لكل طالب على حدة من صفحة الطلاب (مثال: تفوق دراسي، ظرف خاص). يُطبّق على رسومه بعد خصم الأخوة إن وُجد.</p>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl bg-white px-3 py-2.5 border border-slate-100">
              <p className="text-2xl font-extrabold text-rose-600">{db.students.filter((s) => s.hasSpecialDiscount).length}</p>
              <p className="text-xs text-brand-400 font-semibold">طالب بخصم خاص</p>
            </div>
            <div className="rounded-xl bg-white px-3 py-2.5 border border-slate-100">
              <p className="text-2xl font-extrabold text-amber-600">{db.students.filter((s) => s.hasSiblingDiscount && s.discountType !== 'twin').length}</p>
              <p className="text-xs text-brand-400 font-semibold">طالب بخصم أشقاء</p>
            </div>
            <div className="rounded-xl bg-white px-3 py-2.5 border border-slate-100">
              <p className="text-2xl font-extrabold text-violet-600">{db.students.filter((s) => s.discountType === 'twin').length}</p>
              <p className="text-xs text-brand-400 font-semibold">طالب بخصم توأم</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Global Center Profit Model */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-600">
            <DollarSign size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">نظام حساب مكسب السنتر العام</h3>
            <p className="text-xs text-brand-400">النظام الموحد لحساب حصة السنتر من إيراد جميع المجموعات والمعلمين</p>
          </div>
        </div>

        {!canEditCenter && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-sm font-semibold text-amber-700 mb-4 flex items-center gap-2">
            <Lock size={14} /> يمكنك العرض فقط — التعديل متاح للمدير
          </div>
        )}

        {/* Profit Model Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-4">
          {(['percentage', 'fixed_seat', 'flat_per_session'] as PayoutType[]).map((model) => (
            <button
              key={model}
              type="button"
              disabled={!canEditCenter}
              onClick={() => setProfitModelDraft(model)}
              className={`px-4 py-3 rounded-2xl text-sm font-bold transition-all disabled:opacity-60 ${profitModelDraft === model ? 'gradient-brand text-white shadow-soft' : 'bg-brand-50 text-brand-600 hover:bg-brand-100'}`}
            >
              {model === 'percentage' ? 'نسبة مئوية من سعر الطالب' : model === 'fixed_seat' ? 'مبلغ ثابت على كل طالب' : 'مبلغ ثابت على الحصة'}
            </button>
          ))}
        </div>

        {/* Value Input */}
        <div className="flex items-center gap-3 max-w-xs mb-4">
          <div className="relative flex-1">
            <input
              type="number"
              value={profitValueDraft}
              disabled={!canEditCenter}
              onChange={(e) => setProfitValueDraft(e.target.value)}
              className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white px-4 pl-12 text-lg font-bold text-brand-900 disabled:opacity-60 focus:outline-none focus:border-brand-500"
              min="0"
              max={profitModelDraft === 'percentage' ? 100 : undefined}
            />
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-brand-400">
              {profitModelDraft === 'percentage' ? '%' : 'ج.م'}
            </span>
          </div>
          {canEditCenter && (
            <Button onClick={handleSaveProfitModel}>
              <Save size={18} /> حفظ
            </Button>
          )}
        </div>

        {/* Override Toggle */}
        <div className="rounded-2xl bg-brand-50/50 border border-brand-100 px-4 py-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex-1">
              <p className="font-bold text-brand-900 text-sm">السماح بتخصيص طريقة المكسب لكل معلم أو مجموعة بشكل منفرد</p>
              <p className="text-xs text-brand-400 mt-1">
                {db.allowProfitOverride
                  ? 'مفعل — يمكن تخصيص نظام مكسب منفصل لكل معلم أو مجموعة من صفحات المعلمين والمجموعات'
                  : 'مغلق (الافتراضي) — جميع المعلمين والمجموعات تستخدم النظام العام الإلزامي'}
              </p>
            </div>
            {canEditCenter && (
              <button
                onClick={toggleProfitOverride}
                className={`relative h-8 w-14 rounded-full transition-colors shrink-0 ${db.allowProfitOverride ? 'bg-emerald-500' : 'bg-slate-300'}`}
              >
                <span className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-md transition-all ${db.allowProfitOverride ? 'left-1' : 'left-7'}`} />
              </button>
            )}
          </div>
          {!db.allowProfitOverride && (
            <div className="mt-3 flex items-start gap-2 rounded-xl bg-amber-50 border border-amber-200 px-3 py-2">
              <Lock size={14} className="text-amber-600 shrink-0 mt-0.5" />
              <p className="text-xs font-semibold text-amber-700">حقول المكسب الفردية في صفحات المعلمين والمجموعات مغلقة ومخفية حالياً. جميع الحصص تستخدم النظام العام.</p>
            </div>
          )}
        </div>
      </Card>

      {/* Grade Pricing */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-emerald-100 text-emerald-600">
            <DollarSign size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">أسعار الصفوف الدراسية</h3>
            <p className="text-xs text-brand-400">السعر الموحد لكل صف — يُستخدم في تسعير المجموعات والمدفوعات</p>
          </div>
        </div>

        {!canEditPrices && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-sm font-semibold text-amber-700 mb-4 flex items-center gap-2">
            <Lock size={14} /> يمكنك العرض فقط — التعديل متاح للمدير
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {grades.map((grade) => {
            const existing = db.gradePrices.find((gp) => gp.grade === grade);
            const val = priceDraft[grade] ?? (existing ? String(existing.price) : '');
            const price = Number(val) || 0;
            const { centerShare, teacherShare } = computeSharesForPrice(db, price);
            return (
              <div key={grade} className="rounded-2xl bg-brand-50/50 px-4 py-3">
                <label className="block">
                  <span className="block text-sm font-semibold text-brand-900 mb-1.5">{grade}</span>
                  <div className="relative">
                    <input
                      type="number"
                      value={val}
                      disabled={!canEditPrices}
                      onChange={(e) => setPriceDraft((prev) => ({ ...prev, [grade]: e.target.value }))}
                      className="w-full h-11 rounded-xl border-2 border-slate-200 bg-white px-3 pl-12 text-sm font-bold text-brand-900 disabled:opacity-60 focus:outline-none focus:border-brand-500"
                      placeholder="0"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-brand-400">ج.م</span>
                  </div>
                </label>
                {price > 0 && (
                  <div className="mt-2 flex items-center gap-2 text-[10px] font-semibold">
                    <Badge tone="brand" className="text-[9px]">السنتر: {formatEGP(centerShare)}</Badge>
                    <Badge tone="emerald" className="text-[9px]">المعلم: {formatEGP(teacherShare)}</Badge>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {canEditPrices && (
          <div className="mt-4">
            <Button onClick={handleSavePrices}>
              <Save size={18} /> حفظ الأسعار
            </Button>
          </div>
        )}
      </Card>

      {/* QR Code System Toggle */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-violet-100 text-violet-600">
            <QrCode size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">نظام تسجيل الحضور عبر QR Code 📱</h3>
            <p className="text-xs text-brand-400">تفعيل المسح السريع بالكاميرا أو قارئ الباركود لتسجيل الحضور — عند الإيقاف يتم استخدام البحث اليدوي</p>
          </div>
        </div>

        {!canEditCenter && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-sm font-semibold text-amber-700 mb-4 flex items-center gap-2">
            <Lock size={14} /> يمكنك العرض فقط — التعديل متاح للمدير
          </div>
        )}

        <div className="flex items-center justify-between rounded-2xl bg-brand-50/50 px-4 py-4">
          <div className="flex items-center gap-3">
            <div className={`grid place-items-center h-12 w-12 rounded-2xl transition-colors ${db.qrEnabled ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
              <QrCode size={24} />
            </div>
            <div>
              <p className="font-bold text-brand-900 text-sm">تفعيل نظام تسجيل الحضور عبر QR Code 📱</p>
              <p className="text-xs text-brand-400 mt-0.5">{db.qrEnabled ? 'مفعّل — المسح بالكاميرا والباركود متاح كواجهة أساسية' : 'معطل — الحضور بالبحث اليدوي فقط'}</p>
            </div>
          </div>
          {canEditCenter && (
            <button
              onClick={() => {
                update((d) => {
                  d.qrEnabled = !d.qrEnabled;
                  logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بـ${d.qrEnabled ? 'تفعيل' : 'تعطيل'} نظام الـ QR Code.`, user?.name || '', user?.role || 'admin');
                });
                showToast(db.qrEnabled ? 'تم تعطيل نظام الـ QR' : 'تم تفعيل نظام الـ QR');
              }}
              className={`relative h-8 w-14 rounded-full transition-colors ${db.qrEnabled ? 'bg-emerald-500' : 'bg-slate-300'}`}
            >
              <span className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-md transition-all ${db.qrEnabled ? 'left-1' : 'left-7'}`} />
            </button>
          )}
        </div>
      </Card>

      {/* Attendance Window Settings */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-600">
            <Clock size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">إعدادات وقت الحضور والغياب الآلي</h3>
            <p className="text-xs text-brand-400">تحكم في فتح وإغلاق نافذة تسجيل الحضور تلقائياً</p>
          </div>
        </div>
        {!canEditCenter && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-sm font-semibold text-amber-700 mb-4 flex items-center gap-2">
            <Lock size={14} /> يمكنك العرض فقط — التعديل متاح للمدير
          </div>
        )}
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-brand-900 mb-1.5">بداية فتح الحضور (دقائق قبل الحصة)</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={openingBufferDraft}
                  onChange={(e) => setOpeningBufferDraft(e.target.value)}
                  disabled={!canEditCenter}
                  className="flex-1 h-11 rounded-xl border-2 border-slate-200 bg-white px-3 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500 disabled:bg-slate-50"
                  placeholder="10"
                />
                <span className="grid place-items-center px-3 rounded-xl bg-brand-50 text-brand-600 text-sm font-bold shrink-0">دقيقة</span>
              </div>
              <p className="text-xs text-brand-400 mt-1">افتراضي: 10 دقائق قبل موعد الحصة</p>
            </div>
            <div>
              <label className="block text-sm font-semibold text-brand-900 mb-1.5">غلق الحضور (% من مدة الحصة)</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={closingPercentDraft}
                  onChange={(e) => setClosingPercentDraft(e.target.value)}
                  disabled={!canEditCenter}
                  className="flex-1 h-11 rounded-xl border-2 border-slate-200 bg-white px-3 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500 disabled:bg-slate-50"
                  placeholder="50"
                />
                <span className="grid place-items-center px-3 rounded-xl bg-brand-50 text-brand-600 text-sm font-bold shrink-0">%</span>
              </div>
              <p className="text-xs text-brand-400 mt-1">افتراضي: 50% (منتصف الحصة) — يتم تسجيل غياب الباقي تلقائياً</p>
            </div>
          </div>
          {canEditCenter && (
            <Button onClick={handleSaveAttendanceWindow}>
              <Save size={16} /> حفظ إعدادات وقت الحضور
            </Button>
          )}
        </div>

        {/* Flexible attendance time toggle */}
        <div className="mt-5 rounded-2xl bg-brand-50/50 border border-brand-100 px-4 py-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex-1">
              <p className="font-bold text-brand-900 text-sm flex items-center gap-1.5">
                <Clock size={16} className="text-brand-500" />
                السماح بتسجيل الحضور والغياب في أي وقت (إلغاء التقييد بمواعيد الحصص) 🔓
              </p>
              <p className="text-xs text-brand-400 mt-1">
                {db.allowFlexibleAttendanceTime
                  ? 'مفعل — يمكن تسجيل الحضور والغياب في أي وقت بدون قيود أو تأخير تلقائي'
                  : 'مغلق (الافتراضي) — يُطبّق التقييد بمواعيد الحصص وتسجيل التأخير والغياب التلقائي'}
              </p>
            </div>
            {canEditCenter && (
              <button
                onClick={() => {
                  update((d) => {
                    d.allowFlexibleAttendanceTime = !d.allowFlexibleAttendanceTime;
                    logAction(d, 'تعديل الإعدادات', `قام ${user?.name || ''} بـ${d.allowFlexibleAttendanceTime ? 'تفعيل' : 'تعطيل'} مرونة وقت الحضور والغياب.`, user?.name || '', user?.role || 'admin');
                  });
                  showToast(db.allowFlexibleAttendanceTime ? 'تم تعطيل مرونة وقت الحضور — سيُطبّق التقييد بمواعيد الحصص' : 'تم تفعيل مرونة وقت الحضور — يمكن التسجيل في أي وقت');
                }}
                className={`relative h-8 w-14 rounded-full transition-colors shrink-0 ${db.allowFlexibleAttendanceTime ? 'bg-emerald-500' : 'bg-slate-300'}`}
              >
                <span className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-md transition-all ${db.allowFlexibleAttendanceTime ? 'left-1' : 'left-7'}`} />
              </button>
            )}
          </div>
        </div>
      </Card>

      {/* PWA Install */}
      {canInstall && (
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="grid place-items-center h-10 w-10 rounded-2xl bg-emerald-100 text-emerald-600">
              <Smartphone size={20} />
            </div>
            <div>
              <h3 className="font-bold text-brand-900">تثبيت التطبيق على الهاتف</h3>
              <p className="text-xs text-brand-400">ثبّت التطبيق كتطبيق موبايل يعمل بدون متصفح وبدون إنترنت</p>
            </div>
          </div>
          <Button variant="secondary" onClick={promptInstall}>
            <Smartphone size={18} /> تثبيت التطبيق على الهاتف
          </Button>
        </Card>
      )}

      {/* Data Management */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="grid place-items-center h-10 w-10 rounded-2xl bg-brand-100 text-brand-600">
            <Database size={20} />
          </div>
          <div>
            <h3 className="font-bold text-brand-900">تصدير / استيراد إعدادات السنتر</h3>
            <p className="text-xs text-brand-400">نسخة احتياطية كاملة بصيغة JSON — جميع البيانات والإعدادات</p>
          </div>
        </div>

        {/* Data summary */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-4">
          {[
            { label: 'طلاب', count: db.students.length },
            { label: 'مجموعات', count: db.groups.length },
            { label: 'مدفوعات', count: db.payments.length },
            { label: 'مذكرات', count: db.materials.length },
            { label: 'معلمين', count: db.teachers.length },
            { label: 'فروع', count: db.branches.length },
          ].map((item) => (
            <div key={item.label} className="rounded-xl bg-slate-50 px-2 py-2 text-center border border-slate-100">
              <p className="text-lg font-extrabold text-brand-900">{item.count}</p>
              <p className="text-[10px] text-brand-400 font-semibold">{item.label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {allowExport && (
            <button
              onClick={handleExport}
              className="rounded-2xl border-2 border-brand-200 bg-brand-50 p-4 text-right transition-all hover:bg-brand-100 hover:border-brand-300 active:scale-[0.98]"
            >
              <div className="flex items-center gap-3">
                <div className="grid place-items-center h-11 w-11 rounded-xl gradient-brand text-white">
                  <Download size={22} />
                </div>
                <div>
                  <p className="font-bold text-brand-900">تصدير إعدادات السنتر</p>
                  <p className="text-xs text-brand-400">تنزيل نسخة JSON كاملة</p>
                </div>
              </div>
            </button>
          )}

          {allowImport && (
            <button
              onClick={() => fileRef.current?.click()}
              className="rounded-2xl border-2 border-emerald-200 bg-emerald-50 p-4 text-right transition-all hover:bg-emerald-100 hover:border-emerald-300 active:scale-[0.98]"
            >
              <div className="flex items-center gap-3">
                <div className="grid place-items-center h-11 w-11 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 text-white">
                  <Upload size={22} />
                </div>
                <div>
                  <p className="font-bold text-brand-900">استيراد إعدادات السنتر</p>
                  <p className="text-xs text-brand-400">دمج ملف JSON مع البيانات الحالية</p>
                </div>
              </div>
            </button>
          )}
        </div>

        <input ref={fileRef} type="file" accept="application/json,.json" onChange={handleFileChange} className="hidden" />

        {!allowExport && !allowImport && (
          <div className="rounded-2xl bg-slate-50 px-4 py-3 text-sm text-brand-400 text-center">
            لا تملك صلاحية إدارة البيانات
          </div>
        )}

        {/* Sync stamp display */}
        {db.syncStamp.lastImportTime && (
          <div className="mt-4 rounded-2xl bg-brand-50/50 px-4 py-3 text-xs text-brand-500 flex items-center gap-2">
            <Database size={14} className="shrink-0" />
            <span>آخر استيراد: {new Date(db.syncStamp.lastImportTime).toLocaleString('ar-EG')} {db.syncStamp.lastImportActor ? `بواسطة ${db.syncStamp.lastImportActor}` : ''}</span>
          </div>
        )}
      </Card>

      {/* Danger zone (admin only) */}
      {user?.role === 'admin' && (
        <Card className="p-5 border-2 border-rose-100">
          <div className="flex items-center gap-2 mb-4">
            <div className="grid place-items-center h-10 w-10 rounded-2xl bg-rose-100 text-rose-600">
              <AlertTriangle size={20} />
            </div>
            <div>
              <h3 className="font-bold text-brand-900">منطقة الخطر</h3>
              <p className="text-xs text-brand-400">إعادة ضبط البيانات أو تصفير النظام للبدء الفعلي</p>
            </div>
          </div>

          {/* Wipe Demo Data */}
          <div className="rounded-2xl border-2 border-rose-200 bg-rose-50/50 p-4 mb-3">
            <p className="text-sm font-bold text-rose-700 mb-1">تصفير النظام والبدء الفعلي</p>
            <p className="text-xs text-rose-500 mb-3">يحذف جميع البيانات التجريبية (طلاب، مجموعات، مصروفات، مدفوعات) ويترك حساب المدير فقط. لا يمكن التراجع.</p>
            <Button variant="danger" onClick={() => setShowWipe(true)}>
              <Trash2 size={18} /> تصفير النظام والبدء الفعلي (Wipe Demo Data)
            </Button>
          </div>

          {/* Reset to seed */}
          <Button variant="outline" onClick={() => setShowReset(true)}>
            <RotateCcw size={18} /> إعادة ضبط للبيانات الأولية
          </Button>
        </Card>
      )}

      <ConfirmDialog
        open={showReset}
        title="إعادة ضبط البيانات"
        message="⚠️ هل أنت تأكد من مسح البيانات الحالية والعودة للمرحلة التجريبية؟ (سيتم تحميل بيانات توضيحية تجريبية للسنتر)"
        confirmText="إعادة الضبط"
        danger
        onConfirm={handleReset}
        onCancel={() => setShowReset(false)}
      />

      <ConfirmDialog
        open={showWipe}
        title="تصفير النظام والبدء الفعلي"
        message="سيتم حذف جميع البيانات التجريبية نهائياً (طلاب، مجموعات، مصروفات، مدفوعات، سجل الحركات) والاحتفاظ بحساب المدير فقط. لا يمكن التراجع عن هذا الإجراء."
        confirmText="تصفير نهائي"
        danger
        onConfirm={handleWipe}
        onCancel={() => setShowWipe(false)}
      />

      <ConfirmDialog
        open={!!deleteBranchId}
        title="حذف الفرع"
        message="سيتم حذف الفرع وفصل جميع الطلاب والمجموعات والمدفوعات المرتبطة به (تبقى بدون فرع). لا يمكن التراجع."
        confirmText="حذف"
        danger
        onConfirm={handleDeleteBranch}
        onCancel={() => setDeleteBranchId(null)}
      />

      <Modal
        open={showBranchModal}
        onClose={() => setShowBranchModal(false)}
        title={editingBranch ? 'تعديل الفرع' : 'فرع جديد'}
        size="sm"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-brand-900 mb-1.5">اسم الفرع</label>
            <input
              type="text"
              value={branchName}
              onChange={(e) => setBranchName(e.target.value)}
              placeholder="مثال: فرع المهندسين"
              className="w-full h-12 rounded-xl border-2 border-slate-200 bg-white px-4 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500"
              autoFocus
            />
          </div>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setShowBranchModal(false)}>
              <X size={16} /> إلغاء
            </Button>
            <Button onClick={handleSaveBranch}>
              <Save size={16} /> حفظ
            </Button>
          </div>
        </div>
      </Modal>

      {/* User Management Modal */}
      <Modal
        open={showUserModal}
        onClose={() => { setShowUserModal(false); setEditingUser(null); }}
        title={editingUser ? 'تعديل حساب' : 'حساب جديد'}
        size="md"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-brand-900 mb-1.5">الاسم</label>
              <input
                type="text"
                value={userForm.name}
                onChange={(e) => setUserForm((p) => ({ ...p, name: e.target.value }))}
                placeholder="مثال: أحمد محمد"
                className="w-full h-11 rounded-xl border-2 border-slate-200 bg-white px-3 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-brand-900 mb-1.5">اسم المستخدم</label>
              <input
                type="text"
                value={userForm.username}
                onChange={(e) => setUserForm((p) => ({ ...p, username: e.target.value }))}
                placeholder="username"
                className="w-full h-11 rounded-xl border-2 border-slate-200 bg-white px-3 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-brand-900 mb-1.5">كلمة المرور</label>
            <input
              type="text"
              value={userForm.password}
              onChange={(e) => setUserForm((p) => ({ ...p, password: e.target.value }))}
              placeholder="••••••"
              className="w-full h-11 rounded-xl border-2 border-slate-200 bg-white px-3 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-brand-900 mb-1.5">الصلاحية</label>
            <div className="grid grid-cols-2 gap-2">
              {([
                { value: 'admin', label: 'مدير', icon: Shield },
                { value: 'teacher', label: 'معلم', icon: GraduationCap },
                { value: 'secretary', label: 'سكرتير / مساعد', icon: UserCog },
                { value: 'supervisor', label: 'مشرف', icon: Users },
              ] as const).map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setUserForm((p) => ({ ...p, role: opt.value, teacherId: '', linkedTeacherId: '', linkType: 'both', specialty: 'full' }))}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${userForm.role === opt.value ? 'bg-brand-500 text-white shadow-sm' : 'bg-slate-100 text-brand-600 hover:bg-slate-200'}`}
                >
                  <opt.icon size={14} /> {opt.label}
                </button>
              ))}
            </div>
          </div>
          {userForm.role === 'teacher' && (
            <div>
              <label className="block text-sm font-semibold text-brand-900 mb-1.5">المعلم المرتبط</label>
              <select
                value={userForm.teacherId}
                onChange={(e) => setUserForm((p) => ({ ...p, teacherId: e.target.value }))}
                className="w-full h-11 rounded-xl border-2 border-slate-200 bg-white px-3 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500"
              >
                <option value="">بدون معلم</option>
                {db.teachers.map((t) => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>
          )}
          {userForm.role === 'secretary' && (
            <div className="space-y-3 rounded-2xl bg-brand-50/50 border border-brand-100 p-4">
              <div>
                <label className="block text-sm font-semibold text-brand-900 mb-1.5">ربط السكرتير بالمدرس</label>
                <select
                  value={userForm.linkedTeacherId}
                  onChange={(e) => setUserForm((p) => ({ ...p, linkedTeacherId: e.target.value, linkType: e.target.value ? p.linkType : 'both' }))}
                  className="w-full h-11 rounded-xl border-2 border-slate-200 bg-white px-3 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500"
                >
                  <option value="">عام / جميع المدرسين</option>
                  {db.teachers.map((t) => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>
              {userForm.linkedTeacherId && (
                <div>
                  <label className="block text-sm font-semibold text-brand-900 mb-1.5">نوع الربط بالمدرس</label>
                  <div className="grid grid-cols-3 gap-2">
                    {([
                      { value: 'attendance', label: 'حضور وغياب فقط' },
                      { value: 'payments', label: 'دفع وتحصيل فقط' },
                      { value: 'both', label: 'شامل / الاثنين' },
                    ] as const).map((opt) => (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setUserForm((p) => ({ ...p, linkType: opt.value }))}
                        className={`px-2 py-2.5 rounded-xl text-xs font-bold transition-all text-center ${userForm.linkType === opt.value ? 'bg-brand-500 text-white shadow-sm' : 'bg-white text-brand-600 hover:bg-brand-50 border border-slate-200'}`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                  {userForm.linkType === 'attendance' && (
                    <p className="text-[11px] text-amber-600 font-semibold mt-2">سيتم إخفاء جميع مزايا الدفع والتحصيل والمذكرات لهذا السكرتير.</p>
                  )}
                  {userForm.linkType === 'payments' && (
                    <p className="text-[11px] text-amber-600 font-semibold mt-2">سيتم إخفاء مزايا الحضور والغياب والمسح الضوئي لهذا السكرتير.</p>
                  )}
                </div>
              )}
              <div>
                <label className="block text-sm font-semibold text-brand-900 mb-1.5">تخصص الصلاحية</label>
                <div className="grid grid-cols-4 gap-2">
                  {([
                    { value: 'full', label: 'شامل' },
                    { value: 'attendance', label: 'حضور' },
                    { value: 'collection', label: 'تحصيل' },
                    { value: 'materials', label: 'مذكرات' },
                  ] as const).map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setUserForm((p) => ({ ...p, specialty: opt.value }))}
                      className={`px-2 py-2.5 rounded-xl text-xs font-bold transition-all text-center ${userForm.specialty === opt.value ? 'bg-brand-500 text-white shadow-sm' : 'bg-white text-brand-600 hover:bg-brand-50 border border-slate-200'}`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
                {userForm.specialty !== 'full' && (
                  <p className="text-[11px] text-amber-600 font-semibold mt-2">
                    {userForm.specialty === 'attendance' && 'سيقتصر وصول السكرتير على صفحات الحضور والغياب فقط.'}
                    {userForm.specialty === 'collection' && 'سيقتصر وصول السكرتير على صفحات الدفع والتحصيل فقط.'}
                    {userForm.specialty === 'materials' && 'سيقتصر وصول السكرتير على إدارة المذكرات فقط.'}
                  </p>
                )}
              </div>
            </div>
          )}
          {(userForm.role === 'secretary' || userForm.role === 'assistant' || userForm.role === 'supervisor') && (
            <div className="rounded-2xl bg-brand-50/60 border border-brand-100 p-4 space-y-3">
              <p className="text-sm font-bold text-brand-900 flex items-center gap-1.5">
                <Banknote size={16} className="text-brand-500" /> نظام الأجر والراتب
              </p>
              <div>
                <label className="block text-sm font-semibold text-brand-900 mb-1.5">رقم الهاتف</label>
                <input
                  type="tel"
                  value={userForm.phone}
                  onChange={(e) => setUserForm((p) => ({ ...p, phone: e.target.value }))}
                  placeholder="01xxxxxxxxx"
                  className="w-full h-11 rounded-xl border-2 border-slate-200 bg-white px-3 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-brand-900 mb-1.5">نظام الأجر</label>
                <div className="grid grid-cols-3 gap-2">
                  {([
                    { value: 'fixed_monthly', label: 'شهري' },
                    { value: 'per_session', label: 'بالحصة' },
                    { value: 'percentage', label: 'نسبة مئوية' },
                  ] as const).map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setUserForm((p) => ({ ...p, payModel: opt.value }))}
                      className={`px-2 py-2.5 rounded-xl text-xs font-bold transition-all text-center ${userForm.payModel === opt.value ? 'bg-brand-500 text-white shadow-sm' : 'bg-white text-brand-600 hover:bg-brand-50 border border-slate-200'}`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-brand-900 mb-1.5">
                  القيمة ({userForm.payModel === 'fixed_monthly' ? 'ج.م/شهر' : userForm.payModel === 'per_session' ? 'ج.م/حصة' : '%'})
                </label>
                <input
                  type="number"
                  value={userForm.rate}
                  onChange={(e) => setUserForm((p) => ({ ...p, rate: e.target.value }))}
                  placeholder="0"
                  className="w-full h-11 rounded-xl border-2 border-slate-200 bg-white px-3 text-sm font-bold text-brand-900 focus:outline-none focus:border-brand-500"
                />
              </div>
            </div>
          )}
          {userForm.role !== 'admin' && db.branches.length > 0 && (
            <div>
              <label className="block text-sm font-semibold text-brand-900 mb-1.5">الفروع المسموح بها (افصل بينها بفاصلة)</label>
              <div className="space-y-1.5">
                {db.branches.map((b) => {
                  const selected = userForm.branchIds.split(',').includes(b.id);
                  return (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => {
                        const ids = userForm.branchIds.split(',').filter(Boolean);
                        const next = ids.includes(b.id) ? ids.filter((id) => id !== b.id) : [...ids, b.id];
                        setUserForm((p) => ({ ...p, branchIds: next.join(',') }));
                      }}
                      className={`w-full flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition-all ${selected ? 'bg-brand-50 border-2 border-brand-300 text-brand-700' : 'bg-slate-50 border-2 border-transparent text-brand-500 hover:bg-brand-50'}`}
                    >
                      <Building2 size={14} />
                      {b.name}
                      {selected && <Badge tone="brand" className="text-[9px] mr-auto">محدد</Badge>}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          <div className="flex gap-3 pt-2">
            <Button variant="outline" className="flex-1" onClick={() => { setShowUserModal(false); setEditingUser(null); }}>
              <X size={18} /> إلغاء
            </Button>
            <Button className="flex-1" onClick={handleSaveUser}>
              <KeyRound size={18} /> {editingUser ? 'حفظ' : 'إنشاء'}
            </Button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteUserId}
        title="حذف الحساب"
        message="سيتم حذف هذا الحساب نهائياً. هل أنت متأكد؟"
        confirmText="حذف"
        danger
        onConfirm={handleDeleteUser}
        onCancel={() => setDeleteUserId(null)}
      />
    </div>
  );
}
