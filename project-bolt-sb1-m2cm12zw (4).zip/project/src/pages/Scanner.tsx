import { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { CalendarCheck, Wallet, CheckCircle2, X, AlertTriangle, FileText, Check, BookOpen, CreditCard, Search, ScanLine, Zap, Lock, Clock, Camera, CameraOff, SwitchCamera, Users, TrendingUp, Phone, Hash, BookOpen as BookIcon } from 'lucide-react';
import { useDB } from '../context/DBContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { getScopedData, canSecretaryAccessFeature, studentGroupIds } from '../lib/scoping';
import { todayStr, currentMonthStr, formatEGP, formatDate, uid, monthName } from '../lib/date';
import { logAction, discountedSessionFee } from '../lib/finance';
import { parseStudentCode } from '../lib/qr';
import { isMediaDevicesSupported } from '../lib/safe-storage';
import { playSuccessSound, playErrorSound } from '../lib/beep';
import { useCameraScanner } from '../hooks/useCameraScanner';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { StudentSearch } from '../components/StudentSearch';
import type { Student, Payment, PaymentType, StudyMaterial, Group, AttendanceRecord } from '../lib/types';

type Mode = 'attendance' | 'payment' | 'barcode';

export function Scanner() {
  const { db, update } = useDB();
  const { user } = useAuth();
  const { showToast } = useToast();
  const scoped = getScopedData(db, user);

  if (!canSecretaryAccessFeature(user, 'attendance')) {
    return (
      <div className="grid place-items-center py-20">
        <div className="text-center">
          <div className="grid place-items-center h-20 w-20 rounded-3xl bg-amber-50 text-amber-400 mx-auto mb-4">
            <Lock size={36} />
          </div>
          <h3 className="text-lg font-bold text-brand-900 mb-1">خاصية غير متاحة</h3>
          <p className="text-sm text-brand-400">⚠️ هذه الخاصية غير متاحة لنوع ربط السكرتير بهذا المدرس</p>
        </div>
      </div>
    );
  }

  const [mode, setMode] = useState<Mode>(db.qrEnabled ? 'attendance' : 'attendance');
  const qrEnabled = db.qrEnabled;
  const [paymentStudent, setPaymentStudent] = useState<Student | null>(null);
  const [noteAlertStudent, setNoteAlertStudent] = useState<Student | null>(null);
  const [materialsChecklist, setMaterialsChecklist] = useState<Set<string>>(new Set());
  const [lastStudent, setLastStudent] = useState<Student | null>(null);
  const [profileStudent, setProfileStudent] = useState<Student | null>(null);

  // Barcode fast-scan state
  const [barcodeInput, setBarcodeInput] = useState('');
  const [scanLog, setScanLog] = useState<{ name: string; code: string; status: 'present' | 'absent' | 'error'; time: string }[]>([]);
  const barcodeRef = useRef<HTMLInputElement>(null);

  // Quick-search camera state
  const [showCamera, setShowCamera] = useState(false);

  useEffect(() => {
    try {
      if (mode === 'barcode' && qrEnabled) barcodeRef.current?.focus();
    } catch { /* ignore */ }
  }, [mode, qrEnabled]);

  useEffect(() => {
    if (mode === 'barcode' && qrEnabled) {
      try {
        const t = setTimeout(function () { try { barcodeRef.current?.focus(); } catch (e) { /* ignore */ } }, 100);
        return function () { clearTimeout(t); };
      } catch { return; }
    }
  }, [mode, qrEnabled, scanLog.length]);

  const mediaSupported = isMediaDevicesSupported();

  const handleCameraScan = useCallback((code: string) => {
    const studentId = parseStudentCode(code);
    const student = studentId ? scoped.students.find((s) => s.id === studentId) : null;
    if (!student) {
      playErrorSound();
      showToast(`كود غير موجود: ${code}`, 'error');
      return;
    }
    playSuccessSound();
    setProfileStudent(student);
  }, [scoped.students, showToast]);

  const {
    videoRef, canvasRef, cameraActive, cameraError,
    cameras, selectedCameraId, setSelectedCameraId,
    startCamera, stopCamera,
  } = useCameraScanner({ onScan: handleCameraScan, active: showCamera });

  // Cleanup camera when component unmounts
  useEffect(() => {
    return () => { stopCamera(); };
  }, [stopCamera]);

  const handleSelect = (student: Student) => {
    const activeNotes = (db.contactNotes || []).filter((n) => n.studentId === student.id && n.active);
    if (activeNotes.length > 0) {
      setNoteAlertStudent(student);
    }

    if (mode === 'attendance') {
      const sGids = studentGroupIds(student);
      if (sGids.length === 0) {
        showToast('الطالب غير مسجل في أي مجموعة', 'error');
        return;
      }
      const targetGid = sGids[0];
      update((d) => {
        d.attendance = d.attendance.filter((a) => !(a.studentId === student.id && a.date === todayStr() && a.groupId === targetGid));
        d.attendance.push({ id: uid('att'), studentId: student.id, groupId: targetGid, date: todayStr(), status: 'present', createdAt: new Date().toISOString() });
        const grp = d.groups.find((g) => g.id === targetGid);
        logAction(d, 'تسجيل حضور', `قام ${user?.name || ''} بتسجيل حضور الطالب ${student.name} في مجموعة ${grp?.name || ''}.`, user?.name || '', user?.role || 'admin');
      });
      setMaterialsChecklist(new Set());
      setLastStudent(student);
      showToast(`تم تسجيل حضور: ${student.name}`, 'success');
    } else {
      setPaymentStudent(student);
    }
  };

  const groupMaterials = useMemo(() => {
    if (!lastStudent) return [];
    const sGids = studentGroupIds(lastStudent);
    if (sGids.length === 0) return [];
    return db.materials.filter((m) => sGids.includes(m.groupId));
  }, [db.materials, lastStudent]);

  const toggleMaterial = (id: string) => {
    setMaterialsChecklist((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleBarcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const code = barcodeInput.trim();
    if (!code) return;
    const studentId = parseStudentCode(code);
    const student = studentId ? scoped.students.find((s) => s.id === studentId) : scoped.students.find((s) => s.phone === code || s.qrCode === code);
    const time = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    if (!student) {
      setScanLog((prev) => [{ name: 'غير موجود', code, status: 'error' as const, time }, ...prev].slice(0, 20));
      showToast(`كود غير موجود: ${code}`, 'error');
      setBarcodeInput('');
      return;
    }
    const sGids = studentGroupIds(student);
    if (sGids.length === 0) {
      setScanLog((prev) => [{ name: student.name, code, status: 'error' as const, time }, ...prev].slice(0, 20));
      showToast(`الطالب ${student.name} غير مسجل في مجموعة`, 'error');
      setBarcodeInput('');
      return;
    }
    const targetGid = sGids[0];
    const existing = db.attendance.find((a) => a.studentId === student.id && a.date === todayStr() && a.groupId === targetGid);
    const newStatus = existing?.status === 'present' ? 'absent' : 'present';
    update((d) => {
      d.attendance = d.attendance.filter((a) => !(a.studentId === student.id && a.date === todayStr() && a.groupId === targetGid));
      if (newStatus === 'present') {
        d.attendance.push({ id: uid('att'), studentId: student.id, groupId: targetGid, date: todayStr(), status: 'present', createdAt: new Date().toISOString() });
      }
      const grp = d.groups.find((g) => g.id === targetGid);
      logAction(d, newStatus === 'present' ? 'تسجيل حضور' : 'إلغاء حضور', `قام ${user?.name || ''} بـ${newStatus === 'present' ? 'تسجيل' : 'إلغاء'} حضور الطالب ${student.name} في مجموعة ${grp?.name || ''}.`, user?.name || '', user?.role || 'admin');
    });
    setScanLog((prev) => [{ name: student.name, code, status: newStatus as 'present' | 'absent', time }, ...prev].slice(0, 20));
    setLastStudent(student);
    showToast(`${newStatus === 'present' ? 'حاضر' : 'غائب'}: ${student.name}`, newStatus === 'present' ? 'success' : 'error');
    setBarcodeInput('');
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-brand-900 flex items-center gap-2">
          <Search size={24} /> البحث السريع
        </h2>
        <p className="text-sm text-brand-400 mt-0.5">ابحث عن طالب بالاسم أو الكود لاتخاذ إجراء سريع</p>
      </div>

      {/* Flexible time indicator */}
      {db.allowFlexibleAttendanceTime && (
        <div className="rounded-2xl bg-emerald-50 border border-emerald-200 px-4 py-3 flex items-center gap-2 animate-fade-in">
          <Clock size={18} className="text-emerald-500 shrink-0" />
          <p className="text-sm font-bold text-emerald-700">
            وضع مرن — يمكن تسجيل الحضور والغياب في أي وقت بدون تقييد بمواعيد الحصص
          </p>
        </div>
      )}

      {/* Mode toggle */}
      <div className={`grid ${qrEnabled ? 'grid-cols-3' : 'grid-cols-2'} gap-3`}>
        <button
          onClick={() => setMode('attendance')}
          className={`rounded-2xl p-4 text-center transition-all duration-200 ${
            mode === 'attendance' ? 'gradient-brand text-white shadow-soft' : 'glass text-brand-600 hover:bg-brand-50'
          }`}
        >
          <CalendarCheck size={24} className="mx-auto mb-1" />
          <p className="font-bold text-sm">تسجيل الحضور</p>
          <p className={`text-xs ${mode === 'attendance' ? 'text-white/70' : 'text-brand-400'}`}>اختر الطالب</p>
        </button>
        <button
          onClick={() => setMode('payment')}
          className={`rounded-2xl p-4 text-center transition-all duration-200 ${
            mode === 'payment' ? 'gradient-brand text-white shadow-soft' : 'glass text-brand-600 hover:bg-brand-50'
          }`}
        >
          <Wallet size={24} className="mx-auto mb-1" />
          <p className="font-bold text-sm">تسجيل المدفوعات</p>
          <p className={`text-xs ${mode === 'payment' ? 'text-white/70' : 'text-brand-400'}`}>اختر الطالب</p>
        </button>
        {qrEnabled && (
          <button
            onClick={() => setMode('barcode')}
            className={`rounded-2xl p-4 text-center transition-all duration-200 ${
              mode === 'barcode' ? 'gradient-brand text-white shadow-soft' : 'glass text-brand-600 hover:bg-brand-50'
            }`}
          >
            <ScanLine size={24} className="mx-auto mb-1" />
            <p className="font-bold text-sm">ماسح الباركود</p>
            <p className={`text-xs ${mode === 'barcode' ? 'text-white/70' : 'text-brand-400'}`}>مسح سريع بالكود</p>
          </button>
        )}
      </div>

      {/* Live Camera Scanner for Quick Search */}
      {mediaSupported && (
        <Card className="p-4 sm:p-5 border-2 border-brand-200 overflow-hidden">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <div className="grid place-items-center h-10 w-10 rounded-2xl gradient-brand text-white shrink-0">
              <ScanLine size={20} />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-brand-900">ماسح الكاميرا — بحث فوري</h3>
              <p className="text-xs text-brand-400">امسح كود QR الخاص بالطالب لعرض ملفه الكامل فوراً</p>
            </div>
            {cameraActive ? (
              <Badge tone="emerald" className="text-[10px]">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse mr-1" />
                كاميرا نشطة
              </Badge>
            ) : cameraError ? (
              <Badge tone="rose" className="text-[10px]">خطأ في الكاميرا</Badge>
            ) : (
              <Badge tone="brand" className="text-[10px]">جاهز</Badge>
            )}
          </div>

          {/* Camera toggle buttons */}
          <div className="flex flex-col sm:flex-row gap-2 mb-3">
            <button
              onClick={() => { showCamera ? setShowCamera(false) : setShowCamera(true); }}
              className={`flex items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-sm font-bold transition-all sm:flex-1 ${
                showCamera ? 'bg-brand-500 text-white shadow-soft' : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
              }`}
            >
              {showCamera ? <CameraOff size={16} /> : <Camera size={16} />}
              {showCamera ? 'إيقاف الكاميرا' : 'تفعيل الكاميرا'}
            </button>
            {cameras.length > 1 && showCamera && (
              <button
                onClick={() => {
                  const idx = cameras.findIndex((c) => c.deviceId === selectedCameraId);
                  const next = cameras[(idx + 1) % cameras.length];
                  stopCamera();
                  setSelectedCameraId(next.deviceId);
                  setTimeout(() => startCamera(), 200);
                }}
                className="flex items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-sm font-bold bg-brand-50 text-brand-600 hover:bg-brand-100 transition-all sm:flex-1"
              >
                <SwitchCamera size={16} /> تبديل الكاميرا
              </button>
            )}
          </div>

          {/* Live Camera View */}
          {showCamera && (
            <div className="relative rounded-2xl overflow-hidden bg-slate-900 mb-3 animate-fade-in">
              <video
                ref={videoRef}
                playsInline
                muted
                autoPlay
                className="w-full max-h-[300px] aspect-square sm:aspect-auto sm:h-72 min-h-[200px] object-cover"
              />
              <canvas ref={canvasRef} className="hidden" />
              {/* Scanning frame overlay */}
              <div className="absolute inset-0 grid place-items-center pointer-events-none">
                <div className="relative w-56 h-56 sm:w-60 sm:h-60">
                  <div className="absolute top-0 left-0 h-8 w-8 border-t-4 border-l-4 border-emerald-400 rounded-tl-xl" />
                  <div className="absolute top-0 right-0 h-8 w-8 border-t-4 border-r-4 border-emerald-400 rounded-tr-xl" />
                  <div className="absolute bottom-0 left-0 h-8 w-8 border-b-4 border-l-4 border-emerald-400 rounded-bl-xl" />
                  <div className="absolute bottom-0 right-0 h-8 w-8 border-b-4 border-r-4 border-emerald-400 rounded-br-xl" />
                  <div className="absolute inset-0 border-2 border-emerald-400/30 rounded-2xl" />
                </div>
              </div>
              {/* Scanning line animation */}
              {cameraActive && (
                <div className="absolute inset-0 grid place-items-center pointer-events-none">
                  <div className="w-56 h-56 sm:w-60 sm:h-60 relative overflow-hidden rounded-2xl">
                    <div className="absolute left-0 right-0 h-1 bg-emerald-400/80 shadow-lg animate-scan-line" />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Camera error */}
          {showCamera && cameraError && (
            <div className="rounded-2xl bg-rose-50 border border-rose-200 px-4 py-3 mb-3 text-sm font-semibold text-rose-700 flex items-start gap-2 animate-fade-in">
              <AlertTriangle size={16} className="shrink-0 mt-0.5" />
              <div className="flex-1">
                <p>{cameraError}</p>
                <p className="text-xs text-rose-500 mt-1">إذا استمرت المشكلة، تحقق من إعدادات المتصفح: الإعدادات ← الخصوصية والأمان ← الكاميرا ← السماح لهذا الموقع</p>
              </div>
              <button onClick={() => startCamera()} className="shrink-0 text-xs text-rose-600 underline font-bold">إعادة المحاولة</button>
            </div>
          )}

          {!showCamera && (
            <p className="text-xs text-brand-400">اضغط "تفعيل الكاميرا" لتشغيل الماسح. عند مسح كود طالب سيتم عرض ملفه الكامل تلقائياً.</p>
          )}
        </Card>
      )}

      {/* Barcode fast-scan mode */}
      {mode === 'barcode' && qrEnabled && (
        <Card className="p-5 sm:p-6">
          <div className="flex items-center gap-2 mb-4">
            <Zap size={20} className="text-brand-500" />
            <h3 className="font-bold text-brand-900">المسح السريع بالباركود</h3>
          </div>
          <p className="text-xs text-brand-400 mb-4">امسح باركود الطالب أو اكتب كود الطالب / رقم الهاتف ثم اضغط Enter. كل مسح يبدّل حالة الحضور (حاضر ⇄ غائب).</p>
          {!mediaSupported && (
            <div className="rounded-2xl bg-amber-50 border border-amber-200 px-3 py-2 mb-3 text-xs font-semibold text-amber-700">
              تنبيه: كاميرا الجهاز غير مدعومة — يمكنك إدخال الكود يدوياً بالكيبورد
            </div>
          )}
          <form onSubmit={handleBarcodeSubmit} className="space-y-3">
            <div className="relative">
              <ScanLine size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-400" />
              <input
                ref={barcodeRef}
                type="text"
                value={barcodeInput}
                onChange={(e) => setBarcodeInput(e.target.value)}
                placeholder="امسح أو اكتب كود الطالب..."
                className="w-full h-14 rounded-2xl border-2 border-brand-200 bg-white pr-12 pl-4 text-lg font-bold text-brand-900 focus:outline-none focus:border-brand-500 transition-colors"
                autoComplete="off"
              />
            </div>
            <Button type="submit" className="w-full" disabled={!barcodeInput.trim()}><Zap size={18} /> تسجيل</Button>
          </form>

          {scanLog.length > 0 && (
            <div className="mt-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-brand-500">آخر العمليات</span>
                <button onClick={() => setScanLog([])} className="text-xs text-brand-400 hover:text-brand-600">مسح السجل</button>
              </div>
              <div className="space-y-1.5 max-h-64 overflow-y-auto">
                {scanLog.map((entry, i) => (
                  <div key={i} className={`flex items-center justify-between rounded-xl px-3 py-2 text-sm ${
                    entry.status === 'present' ? 'bg-emerald-50 border border-emerald-100' :
                    entry.status === 'absent' ? 'bg-rose-50 border border-rose-100' :
                    'bg-amber-50 border border-amber-100'
                  }`}>
                    <div className="flex items-center gap-2">
                      {entry.status === 'present' ? <CheckCircle2 size={16} className="text-emerald-500" /> :
                       entry.status === 'absent' ? <X size={16} className="text-rose-500" /> :
                       <AlertTriangle size={16} className="text-amber-500" />}
                      <span className="font-semibold text-brand-900">{entry.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-brand-400">#{entry.code}</span>
                      <span className="text-xs font-bold text-brand-300">{entry.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>
      )}

      {/* Search (attendance + payment modes only) */}
      {mode !== 'barcode' && (
        <Card className="p-5 sm:p-6">
          <div className="flex items-center gap-2 mb-4">
            <Search size={20} className="text-brand-500" />
            <h3 className="font-bold text-brand-900">القائمة المنسدلة الذكية</h3>
          </div>
          <StudentSearch
            students={scoped.students}
            groups={scoped.groups}
            onSelect={handleSelect}
            autoFocus
          />
          <p className="text-xs text-brand-400 mt-3">
            {mode === 'attendance' ? 'اختيار الطالب يسجله حاضراً في مجموعته لليوم' : 'اختيار الطالب يفتح نافذة الدفع مع تعبئة المبلغ تلقائياً'}
          </p>
        </Card>
      )}

      {/* Last action confirmation */}
      {lastStudent && mode === 'attendance' && (
        <Card className="p-4 animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="grid place-items-center h-12 w-12 rounded-2xl bg-emerald-500 text-white shadow-soft">
              <CheckCircle2 size={24} />
            </div>
            <div>
              <p className="font-bold text-brand-900">آخر طالب: {lastStudent.name}</p>
              <p className="text-xs text-brand-400">#{lastStudent.id} — تم تسجيل الحضور</p>
            </div>
          </div>
        </Card>
      )}

      {/* Group-filtered materials checklist */}
      {mode === 'attendance' && lastStudent && groupMaterials.length > 0 && (
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-3">
            <FileText size={20} className="text-brand-500" />
            <h3 className="font-bold text-brand-900">مذكرات مجموعات {studentGroupIds(lastStudent).map((id) => db.groups.find((g) => g.id === id)?.name).filter(Boolean).join('، ')}</h3>
          </div>
          <p className="text-xs text-brand-400 mb-3">حدد المذكرات التي استلمها الطالب</p>
          <div className="space-y-2">
            {groupMaterials.map((m) => (
              <button
                key={m.id}
                onClick={() => toggleMaterial(m.id)}
                className={`w-full flex items-center justify-between rounded-2xl px-4 py-3 transition-all ${
                  materialsChecklist.has(m.id) ? 'bg-emerald-50 border-2 border-emerald-300' : 'bg-brand-50/50 border-2 border-transparent hover:bg-brand-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`grid place-items-center h-8 w-8 rounded-xl transition-all ${materialsChecklist.has(m.id) ? 'bg-emerald-500 text-white' : 'bg-white text-brand-400'}`}>
                    {materialsChecklist.has(m.id) ? <Check size={16} /> : <FileText size={16} />}
                  </div>
                  <span className="text-sm font-semibold text-brand-900">{m.title}</span>
                </div>
                {materialsChecklist.has(m.id) && <Badge tone="emerald" className="text-xs">تم الاستلام</Badge>}
              </button>
            ))}
          </div>
        </Card>
      )}

      {/* Parent note alert popup */}
      {noteAlertStudent && (() => {
        const notes = (db.contactNotes || []).filter((n) => n.studentId === noteAlertStudent.id && n.active);
        return (
        <div className="fixed inset-0 z-50 grid place-items-center p-4">
          <div className="absolute inset-0 bg-amber-900/30 backdrop-blur-sm animate-fade-in" onClick={() => setNoteAlertStudent(null)} />
          <div className="relative glass rounded-3xl shadow-glass p-6 max-w-sm w-full animate-scale-in border-2 border-amber-300">
            <div className="grid place-items-center h-16 w-16 rounded-3xl bg-amber-400 text-white shadow-glow mx-auto mb-4">
              <AlertTriangle size={32} />
            </div>
            <h3 className="text-lg font-extrabold text-brand-900 text-center mb-1">تنبيه: ملاحظة ولي الأمر</h3>
            <p className="text-sm text-brand-600 text-center mb-1">الطالب: <span className="font-bold">{noteAlertStudent.name}</span> (#{noteAlertStudent.id})</p>
            <div className="space-y-2 mt-3">
              {notes.map((n) => (
                <div key={n.id} className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-3">
                  <p className="text-sm font-semibold text-amber-700">{n.text}</p>
                  <p className="text-[10px] text-amber-500 mt-1">{n.date}</p>
                </div>
              ))}
            </div>
            <Button className="w-full mt-4" onClick={() => setNoteAlertStudent(null)}>
              <CheckCircle2 size={18} /> استلام
            </Button>
          </div>
        </div>
        );
      })()}

      {/* Student Profile Modal from camera scan */}
      {profileStudent && (
        <StudentProfileModal
          student={profileStudent}
          db={db}
          groups={scoped.groups}
          onClose={() => setProfileStudent(null)}
        />
      )}

      {/* Payment modal */}
      {paymentStudent && (
        <PaymentModal
          student={paymentStudent}
          gradePrice={db.gradePrices.find((gp) => gp.grade === paymentStudent.grade)}
          groupMaterials={paymentStudent ? db.materials.filter((m) => studentGroupIds(paymentStudent).includes(m.groupId)) : []}
          idCardPrice={db.idCardPrice}
          onClose={() => setPaymentStudent(null)}
          onSave={(data, materialId) => {
            update((d) => {
              d.payments.push({ ...data, id: uid('pay'), createdAt: new Date().toISOString() });
              if (materialId) {
                const mat = d.materials.find((m) => m.id === materialId);
                if (mat) mat.stock = Math.max(0, mat.stock - 1);
              }
              const sname = paymentStudent.name;
              let typeLabel: string;
              if (data.paymentType === 'session') {
                typeLabel = `تم تحصيل مبلغ ${formatEGP(data.amount)} ج.م (دفع شهري) من الطالب ${sname} بواسطة ${user?.name || ''}`;
              } else if (data.paymentType === 'book') {
                typeLabel = `تم بيع ${data.bookTitle || 'مذكرة'} بمبلغ ${formatEGP(data.amount)} ج.م للطالب ${sname} بواسطة ${user?.name || ''}`;
              } else {
                typeLabel = `تم تحصيل رسوم كارت الـ ID بقيمة ${formatEGP(data.amount)} ج.م للطالب ${sname} بواسطة ${user?.name || ''}`;
              }
              logAction(d, 'تسجيل دفعة', typeLabel, user?.name || '', user?.role || 'admin');
            });
            showToast(`تم تسجيل دفعة ${formatEGP(data.amount)} للطالب ${paymentStudent.name}`);
            setPaymentStudent(null);
          }}
        />
      )}
    </div>
  );
}

function StudentProfileModal({ student, db, groups, onClose }: {
  student: Student;
  db: import('../lib/types').Database;
  groups: Group[];
  onClose: () => void;
}) {
  const sGids = studentGroupIds(student);
  const studentGroups = sGids.map((id) => groups.find((g) => g.id === id)).filter(Boolean) as Group[];

  const studentAttendance = useMemo(() => {
    return db.attendance.filter((a) => a.studentId === student.id);
  }, [db.attendance, student.id]);

  const attendancePercentage = useMemo(() => {
    if (studentAttendance.length === 0) return 0;
    const present = studentAttendance.filter((a) => a.status === 'present').length;
    return Math.round((present / studentAttendance.length) * 100);
  }, [studentAttendance]);

  const unpaidFees = useMemo(() => {
    const month = currentMonthStr();
    const gradePrice = db.gradePrices.find((gp) => gp.grade === student.grade);
    const expected = gradePrice ? discountedSessionFee(gradePrice.price, student) : 0;
    const paid = db.payments
      .filter((p) => p.studentId === student.id && p.paymentType === 'session' && p.month === month)
      .reduce((sum, p) => sum + p.amount, 0);
    return Math.max(0, expected - paid);
  }, [db.gradePrices, db.payments, student]);

  const recentSessions = useMemo(() => {
    return [...studentAttendance]
      .sort((a, b) => b.date.localeCompare(a.date))
      .slice(0, 5);
  }, [studentAttendance]);

  const totalPaid = useMemo(() => {
    return db.payments
      .filter((p) => p.studentId === student.id)
      .reduce((sum, p) => sum + p.amount, 0);
  }, [db.payments, student.id]);

  return (
    <Modal open onClose={onClose} title="ملف الطالب" size="md">
      {/* Student header */}
      <div className="flex items-center gap-3 rounded-2xl bg-brand-50 p-4 mb-4">
        <div className="grid place-items-center h-14 w-14 rounded-2xl gradient-brand text-white font-bold text-lg shrink-0">
          {student.name.charAt(0)}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-extrabold text-brand-900 text-lg truncate">{student.name}</h3>
          <div className="flex items-center gap-2 flex-wrap mt-1">
            <Badge tone="brand" className="text-[10px]"><Hash size={9} /> {student.id}</Badge>
            <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-brand-400">
              <BookIcon size={9} /> {student.grade}
            </span>
            {student.phone && (
              <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-brand-400">
                <Phone size={9} /> {student.phone}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="rounded-2xl bg-brand-50 p-3 text-center">
          <Users size={18} className="text-brand-500 mx-auto mb-1" />
          <p className="text-lg font-extrabold text-brand-900">{studentGroups.length}</p>
          <p className="text-[10px] text-brand-400 font-semibold">المجموعات</p>
        </div>
        <div className="rounded-2xl bg-emerald-50 p-3 text-center">
          <TrendingUp size={18} className="text-emerald-500 mx-auto mb-1" />
          <p className="text-lg font-extrabold text-emerald-600">{attendancePercentage}%</p>
          <p className="text-[10px] text-emerald-500 font-semibold">نسبة الحضور</p>
        </div>
        <div className={`rounded-2xl p-3 text-center ${unpaidFees > 0 ? 'bg-rose-50' : 'bg-emerald-50'}`}>
          <Wallet size={18} className={`mx-auto mb-1 ${unpaidFees > 0 ? 'text-rose-500' : 'text-emerald-500'}`} />
          <p className={`text-lg font-extrabold ${unpaidFees > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>{formatEGP(unpaidFees)}</p>
          <p className={`text-[10px] font-semibold ${unpaidFees > 0 ? 'text-rose-500' : 'text-emerald-500'}`}>متأخرات الشهر</p>
        </div>
      </div>

      {/* Enrolled groups */}
      <div className="mb-4">
        <p className="text-sm font-bold text-brand-700 mb-2">المجموعات المسجل بها</p>
        <div className="flex flex-wrap gap-2">
          {studentGroups.length === 0 ? (
            <span className="text-xs text-brand-400 font-semibold">غير مسجل في أي مجموعة</span>
          ) : studentGroups.map((g) => (
            <Badge key={g.id} tone="brand" className="text-xs">
              <Users size={10} /> {g.name}
            </Badge>
          ))}
        </div>
      </div>

      {/* Recent sessions */}
      <div className="mb-4">
        <p className="text-sm font-bold text-brand-700 mb-2">آخر الحصص</p>
        {recentSessions.length === 0 ? (
          <p className="text-xs text-brand-400 font-semibold">لا توجد سجلات حضور</p>
        ) : (
          <div className="space-y-1.5 max-h-40 overflow-y-auto">
            {recentSessions.map((a) => {
              const grp = db.groups.find((g) => g.id === a.groupId);
              return (
                <div key={a.id} className={`flex items-center justify-between rounded-xl px-3 py-2 text-sm ${
                  a.status === 'present' ? 'bg-emerald-50 border border-emerald-100' : 'bg-rose-50 border border-rose-100'
                }`}>
                  <div className="flex items-center gap-2">
                    {a.status === 'present' ? <CheckCircle2 size={14} className="text-emerald-500" /> : <X size={14} className="text-rose-500" />}
                    <span className="font-semibold text-brand-900 text-xs">{grp?.name || '—'}</span>
                  </div>
                  <span className="text-xs text-brand-400">{formatDate(a.date)}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Total paid */}
      <div className="rounded-2xl bg-brand-50 px-4 py-3 flex items-center justify-between mb-4">
        <span className="text-sm font-semibold text-brand-600">إجمالي المدفوع</span>
        <Badge tone="emerald">{formatEGP(totalPaid)}</Badge>
      </div>

      <Button className="w-full" onClick={onClose}>
        <CheckCircle2 size={18} /> إغلاق
      </Button>
    </Modal>
  );
}

function PaymentModal({ student, gradePrice, groupMaterials, idCardPrice, onClose, onSave }: {
  student: Student;
  gradePrice?: { grade: string; price: number };
  groupMaterials: StudyMaterial[];
  idCardPrice: number;
  onClose: () => void;
  onSave: (data: Omit<Payment, 'id' | 'createdAt'>, materialId?: string) => void;
}) {
  const [paymentType, setPaymentType] = useState<PaymentType>('session');
  const [amount, setAmount] = useState(String(gradePrice?.price || ''));
  const [month, setMonth] = useState(currentMonthStr());
  const [date, setDate] = useState(todayStr());
  const [method, setMethod] = useState<Payment['method']>('cash');
  const [note, setNote] = useState('');
  const [selectedBookId, setSelectedBookId] = useState('');

  const handleTypeChange = (type: PaymentType) => {
    setPaymentType(type);
    setSelectedBookId('');
    if (type === 'session') {
      setAmount(String(gradePrice?.price || ''));
    } else if (type === 'id') {
      setAmount(String(idCardPrice));
    } else {
      setAmount('');
    }
  };

  const handleBookSelect = (bookId: string) => {
    setSelectedBookId(bookId);
    const book = groupMaterials.find((m) => m.id === bookId);
    if (book) setAmount(String(book.price));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount) return;
    const book = selectedBookId ? groupMaterials.find((m) => m.id === selectedBookId) : undefined;
    onSave({
      studentId: student.id,
      groupId: student.groupId,
      branchId: student.branchId ?? null,
      amount: Number(amount),
      date,
      month,
      method,
      paymentType,
      bookTitle: paymentType === 'book' ? book?.title : undefined,
      note: note.trim(),
    }, paymentType === 'book' ? selectedBookId : undefined);
  };

  const typeOptions: { value: PaymentType; label: string; icon: typeof CalendarCheck }[] = [
    { value: 'session', label: 'رسوم شهرية', icon: CalendarCheck },
    { value: 'book', label: 'كتب / مذكرات', icon: BookOpen },
    { value: 'id', label: 'كارت ID', icon: CreditCard },
  ];

  return (
    <Modal open onClose={onClose} title="تسجيل دفعة" size="md">
      <div className="flex items-center gap-3 rounded-2xl bg-brand-50 p-3 mb-4">
        <div className="grid place-items-center h-12 w-12 rounded-2xl gradient-brand text-white font-bold">{student.name.charAt(0)}</div>
        <div>
          <p className="font-bold text-brand-900">{student.name}</p>
          <div className="flex items-center gap-2">
            <Badge tone="brand">#{student.id}</Badge>
            <span className="text-xs text-brand-400">{student.grade}</span>
          </div>
        </div>
      </div>

      <div className="mb-4">
        <span className="block mb-2 text-sm font-semibold text-brand-900">نوع الدفع</span>
        <div className="grid grid-cols-3 gap-2">
          {typeOptions.map((opt) => {
            const active = paymentType === opt.value;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => handleTypeChange(opt.value)}
                className={`flex flex-col items-center gap-1.5 rounded-2xl p-3 transition-all duration-200 border-2 ${
                  active
                    ? 'gradient-brand text-white shadow-soft border-transparent'
                    : 'bg-brand-50/50 text-brand-600 border-transparent hover:bg-brand-50'
                }`}
              >
                <opt.icon size={20} />
                <span className="text-xs font-bold">{opt.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {paymentType === 'book' && (
          <div className="animate-fade-in">
            {groupMaterials.length === 0 ? (
              <div className="rounded-2xl bg-amber-50 border border-amber-200 px-4 py-3 text-sm font-semibold text-amber-700">
                لا توجد كتب/مذكرات مخصصة لمجموعة هذا الطالب
              </div>
            ) : (
              <Select label="اختر الكتاب / المذكرة" value={selectedBookId} onChange={(e) => handleBookSelect(e.target.value)} required>
                <option value="">اختر كتاب...</option>
                {groupMaterials.map((m) => (
                  <option key={m.id} value={m.id} disabled={m.stock <= 0}>
                    {m.title} — {m.price} ج.م ({m.stock > 0 ? `${m.stock} متوفر` : 'نفد'})
                  </option>
                ))}
              </Select>
            )}
          </div>
        )}

        <Input label="المبلغ (ج.م)" type="number" value={amount} onChange={(e) => setAmount(e.target.value)} required />
        <div className="grid grid-cols-2 gap-3">
          <Input label="الشهر" type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
          <Input label="التاريخ" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        <Select label="طريقة الدفع" value={method} onChange={(e) => setMethod(e.target.value as Payment['method'])}>
          <option value="cash">نقدي</option>
          <option value="card">بطاقة</option>
          <option value="transfer">تحويل</option>
        </Select>
        <Input label="ملاحظات" placeholder="خصم / تسوية..." value={note} onChange={(e) => setNote(e.target.value)} />
        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}><X size={18} /> إلغاء</Button>
          <Button type="submit" className="flex-1"><Wallet size={18} /> تأكيد الدفع</Button>
        </div>
      </form>
    </Modal>
  );
}
