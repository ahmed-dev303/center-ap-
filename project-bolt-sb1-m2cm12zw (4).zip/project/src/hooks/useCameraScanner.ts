import { useRef, useState, useEffect, useCallback } from 'react';
import jsQR from 'jsqr';
import { isMediaDevicesSupported } from '../lib/safe-storage';

interface CameraScannerOptions {
  onScan: (code: string) => void;
  active: boolean;
}

export function useCameraScanner({ onScan, active }: CameraScannerOptions) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const onScanRef = useRef(onScan);
  const lastCodeRef = useRef<string>('');
  const lastTimeRef = useRef<number>(0);

  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');

  useEffect(() => { onScanRef.current = onScan; }, [onScan]);

  const stopCamera = useCallback(() => {
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  }, []);

  const tick = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState !== video.HAVE_ENOUGH_DATA) {
      rafRef.current = requestAnimationFrame(tick);
      return;
    }
    const w = video.videoWidth || 320;
    const h = video.videoHeight || 240;
    if (canvas.width !== w) canvas.width = w;
    if (canvas.height !== h) canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) { rafRef.current = requestAnimationFrame(tick); return; }
    ctx.drawImage(video, 0, 0, w, h);
    const imageData = ctx.getImageData(0, 0, w, h);
    const code = jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: 'dontInvert' });
    if (code && code.data) {
      const now = Date.now();
      if (code.data !== lastCodeRef.current || now - lastTimeRef.current > 3000) {
        lastCodeRef.current = code.data;
        lastTimeRef.current = now;
        onScanRef.current(code.data);
      }
    }
    rafRef.current = requestAnimationFrame(tick);
  }, []);

  const startCamera = useCallback(async () => {
    setCameraError(null);
    if (!isMediaDevicesSupported()) {
      setCameraError('كاميرا الجهاز غير مدعومة في هذا المتصفح. الرجاء استخدام متصفح حديث مثل Chrome أو Safari.');
      return;
    }
    try {
      const constraints: MediaStreamConstraints = {
        audio: false,
        video: selectedCameraId
          ? { deviceId: { exact: selectedCameraId } }
          : { facingMode: 'environment' },
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setCameraActive(true);
      rafRef.current = requestAnimationFrame(tick);
      const tracks = stream.getVideoTracks();
      if (tracks.length > 0 && tracks[0].getCapabilities) {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoDevs = devices.filter((d) => d.kind === 'videoinput');
        setCameras(videoDevs);
        if (!selectedCameraId && videoDevs.length > 1) {
          const usedId = tracks[0].getSettings().deviceId;
          if (usedId) setSelectedCameraId(usedId);
        }
      }
    } catch (err) {
      let msg = 'فشل تشغيل الكاميرا';
      if (err instanceof DOMException) {
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          msg = 'تم رفض إذن الكاميرا. الرجاء السماح بالوصول للكاميرا من إعدادات المتصفح ثم إعادة المحاولة.';
        } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
          msg = 'لم يتم العثور على كاميرا متصلة بهذا الجهاز.';
        } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
          msg = 'الكاميرا قيد الاستخدام بواسطة تطبيق آخر. الرجاء إغلاق التطبيق الآخر ثم إعادة المحاولة.';
        } else if (err.name === 'OverconstrainedError') {
          msg = 'لا توجد كاميرا خلفية متاحة. الرجاء تجربة كاميرا أخرى.';
        } else {
          msg = `خطأ في الكاميرا: ${err.message}`;
        }
      } else if (err instanceof Error) {
        msg = err.message;
      }
      setCameraError(msg);
      setCameraActive(false);
    }
  }, [selectedCameraId, tick]);

  useEffect(() => {
    if (active) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => { stopCamera(); };
  }, [active, startCamera, stopCamera]);

  return {
    videoRef,
    canvasRef,
    cameraActive,
    cameraError,
    cameras,
    selectedCameraId,
    setSelectedCameraId,
    startCamera,
    stopCamera,
  };
}
