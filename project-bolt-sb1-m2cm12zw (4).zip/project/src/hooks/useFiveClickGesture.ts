import { useRef, useCallback } from 'react';

export function useFiveClickGesture(onTrigger: () => void) {
  const clicks = useRef(0);
  const firstClickTime = useRef(0);

  return useCallback(() => {
    const now = Date.now();
    if (now - firstClickTime.current > 3000) {
      clicks.current = 0;
      firstClickTime.current = now;
    }
    clicks.current += 1;
    if (clicks.current >= 5) {
      clicks.current = 0;
      firstClickTime.current = 0;
      onTrigger();
    }
  }, [onTrigger]);
}
